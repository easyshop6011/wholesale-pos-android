# Wholesale POS

An **offline-first Point of Sale** for a wholesale business. One code base runs

* in any modern **web browser** (installable PWA), and
* as an **Android app** (Capacitor APK) with direct Bluetooth / USB thermal printing.

It prints professional **80 mm receipts**, keeps every invoice in a **local database**, and
**syncs to Google Sheets** automatically when the internet returns — never uploading the same
invoice twice.

![New sale screen](docs/screenshots/03-pos.png)

| | |
|---|---|
| Invoice screen (phone) | 80 mm receipt |
| ![phone](docs/screenshots/phone-pos.png) | ![receipt](docs/screenshots/receipt-80mm.png) |

> **🚧 SaaS রূপান্তর চলছে / SaaS migration in progress.** This code base is being turned into a multi-tenant cloud platform
> (Supabase: Auth, PostgreSQL + Row Level Security). Done so far: the audit, the cloud database (migrations, RLS, approval
> workflow — written, **not yet run against a real PostgreSQL**) and the first part of the cloud sign-in (Bengali sign-in,
> registration, business application, Super Admin review, per-business local database — tested against a **fake** server).
> See [docs/SAAS-PROGRESS.md](docs/SAAS-PROGRESS.md). **The cloud is OFF by default:** with an empty `js/cloud/config.js` this
> is still the classic offline-only POS, unchanged.

## Feature checklist

| # | Requirement | Where it lives |
|---|---|---|
| 1 | Invoices: auto number, auto date/time, logo + company info, customer, many products picked from a list, **manual qty and unit price**, line total, grand total, discount, paid, due, print | `js/services/sales.js`, `js/ui/views/pos.js`, `js/printing/receipt*.js` |
| 2 | Printing: Bluetooth, USB, 80 mm, direct from Android, offline | `js/printing/printer.js`, `android-plugin/` — see [docs/PRINTING.md](docs/PRINTING.md) |
| 3 | Products: add / edit / delete, category, search | `js/services/catalog.js`, `views/products.js` |
| 4 | Customers: add, search, purchase history, due history | `js/services/customers.js`, `views/customers.js` |
| 5 | Inventory: auto stock reduction, low-stock warning, adjustments, movement log | `js/services/inventory.js`, `views/inventory.js` |
| 6 | Reports & graphs: overview with previous-period comparison, sales trend, products, customers + due ageing, profit, staff, busy hours, inventory + re-order suggestions, daily sheet (+ CSV, print) | `js/services/reports.js`, `views/reports.js`, `js/ui/charts.js` — see [docs/REPORTS.md](docs/REPORTS.md) |
| 7 | Offline first: everything local, service worker caches the app | `sw.js`, `js/core/db.js` |
| 8 | Auto sync, no duplicates, unique invoice IDs | `js/services/sync.js` — see [docs/SYNC.md](docs/SYNC.md) |
| 9 | Google Sheets columns: Invoice Number, Date, Time, Customer, Product, Quantity, Unit Price, Total, Paid, Due | `integrations/google-apps-script/Code.gs` |
| 10 | Local database | IndexedDB (`js/core/db.js`); SQL equivalent in [db/schema.sql](db/schema.sql) |
| 11 | Settings: business name, logo, address, phone, footer | `views/settings.js` |
| 12 | Security: Administrator / Manager / Cashier roles with custom permissions, PIN lock, fast user switching, activity log | `js/services/auth.js`, `audit.js` — see [docs/USERS.md](docs/USERS.md) |
| 13 | Backup: **automatic** snapshots + Drive + device copy, restore points, export, import | `js/services/autobackup.js`, `backup.js` — see [docs/BACKUP.md](docs/BACKUP.md) |
| 14 | Dashboard: today, month, total due, customers, products | `views/dashboard.js` |
| 15 | Modern, responsive, clean, commented, scalable | [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) |
| 16 | Fast, pretty UI: light / dark / auto theme, compact density, skeleton loaders, paging, view warm-up | `css/ui.css`, `js/ui/appearance.js` — see [docs/UI.md](docs/UI.md) |
| 17 | Advanced search & filters: global search (Ctrl/⌘ + K), ranked multi-word search, Bengali-digit aware, filter bars with chips | `js/core/search.js`, `js/services/globalsearch.js`, `js/ui/palette.js` — see [docs/SEARCH.md](docs/SEARCH.md) |
| 18 | Stronger offline → cloud: back-off with jitter, adaptive batches, per-record errors, verify uploads, catalog sync, sync health screen | `js/services/sync.js`, `views/settings-sync.js` — see [docs/SYNC.md](docs/SYNC.md) |

## Quick start (web)

Requires Node 18+ only to serve the files; the app itself has **no runtime dependencies**.

```bash
npm start            # http://localhost:5173
```

On first run you create the admin account (business name, password, optional quick-unlock PIN)
and may load sample products/customers. Open the same URL on a phone and use
*Add to Home screen* to install it; after the first load it works with no network.

> Service workers, Web Bluetooth and WebUSB need **HTTPS** or `http://localhost`.
> To use other devices on your shop network, host the folder on any HTTPS static host
> (GitHub Pages, Netlify, Cloudflare Pages…) — it is just static files.

## Android app (direct printing)

```bash
npm install
npm run android:setup     # builds www/, creates android/, installs the printer plugin + permissions
npm run android:apk       # debug APK -> android/app/build/outputs/apk/debug/
```

Full guide (JDK, Android SDK, signing a release build): [docs/ANDROID.md](docs/ANDROID.md).

## Google Sheets + Drive

1. Create a Google Sheet → *Extensions → Apps Script* → paste `integrations/google-apps-script/Code.gs`.
2. Add Script Property `POS_TOKEN` (a long random secret) and deploy as a **Web app** (Anyone).
3. In the POS: *Settings → Sync* → paste the URL and the same secret → *Test connection*.

Details and troubleshooting: [docs/SYNC.md](docs/SYNC.md).

## Tests

```bash
npm test               # 178 unit tests (107 classic app + 23 static SQL checks + 48 cloud client/gate/watch) — the date tests also run under two other device time zones
npm run test:e2e:cloud  # the whole SaaS start-up flow in Chromium against a FAKE Supabase server (16 steps)
npm run check:sql      # static safety rules for supabase/migrations (RLS, tenant isolation, grants …) — does not run the SQL
npm run test:browser   # 104 integration tests in headless Chromium (real IndexedDB, the real Code.gs behind the sync, migration from a real v2 database)
npm run test:e2e       # 25-step end-to-end run through the real UI (offline, phone layout, customer profile, stock history, returns, encrypted backup) + a 7-step run with the browser in the WRONG time zone (Bengali names, Dhaka time, restart)
npm run test:all
```

The browser and e2e suites need Playwright (`npm i -D playwright && npx playwright install chromium`).

## Documentation

* [Architecture & how to extend](docs/ARCHITECTURE.md)
* [Database design](docs/DATABASE.md) and [db/schema.sql](db/schema.sql)
* [Printing](docs/PRINTING.md)
* [Offline sync & Google Sheets](docs/SYNC.md)
* [Android build](docs/ANDROID.md)
* [UI design](docs/UI.md)
* [Reports & graphs](docs/REPORTS.md)
* [Search & filters](docs/SEARCH.md)
* [Automatic backup](docs/BACKUP.md)
* [Users, roles & activity log](docs/USERS.md)
* [User guide](docs/USER_GUIDE.md)
* [Security notes](docs/SECURITY.md)
* SaaS migration: [audit report](docs/AUDIT-REPORT.md) · [progress](docs/SAAS-PROGRESS.md) · [cloud setup (Supabase)](docs/CLOUD-SETUP.md) · [cloud database & RLS](docs/CLOUD-DATABASE.md) · [cloud client](docs/CLOUD-CLIENT.md)

## Project layout

```
index.html, manifest.webmanifest, sw.js   PWA shell + offline cache (sw.js is generated)
css/app.css, ui.css, charts.css, sync.css design tokens, components, polish, charts, sync panel
js/core/        db, utils, format, bus, sha256
js/services/    business logic (no DOM): sales, catalog, customers, inventory,
                reports, globalsearch, sync, backup, autobackup, auth, audit, settings
js/printing/    receipt model, ESC/POS encoder, canvas renderer, printer transports
js/ui/          shell, routes, components, views/ (one file per screen)
android-plugin/ native Bluetooth + USB printer plugin (copied into the Capacitor project)
integrations/   Google Apps Script receiver (Sheets + Drive)
db/schema.sql   relational schema (SQLite-ready)
tools/          build / serve / Android setup scripts
tests/          unit, browser integration, end-to-end
```

## Version 3 highlights

* **Customer profile & complete history** (`#/customers/<id>`): totals, due, every invoice with product lines, partial payments with method, returns, voids with reason — date filter, CSV, printable statement.
* **Stock History** (`#/stock-history`, and per product `#/products/<id>`): every stock change with exact Asia/Dhaka date & time, before / change / after, reason, reference, user, cost / supplier / batch; append-only.
* **Sales returns**, **payment methods**, **duplicate-submit protection** (same sale / payment / return / delivery saved once), **exact money arithmetic**.
* **Security**: permissions enforced inside the services (not only by hiding buttons), admin-only user management, password confirmation for credential changes — and an honest list of what a client-only app cannot protect (`docs/SECURITY.md`).
* **Backup**: complete validation before restore, all-or-nothing restore, passphrase encryption (key never stored with the file), sync token never exported.
* **Sync**: revisions (a void during upload is not lost), quota back-off, secrets never logged, invoice-number conflicts and two-device stock warnings, Returns tab; `Code.gs` v4.
* Full list of changes, fixes, test results and **remaining risks**: `docs/CHANGES-v3.md`.

package com.wholesalepos.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

/** App entry point. Registers the local ThermalPrinter plugin BEFORE the bridge starts. */
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ThermalPrinterPlugin.class);
        super.onCreate(savedInstanceState);
    }
}

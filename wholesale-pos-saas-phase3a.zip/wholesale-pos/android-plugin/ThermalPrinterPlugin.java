package com.wholesalepos.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.util.Base64;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * ThermalPrinter — a small Capacitor plugin that sends raw ESC/POS bytes to
 * an 80 mm thermal printer directly from the Android app, fully offline.
 *
 * Two transports:
 *   - Bluetooth Classic (SPP / RFCOMM) to a printer that is already PAIRED in
 *     Android Settings. This is how the vast majority of thermal printers work.
 *   - USB host (OTG cable): finds the USB "Printer" interface (class 7) or any
 *     interface with a bulk-OUT endpoint.
 *
 * JavaScript API (all promise based; see js/printing/printer.js "native"):
 *   ensurePermissions()                 -> {}
 *   listBluetoothDevices()              -> {devices:[{name,address}]}
 *   listUsbDevices()                    -> {devices:[{name,address}]}
 *   connect({type:'bluetooth'|'usb', address})
 *   write({data: <base64>})
 *   isConnected()                       -> {connected:boolean}
 *   disconnect()
 *
 * Capacitor runs plugin methods on a background thread, so blocking I/O here is fine.
 */
@CapacitorPlugin(
    name = "ThermalPrinter",
    permissions = {
        @Permission(strings = { Manifest.permission.BLUETOOTH_CONNECT }, alias = "bluetooth")
    }
)
public class ThermalPrinterPlugin extends Plugin {

    /** Standard Serial Port Profile UUID used by virtually all Bluetooth printers. */
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String ACTION_USB_PERMISSION = "com.wholesalepos.app.USB_PERMISSION";
    private static final int USB_CHUNK = 16384;
    private static final int USB_TIMEOUT_MS = 10000;

    // Active connection state (guarded by `this`).
    private BluetoothSocket btSocket;
    private OutputStream btOut;
    private UsbDeviceConnection usbConnection;
    private UsbInterface usbInterface;
    private UsbEndpoint usbEndpoint;

    // ------------------------------------------------------------------ permissions

    /** Ask for the Android 12+ "Nearby devices" permission (no-op on older Android). */
    @PluginMethod
    public void ensurePermissions(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || getPermissionState("bluetooth") == PermissionState.GRANTED) {
            call.resolve();
            return;
        }
        requestPermissionForAlias("bluetooth", call, "permissionsCallback");
    }

    @PermissionCallback
    private void permissionsCallback(PluginCall call) {
        if (getPermissionState("bluetooth") == PermissionState.GRANTED) call.resolve();
        else call.reject("Bluetooth permission denied. Allow 'Nearby devices' for this app in Android settings.");
    }

    private boolean hasBluetoothPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || getPermissionState("bluetooth") == PermissionState.GRANTED;
    }

    // ------------------------------------------------------------------ discovery

    /** Paired (bonded) Bluetooth devices. Printers must be paired in Android settings first. */
    @SuppressLint("MissingPermission")
    @PluginMethod
    public void listBluetoothDevices(PluginCall call) {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) { call.reject("This device has no Bluetooth."); return; }
        if (!adapter.isEnabled()) { call.reject("Bluetooth is turned off."); return; }
        if (!hasBluetoothPermission()) { call.reject("Bluetooth permission not granted."); return; }
        try {
            JSArray list = new JSArray();
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            for (BluetoothDevice d : bonded) {
                JSObject o = new JSObject();
                o.put("name", d.getName() == null ? d.getAddress() : d.getName());
                o.put("address", d.getAddress());
                list.put(o);
            }
            JSObject res = new JSObject();
            res.put("devices", list);
            call.resolve(res);
        } catch (SecurityException e) {
            call.reject("Bluetooth permission not granted.");
        }
    }

    /** USB devices currently attached (OTG). `address` is the system device name. */
    @PluginMethod
    public void listUsbDevices(PluginCall call) {
        UsbManager usb = (UsbManager) getContext().getSystemService(Context.USB_SERVICE);
        JSArray list = new JSArray();
        if (usb != null) {
            for (UsbDevice d : usb.getDeviceList().values()) {
                JSObject o = new JSObject();
                String label = d.getProductName() != null ? d.getProductName()
                        : String.format("USB %04x:%04x", d.getVendorId(), d.getProductId());
                o.put("name", label);
                o.put("address", d.getDeviceName());
                list.put(o);
            }
        }
        JSObject res = new JSObject();
        res.put("devices", list);
        call.resolve(res);
    }

    // ------------------------------------------------------------------ connect

    @PluginMethod
    public void connect(PluginCall call) {
        String type = call.getString("type", "bluetooth");
        String address = call.getString("address");
        if (address == null || address.isEmpty()) { call.reject("No printer address given."); return; }
        try {
            synchronized (this) {
                closeQuietly();
                if ("usb".equals(type)) connectUsb(address);
                else connectBluetooth(address);
            }
            call.resolve();
        } catch (Exception e) {
            synchronized (this) { closeQuietly(); }
            call.reject(e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    @SuppressLint("MissingPermission")
    private void connectBluetooth(String address) throws IOException {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null || !adapter.isEnabled()) throw new IOException("Bluetooth is turned off.");
        if (!hasBluetoothPermission()) throw new IOException("Bluetooth permission not granted.");
        BluetoothDevice device = adapter.getRemoteDevice(address);
        adapter.cancelDiscovery(); // discovery slows / breaks RFCOMM connects
        BluetoothSocket socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
        try {
            socket.connect();
        } catch (IOException first) {
            // Some printers only accept the "insecure"/channel-1 fallback.
            try { socket.close(); } catch (IOException ignore) { /* ignore */ }
            try {
                Method m = device.getClass().getMethod("createRfcommSocket", int.class);
                socket = (BluetoothSocket) m.invoke(device, 1);
                socket.connect();
            } catch (Exception second) {
                throw new IOException("Bluetooth connection failed: " + first.getMessage());
            }
        }
        btSocket = socket;
        btOut = socket.getOutputStream();
    }

    private void connectUsb(String deviceName) throws Exception {
        Context ctx = getContext();
        UsbManager usb = (UsbManager) ctx.getSystemService(Context.USB_SERVICE);
        UsbDevice device = usb == null ? null : usb.getDeviceList().get(deviceName);
        if (device == null) throw new IOException("USB printer not found. Re-plug the cable.");
        if (!usb.hasPermission(device)) requestUsbPermission(usb, device);
        if (!usb.hasPermission(device)) throw new IOException("USB permission was not granted.");

        // Prefer the USB Printer class (7); otherwise any interface with a bulk-OUT endpoint.
        UsbInterface pickIface = null;
        UsbEndpoint pickEp = null;
        for (int i = 0; i < device.getInterfaceCount(); i++) {
            UsbInterface iface = device.getInterface(i);
            for (int e = 0; e < iface.getEndpointCount(); e++) {
                UsbEndpoint ep = iface.getEndpoint(e);
                if (ep.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK
                        && ep.getDirection() == UsbConstants.USB_DIR_OUT) {
                    if (pickIface == null || iface.getInterfaceClass() == UsbConstants.USB_CLASS_PRINTER) {
                        pickIface = iface;
                        pickEp = ep;
                    }
                }
            }
        }
        if (pickIface == null) throw new IOException("This USB device has no printable (bulk OUT) endpoint.");
        UsbDeviceConnection conn = usb.openDevice(device);
        if (conn == null) throw new IOException("Could not open the USB device.");
        if (!conn.claimInterface(pickIface, true)) {
            conn.close();
            throw new IOException("Could not claim the USB printer interface.");
        }
        usbConnection = conn;
        usbInterface = pickIface;
        usbEndpoint = pickEp;
    }

    /** Show Android's "Allow access to USB device?" dialog and wait for the answer. */
    private void requestUsbPermission(UsbManager usb, UsbDevice device) throws Exception {
        final CountDownLatch latch = new CountDownLatch(1);
        final Context ctx = getContext();
        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent intent) { latch.countDown(); }
        };
        ContextCompat.registerReceiver(ctx, receiver, new IntentFilter(ACTION_USB_PERMISSION),
                ContextCompat.RECEIVER_NOT_EXPORTED);
        try {
            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_MUTABLE : 0;
            Intent intent = new Intent(ACTION_USB_PERMISSION).setPackage(ctx.getPackageName());
            usb.requestPermission(device, PendingIntent.getBroadcast(ctx, 0, intent, flags));
            latch.await(30, TimeUnit.SECONDS);
        } finally {
            try { ctx.unregisterReceiver(receiver); } catch (IllegalArgumentException ignore) { /* ignore */ }
        }
    }

    // ------------------------------------------------------------------ I/O

    /** Write raw bytes (base64 in `data`) to the connected printer. */
    @PluginMethod
    public void write(PluginCall call) {
        String b64 = call.getString("data");
        if (b64 == null) { call.reject("No data."); return; }
        byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
        try {
            synchronized (this) {
                if (btOut != null) {
                    btOut.write(bytes);
                    btOut.flush();
                } else if (usbConnection != null) {
                    int offset = 0;
                    while (offset < bytes.length) {
                        int len = Math.min(USB_CHUNK, bytes.length - offset);
                        byte[] part = new byte[len];
                        System.arraycopy(bytes, offset, part, 0, len);
                        int sent = usbConnection.bulkTransfer(usbEndpoint, part, len, USB_TIMEOUT_MS);
                        if (sent < 0) throw new IOException("USB transfer failed.");
                        offset += len;
                    }
                } else {
                    throw new IOException("Printer is not connected.");
                }
            }
            call.resolve();
        } catch (IOException e) {
            synchronized (this) { closeQuietly(); } // force a clean reconnect next time
            call.reject(e.getMessage() == null ? "Write failed" : e.getMessage());
        }
    }

    @PluginMethod
    public void isConnected(PluginCall call) {
        boolean ok;
        synchronized (this) {
            ok = (btSocket != null && btSocket.isConnected()) || usbConnection != null;
        }
        JSObject res = new JSObject();
        res.put("connected", ok);
        call.resolve(res);
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        synchronized (this) { closeQuietly(); }
        call.resolve();
    }

    @Override
    protected void handleOnDestroy() {
        synchronized (this) { closeQuietly(); }
    }

    /** Close whatever is open; never throws. */
    private void closeQuietly() {
        try { if (btOut != null) btOut.close(); } catch (IOException ignore) { /* ignore */ }
        try { if (btSocket != null) btSocket.close(); } catch (IOException ignore) { /* ignore */ }
        btOut = null;
        btSocket = null;
        if (usbConnection != null) {
            try { if (usbInterface != null) usbConnection.releaseInterface(usbInterface); } catch (Exception ignore) { /* ignore */ }
            usbConnection.close();
        }
        usbConnection = null;
        usbInterface = null;
        usbEndpoint = null;
    }
}

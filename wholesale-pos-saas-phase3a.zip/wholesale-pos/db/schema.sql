-- ============================================================================
-- Wholesale POS — relational schema (reference / SQLite-ready)
-- ============================================================================
-- The shipped app stores the same entities in IndexedDB (js/core/db.js), which
-- works in every browser and Android WebView with no native plugin.  This file
-- is the authoritative *logical* model: it is what you implement if you later
-- move to SQLite (e.g. @capacitor-community/sqlite) — only js/core/db.js
-- needs re-implementing, every service talks to it through run()/helpers.
--
-- Conventions
--   * Primary keys are TEXT UUIDs generated on the device, so records created
--     offline on several devices never collide and can be de-duplicated.
--   * Money is stored as REAL rounded to 2 decimals (use INTEGER minor units if
--     you need exact cents at very large scale).
--   * created_at / updated_at / voided_at are UTC ISO-8601 instants — the reliable, unambiguous
--     time of every event. The derived strings date 'YYYY-MM-DD', time 'HH:MM:SS' and month
--     'YYYY-MM' are BUSINESS time in Asia/Dhaka (UTC+6), not the device's zone, so a phone set
--     to the wrong zone cannot move a sale into the wrong business day. Screens show Asia/Dhaka.
--   * Money has at most 2 decimals, quantities at most 3; the app rounds on the decimal text the
--     user sees (core/money.js), never on the binary float, and adds amounts in whole paisa.
--   * Version 3 added: short codes (C-0001 / P-0001), stock-history detail (previous stock, Dhaka date,
--     reference number, user, cost / supplier / batch, idempotency key), sales_returns, payment methods,
--     idempotency keys (request_id) and invoice revisions (rev). Existing rows are never rewritten.
--   * sync_status: 'pending' -> 'synced' | 'failed'  (see docs/SYNC.md)
-- ============================================================================

PRAGMA foreign_keys = ON;

-- ---- Security ---------------------------------------------------------------
CREATE TABLE users (
  id             TEXT PRIMARY KEY,
  username       TEXT NOT NULL,
  username_lower TEXT NOT NULL UNIQUE,
  display_name   TEXT NOT NULL,
  role           TEXT NOT NULL CHECK (role IN ('admin', 'manager', 'employee')),  -- 'employee' is shown as "Cashier"
  permissions    TEXT,                   -- JSON array of permission keys; NULL = use the role's defaults
  last_login_at  TEXT,
  password_algo  TEXT NOT NULL,          -- 'pbkdf2' (iterated-SHA-256 fallback on plain http:// hosts)
  password_iter  INTEGER NOT NULL,
  password_salt  TEXT NOT NULL,          -- random 16 bytes, base64
  password_hash  TEXT NOT NULL,          -- never plain text
  pin_algo       TEXT,                   -- quick-unlock PIN, hashed the same way
  pin_iter       INTEGER,
  pin_salt       TEXT,
  pin_hash       TEXT,
  active         INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL
);

-- ---- Configuration ----------------------------------------------------------
CREATE TABLE settings (               -- key/value: business name, logo (data URL),
  key   TEXT PRIMARY KEY,             -- address, phone, footer, currency, printer,
  value TEXT                          -- sync URL/token, low-stock default, ...
);

CREATE TABLE meta (                   -- counters, e.g. 'invseq:<device>:<yymmdd>' -> n
  key   TEXT PRIMARY KEY,
  value TEXT
);

-- ---- Catalogue --------------------------------------------------------------
CREATE TABLE categories (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  name_lower TEXT NOT NULL UNIQUE
);

CREATE TABLE products (
  code         TEXT,                         -- v3: short human code P-0001 (device code in the middle when set)
  last_move_at TEXT,                         -- v3: time of the latest stock movement (keeps history in order if the clock is moved back)
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  name_lower      TEXT NOT NULL,
  sku             TEXT,
  category_id     TEXT REFERENCES categories(id) ON DELETE SET NULL,
  unit            TEXT NOT NULL DEFAULT 'pc',
  cost_price      REAL NOT NULL DEFAULT 0,
  default_price   REAL NOT NULL DEFAULT 0,   -- only a hint: price is typed per sale
  stock           REAL NOT NULL DEFAULT 0,
  low_stock_level REAL NOT NULL DEFAULT 0,   -- warn when stock <= this
  active          INTEGER NOT NULL DEFAULT 1,-- 0 = archived (kept for history)
  created_at      TEXT NOT NULL,
  updated_at      TEXT NOT NULL
);
CREATE INDEX idx_products_name     ON products(name_lower);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_sku      ON products(sku);

CREATE TABLE customers (
  code         TEXT,                         -- v3: short human code C-0001
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  name_lower TEXT NOT NULL,
  phone      TEXT,                           -- normalised; unique when present
  address    TEXT,
  notes      TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_customers_name  ON customers(name_lower);
CREATE UNIQUE INDEX idx_customers_phone ON customers(phone) WHERE phone <> '';

-- ---- Sales ------------------------------------------------------------------
CREATE TABLE invoices (
  -- v3 additions: rev (starts at 1, +1 when voided — lets sync tell "changed while uploading"), request_id (UNIQUE:
  -- the same sale submitted twice is saved once), payment_method (how the paid amount was received),
  -- void_refund (money to give back on a void; void_reason / voided_at / voided_by below are now REQUIRED on a void)
  rev            INTEGER NOT NULL DEFAULT 1,
  request_id     TEXT UNIQUE,
  payment_method TEXT,
  void_refund    REAL,                   -- v3: what the customer paid at the counter = money to give back on a void
  id             TEXT PRIMARY KEY,           -- UUID = de-duplication key for Google Sheets
  invoice_no     TEXT NOT NULL UNIQUE,       -- PREFIX-[DEVICE-]YYMMDD-NNNN
  date           TEXT NOT NULL,
  time           TEXT NOT NULL,
  month          TEXT NOT NULL,
  created_at     TEXT NOT NULL,
  customer_id    TEXT REFERENCES customers(id),   -- NULL = walk-in
  customer_name  TEXT NOT NULL,              -- snapshot, so later edits don't alter history
  customer_phone TEXT,
  subtotal       REAL NOT NULL,
  discount       REAL NOT NULL DEFAULT 0,
  total          REAL NOT NULL,              -- subtotal - discount  (grand total)
  paid           REAL NOT NULL DEFAULT 0,
  due            REAL NOT NULL DEFAULT 0,    -- total - paid
  previous_due   REAL NOT NULL DEFAULT 0,    -- customer's balance before this sale
  status         TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'void')),
  void_reason    TEXT,
  voided_at      TEXT,
  voided_by      TEXT,
  notes          TEXT,
  created_by     TEXT REFERENCES users(id),
  created_by_name TEXT,
  device_code    TEXT,
  sync_status    TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending', 'synced', 'failed')),
  sync_attempts  INTEGER NOT NULL DEFAULT 0,
  sync_error     TEXT,
  synced_at      TEXT,
  CHECK (total = round(subtotal - discount, 2)),
  CHECK (due   = round(total - paid, 2))
);
CREATE INDEX idx_invoices_date     ON invoices(date);
CREATE INDEX idx_invoices_month    ON invoices(month);
CREATE INDEX idx_invoices_customer ON invoices(customer_id);
CREATE INDEX idx_invoices_sync     ON invoices(sync_status);

CREATE TABLE invoice_items (
  id         TEXT PRIMARY KEY,
  invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  line       INTEGER NOT NULL,               -- entry order (1, 2, 3 …) — keeps receipt/sheet order
  product_id TEXT NOT NULL REFERENCES products(id),
  name       TEXT NOT NULL,                  -- snapshot of product name / unit / cost at sale time
  unit       TEXT,
  qty        REAL NOT NULL CHECK (qty > 0),
  unit_price REAL NOT NULL CHECK (unit_price >= 0),   -- typed manually per customer
  cost_price REAL NOT NULL DEFAULT 0,
  total      REAL NOT NULL,                  -- qty * unit_price
  UNIQUE (invoice_id, line)
);
CREATE INDEX idx_items_invoice ON invoice_items(invoice_id);
CREATE INDEX idx_items_product ON invoice_items(product_id);

-- Money received from a customer against their due (not tied to one invoice).
CREATE TABLE payments (
  method         TEXT,                   -- v3: cash | bkash | nagad | rocket | bank | card | cheque | other
  request_id     TEXT UNIQUE,            -- v3: idempotency key
  user_id        TEXT,
  id             TEXT PRIMARY KEY,
  customer_id    TEXT NOT NULL REFERENCES customers(id),
  customer_name  TEXT NOT NULL,
  customer_phone TEXT,
  amount         REAL NOT NULL CHECK (amount > 0),
  note           TEXT,
  date           TEXT NOT NULL,
  time           TEXT NOT NULL,
  created_at     TEXT NOT NULL,
  created_by_name TEXT,
  sync_status    TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending', 'synced', 'failed')),
  synced_at      TEXT
);
CREATE INDEX idx_payments_customer ON payments(customer_id);
CREATE INDEX idx_payments_date     ON payments(date);
CREATE INDEX idx_payments_sync     ON payments(sync_status);

-- ---- Inventory --------------------------------------------------------------
-- Append-only log: every change to products.stock writes one row here.
CREATE TABLE stock_movements (       -- APPEND-ONLY: rows are never updated or deleted; a correction is a new row
  id             TEXT PRIMARY KEY,
  product_id     TEXT NOT NULL REFERENCES products(id),
  product_name   TEXT NOT NULL,
  product_code   TEXT,
  type           TEXT NOT NULL CHECK (type IN ('created', 'initial', 'receive', 'sale', 'void', 'return', 'adjustment', 'damage')),
  qty            REAL NOT NULL,              -- signed change (+ in, - out); 0 only for 'created'
  previous_stock REAL NOT NULL,              -- v3: stock before   (previous_stock + qty = balance)
  balance        REAL NOT NULL,              -- stock after the change
  reason         TEXT,
  ref            TEXT,                       -- id of the related invoice / return
  ref_no         TEXT,                       -- v3: its human number (INV-…, RET-…)
  user_id        TEXT,                       -- v3
  user_name      TEXT,
  unit_cost      REAL,                       -- v3: purchase cost per unit (deliveries)
  supplier       TEXT,
  batch_no       TEXT,
  op_key         TEXT UNIQUE,                -- v3: idempotency key — the same operation can never move stock twice
  date           TEXT NOT NULL,              -- v3: Asia/Dhaka calendar day of created_at
  created_at     TEXT NOT NULL
);
CREATE INDEX idx_movements_product ON stock_movements(product_id);
CREATE INDEX idx_movements_created ON stock_movements(created_at);
CREATE INDEX idx_movements_type    ON stock_movements(type);
CREATE INDEX idx_movements_user    ON stock_movements(user_id);
CREATE INDEX idx_movements_date    ON stock_movements(date);
CREATE INDEX idx_movements_ref     ON stock_movements(ref);

-- ---- Sales returns (v3) -----------------------------------------------------
-- Goods a customer brings back. One return = stock back in (a 'return' row per product) + its value applied
-- FIRST to what the customer owes (credit_applied) and the rest handed back (refund).
--   customer balance = Σ due of ACTIVE invoices − Σ payments − Σ credit_applied
CREATE TABLE sales_returns (
  id             TEXT PRIMARY KEY,
  return_no      TEXT NOT NULL UNIQUE,   -- RET-[DEVICE-]YYMMDD-NNNN
  invoice_id     TEXT NOT NULL REFERENCES invoices(id),
  invoice_no     TEXT NOT NULL,
  customer_id    TEXT REFERENCES customers(id),
  customer_name  TEXT,
  items          TEXT NOT NULL,          -- JSON: [{item_id, product_id, name, unit, qty, unit_price, amount}]
  amount         REAL NOT NULL CHECK (amount >= 0),
  credit_applied REAL NOT NULL CHECK (credit_applied >= 0),
  refund         REAL NOT NULL CHECK (refund >= 0),            -- amount = credit_applied + refund
  refund_method  TEXT,
  reason         TEXT NOT NULL,
  request_id     TEXT UNIQUE,
  date           TEXT NOT NULL,
  time           TEXT NOT NULL,
  created_at     TEXT NOT NULL,
  created_by_name TEXT,
  sync_status    TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending', 'synced', 'failed')),
  synced_at      TEXT
);
CREATE INDEX idx_returns_invoice  ON sales_returns(invoice_id);
CREATE INDEX idx_returns_customer ON sales_returns(customer_id);
CREATE INDEX idx_returns_date     ON sales_returns(date);

-- ---- Activity & sync diagnostics (v2) ---------------------------------------
-- Who did what: sign-ins, user switches, voided invoices, stock changes, user admin.
-- The app keeps the newest 5 000 rows.
CREATE TABLE audit_log (
  id         TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  user_id    TEXT,                           -- NULL for failed sign-ins
  user_name  TEXT,
  action     TEXT NOT NULL,                  -- dotted verb: 'invoice.void', 'auth.switch', 'stock.adjust' …
  target     TEXT,
  detail     TEXT
);
CREATE INDEX idx_audit_created ON audit_log(created_at);
CREATE INDEX idx_audit_user    ON audit_log(user_id);
CREATE INDEX idx_audit_action  ON audit_log(action);

-- One row per sync / verify run (newest 200 kept) — the "Recent sync runs" list.
CREATE TABLE sync_log (
  id         TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  kind       TEXT,                           -- 'sync' | 'verify'
  ok         INTEGER NOT NULL,
  sent       INTEGER, duplicates INTEGER, catalog INTEGER, rejected INTEGER,
  checked    INTEGER, missing INTEGER,
  ms         INTEGER,
  error      TEXT
);
CREATE INDEX idx_synclog_created ON sync_log(created_at);

-- meta rows 'catsync:product:<id>' / 'catsync:customer:<id>' hold the hash of the last
-- payload CONFIRMED by Google Sheets, so only changed products/customers are re-sent.
-- Automatic backup snapshots live in a SEPARATE database ('wholesale-pos-backups', store
-- 'snapshots': id, createdAt, reason auto|manual|before-restore, bytes, counts, json) so
-- restoring or clearing the main database can never delete them.

-- ============================================================================
-- Derived values (no stored copy: always computed, so they can never drift)
-- ============================================================================
-- Customer balance (total due):
--   SELECT c.id,
--          COALESCE((SELECT SUM(due)    FROM invoices WHERE customer_id = c.id AND status = 'active'), 0)
--        - COALESCE((SELECT SUM(amount) FROM payments WHERE customer_id = c.id), 0) AS balance
--   FROM customers c;
--
-- Daily sales:      SELECT date,  SUM(total) FROM invoices WHERE status='active' GROUP BY date;
-- Monthly sales:    SELECT month, SUM(total) FROM invoices WHERE status='active' GROUP BY month;
-- Product sales:    SELECT i.product_id, i.name, SUM(i.qty), SUM(i.total)
--                   FROM invoice_items i JOIN invoices v ON v.id = i.invoice_id
--                   WHERE v.status='active' GROUP BY i.product_id;
-- Low stock:        SELECT * FROM products WHERE active = 1 AND stock <= low_stock_level;

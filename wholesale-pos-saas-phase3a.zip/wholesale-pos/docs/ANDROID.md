# Android build

The Android app is the same web app wrapped by **Capacitor**, plus a small native plugin (`android-plugin/`) for direct **Bluetooth-classic (SPP)** and **USB-host** printing.

## Prerequisites

* Node 18+ and npm
* JDK 17+
* Android Studio (or just the Android SDK command-line tools, API 34+), with `ANDROID_HOME` set

## Build

```bash
npm install
npm run android:setup     # idempotent
```

`android:setup` does everything: builds `www/`, runs `cap add android` the first time, copies
`ThermalPrinterPlugin.java` and `MainActivity.java` into `android/app/src/main/java/com/wholesalepos/app/`,
adds the Bluetooth / USB permissions to `AndroidManifest.xml`, and runs `cap sync`.

Then either:

```bash
npm run android:open      # open in Android Studio → Run ▶ on a device
npm run android:apk       # debug APK: android/app/build/outputs/apk/debug/app-debug.apk
```

Install the APK on the tablet/phone (allow “install unknown apps”).

After changing any web code: `npm run android:sync` (rebuilds `www/` and syncs).

## Release build (Play Store or your own distribution)

1. Create a keystore: `keytool -genkey -v -keystore pos.jks -keyalg RSA -keysize 2048 -validity 10000 -alias pos`
2. Android Studio → *Build → Generate Signed Bundle / APK*, or configure `signingConfigs` in `android/app/build.gradle`.
3. **Keep the keystore and passwords safe** — you need the same key for every update.
4. Change `appId` in `capacitor.config.json` *before* the first release if you want your own package name (and the Java package folder in `tools/setup-android.mjs`).

## Permissions

| Permission | Why |
|---|---|
| `BLUETOOTH_CONNECT` (Android 12+), `BLUETOOTH` / `BLUETOOTH_ADMIN` (≤ 11) | talk to paired Bluetooth printers |
| `uses-feature usb.host` (optional) | USB printers via OTG cable; Android asks the user to allow each USB device |
| `INTERNET` (Capacitor default) | only for Google Sheets sync / Drive backup |

## Data safety on Android

* The database lives in the app’s WebView storage. The app asks the system to mark it **persistent** so it is not evicted under storage pressure.
* **Uninstalling the app or clearing its data deletes the database.** Export backups regularly (Settings → Backup) and enable Google Sheets/Drive.
* Local-file backups use the Share sheet / Files so they can be saved to Drive, e-mail or a USB stick.

## Connecting the printer

See [PRINTING.md](PRINTING.md). In short: pair in Android Bluetooth settings (or plug USB-OTG) → *Settings → Printer → Bluetooth / USB — Android app → Choose printer → Test print*.

## Without building an APK

Host the folder on any HTTPS static site and open it in **Chrome for Android → Add to Home screen**. Printing then uses Web Bluetooth/WebUSB or the RawBT app. The APK is recommended for shops because direct Bluetooth-classic printing works only there.

## Troubleshooting

| Problem | Fix |
|---|---|
| Printer not in the list | Pair it first in Android Bluetooth settings; grant *Nearby devices* permission. |
| USB printer not listed | Use a data-capable OTG cable; accept the USB permission prompt. |
| `cap add android` fails | Run `npm install` first; check JDK/Android SDK paths. |
| Build error about the plugin package | Plugin sources must be in `com/wholesalepos/app/` (re-run `npm run android:setup`). |

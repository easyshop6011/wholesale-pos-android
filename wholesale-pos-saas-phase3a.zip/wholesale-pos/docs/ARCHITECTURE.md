# Architecture

## Goals

1. Work **completely offline**; the network is only ever an optional extra (sync, Drive backup).
2. One code base for **browser and Android**.
3. Easy to extend: new screens, reports, printers or storage engines should not require touching unrelated code.

## Layers

```
┌────────────────────────── js/ui ──────────────────────────┐
│ shell · routes · views/* · components · dom helpers       │  DOM only
└───────────────┬───────────────────────────────────────────┘
                │ calls (async functions), listens to bus events
┌───────────────▼────────────── js/services ────────────────┐
│ sales · catalog · customers · inventory · reports ·       │  business rules,
│ sync · backup · auth · settings                           │  no DOM
└───────┬─────────────────────────────────────┬─────────────┘
        │                                     │
┌───────▼──────── js/core ─────────┐  ┌────────▼──── js/printing ─────┐
│ db (IndexedDB wrapper) · utils · │  │ receipt model · ESC/POS ·     │
│ format · bus · sha256            │  │ canvas renderer · transports  │
└──────────────────────────────────┘  └───────────────────────────────┘
```

Rules that keep it clean:

* **Views never touch the database.** They call services.
* **Services never touch the DOM.** That is why most of the app is tested in Node/headless Chromium without UI.
* **Everything that must be consistent is one transaction.** `createInvoice` writes the invoice, its lines, the stock reduction, the stock-movement log and the invoice-number counter atomically; if anything fails nothing is saved.
* Services announce changes on a tiny event bus (`js/core/bus.js`, e.g. `data:changed`); views and the sync engine subscribe.

## Key design decisions

| Decision | Reason |
|---|---|
| IndexedDB, not a native SQLite plugin | Built into every browser and Android WebView, transactional, offline, no native dependency. The relational model is documented in `db/schema.sql`; swapping engines means re-implementing `js/core/db.js` only. |
| UUID primary keys generated on the device | Records made offline on several devices never collide; the invoice UUID is the Google Sheets de-duplication key. |
| Invoice number `PREFIX-[DEVICE-]YYMMDD-NNNN` | Human friendly; the optional device letter keeps numbers unique when several devices sell at once. Counter is allocated inside the sale transaction. |
| Snapshots on invoice lines | Product name/unit/cost and customer name are copied at sale time, so renaming or deleting later never changes history. |
| Balances are computed, never stored | Customer due = Σ active invoice due − Σ payments. Cannot drift or go out of sync with the ledger. |
| Void instead of delete | A voided invoice restores stock, drops out of sales/dues, and is re-synced so the sheet shows `Void`. |
| No build step | Native ES modules; `tools/build-www.mjs` just copies files. Easy for the next developer to read and debug. |
| Strictly increasing timestamps | `monotonicNow()` guarantees unique, ordered `createdAt` values so “newest first” lists and oldest-first sync never tie. Invoice lines also store a `line` number to keep entry order. |

## Extending

**Add a screen**
1. Create `js/ui/views/<name>.js` exporting `default async function render(root, ctx)`.
2. Add one entry to `js/ui/routes.js` (path, label, icon, permission). Navigation, lazy loading and permission checks come for free.

**Add a permission / role** — edit `PERMISSIONS` in `js/services/auth.js`.

**Add a setting** — add the key and default to `DEFAULTS` in `js/services/settings.js`, then a field in `views/settings.js`.

**Add a report** — add a function to `js/services/reports.js` (pure queries over the stores), then a tab in `views/reports.js`.

**Add a stored field or table** — add it to `SCHEMA` in `js/core/db.js`, bump `DB_VERSION`, add a `MIGRATIONS` entry if existing rows must change, and mirror it in `db/schema.sql`. Backups automatically include every store in `SCHEMA`.

**Add a printer type** — push a transport object (`id, label, supported(), name(), connect(), send(bytes), disconnect()`) onto `TRANSPORTS` in `js/printing/printer.js`.

**Sync another entity** — mirror what `sync.js` does for `payments`: a `syncStatus` field, a payload builder, a new `action` in `Code.gs`.

**Move to SQLite / a server** — re-implement `js/core/db.js` (`run`, `Tx` methods). The service layer only uses that API.

## Testing strategy

| Suite | Runs in | Covers |
|---|---|---|
| `tests/unit` | Node | maths, ids, dates, CSV, SHA-256, ESC/POS bytes, text receipt width |
| `tests/browser` | headless Chromium | all services against real IndexedDB: sales, stock, dues, reports, sync (duplicates, offline, lost response), backup, auth, printing pipeline |
| `tests/e2e` | headless Chromium | the real UI end-to-end, offline reload via service worker, phone layout |

## v2 modules

* `core/search.js` (pure ranked search), `core/cache.js` (memoised queries cleared on `data:changed`).
* `services/globalsearch.js`, `autobackup.js`, `audit.js`, `sync-backoff.js` (pure back-off / batch logic).
* `ui/charts.js` + `ui/chart-math.js` (SVG charts + unit-tested geometry), `ui/palette.js` (global search), `ui/appearance.js` (theme/density), `ui/settings-form.js`, `views/settings-{backup,users,sync}.js`.
* New events on the bus: `backup:status`, `auth:changed`, `sync:status`, `settings:changed`, `data:changed`.
* Views repaint through `debounce(paint)`; services never touch the DOM and views never touch the database.

## Version 3 additions

* `core/money.js` (exact money / quantity arithmetic, strict parsing), `core/datetime.js` (Asia/Dhaka business time), `core/errors.js`, `core/upgrade.js` (old-row upgrades shared by the migration and by restore).
* `services/guard.js` (service-layer authorization, `authorize(perm)`) and `services/permissions.js` (pure role / permission matrix).
* `services/stockledger.js` — the ONLY writer of stock quantities and of the append-only `stockMovements`; `services/inventory.js` — receive / correct / write off, history queries, ledger check, CSV.
* `services/returns.js`, `services/payment-methods.js`, `services/codes.js` (C-/P- codes).
* `services/backup-validate.js` (pure restore gate), `services/backup-crypto.js` (PBKDF2 + AES-GCM).
* UI: `views/customer-profile.js`, `views/stock-history.js`, `views/product-profile.js`, `stock-ui.js`, `return-dialog.js`, `customer-dialogs.js`, `report-print.js`; `css/history.css`.
* Tests: `tests/shared/fake-google.js` runs the REAL `Code.gs` in memory (Node and browser); `tests/browser/legacy-db.js` builds a real version-2 database for the migration test.
* To add a stock-changing feature, call `recordMovement(tx, …)` inside your transaction — never write `products.stock` directly.

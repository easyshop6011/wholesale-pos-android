# Automatic backup

*Settings → Backup* (administrators). Three safety nets, each optional:

1. **Local snapshots** — a full copy of the database every N hours (6 h … weekly) and/or after N new invoices. Stored in a *separate* IndexedDB (`wholesale-pos-backups`), so importing, restoring or clearing the main data never deletes them. The newest 5–30 are kept (your choice); older ones are removed automatically.
2. **Google Drive** — the same backup uploaded to the “POS Backups” folder (needs Sync set up and internet). A failure is remembered and retried at the next check; selling is never interrupted.
3. **Device file** — in the Android app the newest backup is also written to `Documents/WholesalePOS/latest-backup.json`.

**Restore points**: the snapshot list shows date, reason (Automatic / Manual / Before restore), invoice/product/customer counts and size; each can be **Saved** as a file, **Restored** or deleted. Before *any* restore or import the app takes a “Before restore” snapshot (newest 3 kept), so a wrong restore can be undone from the list.

**When it runs**: shortly after the app starts, every 10 minutes while open, when the app goes to the background and when the internet returns. `backupDue()` (pure, unit-tested) decides whether a backup is due; `snapshotsToPrune()` decides what to delete.

**Privacy**: backups contain every record, password hashes and the sync token. Keep exported files and the Drive folder private.

Code: `js/services/autobackup.js`, `js/services/backup.js`, `views/settings-backup.js`.

## Version 3 — safe restore and encrypted backups

**Restore is all-or-nothing.** Importing a file (or restoring a snapshot / Drive backup) does this, in order:

1. read the file (decrypt it if needed) and **validate it completely** (`js/services/backup-validate.js`): every store
   present and a list; every record an object with its required fields and types; primary keys and unique indexes
   (invoice numbers, usernames) really unique; relationships (invoice lines → invoice, invoice / payment / return →
   customer, stock history → product); money arithmetic (`total = subtotal − discount`, `due = total − paid`, lines add
   up to the subtotal, `credit + refund = return value`); and at least one **active administrator** (no lock-out). A bad
   file stops here — nothing was touched;
2. save a **"before restore" snapshot** of the current data. If that fails the restore is **refused**;
3. replace every store inside **one IndexedDB transaction**: if anything fails the browser rolls the whole thing back;
4. reload settings, give short codes to old records, and sign out the current user if they no longer exist.

Older backups (version 1) restore too: their stock-history rows are upgraded from facts they already hold
(`previous = balance − change`, the Dhaka day of the stored time, the invoice number written in the reason text).
Stock that no row explains is *reported*, never invented.

**What a backup does not contain.** The Google Sheets **token** is a device secret and is never exported. After a
restore this device keeps its own token.

**Encryption (recommended).** *Settings → Backup → Export* asks for a passphrase (≥ 8 characters, typed twice).
The file is then `AES-256-GCM` encrypted with a key derived by `PBKDF2-SHA256` (310 000 rounds, random salt and IV). The file
holds only salt, IV, round count and ciphertext — **the passphrase and the key are never stored anywhere**, not in the file,
not in settings, not on Drive. A wrong passphrase, a damaged file or any edit (even to the header) is refused. Losing the
passphrase means nobody can open that file. Encryption needs HTTPS or localhost (WebCrypto); on plain `http://` it is reported
as unavailable rather than silently weakened.

* Manual export, snapshot download and "Back up to Google Drive now" can all be encrypted.
* **Automatic Drive upload:** tick *Encrypt the Google Drive copy*; an administrator types the passphrase once after the
  app starts (kept in memory only, forgotten on sign-out / restart). While it is missing, **nothing is uploaded** — a plain
  copy is never sent — and the backup screen says so. Local snapshots stay on the device unencrypted (they are as
  sensitive as the database itself).

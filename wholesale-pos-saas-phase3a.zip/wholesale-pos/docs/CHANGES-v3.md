# Version 3 — what changed, what was tested, what is still open

This file is the honest summary of the "customer history, stock history, security / backup / sync / accounting audit" work.
Nothing here is claimed unless a test in this repository exercises it; the last section lists what could **not** be tested.

## 1. Test results (all run in this environment)

| Suite | Before | Now | Command |
|---|---|---|---|
| Unit (Node) | 36 | **107** (+4 and +4: the date tests re-run with the device zone set to Los Angeles and Tokyo) | `npm test` |
| Browser integration (headless Chromium, real IndexedDB, real WebCrypto) | 68 | **104** | `npm run test:browser` |
| End-to-end through the real UI | 21 steps | **26** steps + a **7**-step run with the browser deliberately in the *wrong* time zone | `npm run test:e2e` |
| Lint (`tools/lint.mjs`): syntax of every `.js` / `.mjs` / `Code.gs` **plus five project safety rules** — R1 stock is written only through the ledger, R2 screens use the permission-checked `settings.update`, R3 no device-zone time formatting, R4 no secret on the console, R5 every sensitive service authorizes its caller | — | **clean** (105 files) | `npm run lint` |
| Web bundle build | — | clean | `npm run build` |

The project has no ESLint, so `npm run lint` is a small project-specific linter (syntax + the five rules above), not a style checker. It found two real defects while it was being written (see section 3).

**Your 12 mandatory scenarios**

| # | Scenario | Where it is tested |
|---|---|---|
| 1 | New customer → profile | browser *customer profile: a new customer has a complete, empty, consistent profile* |
| 2 | Several sales + payment history | browser *several sales and payments — every figure agrees with the raw records*; e2e customer-profile steps |
| 3 | Partial / full payment, due | browser *partial → full payment…*, *a void keeps the whole audit trail…*, *money stays exact* |
| 4 | New product + opening stock → history | browser *a new product records "created" and "opening stock"…*; e2e stock-history step |
| 5 | Stock up / down / sale / return / void → correct history | browser *receive, correct, write-off, sale, void and return each leave a correct, chained row*, *append-only*, *several lines of one product*, *invalid changes leave NO partial rows*, *no invented history* |
| 6 | Wrong backup → original data intact | browser *damaged, incomplete or hostile files are refused…* (17 kinds), *a restore that fails HALF-WAY is rolled back*; unit validator tests |
| 7 | Unauthorized sensitive operations refused | browser 6 *security:* tests (34 services signed-out, locked screen, cashier, manager, account take-over, throttling, first-run race) |
| 8 | Same sale submitted twice | browser *submitting the same operation twice never duplicates it* (sequential **and** simultaneous) |
| 9 | Sheets sync fails → resync | browser 5 *sync:* tests with the **real `Code.gs`** behind the real client; 9 unit tests of the server rules |
| 10 | Old database → new version | browser *migration: a version-2 database upgrades…* (a real v2 IndexedDB is built and opened) |
| 11 | Bengali receipt and time | browser *receipt: Bengali … drawn as real glyphs; invoice time is Asia/Dhaka*; e2e time-zone run |
| 12 | Restart keeps all history | browser *restart…*; e2e *RESTART* step |

## 2. Files

**Changed (17 entries listed by group)**

```
README.md · db/schema.sql · docs/{ARCHITECTURE,BACKUP,DATABASE,REPORTS,SECURITY,SYNC,USERS,USER_GUIDE}.md · index.html · package.json · sw.js (regenerated)
integrations/google-apps-script/Code.gs
js/app.js · js/core/{db,format,utils}.js
js/services/{audit,auth,autobackup,backup,catalog,customers,inventory,reports,sales,settings,sync,sync-backoff}.js
js/ui/{auth-screens,components,routes,settings-form,shell}.js
js/ui/views/{customers,dashboard,inventory,invoices,pos,products,settings,settings-backup,settings-sync,settings-users}.js
tests/browser/{env,harness,helpers,suite,suite-core,suite-reports}.js · tests/browser/index.html · tests/e2e/smoke.mjs · tests/unit/utils.test.mjs
```

**Added (35 files)**

```
css/history.css
js/core/{datetime,errors,money,upgrade}.js
js/services/{backup-crypto,backup-validate,codes,guard,payment-methods,permissions,returns,stockledger}.js
js/ui/{customer-dialogs,report-print,return-dialog,stock-ui}.js · js/ui/views/{customer-profile,product-profile,stock-history}.js
tests/browser/{legacy-db,real-script,suite-v3-books,suite-v3-safety}.js · tests/shared/fake-google.js · tests/e2e/timezone.mjs
tests/unit/{backup-crypto,backup-validate,codegs,datetime,ledger-math,money,permissions}.test.mjs · tests/unit/helpers/{apps-script-fake,backup-fixture}.mjs
```

Nothing was removed. No existing feature was deleted; the old customer detail page became the new profile (its "due history" tab is now part of the full history).

## 3. Problems found in the existing code, and the fix

| Area | Problem | Fix |
|---|---|---|
| Authorization | `createUser`, `updateUser`, `setCredentials` and every other service ran for **anyone** (security was only hidden buttons); a locked screen still counted as signed in; a cashier could change the administrator's password; last-admin protection was the only guard | `services/guard.js`: every sensitive service calls `authorize(perm)`; user management is administrator-only; changing credentials needs the signed-in person's own password and is throttled; self-disable blocked; locked = no permissions; refusals logged. First-run setup is atomic. Client-side limits documented in `docs/SECURITY.md`. |
| Backup validation | Only the format name and version number were checked; a file missing the `users` store would **wipe all users**; the safety snapshot's failure was silently ignored and the restore went ahead | Complete validation before anything is written (structure, fields, keys, relationships, money arithmetic, at least one admin); restore refused if the safety snapshot cannot be saved; one transaction; session re-checked afterwards. |
| Backup secrecy | The Google Sheets token was written into every backup, snapshot and Drive upload | Never exported; this device keeps its own on restore. Optional AES-256-GCM encryption with a passphrase that is never stored. |
| Sync | An invoice **voided while its sale was uploading** was marked "synced" with the old (Active) content — the void never reached the sheet | Invoice revision (`rev`); a response only marks the revision that was sent. |
| Sync | Quota errors were retried like any failure; error text could carry the token / script URL; two devices with the same Device code produced two invoices with one number silently | 30-minute minimum wait after quota errors; `redactSecrets` on everything stored or shown; the script reports a `conflict` and the app parks that record; two-device stock overwrite is flagged. |
| Sync | No way to sync returns / payment methods; the status chip said "UTC" | Returns tab, method columns, `Code.gs` v4; times shown in Asia/Dhaka. |
| Stock | **Deleting a product deleted its stock history.** History lacked previous stock, user, reference, cost / supplier / batch; no "created", "delivery", "damage", "return" kinds; a quantity like 0.0004 produced a sale without moving stock | `stockledger.recordMovement` is the only writer of stock; rows are append-only; a product is archived, never erased; quantities are exact to 3 decimals and anything smaller is refused. |
| Accounting | `"abc"` or a Bengali-digit amount silently became **0**; half-cent rounding was binary-float dependent; the same sale / payment could be saved twice; a void had no required reason and no record of the refund owed | `core/money.js` (decimal-text rounding, whole-paisa sums, scaled-integer line totals, strict parsing, Bengali digits); idempotency keys (unique indexes) on sales, payments, returns, deliveries, product creation; void needs a reason (kept with who / when / refund owed). |
| Time | `date` / `time` / day filters followed the **device's** zone (a phone set to another zone moved sales to another day); activity-log times and the sync chip used device time | Business time is Asia/Dhaka everywhere (`core/datetime.js`); every displayed time is Asia/Dhaka; calendar arithmetic is zone-independent. |
| Phones | With real data the dashboard cards (icon + figure + sparkline) did not fit two to a row: the figures broke letter by letter and the page grew wider than the screen. Wide history tables needed sideways scrolling | sparkline hidden and cards tightened on phones; the stock-history table becomes one small labelled card per row on phones. The test that guards this now measures against the phone's real 390 px width (the old check compared with `innerWidth`, which grows with the overflow and so could never fail). |
| Printing | The *test print* receipt stamped the device's clock | uses the shop time (Asia/Dhaka) like every real invoice. |
| Services | `receiveStock` / `adjustStock` / `writeOffStock` validated the input *before* checking who was asking | authorization first (found by the new lint rule R5). |
| UI | Every filter bar showed the word **"null"** when no filter was active (`replaceChildren(null)`); a slow page could finish after a newer one and **overwrite it** (URL `#/pos`, screen still Settings) | both fixed. |
| Setup | First-run saved business settings before the administrator existed (would now be refused) | order corrected. |

## 4. New features

* **Customer profile** `#/customers/<id>` — ID + short code, contact, total purchases, total paid, current due (or credit), invoice count, last purchase (date, time, invoice); complete history (every product line with quantity, unit, price, discount share, net; paid at the counter and how; every later payment with time, amount, method; returns; voids with reason / who / when / refund owed); running balance after every entry; date filter; open / print invoices; *New sale* pre-selects the customer; **CSV** and **printable statement**. A built-in cross-check shows a warning if the totals ever stop adding up.
* **Stock History** page + per-product profile — exact Asia/Dhaka date and time (to the second), kind of change, before / change / after, reason, reference, user, cost / supplier / batch; filters (date, product, kind, user, text); newest first; CSV; print; an honest banner for stock that pre-dates the history.
* **Stock actions**: receive delivery (cost, supplier, batch), correct a count (add / remove / set), write off damaged goods — each creates a new row.
* **Sales returns** (goods back to stock; credit against the due first, cash refund for the rest) and **payment methods** (cash, bKash, Nagad, Rocket, bank, card, cheque, other).
* Short codes C-0001 / P-0001; encrypted backups; backup / sync / security screens updated; `docs/` updated.

**Behaviour changes you should know about** — voiding needs a reason; "Delete product" archives it (history is never destroyed); a signed-in user is now required by the services themselves; backups no longer contain the sync token; an invoice that already has returns cannot be voided (take the rest back instead); after paying for an invoice that is later voided the customer shows **credit**.

## 5. Upgrade notes

1. Take a backup of the current app first (Settings → Backup).
2. Open the new version once: the database upgrades 2 → 3 automatically (additive; tested).
3. Re-paste `integrations/google-apps-script/Code.gs` and deploy a **new version** (the app keeps working with the old one, but returns and conflict detection need v4). Give every device its own **Device code**.
4. Re-enter the Sheets token on a device if you restore onto a new device (it is not in backups any more).

## 6. NOT done / NOT tested / remaining risks

* **Real printers** — no Bluetooth / USB thermal printer was available. Receipts are verified as rendered images (Bengali glyphs are really drawn and differ per word) and as ESC/POS bytes only. **Not tested on hardware.** In ASCII *Text mode* Bengali prints as `?` (use the default Raster mode).
* **Android app** — the web bundle builds (`npm run build`) but no APK was built or run (no Android SDK here). The printable statement uses the browser print dialog, which may be missing inside the Android WebView; use *Export CSV* there.
* **Real Google account** — `Code.gs` is run against an in-memory imitation, so its dedupe / revision / conflict logic is proven, but Google's real quotas, latency, number auto-formatting and the 6-minute limit are not. Re-test once with your own sheet.
* **Two devices** — conflicts are *detected and reported*, not merged. There is still no shared live stock between devices (needs a server).
* **A client-only app cannot defend against a person who controls the unlocked device** (developer tools can edit IndexedDB; the sign-in throttle lives in `localStorage`; a 4–6 digit PIN can be brute-forced offline). See `docs/SECURITY.md`.
* Local automatic snapshots are not encrypted (same sensitivity as the database); automatic Drive uploads are encrypted only when you switch it on and enter the passphrase each session.
* Not implemented: reversing a customer **payment**; applying a customer's **credit** to a new sale automatically (it is shown, not applied); returns are not deducted in the trend / top-customer / category / staff / busy-hour analytics (they are in daily, monthly, dashboard, cash, profit and product reports).
* The end-to-end suite drives a real browser and is timing-sensitive (the app focuses a field shortly after a dialog opens). It passed 6 of 6 consecutive full runs after the waits were added; a very slow machine can still produce an occasional false failure.

## 7. Screenshots

`docs/screenshots/` was emptied and regenerated from the real UI by the end-to-end runs (`SHOTS=docs/screenshots npm run test:e2e`): 44 images — setup, dashboard, POS, receipt preview, inventory, invoice detail, **customer profile (+ history)**, **Stock History page**, **product history**, **receive-stock / return / void-reason / encrypted-backup dialogs**, reports, sync, backup, users, activity, settings, dark mode, offline sale, **phone** versions (dashboard, POS, invoices, customers, **customer profile**, products, **product history**, **stock history**, reports, settings, **More menu**) and the **Bengali** set taken with the browser deliberately in the wrong time zone (customer profile, stock history, 80 mm receipt).


# ক্লাউড ডাটাবেজ (PostgreSQL / Supabase)

মাইগ্রেশন: `supabase/migrations/` · টেস্ট: `supabase/tests/database/` · স্ট্যাটিক যাচাই: `npm run check:sql`

> **অযাচাইকৃত:** SQL এখনো কোনো PostgreSQL-এ চালানো হয়নি (লেখকের পরিবেশে ছিল না)। `npm run check:sql` শুধু কাঠামোগত নিয়ম যাচাই করে;
> সত্যিকারের প্রমাণ `supabase db reset && supabase test db` (দেখুন `docs/CLOUD-SETUP.md`)।

## ১. নিরাপত্তার মূল নকশা

| নীতি | কীভাবে বাস্তবায়িত |
|---|---|
| **Default deny** | প্রতিটি টেবিলে RLS চালু; নতুন টেবিলে API-ভূমিকার কোনো অধিকার স্বয়ংক্রিয়ভাবে নেই (`alter default privileges … revoke`); অধিকার ০০০৪-এ এক এক করে দেওয়া |
| **Tenant isolation (RLS)** | সব স্টাফ-পলিসি `my_business_ids(পারমিশন, লিখবে?)` দিয়ে: *সক্রিয় সদস্য* + *ব্যবসা `approved`* + *অ্যাকাউন্ট সক্রিয়* + *সেশন বাতিল নয়* (+ লেখার জন্য: *সাবস্ক্রিপশন মেয়াদোত্তীর্ণ নয়*) |
| **Tenant isolation (ডেটা-স্তর)** | টেবিলগুলোর মধ্যে রেফারেন্স composite FK `(business_id, id)`; ব্যবসা A-এর ইনভয়েস B-এর কাস্টমারকে ধরতে পারে না, ফাংশনে ভুল থাকলেও |
| **টাকার টেবিল শুধু-পড়া** | `invoices, invoice_items, payments, sales_returns(+items), stock_movements, purchases(+items), supplier_payments` — ক্লায়েন্টের INSERT/UPDATE/DELETE নেই। লেখা হবে সার্ভার-ফাংশনে এক ট্রানজ্যাকশনে (Phase 5)। ফলে `stock` কখনো ক্লায়েন্টের হিসাবে নির্ভর করে না |
| **স্টক** | `products.stock` ও `last_move_at` ক্লায়েন্ট insert/update করতে পারে না (কলাম-অধিকার নেই) |
| **ক্রয়-মূল্য গোপন** | `products.cost_price`, `invoice_items.cost_price`, `stock_movements.unit_cost` API-তে পড়া যায় না (কলাম-ভিত্তিক SELECT); পাওয়া যাবে `get_product_costs()` ফাংশনে, শুধু `reports.profit` বা `products.edit` থাকলে |
| **Append-only** | `audit_logs, access_logs, subscription_events, business_approvals, payments, sales_returns, sales_return_items, stock_movements, supplier_payments` — ট্রিগার UPDATE/DELETE-ই আটকায় (service role-ও পারে না); `invoice_items`/`purchase_items` শুধু UPDATE আটকায়; ইনভয়েসের টাকার ঘর অপরিবর্তনীয়, শুধু বাতিল (void) সম্ভব, বাতিল-ফেরত নয় |
| **Super Admin** | `platform_admins`-এ API-র অধিকার নেই; বানানো যায় শুধু SQL Editor-এ (`private.grant_super_admin`); ক্ষমতা সক্রিয় শুধু **aal2 (MFA)** সেশনে; ব্যবসার বিক্রয়-ডেটার কোনো পলিসি নেই (শুধু সংখ্যা/সারাংশ) |
| **কাস্টমার** | কাস্টমার-লগইনের কোনো টেবিল-পলিসি **নেই**; নিজের ডেটা পাবে ডেডিকেটেড ফাংশনে (নিরাপদ কলাম, ক্রয়-মূল্য ছাড়া) — Phase 4 |
| **SECURITY DEFINER** | প্রতিটিতে `set search_path = ''` + সম্পূর্ণ-যোগ্য নাম; `EXECUTE` সবার কাছ থেকে প্রত্যাহার করে শুধু `authenticated`-কে নির্দিষ্ট তালিকায় |
| **Idempotency** | `request_id` + `unique (business_id, request_id)` (অফলাইনে বানানো রেকর্ড দুবার সিঙ্ক হলে একবারই থাকে); স্টকে `op_key` |
| **ব্যবসায়িক সময়** | `occurred_at` (ডিভাইসের মুহূর্ত); `biz_date/biz_time/biz_month` ট্রিগারে Asia/Dhaka থেকে **নির্ণীত** — ক্লায়েন্টের পাঠানো তারিখ বিশ্বাস করা হয় না |
| **সেশন বাতিল** | `revoke_device` সেই সেশনের id `revoked_sessions`-এ রাখে; পরের প্রতিটি অনুরোধে RLS তা দেখে (access token-এর মেয়াদ ফুরানোর অপেক্ষা নয়); একই ডিভাইসে নতুন লগইন = নতুন সেশন, পুরোনোটি মৃতই থাকে |

## ২. টেবিল-তালিকা (৩১টি)

**অ্যাকাউন্ট ও নিরাপত্তা:** `profiles`, `platform_admins`, `user_devices`, `revoked_sessions`, `user_security_events`, `audit_logs`, `access_logs`
**ব্যবসা:** `businesses`, `business_approvals`, `business_members`, `business_invitations`, `business_settings`
**SaaS:** `plans`, `subscriptions`, `subscription_events`, `platform_settings`
**ক্যাটালগ ও মজুত:** `categories`, `products`, `suppliers`, `stock_movements`, `purchases`, `purchase_items`, `supplier_payments`
**বিক্রয়:** `customers`, `customer_accounts`, `customer_invitations`, `invoices`, `invoice_items`, `payments`, `sales_returns`, `sales_return_items`

আপনার তালিকার বাইরে যা যোগ করেছি: `platform_admins` (Super Admin), `sales_return_items` (রিটার্নের লাইন), `supplier_payments` (সরবরাহকারীকে পরিশোধ), `customer_invitations` (কাস্টমার-ক্লেইম কোড) — সবই আপনার আবশ্যিক ফিচারের অংশ। আপনার তালিকার `user_sessions`-এর জায়গায় আছে `revoked_sessions` (সেশনের মালিক Supabase Auth; আমরা শুধু "বাতিল" সেশনের তালিকা রাখি)।

## ৩. কে কী করতে পারে (API-র মাধ্যমে)

| টেবিল | মালিক/অ্যাডমিন | ম্যানেজার | ক্যাশিয়ার (ডিফল্ট) | Super Admin | কাস্টমার |
|---|---|---|---|---|---|
| `products`, `categories` | পড়া/লেখা (`stock`, মূল্য-পড়া বাদে) | পড়া/লেখা | **শুধু পড়া** | ✘ | ✘ |
| `customers` | পড়া/লেখা/soft-delete | পড়া/লেখা (soft-delete ✘) | পড়া/**তৈরি** | ✘ | ✘ |
| `suppliers` | পড়া/লেখা | পড়া/লেখা | পড়া | ✘ | ✘ |
| `invoices`, `payments`, `sales_returns`, `stock_movements`, `purchases` … | **শুধু পড়া** | শুধু পড়া | শুধু পড়া (`invoices`, `customers` পারমিশন অনুযায়ী) | ✘ | ✘ |
| `business_settings` | পড়া/লেখা | পড়া | পড়া | ✘ | ✘ |
| `business_members` | পড়া (লেখা শুধু ফাংশনে — Phase 3) | পড়া | পড়া | ✘ | ✘ |
| `audit_logs` | পড়া (`audit` পারমিশন) | পড়া | ✘ | সব | ✘ |
| `businesses` | নিজের: পড়া + আবেদনের তথ্য সংশোধন | পড়া | পড়া | সব পড়া | ✘ |
| `subscriptions`, `plans` | নিজের পড়া / প্ল্যান পড়া | — | — | সব পড়া, `plans` লেখা | প্ল্যান পড়া |
| `platform_admins`, `revoked_sessions` | ✘ | ✘ | ✘ | ✘ (শুধু SQL Editor) | ✘ |

"মালিক/অ্যাডমিন" মানে `owner`/`admin` রোল — সব পারমিশন। কাস্টম রোলে ক্যাশিয়ার/ম্যানেজারের `permissions` তালিকা ডিফল্টকে প্রতিস্থাপন করে (ঠিক `permissions.js`-এর মতো; সমতা `sql-policy.test.mjs` যাচাই করে)।

## ৪. ব্যবসার অবস্থা-প্রবাহ

```
register_business ──▶ pending ──approve──▶ approved ──suspend──▶ suspended
   (ইমেইল যাচাইকৃত)      │                    ▲                     │
                         │                    └──────reinstate──────┘
                         └──reject (কারণ বাধ্যতামূলক)──▶ rejected ──resubmit_business──▶ pending
```

| থেকে | কাজ | কে | ফল |
|---|---|---|---|
| — | `register_business` | যাচাইকৃত ইউজার | `pending` |
| `pending` | `review_business('approve')` | Super Admin (MFA) | `approved` |
| `pending` | `review_business('reject', কারণ)` | Super Admin (MFA) | `rejected` |
| `rejected` | `resubmit_business` | মালিক | `pending` |
| `approved` | `set_business_suspension(true, কারণ)` | Super Admin (MFA) | `suspended` |
| `suspended` | `set_business_suspension(false)` | Super Admin (MFA) | `approved` |

অন্য যেকোনো ধাপ `invalid_transition` ত্রুটি দেয়।

* `approved`-এর বাইরে (pending/rejected/suspended) সদস্যরা কোনো POS-ডেটা পায় না; মালিক শুধু নিজের `businesses`/`business_approvals` সারি পড়ে কারণ দেখতে।
* `suspended` হলে সবার ক্লাউড-অ্যাক্সেস তৎক্ষণাৎ বন্ধ (RLS-এ); `my_access_state()` কারণসহ জানায় ও `access_logs`-এ লেখে।
* সাবস্ক্রিপশন মেয়াদ ফুরালে: ডেটা মোছে না, **শুধু পড়া** চলে (`can_write=false`); নবায়নে (`current_period_end` বাড়লে/`null` হলে) লেখা ফিরে আসে।
* একটি আবেদনের ইতিহাস `business_approvals`-এ (submitted → rejected → resubmitted → approved …), মোছা যায় না।

## ৫. RPC (`supabase.rpc(name, args)`)

| ফাংশন | কে | কাজ |
|---|---|---|
| `register_business(p_name, p_owner_name, p_phone, p_email, p_address, p_district, p_trade_license)` | যাচাইকৃত-ইমেইল ইউজার | `pending` আবেদন + মালিক-সদস্য + ফ্রি সাবস্ক্রিপশন (প্রথমবার); প্ল্যান-সীমা ও দৈনিক ৫টি সীমা সার্ভারে |
| `resubmit_business(p_business)` | মালিক | `rejected` → `pending` |
| `review_business(p_business, p_decision 'approve'/'reject', p_reason)` | Super Admin (aal2) | অনুমোদন/প্রত্যাখ্যান |
| `set_business_suspension(p_business, p_suspend, p_reason)` | Super Admin (aal2) | সাসপেন্ড/পুনরায় চালু |
| `my_access_state()` | যেকোনো সাইন-ইন ইউজার | আমার ব্যবসা, রোল, পারমিশন, `can_read/can_write`, প্ল্যান, super-admin অবস্থা |
| `record_login(p_device_id, p_label, p_platform, p_user_agent)` | সাইন-ইন ইউজার | ডিভাইস নিবন্ধন; নতুন ডিভাইস/অনেক ডিভাইস শনাক্ত |
| `revoke_device(p_device)` | সাইন-ইন ইউজার | সেই ডিভাইসের সেশন বাতিল |
| `log_security_event(p_type, p_details)` | সাইন-ইন ইউজার | নিরাপদ তালিকাভুক্ত ইভেন্ট (`password_changed`, `mfa_enrolled` …) |
| `get_product_costs(p_business)` | `reports.profit`/`products.edit` | ক্রয়-মূল্য |
| `private.grant_super_admin(email)` / `revoke_super_admin` | **শুধু SQL Editor** | Super Admin বুটস্ট্র্যাপ |

আসছে: Phase 3 — কর্মচারী আমন্ত্রণ/ব্যবস্থাপনা ফাংশন; Phase 4 — কাস্টমার-ক্লেইম ও পোর্টাল ফাংশন; Phase 5 — `post_sale`/`receive_payment`/`create_return`/`stock` ও `sync_push/pull`; Phase 6 — সাবস্ক্রিপশন-অ্যাডমিন ও `get_platform_stats`।

## ৬. ত্রুটি-কোড → বাংলা বার্তা (Phase 3-এর UI এগুলো ব্যবহার করবে)

| কোড (বার্তা) | বাংলা |
|---|---|
| `auth_required` | আগে লগইন করুন। |
| `account_disabled` | আপনার অ্যাকাউন্টটি নিষ্ক্রিয় করা হয়েছে। |
| `email_not_verified` | প্রথমে আপনার ইমেইল যাচাই করুন। |
| `invalid_name` / `invalid_owner_name` | নাম কমপক্ষে ২ অক্ষরের হতে হবে। |
| `invalid_phone` | সঠিক মোবাইল নম্বর দিন (যেমন ০১৭১২৩৪৫৬৭৮)। |
| `invalid_email` | সঠিক ইমেইল ঠিকানা দিন। |
| `registration_closed` | বর্তমানে নতুন নিবন্ধন বন্ধ আছে। |
| `rate_limited` | অনেকবার চেষ্টা হয়েছে, একটু পরে আবার চেষ্টা করুন। |
| `plan_limit:businesses` | আপনার বর্তমান প্ল্যানে আর কোনো ব্যবসা যোগ করা যাবে না। |
| `plan_limit:employees` | আপনার বর্তমান প্ল্যানে আর কর্মচারী যোগ করা যাবে না। |
| `duplicate_business_name` | এই নামে আপনার একটি ব্যবসা আগেই আছে। |
| `business_not_found` | ব্যবসাটি পাওয়া যায়নি। |
| `invalid_transition` | বর্তমান অবস্থায় এই কাজটি করা যায় না। |
| `not_platform_admin` | এই কাজের জন্য প্রধান প্রশাসকের অনুমতি (MFA সহ) লাগবে। |
| `reason_required` | কারণ লিখুন (কমপক্ষে ৫ অক্ষর)। |
| `invalid_decision` | অবৈধ সিদ্ধান্ত। |
| `permission_denied` / SQLSTATE `42501` | এই কাজের অনুমতি আপনার নেই। |
| `invalid_device` / `device_not_found` / `invalid_event` | ডিভাইসের তথ্য সঠিক নয় / ডিভাইস পাওয়া যায়নি / অবৈধ ইভেন্ট। |

## ৭. ক্লায়েন্ট (অ্যাপ) লেখার নিয়ম

1. `select *` **চলবে না** `products`, `invoice_items`, `stock_movements`-এ — কলাম-তালিকা দিন (ক্রয়-মূল্য লুকানো; `*` পুরো কলামে প্রসারিত হয়ে `42501` দেয়)।
2. অফলাইনে নতুন রেকর্ডের `id` (UUID v4) ক্লায়েন্টেই বানান ও `insert` গ্র্যান্টে `id` অনুমোদিত। বিক্রয়/পেমেন্ট/রিটার্নে `request_id` (৮–৮০ অক্ষর) বাধ্যতামূলক প্রথা।
3. টাকার রেকর্ড (ইনভয়েস, পেমেন্ট, রিটার্ন, স্টক) সরাসরি `insert` নয় — Phase 5-এর RPC।
4. ব্যবহারকারী মুছে ফেলা যায় না যদি তার নামে আর্থিক ইতিহাস থাকে (append-only সারির `created_by` বদলানো আটকানো): মুছবেন না, `profiles.is_active = false` / সদস্যের `status = 'disabled'` করুন। (মালিকের `businesses.owner_id` `restrict`)।
5. `my_access_state()` প্রতিবার সাইন-ইনের পর ও অ্যাপ ফোরগ্রাউন্ডে এলে কল করে স্ক্রিন ঠিক করুন; এটাই "পেন্ডিং/প্রত্যাখ্যাত/সাসপেন্ডেড" বার্তার উৎস।

## ৮. জানা সীমাবদ্ধতা

* **কেবল প্রতি-ব্যবসা প্ল্যান নয়, প্রতি-মালিক:** সাবস্ক্রিপশন মালিকের (সব ব্যবসা একই প্ল্যান)।
* `access_logs` কেবল সফল-পথে লেখা যায় (ব্যর্থ লেনদেনের রোলব্যাকে লগও যায়); প্রত্যাখ্যাত চেষ্টা Supabase-এর Postgres/API লগে থাকে।
* `ip` কেবল `x-forwarded-for` হেডার থেকে; প্রক্সি-বিন্যাস অনুযায়ী ভরসাযোগ্যতা বদলায়।
* ইনভয়েস নম্বরের ডিভাইসভিত্তিক সংঘাত (দুই ডিভাইসে একই কোড) সার্ভারে `unique (business_id, invoice_no)` ধরবে; সংঘাত-সমাধান Phase 5-এ।
* SMS/ফোন-যাচাই ছাড়া কাস্টমার-লিংক হবে *ইমেইল মিল* বা *দোকানের দেওয়া ক্লেইম-কোড* দিয়ে; ফোন-OTP-তে লিংক করতে SMS প্রোভাইডার লাগবে (Phase 4-এ বিস্তারিত)।

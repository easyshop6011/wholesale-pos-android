# ক্লাউড সেটআপ গাইড (Supabase)

> **অবস্থা:** এই গাইডের SQL ও কনফিগ আমি লিখেছি, কিন্তু আমার পরিবেশে PostgreSQL/Docker ছিল না — তাই **এগুলো এখনো কোথাও চালানো হয়নি**।
> প্রথম ধাপের উদ্দেশ্যই সেটা যাচাই করা। কোনো ধাপে ত্রুটি এলে **ত্রুটির হুবহু লেখাটি** আমাকে দিন; পাসওয়ার্ড/কী দেবেন না।

## নিয়ম (এক নজরে)

* অ্যাপে (ওয়েব ও APK) শুধু **publishable/anon key** ও প্রজেক্ট URL যাবে — দুটোই প্রকাশ্য, RLS ডেটা রক্ষা করে।
* **`service_role` / secret key কখনো** অ্যাপ, APK, git, `.env.example` বা চ্যাটে যাবে না।
* Google **Client Secret** বসবে শুধু Supabase ড্যাশবোর্ডে (বা CI-র গোপন ভাণ্ডারে)।
* ডাটাবেজ পাসওয়ার্ড পাসওয়ার্ড-ম্যানেজারে রাখুন।

---

## ধাপ ১ — লোকালে যাচাই (কোনো অ্যাকাউন্ট ছাড়াই)

দরকার: Node 18+, Docker Desktop (চালু), Supabase CLI (`npx supabase` যথেষ্ট)।

```bash
cp .env.example .env            # মান না বদলালেও চলবে
npx supabase start              # প্রথমবার ইমেজ নামাতে সময় লাগবে
npx supabase db reset           # supabase/migrations/*.sql ০০০১ → ০০০৫ ক্রমে প্রয়োগ
npm run db:test                 # pgTAP: supabase/tests/database/01_tenant_isolation.test.sql
npm run check:sql               # (Docker ছাড়াই) স্ট্যাটিক নিয়ম S1–S13
```

**প্রত্যাশা:** `db reset` ত্রুটি ছাড়া শেষ হবে; `db:test` প্রায় ১৪০টি assertion সব `ok` দেখাবে।

যদি `supabase start` Google-এর `env(...)` মান নিয়ে অভিযোগ করে: `supabase/config.toml`-এ `[auth.external.google]` অংশে সাময়িকভাবে `enabled = false` করুন (লোকাল পরীক্ষায় Google লাগে না), অথবা `.env`-এ নকল মান বসান।

**লোকাল ইমেইল:** `supabase start` একটি মেইল-ক্যাচার চালায় — OTP কোড http://127.0.0.1:54324 এ দেখা যায়।

যদি `db reset` বা টেস্ট ব্যর্থ হয় → ত্রুটির টেক্সট আমাকে পাঠান। Phase 3 শুরুর আগে এই ধাপ সবুজ হওয়া জরুরি, কারণ পরের সব কাজ এর ওপর দাঁড়াবে।

---

## ধাপ ২ — হোস্টেড Supabase প্রজেক্ট

1. https://supabase.com → **New project**। Region: **Singapore (ap-southeast-1)**। শক্তিশালী ডাটাবেজ পাসওয়ার্ড দিন (সংরক্ষণ করুন)।
2. টার্মিনালে:
   ```bash
   npx supabase login
   npx supabase link --project-ref <আপনার-project-ref>
   npx supabase db push            # ০০০১–০০০৫ মাইগ্রেশন প্রয়োগ
   ```
3. **Project Settings → API → Exposed schemas:** শুধু `public` রাখুন (`graphql_public` লাগবে না)। **`private` কখনো যোগ করবেন না** — Super Admin বুটস্ট্র্যাপ সেখানে থাকে।
4. **Project Settings → API:** `anon`/publishable key আর URL টুকে রাখুন (অ্যাপের জন্য; প্রকাশ্য)। `service_role` কোথাও কপি করবেন না।

## ধাপ ৩ — Authentication সেটিংস (ড্যাশবোর্ড → Authentication)

`supabase config push` চালালে `config.toml`-এর `[auth]` অংশ প্রয়োগ হয়; না চালালে হাতে সেট করুন:

| ড্যাশবোর্ডের জায়গা | মান | কেন |
|---|---|---|
| Sign In / Providers → **Email** | Enable; **Confirm email = ON**; Secure password change ON; Minimum length **10** | নিরাপদ Account Linking-এর পূর্বশর্ত — ইমেইল যাচাই ছাড়া কেউ অন্যের ইমেইল আগেই নিবন্ধন করে রাখতে পারবে না |
| Email → OTP | দৈর্ঘ্য **৬**, মেয়াদ **৬০০ সেকেন্ড** | আপনার শর্ত: ৬ সংখ্যা + মেয়াদ |
| Email → Minimum interval | **60 সেকেন্ড** | Resend rate limit |
| **Rate Limits** | email sent ৪/ঘণ্টা (শুরুতে), sign-ins ৩০, token verifications ৩০ | ব্রুট-ফোর্স/OTP-স্প্যাম প্রতিরোধ |
| **URL Configuration** | Site URL = আপনার HTTPS ডোমেইন; Redirect URLs তে: `https://<ডোমেইন>`, `http://localhost:5173`, `com.wholesalepos.app://auth/callback` | Google/ইমেইল লিংকের রিডাইরেক্ট |
| **Multi-Factor** | TOTP: Enroll ও Verify দুটোই **Enabled** | Super Admin MFA |
| **Email Templates** | `supabase/templates/*.html` থেকে Confirm signup, Magic Link, Reset Password-এ পেস্ট; Subject বাংলায় | OTP ইমেইল বাংলায় |
| **SMTP Settings** | নিজের SMTP (Resend/Brevo/SendGrid…) | বিল্ট-ইন মেইলার শুধু পরীক্ষার জন্য, সীমিত |
| Sessions | (Pro প্ল্যানে) timebox/inactivity | সেশন মেয়াদ |

### Google লগইন

1. Google Cloud Console → **APIs & Services → OAuth consent screen** (External) সম্পূর্ণ করুন।
2. **Credentials → Create OAuth client ID → Web application**। **Authorized redirect URIs** এ বসান Supabase-এর দেখানো URL: `https://<project-ref>.supabase.co/auth/v1/callback` (Authentication → Providers → Google পাতায় দেখা যায়)।
3. Client ID ও Client Secret নিয়ে Supabase → Providers → **Google** → Enable → বসান। **Secret অন্য কোথাও রাখবেন না।**
4. Android-এর জন্য (Phase 7): আলাদা **Android** OAuth ক্লায়েন্ট — Package name `com.wholesalepos.app` ও আপনার (debug এবং release) কিস্টোরের **SHA-1**।

---

## ধাপ ৪ — Super Admin তৈরি (নিরাপদ বুটস্ট্র্যাপ)

পাবলিক নিবন্ধন থেকে কেউ নিজেকে Super Admin বানাতে পারে না: `platform_admins` টেবিলে API-র কোনো অধিকার নেই, আর বুটস্ট্র্যাপ ফাংশনটি `private` স্কিমায় (API-তে প্রকাশিত নয়)।

1. নিজের ইমেইল দিয়ে অ্যাপে/Auth-এ নিবন্ধন করুন ও **ইমেইল যাচাই** করুন (লগইন UI আসছে Phase 3-এ; তার আগে Dashboard → Authentication → Users → *Add user* দিয়ে "Auto Confirm" সহ তৈরি করতে পারেন)।
2. **SQL Editor** এ (এটি `postgres` রোলে চলে):
   ```sql
   select private.grant_super_admin('আপনার@ইমেইল');
   ```
3. MFA বাধ্যতামূলক: Super Admin ক্ষমতা (`is_platform_admin()`) শুধু **aal2** (TOTP যাচাইকৃত) সেশনে সক্রিয়। MFA-নিবন্ধনের স্ক্রিন Phase 3-এ আসছে।
4. **Authenticator হারালে:** SQL Editor-এ
   ```sql
   delete from auth.mfa_factors where user_id = (select id from auth.users where email = 'আপনার@ইমেইল');
   ```
   (প্রয়োজনে সাময়িকভাবে `update public.platform_settings set value = 'false'::jsonb where key = 'security.super_admin_require_mfa';` — **কাজ শেষে অবশ্যই `true` করুন**।)
5. অতিরিক্ত অ্যাডমিন: একই ফাংশন আবার কল। বাদ দিতে: `select private.revoke_super_admin('…');` (শেষ অ্যাডমিনকে সরানো যায় না)।

---

## ধাপ ৫ — যাচাই-তালিকা (হোস্টেড প্রজেক্টে, SQL Editor-এ)

```sql
-- ১. RLS ছাড়া কোনো টেবিল নেই (ফলাফল: ০ সারি)
select c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity;

-- ২. API ভূমিকাগুলোর কোনো টেবিলে লেখার অধিকার নেই এমন "টাকার" টেবিল (ফলাফল: ০ সারি)
select table_name, privilege_type from information_schema.role_table_grants
where table_schema = 'public' and grantee in ('anon', 'authenticated')
  and table_name in ('invoices','payments','stock_movements','sales_returns','purchases','audit_logs')
  and privilege_type <> 'SELECT';

-- ৩. OTP/টোকেন সাধারণ লেখায় সংরক্ষিত নয় (ফলাফলে ৬ অঙ্কের মান দেখলে আমাকে জানান)
select length(confirmation_token) as len from auth.users where confirmation_token <> '' limit 5;

-- ৪. প্ল্যান দুটি আছে
select code, max_businesses, max_employees_per_business from public.plans;
```

অ্যাপ ছাড়া বাইরে থেকে পরীক্ষা (anon key দিয়ে — প্রত্যাশা: ফাঁকা বা অনুমতি-নেই):
```bash
curl "https://<ref>.supabase.co/rest/v1/products?select=id" -H "apikey: <publishable-key>"
curl "https://<ref>.supabase.co/rest/v1/platform_admins?select=*" -H "apikey: <publishable-key>"
```

---

## ধাপ ৬ — ডাটাবেজ ব্যাকআপ কৌশল

* Supabase-এর স্বয়ংক্রিয় দৈনিক ব্যাকআপ পেইড প্ল্যানে; PITR আলাদা অ্যাড-অন। **ফ্রি প্ল্যানে ধরে নিন কোনো ব্যাকআপ নেই।**
* সাপ্তাহিক (বা প্রতিদিন) `pg_dump` চালিয়ে এনক্রিপ্ট (`age`/`gpg`) করে অন্য জায়গায় রাখুন; কানেকশন স্ট্রিং `.env`-এ, গিটে নয়:
  ```bash
  pg_dump "$SUPABASE_DB_URL" --format=custom --file=pos-$(date +%F).dump
  ```
* মাসে একবার **রিস্টোর অনুশীলন** করুন (লোকাল `supabase start`-এ) — না করা ব্যাকআপ ব্যাকআপ নয়।
* প্রতি ব্যবসার নিজস্ব এনক্রিপ্টেড JSON ব্যাকআপ (Phase 5/6) এর বাইরে এটি প্ল্যাটফর্ম-স্তরের নিরাপত্তা।

## ধাপ ৭ — অ্যাপে ক্লাউড চালু করা (ধাপ ১–৫ সবুজ হওয়ার পরে)

1. **আগে ব্যাকআপ নিন** (অ্যাপের Settings → Backup)। ক্লাউড মোডে প্রতি ব্যবসার *নতুন, আলাদা* লোকাল ডাটাবেজ খোলে (`wholesale-pos:<ব্যবসা-আইডি>`); আপনার বর্তমান ডেটা পুরোনো ডাটাবেজেই অক্ষত থাকে কিন্তু ক্লাউড-মোডে দেখা যাবে না। পুরোনো ডেটা ক্লাউডে আমদানির টুল **Phase 5-এ** আসছে।
2. `js/cloud/config.js`-এ দুটি **প্রকাশ্য** মান বসান:
   ```js
   export const CLOUD_DEFAULTS = Object.freeze({
     url: 'https://<project-ref>.supabase.co',
     publishableKey: '<anon বা publishable key>',
   });
   ```
   `service_role`/secret key বসালে অ্যাপ চালুই হবে না (ইচ্ছাকৃত)।
3. `npm run build` → `www/` হোস্ট করুন (HTTPS)। Supabase-এর **Site URL / Redirect URLs**-এ সেই ঠিকানা থাকতে হবে (ধাপ ৩)।
4. প্রথম পরীক্ষা: অ্যাপ খুলুন → নিবন্ধন → ইমেইলের কোড → ব্যবসার আবেদন → (আপনি Super Admin হয়ে, MFA নিবন্ধন করে) অনুমোদন → POS।
5. ভাষা বদলে দেখতে: ঠিকানার শেষে `?lang=en`।
6. **নকল সার্ভারে** পুরো যাত্রা Supabase ছাড়াই চালাতে: `npm run test:e2e:cloud`।

## সাধারণ সমস্যা

| লক্ষণ | সম্ভাব্য কারণ |
|---|---|
| `db reset`-এ `permission denied for schema auth` / trigger তৈরি ব্যর্থ | মাইগ্রেশন `postgres` রোলে চালাতে হবে (CLI-তে স্বাভাবিক)। হাতে SQL Editor-এ চালালে সঠিক রোল আছে কি দেখুন |
| `unknown key` (config.toml) | CLI-র সংস্করণ ভিন্ন; লাইনটি মুছে ড্যাশবোর্ডে সেট করুন |
| pgTAP `function throws_ok(...) is not unique` | আমাকে সম্পূর্ণ ত্রুটি দিন — টেস্টের কল ঠিক করব |
| লগইনের পর `42501 permission denied` | `select * from products` এর বদলে কলাম-তালিকা দিন (`cost_price` লুকানো — `docs/CLOUD-DATABASE.md` দেখুন) |

# Database design

The app stores data in **IndexedDB** (database `wholesale-pos`) — local, transactional, offline.
The same model as a relational schema is in [`../db/schema.sql`](../db/schema.sql) (validated in SQLite).

## Entities

| Store / table | Purpose | Notable fields |
|---|---|---|
| `users` | Admin and employee accounts | `role`, salted PBKDF2 password hash, optional PIN hash |
| `settings` | Business profile, printer, sync config | key → value |
| `meta` | Counters (invoice sequence per device and day) | key → value |
| `categories` | Product categories | unique name |
| `products` | Catalogue and live stock | `stock`, `lowStockLevel`, `active` (archived when it has sales history) |
| `customers` | Customer directory | unique normalised `phone` |
| `invoices` | Sales header | `id` (UUID), `invoiceNo` (unique), `subtotal`, `discount`, `total`, `paid`, `due`, `status`, `syncStatus` |
| `invoiceItems` | Sale lines | `line` (order), `qty`, `unitPrice`, `total` + name/unit/cost snapshot |
| `payments` | Money received against a customer’s due | `amount`, `syncStatus` |
| `stockMovements` | Append-only stock log | `type` (initial / sale / void / adjustment), signed `qty`, resulting `balance` |

## Relationships

```
customers 1──* invoices 1──* invoiceItems *──1 products 1──* stockMovements
customers 1──* payments            categories 1──* products
```

## Money rules (enforced in code and as SQL CHECKs)

```
line total  = qty × unitPrice            (unit price typed per sale)
subtotal    = Σ line totals
total       = subtotal − discount        (0 ≤ discount ≤ subtotal)
due         = total − paid               (0 ≤ paid ≤ total)
customer balance = Σ due of active invoices − Σ payments
```

A sale with `due > 0` requires a saved customer (no credit for walk-ins).

## Indexes

Defined in `SCHEMA` (`js/core/db.js`): invoices by `date`, `month`, `customerId`, `syncStatus`, unique `invoiceNo`; items by `invoiceId`, `productId`; products by name, category, SKU; customers by name and phone; payments by customer, date, `syncStatus`; movements by product and time.

## Migrations

`DB_VERSION` in `db.js`. Adding stores/indexes is automatic on upgrade; transforming existing rows goes in `MIGRATIONS` (`{version, up(tx)}`).

## Backup format

`exportDatabase()` writes JSON `{format:'wholesale-pos-backup', version, exportedAt, stores:{<store>:[rows]}}`.
Import validates the format, version and store names **before** touching any data, then replaces all stores in one transaction.

## Moving to SQLite

Implement the same API as `js/core/db.js` (`run(stores, mode, fn)` with `get/put/add/delete/getAll/getAllByIndex/count…`) on top of e.g. `@capacitor-community/sqlite`, using `db/schema.sql` for DDL. No service or UI code needs to change.

## v2 additions

| Store / table | Purpose |
|---|---|
| `users.permissions`, `users.last_login_at`, role `manager` | custom permission lists, last sign-in, Manager role |
| `invoice_items.line` | entry order of lines (stable receipt / sheet order) |
| `auditLog` / `audit_log` | activity log (newest 5 000 kept) |
| `syncLog` / `sync_log` | one row per sync / verify run (newest 200 kept) |
| `meta` keys `catsync:*` | hash of the last confirmed product / customer upload |
| `wholesale-pos-backups` (separate DB) | automatic backup snapshots |

IndexedDB `DB_VERSION` is 2; the upgrade only adds the new stores/indexes, so existing data is kept.

## Version 3 (IndexedDB version 3)

Additive only — the upgrade adds stores, indexes and fields and **never deletes or rewrites existing business data**.

* **`stockMovements` is append-only.** New fields: `previousStock`, `refNo`, `userId`, `unitCost`, `supplier`, `batchNo`, `opKey`
  (unique), `date` (Asia/Dhaka day), and new types `created`, `receive`, `return`, `damage`. Every stock change goes through
  `services/stockledger.js::recordMovement`, inside the same transaction as the business operation (sale, void, return, delivery…).
  Rows are never edited or deleted — not even when a product is "deleted" (it is archived).
* **`salesReturns`** (new): goods taken back, with the credit applied to the customer's due and the cash refund.
* **Idempotency keys**: `invoices.requestId`, `payments.requestId`, `salesReturns.requestId`, `stockMovements.opKey` are unique indexes — the same
  operation submitted twice (double tap, crash retry, two tabs) is saved once.
* **Customers / products** get a short `code` (C-0001 / P-0001, device code inside when set). Invoices get `rev`, `paymentMethod`; payments get `method`.
* **Migration 2 → 3** fills `previousStock` (= balance − qty), `date` (Dhaka day of the stored time) and `refNo` (from "Sale/Void INV-…") on
  old movement rows and assigns codes oldest-first. It invents no history rows. Tested by building a real version-2 database and opening it.
* **Customer balance** = Σ due of active invoices − Σ payments − Σ credit applied by returns (computed from the transactions every time; one
  function, `computeBalances`, is used everywhere). `docs/REPORTS.md` explains the report figures.
* **Time.** `createdAt` etc. are UTC instants; `date` / `time` / `month` are Asia/Dhaka business time; screens show Asia/Dhaka.
* **Money.** At most 2 decimals, quantities 3. Rounding works on the decimal text (`1.005 → 1.01`), amounts are added in whole paisa, line totals use scaled
  integers (`core/money.js`). Garbage input ("abc", "1e3", NaN) is rejected instead of becoming 0; Bengali digits are understood.

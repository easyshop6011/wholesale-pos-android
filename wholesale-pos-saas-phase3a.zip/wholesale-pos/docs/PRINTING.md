# Printing (80 mm thermal)

![80 mm receipt](screenshots/receipt-80mm.png)

## Pipeline

```
invoice + lines + settings
        │  buildReceiptModel()               js/printing/receipt.js
        ▼
   receipt model (neutral: business, meta, lines, totals, footer)
        │
        ├── Raster mode (default)  renderReceiptCanvas() → 1-bit bitmap → GS v 0 bands
        │       pixel-perfect: logo, bold/large totals, any language (Bengali, Arabic …)
        └── Text mode              buildTextReceipt() → ASCII ESC/POS, 48 columns
                fastest and smallest; ASCII only (৳ prints as "Tk")
        │
        ▼
   ESC/POS bytes  (init · align · size · cut · optional drawer pulse · N copies)
        │
        ▼
   transport.send(bytes)                      js/printing/printer.js
```

Paper: 80 mm @ 203 dpi = **576 printable dots** (setting *Paper width dots*; use 512 for some models, 384 for 58 mm).
Receipt contents: logo, business name/address/phone, invoice number, date & time, cashier, customer name and phone,
numbered lines (`qty unit × unit price … line total`), subtotal, discount, **grand total**, paid, **due**,
previous due and total due (optional), footer message, `** VOID **` banner for voided invoices.

## Transports (Settings → Printer)

| Transport | Where it works | Printer connection | Notes |
|---|---|---|---|
| **Bluetooth / USB — Android app (direct)** `native` | The Android APK | Paired Bluetooth-classic (SPP) **and** USB-OTG printers | Recommended for Android. No internet, no extra app. Uses `android-plugin/ThermalPrinterPlugin.java`. |
| Web Bluetooth `webbluetooth` | Chrome/Edge (Android, desktop), HTTPS | BLE printers | Chrome shows a device picker; GATT services of common printers are pre-listed. |
| WebUSB `webusb` | Chrome (Android with OTG cable, desktop), HTTPS | USB printers | Needs the printer to expose a vendor/printer-class interface. |
| Web Serial `webserial` | Desktop Chrome/Edge | USB-serial or paired Bluetooth COM ports | |
| RawBT app `rawbt` | Android browser | Any Bluetooth / USB / LAN printer set up in the free RawBT app | Use *Text mode* (intent size limit). |
| Native BLE `capble` | APK with `@capacitor-community/bluetooth-le` | BLE printers | Optional alternative to `native`. |
| System print dialog `browser` | Everywhere | Any installed printer / Android print service | Fallback; prints the receipt image at exactly 80 mm wide. |

All transports are **offline**: nothing in the print path touches the network.

## Using it

**Android app** — pair the printer in Android *Settings → Bluetooth* (PIN usually `0000` or `1234`), or plug a USB printer with an OTG cable → open *Settings → Printer* → transport **Bluetooth / USB — Android app** → **Choose printer** → **Test print**. The choice is remembered.

**Android Chrome (no APK)** — Web Bluetooth (BLE printers) or WebUSB, or install RawBT and pick *RawBT*.

**New Sale → Save & Print** saves the invoice first (so it is never lost), then prints. *Print* / *Preview* are also available on the “Invoice saved” dialog and on every invoice in *Invoices*. Copies, automatic printing after save, cutting and the cash-drawer pulse are settings.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Garbled characters / `?` | Use *Raster* mode (any language) or keep Text mode to ASCII. |
| Receipt cut off on the right | Lower *Paper width dots* (576 → 512). |
| Blank lines/tail too long or short | Adjust *Blank lines before cutting*. |
| BLE printer prints partially | Lower the *Bluetooth chunk size* (20–60) or raise the *delay between chunks*. |
| “Could not connect” (native) | Printer off, out of range, or not paired in Android settings; grant the *Nearby devices* permission. |
| Web Bluetooth/USB option missing | Page must be HTTPS or `localhost`, in Chrome/Edge. |

## Adding a printer type

Push an object with `id`, `label`, `supported()`, `name()`, `connect()`, `send(bytes)`, `disconnect()` onto `TRANSPORTS`. The pipeline above does the rest.

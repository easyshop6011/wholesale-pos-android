# Reports & graphs

*Reports* has one tab per question. Every tab honours the period picker (Today · 7 / 30 / 90 days · This month · Last month · This year · Custom), can be exported to **CSV** (UTF-8 with BOM, Bengali-safe) and printed.

| Tab | Answers | Highlights |
|---|---|---|
| Overview | How are we doing? | KPI tiles (sales, invoices, average invoice, cash collected, due created, gross profit*) each with a ▲/▼ badge against the **previous period of the same length**; sales + cash line chart; top products; sales by category donut; where the money went |
| Sales | Trend over time | Auto day / week / month grouping (or choose), bar chart, 12-month line, table with totals |
| Products | What sells? | Top-10 revenue bars, category donut, full table (qty, invoices, average price, revenue, profit*) |
| Customers | Who buys, who owes? | Top customers; **due ageing** 0–30 / 31–60 / 61–90 / 90+ days (payments are applied to the oldest invoices first) with chart and per-customer table |
| Profit* | Are we making money? | Net revenue, cost, profit, margin, discounts given, profit by day, most profitable products; warns about sold lines with no cost price |
| Staff | Who sold what? | Sales, invoices, average invoice, discounts, dues created and voids per cashier |
| Busy hours | When is it busy? | Sales by hour of day + heat strip |
| Inventory | What do I hold, what to re-order? | Stock value (cost / retail), **re-order suggestions** from the last 30 days' sales (days of stock left, quantity to buy for 14 days of cover), full stock table |
| Daily sheet | One day's invoices | Opens invoices; cash collected and due created |

\* needs the **See cost and profit figures** permission (`reports.profit`).

## How it is built

* `js/services/reports.js` — pure data functions (`salesTrend`, `periodSummary`, `profitReport`, `dueAging`, `reorderSuggestions` …). Empty days/weeks/months are zero-filled so chart axes are continuous. The dashboard result is cached per day and cleared on any data change (`js/core/cache.js`).
* `js/ui/chart-math.js` — geometry (nice axis scales, paths, donut arcs, label spacing); unit-tested in Node.
* `js/ui/charts.js` — dependency-free SVG charts that follow the theme, resize with their container, show a tooltip on hover/touch and include a hidden data table for screen readers.
* To add a report: write a service function, add a tab function in `views/reports.js` that returns a DOM node (and sets `csv`).

## Sales returns (version 3)

*Sales* stays the value **invoiced**. Returns are shown next to it: the daily and monthly reports and the dashboard carry `returnsValue`
(and `netAfterReturns`, `refunds`); **cash collected** is reduced by cash refunds; the **profit** report and **product sales** report subtract the returned
goods (revenue and cost) in the period the return happened; **due ageing** treats credit from returns like a payment. The remaining analytics (trend, top customers,
category share, staff, busy hours) show invoiced sales and do not deduct returns.

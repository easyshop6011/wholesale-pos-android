# Search & filters

## Global search
Press **Ctrl/⌘ + K** (or tap *Search* in the top bar) and type: products (name, SKU, category), customers (name, phone, address) and invoices (number, customer, phone) appear together; ↑/↓ + Enter opens the match. Results you may not open (by permission) are not shown.

## Rules (`js/core/search.js`)
* Case and accents are ignored.
* **Bengali digits equal ASCII digits** — `০১৭১১` finds `01711…`; phone numbers match in any format.
* Several words must **all** match, in any order — `rice 25` finds *Basmati Rice 25kg*.
* Results are ranked: exact > starts-with > word-starts-with > contains; earlier fields (name) count more than later ones (SKU, category).

## Filter bars
| Screen | Filters | Sort |
|---|---|---|
| Invoices | period (incl. custom dates), payment (paid / has due / unpaid / partly paid), total range, status, sync state, cashier | newest, oldest, highest/lowest total, highest due |
| Products | category, stock (needs attention / low / out / in stock), price range | name, stock, price, newest |
| Customers | owes money / no due, due at least, not bought in 30/60/90 days | name, highest due, top buyers, recent, longest inactive |

Active filters appear as removable chips with *Clear all*. Lists show the number of matches and totals for **all** matches, and page through results (50–60 per page). Dashboard tiles and the palette link into pre-filtered lists (e.g. `#/customers?due=has`).

Service functions: `queryInvoices`, `listProducts`, `listCustomers`, `globalSearch` — all accept the same filter objects, so new screens or exports can reuse them.

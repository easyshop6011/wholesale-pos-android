# Security notes

| Area | What is done | Limits |
|---|---|---|
| Passwords & PINs | Salted **PBKDF2-SHA256** (150 000 iterations) via WebCrypto; salted iterated-SHA-256 fallback on plain-http hosts. Never stored in clear text. | A short PIN is inherently guessable — see throttling. |
| Brute force | 5 failures → 30 s cool-down, doubling thereafter. The last active admin cannot be disabled. | Throttling is client-side. |
| PIN lock | Screen lock for shared counters; auto-locks after idle time. | **Not encryption.** Someone with access to the unlocked device’s browser/app storage can read the local database. Use the device’s own screen lock and storage encryption (default on modern Android). |
| Roles | Administrator / Manager / Cashier plus per-user custom permissions (`PERMISSION_LIST`, `effectivePermissions` in `auth.js`), enforced for routes and actions. Every sign-in, user switch, void and stock change is written to the activity log. | Roles protect the UI, not the raw device storage. |
| Sync endpoint | Every request needs the shared secret (`POS_TOKEN`); constant placeholder is refused; writes run under a script lock. | Keep the token private; rotate it by changing the script property and the app setting. The token is stored in the local settings. |
| Sheets injection | Text beginning `= + - @` is escaped in Sheets and CSV exports. | |
| Backups | Import validates format, version and store names before writing. Backup files contain **all data including password hashes** — store them privately. | Backup files are not encrypted. Automatic snapshots stay on the device (separate database) and are as sensitive as a backup file. |
| Service worker | Only the app’s own static files are cached; no API responses. | |
| Web server | `tools/serve.mjs` serves only the PWA files, never tests, tools or sources. | Development/LAN use; use a proper HTTPS host in production. |

Recommended: set a device screen lock, keep Android updated, export backups weekly, restrict the Google Sheet’s sharing to people who need it.

## Version 3 — permissions are enforced by the services, and what a client-only app cannot do

**What changed.** Hiding a button is not security. Every sensitive service function now starts with
`authorize('<permission>')` (`js/services/guard.js`), which refuses unless a user is **signed in, not on the PIN lock
screen, and holds that permission**. The signed-in user — not a `user` argument supplied by the caller — is who gets
recorded as the author of a sale, void, payment, return or stock change. Refused attempts are written to the activity
log as `security.denied` (Settings → Activity → *Denied attempts*).

| Area | Rule (enforced in the service) |
|---|---|
| Users | `createUser`, `updateUser`, `listUsers`: **administrator only**. Nobody can disable their own account; there is always ≥ 1 active administrator. First-run `setupAdmin` works only while **no** user exists (checked inside the transaction, so two simultaneous setups create one admin). |
| Credentials | `setCredentials`: own account, or an administrator for someone else — **and always requires the signed-in person's current password** (step-up check). Wrong confirmations are throttled like sign-in and logged. |
| Sales | `createInvoice` needs `pos`; `voidInvoice` needs `invoices.void` and a reason; `returnSale` needs `invoices.return`. |
| Stock | `saveProduct`/`deleteProduct` need `products.edit`; receive / correct / write off need `inventory.adjust`; reading the history needs `inventory.view` (purchase cost only with `reports.profit`). |
| Money / data | payments, customer edit: `customers`; delete customer: `customers.delete`; profit report: `reports.profit`; activity log: `audit`. |
| Settings, backup, restore, sync, snapshots | `settings` (printer settings: `printer`). |

Locked screen: `auth.can()` and `authorize()` return *no* permission while the PIN lock is showing.

**Limits that cannot be removed without a server.** The whole app — including these checks — runs inside the user's own
browser, and the data lives in that browser's IndexedDB.

* Anyone who can open the browser's developer tools on an **unlocked** device can read or edit IndexedDB directly and
  bypass every service check. The checks stop mistakes, other staff using the app, UI bugs and console misuse by people
  who are not developers — they do not stop an attacker who controls the device.
* Passwords and PINs are stored only as salted PBKDF2 hashes, but a 4–6 digit PIN can be brute-forced offline from a
  copy of the database. Treat the device (and every backup file) as sensitive; use the device screen lock and encrypted
  backups.
* The sign-in throttle is kept in `localStorage`, which the user can clear.
* If you need protection against the people who use the device, the data must move behind a server that checks
  permissions itself (the services are the only layer that would need re-implementing; see `db/schema.sql`).
* The Google Sheets token is a device setting. It is never written to backups, to the activity log, to the sync log or to
  on-screen messages (`redactSecrets` strips the token and any script URL from stored / shown errors).

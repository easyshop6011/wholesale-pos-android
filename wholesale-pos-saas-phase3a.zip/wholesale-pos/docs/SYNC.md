# Offline sync & Google Sheets

![Sync settings](screenshots/09-sync.png)

## Principle

The local database is the **source of truth**. A sale is complete the moment it is saved on the device. Uploading to Google Sheets is a background job that can be late, fail, or be retried without consequence.

```
 sale saved ──► invoice.syncStatus = 'pending'
                     │   (online event · app start · every 60 s · after each sale · "Sync now")
                     ▼
        batch of ≤15 oldest pending invoices ──POST──► Apps Script (locked)
                     │                                      │ unknown id  → insert rows → "inserted"
                     │                                      │ known id    → no insert   → "duplicate"
                     ▼                                      ▼
        mark 'synced' only for ids the server confirmed
        network error / timeout → stay 'pending' → retried later
        invalid record          → 'failed' (does not block the queue; "Retry failed" re-queues it)
```

## Why a duplicate is impossible

1. **Unique ID** — every invoice (and customer payment) gets a UUID when created.
2. **Confirm-then-mark** — a record becomes `synced` only after the server confirms it. If the app is killed mid-request, it simply stays `pending`.
3. **Server-side check** — the script stores the invoice ID in column K and, under a script lock, answers `duplicate` for any ID already present. A retry after a *lost response* therefore adds nothing; the client just marks it synced.
4. **Cross-tab guard** — a Web Lock prevents two open tabs from syncing simultaneously; the script lock covers two different devices.

Voiding an already-synced invoice updates its **Status** cell to `Void` (rows are kept for audit) — it never inserts again.

## Sheet layout

Tab **Invoices** — one row per product line:

| A | B | C | D | E | F | G | H | I | J |
|---|---|---|---|---|---|---|---|---|---|
| Invoice Number | Date | Time | Customer | Product | Quantity | Unit Price | Total | Paid | Due |

Extra columns for integrity/reporting: **K** Invoice ID (dedupe key) · **L** Status · **M** Customer Phone · **N** Discount · **O** Grand Total.

*Paid, Due, Discount and Grand Total are written on the invoice’s first row only*, so `SUM(I:I)` / `SUM(J:J)` are correct without double counting. Tab **Payments**: Payment ID, Date, Time, Customer, Phone, Amount, Note. Text cells beginning with `= + - @` are escaped to prevent spreadsheet formula injection.

## Setup (≈5 minutes)

1. Create a Google Sheet. **Extensions → Apps Script**; delete the sample code and paste `integrations/google-apps-script/Code.gs`.
2. **Project Settings → Script properties → Add** `POS_TOKEN` = a long random secret (20+ characters). *(Optional `SHEET_ID` if the script is not bound to the sheet.)*
3. **Deploy → New deployment → Web app** · Execute as **Me** · Who has access **Anyone** → *Deploy* → authorise → copy the **Web app URL**.
   (Anyone can reach the URL, but every request without the correct token is rejected.)
4. In the POS: **Settings → Sync** → paste URL and secret → **Test connection** → enable sync → **Sync now**.
5. After editing the script, use **Deploy → Manage deployments → Edit → New version**, otherwise the old code keeps running.

Several devices can share one sheet: give each a different **Device code** (*Settings → Invoices*) so invoice numbers never clash.

## Google Drive backup

The same web app stores full database backups in a **“POS Backups”** folder in *your* Drive (newest 60 kept). *Settings → Backup → Back up to Google Drive* / *Restore from Drive*. Requires the Apps Script to be authorised once (it asks for Drive access on first deploy).

## Status & troubleshooting

The header pill shows **Synced / N pending / Offline / Error**. *Settings → Sync* is the **Sync health** screen: a status headline, counts (waiting / need attention / catalog changes), the queue with each record's last error, the last 15 runs, and the buttons **Sync now**, **Retry failed**, **Verify uploads** and **Re-send catalog**.

| Message | Meaning / fix |
|---|---|
| Unauthorized: wrong or missing token | Token differs from `POS_TOKEN`, or the placeholder was left in `Code.gs`. |
| Unexpected response … deployed for “Anyone”? | Deployment access is not *Anyone*, or the URL is not the `/exec` Web app URL. |
| Timed out — will retry | Slow network; nothing is lost. |
| Rows missing after editing the script | Create a **new version** of the deployment. |

## Stronger sync (script v3)

Paste the new `integrations/google-apps-script/Code.gs`, then **Deploy → Manage deployments → Edit → New version**. The app negotiates capabilities with `ping`, so an older script keeps working (invoices/payments only) and the Sync screen tells you what to update.

* **Confirm-then-mark**: an invoice is marked *synced* only after the server answered for *that* id (`inserted` / `duplicate`). A rejected record is parked as *failed* with the reason; the rest of the batch continues.
* **Back-off with jitter**: after a failure the next automatic attempt waits 15 s, 30 s, 1 min … up to 15 min (randomised so several devices do not retry together). Going online, opening the app or pressing *Sync now* retries immediately. The batch size shrinks after timeouts and grows back after successes.
* **Verify uploads**: asks the sheet which already-synced invoices it really contains (`verifyInvoices`) and re-queues any that were deleted from the sheet.
* **Catalog sync**: products (with stock) and customers (with due) are upserted into *Products* / *Customers* tabs; a hash of each payload decides what changed, so only changes are sent. Switch off with *Also send products and customers*.
* **Sync log**: every run (sent / duplicates / catalog / rejected / time / error) is kept locally (newest 200).
* Background Sync API is deliberately not used: sync runs while the app is open (and when it comes back online), which works the same on every browser and in the Android app.

## Limits worth knowing

* Sync is **one-way** (device → Sheets). The sheet is a reporting/audit copy; editing it does not change the POS.
* Apps Script quotas apply (very large daily volumes: use more devices per sheet sparingly or archive old rows).
* Each device keeps its own local database; multi-device *live* stock sharing is not part of this version (see ARCHITECTURE → “Move to SQLite / a server”).

## Version 4 — safer sync (script v4 + app)

Re-paste `integrations/google-apps-script/Code.gs` and *Deploy → Manage deployments → Edit → New version*. The app works
with an older script too (it shows a notice and keeps what the old script cannot take — e.g. returns — queued).

* **Revisions.** Every invoice has a revision (`rev`, +1 when voided). The script ignores a copy that is not newer than what the sheet
  holds, so a late retry can never turn a Void back into Active; sending the same invoice or the same void twice changes nothing.
* **Changed while uploading.** If an invoice is voided *during* its own upload, the response no longer marks it synced — the void
  is sent next (tested against the real script code).
* **Lost responses and failures.** The script's dedupe is by invoice id, so after a timeout, a dropped connection or a crash the
  retry is recognised as "duplicate" — never inserted twice. A failure leaves records `pending`; automatic retries back off.
* **Quota / rate limits.** If Google answers "too many times / quota / 429" the app waits **at least 30 minutes** before trying
  automatically (the *Sync now* button still works).
* **Returns** go to a new **Returns** tab (deduplicated by Return ID). Payments and invoices now carry the payment method.
* **Two devices.** Invoices cannot clash (UUID ids). The script refuses a *reused invoice number* from a different invoice (two devices
  with the same *Device code*) as a `conflict`; the app parks it as *failed* with a clear message and carries on. **Give every device
  its own Device code.** Stock is per device: if the script sees a product's stock written by a *different* device with a different
  number, it still takes the newest write but tells the app, which shows a warning. A real shared live stock across devices needs a
  server and is **not** part of this version.
* **Secrets.** The token and the script URL are removed from every message that is stored or shown.
* **Summing the sheet.** Voided invoices stay (audit). Use `=SUMIFS(O:O, L:L, "Active")` for sales and subtract the Returns tab.
* **Sheet limits.** Apps Script allows ≈ 6 minutes per run and daily quotas; the script refuses requests with more than 500 records.

# UI design

Modern, calm and fast to use at a busy counter. One responsive layout: **sidebar on tablets/desktop, bottom navigation on phones**.

## Principles

* **Counter speed first** — the New Sale screen needs only: pick customer → add products → type qty and price → Paid → *Save & Print*. Numeric fields open the numeric keypad; amounts are right-aligned; *Full* / *None* buttons fill Paid.
* **Prices are always typed** (every customer differs). The product’s default price and the customer’s *last price* are only tap-to-fill hints.
* **Money is colour-coded** — due in red/amber, settled in green; low stock is flagged on the dashboard, in Products and in Inventory.
* **Big touch targets** (≥ 44 px), clear focus rings, labels on every field, `prefers-reduced-motion` respected.
* **Design tokens** in `css/app.css` (`--primary`, `--surface`, `--radius`, spacing scale) — restyle the whole app by editing a dozen variables.

## Screens

| Screen | Purpose |
|---|---|
| Dashboard | KPI tiles with trend badges and sparkline, 7/30-day sales chart, top products, low stock, recent invoices |
| New Sale | Customer (or walk-in), product lines, discount, paid, due, Save / Save & Print |
| Invoices | Search + filter bar (period, payment, amount range, cashier, sync…), sort, paging with totals, open, re-print, void |
| Customers | Search by name or phone, add/edit. Opening a customer shows the **full profile**: totals, due, complete history (every invoice with its products, every payment with its method, returns, voids with reason), date filter, CSV, printable statement, *New sale*, *Receive payment* |
| Products | Search, category filter, add/edit/delete, stock and low-stock level |
| Inventory | Stock levels; **Receive** a delivery, **Correct** a count, **Damaged** goods; link to the full history |
| Stock History | **Every** stock change of every product with exact Asia/Dhaka date & time — filters (date, product, kind, user, text), CSV, print; a product's own page shows its complete history |
| Reports | Overview · Sales · Products · Customers · Profit · Staff · Busy hours · Inventory · Daily sheet — see REPORTS.md |
| Settings | Business · Printer · Invoices · Sync (health) · Backup (automatic) · Users · Activity · Appearance · My account |

| Desktop / tablet | Phone |
|---|---|
| ![dashboard](screenshots/02-dashboard-empty.png) | ![dashboard](screenshots/phone-dashboard.png) |
| ![invoice](screenshots/06-invoice-detail.png) | ![customers](screenshots/phone-customers.png) |
| ![reports](screenshots/08-reports-inventory.png) | ![reports](screenshots/phone-reports.png) |
| ![customer profile](screenshots/07-customer.png) | ![customer profile on a phone](screenshots/phone-customer-profile.png) |
| ![stock history](screenshots/07d-stock-history-page.png) | ![stock history on a phone](screenshots/phone-stock-history.png) |
| ![product history](screenshots/07b-stock-history.png) | ![product page on a phone](screenshots/phone-product-history.png) |
| ![Bengali customer profile, shop time shown while the device is in another zone](screenshots/bn-customer-profile.png) | ![Bengali receipt](screenshots/bn-receipt-80mm.png) |

## Speed and polish

* **Theme**: *Settings → Appearance* — Match device / Light / Dark, applied before first paint (`js/ui/appearance.js` + a 3-line script in `index.html`). Colours are tokens in `css/app.css`; charts use `--c1…--c6` in `css/charts.css`.
* **Density**: Comfortable or Compact (more rows per screen).
* **Perceived speed**: skeleton placeholders while a screen loads, other screens are pre-loaded when the browser is idle, bursts of data changes repaint once (debounce), long lists are paged, results arrive in order (stale searches are dropped).
* **Global search**: Ctrl/⌘ + K or the Search button — products, customers, invoices in one box.

## Components (`js/ui/components.js`)

`filterBar` (search + selects + dates + “More filters” + removable chips), `pager`, `skeleton`, `debounce`, `charts.js` (`lineChart`, `barChart`, `hBars`, `donut`, `sparkline`, `delta`), 

`openModal`, `confirmDialog`, `toast`, `field`, `select`, `segmented`, `badge`, `emptyState`, `pageHeader`, `downloadFile`, `pickFile`, plus a sortable table (`table.js`) and DOM helper `h()` (`dom.js`). Build new screens from these to stay consistent.

## Accessibility

Semantic buttons/labels/tabs, visible focus, sufficient contrast, no information by colour alone (badges carry text), keyboard operable dialogs.

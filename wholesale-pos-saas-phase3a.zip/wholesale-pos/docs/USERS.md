# Users, roles & activity

## Roles
| Role | Default permissions |
|---|---|
| Administrator | everything, including settings, sync, backup and users |
| Manager | sales, invoices (+ void), customers, products (view + edit), inventory (view + adjust), reports incl. profit, activity log, printer |
| Cashier (stored as `employee`) | sales, invoices, customers, view products and stock, printer |

*Settings → Users → Edit → Customise what this user can do* replaces the role defaults with a tick-list grouped as Sales · Customers · Stock · Management · Administration (`PERMISSION_LIST` in `auth.js`). Administrators always have everything; the last active administrator cannot be removed or disabled.

## Shared counters
* Each person has their own **password** (sign-in) and **PIN** (quick unlock).
* On the lock screen tap another person's name and enter *their* PIN to **switch user** without signing out — every invoice, void and stock change is attributed to the person who did it (`createdBy`, shown in *Reports → Staff*).
* PIN attempts are throttled (5 failures → 30 s, doubling).

## Activity log (*Settings → Activity*, permission `audit`)
Sign-ins, failed sign-ins, user switches, voided invoices, stock adjustments, user changes. Search, filter by type / user / date. The newest 5 000 entries are kept (`AUDIT_KEEP`).

To log a new action call `logAction('thing.done', { target, detail })` from a service.

## Version 3 — permissions

New keys: `invoices.return` (take goods back), and `inventory.adjust` now also covers receiving stock and writing off damaged
goods. Managers have both; cashiers have neither. Changing a password / PIN always asks for **your own password**; only an
administrator can create users, change roles / permissions or reset someone else's credentials; nobody can disable themselves.
See `docs/SECURITY.md` for what is enforced where.

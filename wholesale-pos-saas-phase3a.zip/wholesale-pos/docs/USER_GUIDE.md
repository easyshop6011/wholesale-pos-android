# User guide

## First start
1. Open the app. Enter business name, your name, a **password** (min 6) and an optional **quick-unlock PIN**. You become the **Admin**.
2. Tick *Load sample data* to practise, or start empty.
3. **Settings → Business**: logo, address, phone, footer message. **Settings → Printer**: connect and *Test print*.

## Make a sale
1. **New Sale** → *Select customer* (or leave *Walk-in*). A due amount needs a saved customer.
2. *Add product* → search/choose. Type **Qty** and **Unit price** for each line. Line total = Qty × Unit price.
3. Enter **Discount** (amount) and **Paid** (*Full* / *None* shortcuts). **Due** updates automatically.
4. **Save & Print** (or **Save**). Stock reduces automatically. The invoice number, date and time are added for you.

Works with **no internet**. A small pill at the top shows sync status; pending invoices upload automatically later.

## Customers & dues
*Customers* → open a customer: **Purchase history** and **Due history** tabs (ledger: each credit sale and each payment with running balance). **Receive payment** reduces the due; the payment is also synced.

## Products & stock
*Products*: add/edit/delete, category, search, low-stock level. Deleting a product that has sales **archives** it (history stays intact). *Inventory*: **Adjust stock** — add, remove or set to counted quantity, with a reason; everything is logged. Items at or below their low-stock level appear in the dashboard warning.

## Reports
*Reports* → Daily sales, Monthly sales, Customer dues, Product sales, Inventory. **Export CSV** on each.

## Security
* **Admin** can do everything. **Employee** can sell, manage customers, view products/stock and print — not reports, settings, void invoices or users.
* **Lock** (padlock) or auto-lock after idle time (default 5 min) → unlock with the PIN. 5 wrong attempts → a cool-down.
* Admins create employees in **Settings → Users**.

## Backup — do this
* **Settings → Backup → Export database** (a `.json` file) — store it off the device.
* **Import** restores a backup (replaces current data; the file is validated first).
* **Back up to Google Drive** (needs the Sync setup) — see [SYNC.md](SYNC.md).
* On Android, uninstalling the app or clearing its data **deletes the local database**.

## Voiding an invoice
Admin → *Invoices* → open → **Void** with a reason. Stock is restored, sales and dues are corrected, and the Google Sheet row shows *Void*.

## New in this version
* **Search everything**: press Ctrl/⌘ + K (or tap *Search*) and type a name, phone, SKU or invoice number.
* **Filters** on Invoices, Products and Customers — tap *More filters* for dates and amounts; tap a chip to remove a filter.
* **Reports** now have graphs and compare with the previous period; *Customers → Due ageing* shows who owes for how long; *Inventory → Re-order suggestions* tells you what to buy.
* **Automatic backup**: *Settings → Backup* — keep it on; you can restore any snapshot.
* **Several people**: add Managers and Cashiers in *Settings → Users*; on the lock screen tap a name and enter their PIN to switch.
* **Dark mode / compact view**: *Settings → Appearance*.
* **Sync health**: *Settings → Sync* shows what is waiting and why anything failed.

## New in version 3

**Customer profile** — *Customers → tap a customer.* Shows the customer's name, phone, address, short code and unique ID, **total purchases, total
paid, current due (or credit), number of invoices and the last purchase with date and time**. Below is the complete history, newest first: every sale
with its products (quantity, unit, price, discount share, net), the amount paid at the counter and how, every later payment (time, amount, bKash / cash …),
every return and every voided invoice with its reason, who and when. Filter by date, export **CSV** (opens in Excel with Bengali text intact) or **Print statement**.
*New sale* from the profile selects the customer automatically.

**Stock History** — *Stock History* in the menu (or *History* next to a product). Every change of every product with the exact date and time: new product,
opening stock, delivery, sale, void, customer return, count correction, damaged goods — with stock before, change, stock after, reason, invoice number and who did it.
Filter by date, product, kind of change and user; export CSV; print. Records are never edited or deleted — if a count was wrong you add a *correction*, which is a new row.
Open a product to see its own history. For products that existed before this version the history starts at the first recorded change (the earlier stock is shown as "not tracked", never invented).

**Receive stock / correct a count / damaged goods** — on *Inventory* or the product page. **Take goods back** — open the invoice → *Take goods back* (the goods return to stock;
what the customer owes is reduced first, only the rest is refunded). **Void** now needs a reason.

**Backups** — export with a passphrase (recommended). Write the passphrase down: without it the file cannot be opened.

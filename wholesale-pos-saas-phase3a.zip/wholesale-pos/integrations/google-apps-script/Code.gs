/**
 * Wholesale POS — Google Sheets + Drive receiver (Google Apps Script web app).
 *
 * SETUP (details in docs/SYNC.md)
 *  1. Create a Google Sheet. Extensions → Apps Script. Paste this file.
 *  2. Project Settings → Script properties → add  POS_TOKEN = <long random secret>.
 *     (Or edit CONFIG_TOKEN below — a Script Property is safer.)
 *  3. Deploy → New deployment → type "Web app" → Execute as: Me,
 *     Who has access: Anyone → copy the Web app URL.
 *  4. In the POS: Settings → Sync → paste URL + the same secret → "Test connection".
 *
 * GUARANTEES
 *  - Every invoice carries a unique ID (column K). An ID that is already in the
 *    sheet is NEVER inserted again (answer: "duplicate"), so retries are safe.
 *  - All writes run under a script lock, so two devices syncing at once cannot
 *    interleave or double-insert.
 *  - If an already-synced invoice is voided in the POS, its Status cell is
 *    updated to "Void" (the rows are kept for audit).
 *  - Products and customers are UPSERTED by id into the "Products" / "Customers"
 *    tabs (an existing row is updated in place, never duplicated).
 *  - "verifyInvoices" lets the app ask which invoice ids are really in the sheet.
 *  - Every invoice carries a REVISION. A copy older than what the sheet already holds
 *    is ignored, so a late retry can never turn a Void back into Active.
 *  - An invoice NUMBER already used by a DIFFERENT invoice id (two devices with the same
 *    "Device code") is refused with result "conflict" instead of silently producing two
 *    invoices with one number.
 *  - A product whose stock was last written by ANOTHER device is flagged "conflict" in
 *    the answer (the row is still updated — last writer wins; see docs/SYNC.md).
 *  - Sales returns go to the "Returns" tab, deduped by Return ID.
 *
 * SUMMING THE SHEET: voided invoices stay in the sheet for the audit trail. Use
 *   =SUMIFS(O:O, L:L, "Active")     (Grand Total of Active invoices)
 * and subtract the Returns tab (Return Value) when you want net sales.
 *
 * VERSION 4 — if you pasted an older version, paste this one over it and use
 * Deploy → Manage deployments → Edit → New version. The POS shows a notice
 * while the script is older than the app expects.
 */

const SCRIPT_VERSION = 4;
const CAPABILITIES = ['invoices', 'payments', 'backup', 'catalog', 'verify', 'returns', 'conflicts'];
const MAX_RECORDS = 500; // per request — a bigger request is refused instead of risking the 6-minute limit

// Fallback only. Prefer Script Properties → POS_TOKEN.
const CONFIG_TOKEN = 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET';

const SHEET_INVOICES = 'Invoices';
const SHEET_PAYMENTS = 'Payments';
const BACKUP_FOLDER = 'POS Backups';
const KEEP_BACKUPS = 60;

// Columns A–J are the ones requested; K–O are extras used for dedupe & audit.
const INVOICE_HEADERS = [
  'Invoice Number', 'Date', 'Time', 'Customer', 'Product', 'Quantity', 'Unit Price', 'Total', 'Paid', 'Due',
  'Invoice ID', 'Status', 'Customer Phone', 'Discount', 'Grand Total',
  'Payment Method', 'Revision', 'Void Reason', 'Voided At', // v4 (appended — older sheets keep working)
];
const PAYMENT_HEADERS = ['Payment ID', 'Date', 'Time', 'Customer', 'Customer Phone', 'Amount', 'Note', 'Method'];
const SHEET_RETURNS = 'Returns';
const RETURN_HEADERS = [
  'Return ID', 'Return Number', 'Date', 'Time', 'Invoice Number', 'Customer', 'Customer Phone', 'Product', 'Quantity', 'Unit Price',
  'Line Value', 'Return Value', 'Credit Applied', 'Refund', 'Refund Method', 'Reason',
];
// Columns kept as literal text per tab (ids, dates, times, names, phones) — numbers stay numeric.
const TEXT_COLUMNS = {
  Invoices: [1, 2, 3, 4, 5, 11, 12, 13, 16, 18, 19],
  Payments: [1, 2, 3, 4, 5, 7, 8],
  Returns: [1, 2, 3, 4, 5, 6, 7, 8, 15, 16],
  Products: [1, 2, 3, 4, 5, 10, 12, 13],
  Customers: [1, 2, 3, 4, 7],
};
const SHEET_PRODUCTS = 'Products';
const SHEET_CUSTOMERS = 'Customers';
const PRODUCT_HEADERS = ['Product ID', 'Name', 'SKU', 'Category', 'Unit', 'Cost Price', 'Default Price', 'Stock', 'Low Stock Level', 'Status', 'Updated', 'Code', 'Device'];
const CUSTOMER_HEADERS = ['Customer ID', 'Name', 'Phone', 'Address', 'Due', 'Updated', 'Code'];
const COL_NO = 1; // A  invoice number
const COL_ID = 11; // K
const COL_STATUS = 12; // L
const COL_REV = 17; // Q
const COL_VOID_REASON = 18; // R
const COL_VOIDED_AT = 19; // S
const PRODUCT_COL_STOCK = 8; // H
const PRODUCT_COL_DEVICE = 13; // M

/** Health check: open the web app URL in a browser to confirm deployment. */
function doGet() {
  return json_({ ok: true, service: 'wholesale-pos', time: new Date().toISOString() });
}

/** Single entry point for all POS requests (JSON body, text/plain). */
function doPost(e) {
  let lock = null;
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (!tokenOk_(body.token)) return json_({ ok: false, error: 'Unauthorized: wrong or missing token' });

    lock = LockService.getScriptLock();
    lock.waitLock(30000);

    switch (body.action) {
      case 'ping':
        return json_({ ok: true, message: 'pong', time: new Date().toISOString(), version: SCRIPT_VERSION, capabilities: CAPABILITIES });
      case 'upsertProducts':
        return json_({ ok: true, results: upsertRows_(SHEET_PRODUCTS, PRODUCT_HEADERS, limit_(body.products).map(productRow_), true) });
      case 'upsertCustomers':
        return json_({ ok: true, results: upsertRows_(SHEET_CUSTOMERS, CUSTOMER_HEADERS, limit_(body.customers).map(customerRow_), false) });
      case 'verifyInvoices':
        return json_({ ok: true, missing: missingInvoiceIds_(body.ids || []) });
      case 'syncInvoices':
        return json_({ ok: true, results: syncInvoices_(limit_(body.invoices)) });
      case 'syncPayments':
        return json_({ ok: true, results: syncPayments_(limit_(body.payments)) });
      case 'syncReturns':
        return json_({ ok: true, results: syncReturns_(limit_(body.returns)) });
      case 'backup':
        return json_({ ok: true, file: saveBackup_(String(body.name || 'pos-backup.json'), String(body.content || '')) });
      case 'listBackups':
        return json_({ ok: true, files: listBackups_() });
      case 'getBackup':
        return json_({ ok: true, content: getBackup_(String(body.id || '')) });
      default:
        return json_({ ok: false, error: 'Unknown action: ' + body.action });
    }
  } catch (err) {
    return json_({ ok: false, error: String((err && err.message) || err) });
  } finally {
    if (lock) {
      try { lock.releaseLock(); } catch (ignore) { /* not held */ }
    }
  }
}

// ---- helpers ---------------------------------------------------------------

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Compare the request token with the configured secret (refuses the placeholder). Never logs either value. */
function tokenOk_(token) {
  const props = PropertiesService.getScriptProperties();
  const secret = props.getProperty('POS_TOKEN') || CONFIG_TOKEN;
  if (!secret || secret === 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET') return false;
  if (typeof token !== 'string' || token.length !== secret.length) return false;
  let diff = 0; // constant-time comparison
  for (let i = 0; i < secret.length; i++) diff |= token.charCodeAt(i) ^ secret.charCodeAt(i);
  return diff === 0;
}

/** A request array, or an error if it is absurdly large. */
function limit_(list) {
  const arr = list || [];
  if (arr.length > MAX_RECORDS) throw new Error('Too many records in one request (max ' + MAX_RECORDS + ')');
  return arr;
}

/** A finite number (strings like "12.5" accepted), else NaN. */
function num_(v) {
  const n = typeof v === 'number' ? v : parseFloat(v);
  return isFinite(n) ? n : NaN;
}

/** Add any header cells that an OLDER version of this script did not write (never touches data rows). */
function ensureHeaders_(sh, headers) {
  const have = sh.getLastColumn() > 0 ? sh.getRange(1, 1, 1, Math.max(sh.getLastColumn(), 1)).getValues()[0] : [];
  for (let i = 0; i < headers.length; i++) {
    if (!have[i]) sh.getRange(1, i + 1).setValue(headers[i]).setFontWeight('bold');
  }
}

/** Spreadsheet bound to this script, or the one named in Script Property SHEET_ID. */
function spreadsheet_() {
  const id = PropertiesService.getScriptProperties().getProperty('SHEET_ID');
  return id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActiveSpreadsheet();
}

/** Get a tab, creating it (with header row + text formats) on first use. */
function sheet_(name, headers) {
  const ss = spreadsheet_();
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
    sh.setFrozenRows(1);
    // Keep IDs, dates, times and names as literal text so Sheets never reformats them.
    const textCols = TEXT_COLUMNS[name] || [1];
    textCols.forEach(function (c) { sh.getRange(1, c, sh.getMaxRows(), 1).setNumberFormat('@'); });
  } else {
    ensureHeaders_(sh, headers); // sheet made by an older script version: add the new column titles
  }
  return sh;
}

/** Stop spreadsheet formula injection from text typed at the POS (e.g. a customer named "=1+1"). */
function safe_(v) {
  const s = v === null || v === undefined ? '' : String(v);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

/** Existing ids in column `col` => array of row numbers. */
function indexIds_(sh, col) {
  const map = {};
  const last = sh.getLastRow();
  if (last < 2) return map;
  const vals = sh.getRange(2, col, last - 1, 1).getValues();
  for (let i = 0; i < vals.length; i++) {
    const id = String(vals[i][0]);
    if (!id) continue;
    (map[id] = map[id] || []).push(i + 2);
  }
  return map;
}

// ---- invoices --------------------------------------------------------------

/**
 * Insert new invoices (one row per product line) and skip ones already present.
 * Returns [{id, result: 'inserted' | 'duplicate' | 'updated' | 'invalid' | 'conflict'}].
 *  - known id, newer revision (e.g. now Void)    => 'updated' (status / revision / void details)
 *  - known id, same or OLDER revision            => 'duplicate' (nothing written)
 *  - new id but invoice number used by another id => 'conflict' (nothing written)
 */
function syncInvoices_(invoices) {
  const sh = sheet_(SHEET_INVOICES, INVOICE_HEADERS);
  const known = indexIds_(sh, COL_ID);
  const owner = numberOwners_(sh);
  const results = [];
  const rows = [];

  invoices.forEach(function (inv) {
    if (!inv || !inv.id || !inv.items || !inv.items.length || isNaN(num_(inv.total)) || isNaN(num_(inv.paid)) || isNaN(num_(inv.due))) {
      results.push({ id: inv && inv.id, result: 'invalid' });
      return;
    }
    const rev = isNaN(num_(inv.rev)) ? 1 : num_(inv.rev);
    if (known[inv.id]) {
      // Already uploaded: never insert again. Refresh status / revision / void details only if this copy is NEWER.
      const rowNums = known[inv.id];
      const storedRev = rowNums.length ? (num_(sh.getRange(rowNums[0], COL_REV).getValue()) || 1) : 1;
      const storedStatus = rowNums.length ? String(sh.getRange(rowNums[0], COL_STATUS).getValue()) : inv.status;
      const newer = rev > storedRev || (rev === storedRev && storedStatus !== inv.status && inv.status === 'Void');
      if (rowNums.length && newer) {
        rowNums.forEach(function (r) {
          sh.getRange(r, COL_STATUS).setValue(inv.status);
          sh.getRange(r, COL_REV).setValue(rev);
          sh.getRange(r, COL_VOID_REASON, 1, 2).setValues([[safe_(inv.voidReason), safe_(inv.voidedAt)]]);
        });
        results.push({ id: inv.id, result: 'updated' });
      } else {
        results.push({ id: inv.id, result: 'duplicate' });
      }
      return;
    }
    const taken = owner[String(inv.invoiceNo)];
    if (taken && taken !== inv.id) {
      results.push({ id: inv.id, result: 'conflict', message: 'Invoice number ' + inv.invoiceNo + ' is already used by another invoice' });
      return;
    }
    owner[String(inv.invoiceNo)] = inv.id;
    known[inv.id] = []; // also guards against the same id twice inside one batch
    inv.items.forEach(function (it, idx) {
      const first = idx === 0; // invoice-level money shown once per invoice so SUMs stay correct
      rows.push([
        safe_(inv.invoiceNo), safe_(inv.date), safe_(inv.time), safe_(inv.customer), safe_(it.name),
        it.qty, it.unitPrice, it.total,
        first ? inv.paid : '', first ? inv.due : '',
        inv.id, inv.status, safe_(inv.phone), first ? inv.discount : '', first ? inv.total : '',
        first ? safe_(inv.method) : '', rev, safe_(inv.voidReason), safe_(inv.voidedAt),
      ]);
    });
    results.push({ id: inv.id, result: 'inserted' });
  });

  if (rows.length) sh.getRange(sh.getLastRow() + 1, 1, rows.length, INVOICE_HEADERS.length).setValues(rows);
  return results;
}

/** invoice number => invoice id for every row already in the sheet. */
function numberOwners_(sh) {
  const map = {};
  const last = sh.getLastRow();
  if (last < 2) return map;
  const vals = sh.getRange(2, 1, last - 1, COL_ID).getValues();
  for (let i = 0; i < vals.length; i++) {
    const no = String(vals[i][COL_NO - 1]);
    const id = String(vals[i][COL_ID - 1]);
    if (no && id) map[no] = id;
  }
  return map;
}

// ---- verification ------------------------------------------------------------

/** Which of the given invoice ids are NOT present in the Invoices sheet? */
function missingInvoiceIds_(ids) {
  const known = indexIds_(sheet_(SHEET_INVOICES, INVOICE_HEADERS), COL_ID);
  return ids.filter(function (id) { return !known[String(id)]; });
}

// ---- products & customers (upsert by id) -------------------------------------

function productRow_(p) {
  return [p.id, safe_(p.name), safe_(p.sku), safe_(p.category), safe_(p.unit), p.costPrice, p.defaultPrice, p.stock, p.lowStockLevel, safe_(p.status), new Date(), safe_(p.code), safe_(p.device)];
}

function customerRow_(c) {
  return [c.id, safe_(c.name), safe_(c.phone), safe_(c.address), c.due, new Date(), safe_(c.code)];
}

/**
 * Insert a row for a new id, or overwrite the existing row of a known id.
 * Column 1 holds the id.
 * Returns [{id, result: 'inserted' | 'updated', conflict?: true}].
 * With `checkDevice` (products): if the row was last written by a DIFFERENT device and the
 * stock differs, the answer carries conflict:true — the row is still updated (last writer
 * wins) but the POS shows the user a warning.
 */
function upsertRows_(name, headers, rows, checkDevice) {
  const sh = sheet_(name, headers);
  const known = indexIds_(sh, 1);
  const results = [];
  const fresh = [];
  rows.forEach(function (row) {
    const id = String(row[0]);
    if (!id) return;
    if (known[id] && known[id].length) {
      let conflict = false;
      if (checkDevice) {
        const old = sh.getRange(known[id][0], 1, 1, headers.length).getValues()[0];
        const oldDevice = String(old[PRODUCT_COL_DEVICE - 1] || '');
        const newDevice = String(row[PRODUCT_COL_DEVICE - 1] || '');
        conflict = !!oldDevice && !!newDevice && oldDevice !== newDevice && Number(old[PRODUCT_COL_STOCK - 1]) !== Number(row[PRODUCT_COL_STOCK - 1]);
      }
      sh.getRange(known[id][0], 1, 1, headers.length).setValues([row]);
      results.push(conflict ? { id: id, result: 'updated', conflict: true } : { id: id, result: 'updated' });
    } else {
      known[id] = [];
      fresh.push(row);
      results.push({ id: id, result: 'inserted' });
    }
  });
  if (fresh.length) {
    sh.getRange(sh.getLastRow() + 1, 1, fresh.length, headers.length).setValues(fresh);
  }
  return results;
}

// ---- customer payments -----------------------------------------------------

/** Append customer due-payments to the "Payments" tab (deduped by Payment ID). */
function syncPayments_(payments) {
  const sh = sheet_(SHEET_PAYMENTS, PAYMENT_HEADERS);
  const known = indexIds_(sh, 1);
  const results = [];
  const rows = [];
  payments.forEach(function (p) {
    if (!p || !p.id) { results.push({ id: p && p.id, result: 'invalid' }); return; }
    if (known[p.id]) { results.push({ id: p.id, result: 'duplicate' }); return; }
    known[p.id] = [];
    if (isNaN(num_(p.amount))) { results.push({ id: p.id, result: 'invalid' }); return; }
    rows.push([p.id, safe_(p.date), safe_(p.time), safe_(p.customer), safe_(p.phone), p.amount, safe_(p.note), safe_(p.method)]);
    results.push({ id: p.id, result: 'inserted' });
  });
  if (rows.length) sh.getRange(sh.getLastRow() + 1, 1, rows.length, PAYMENT_HEADERS.length).setValues(rows);
  return results;
}

// ---- sales returns ----------------------------------------------------------

/** Append returned goods to the "Returns" tab (one row per product; deduped by Return ID). */
function syncReturns_(returns) {
  const sh = sheet_(SHEET_RETURNS, RETURN_HEADERS);
  const known = indexIds_(sh, 1);
  const results = [];
  const rows = [];
  returns.forEach(function (r) {
    if (!r || !r.id || !r.items || !r.items.length || isNaN(num_(r.amount))) { results.push({ id: r && r.id, result: 'invalid' }); return; }
    if (known[r.id]) { results.push({ id: r.id, result: 'duplicate' }); return; }
    known[r.id] = [];
    r.items.forEach(function (it, idx) {
      const first = idx === 0; // return-level money shown once so SUMs stay correct
      rows.push([
        r.id, safe_(r.returnNo), safe_(r.date), safe_(r.time), safe_(r.invoiceNo), safe_(r.customer), safe_(r.phone),
        safe_(it.name), it.qty, it.unitPrice, it.amount,
        first ? r.amount : '', first ? r.creditApplied : '', first ? r.refund : '', first ? safe_(r.method) : '', first ? safe_(r.reason) : '',
      ]);
    });
    results.push({ id: r.id, result: 'inserted' });
  });
  if (rows.length) sh.getRange(sh.getLastRow() + 1, 1, rows.length, RETURN_HEADERS.length).setValues(rows);
  return results;
}

// ---- Google Drive backups ---------------------------------------------------

function backupFolder_() {
  const it = DriveApp.getFoldersByName(BACKUP_FOLDER);
  return it.hasNext() ? it.next() : DriveApp.createFolder(BACKUP_FOLDER);
}

/** Save a backup file and keep only the newest KEEP_BACKUPS files. */
function saveBackup_(name, content) {
  if (!content) throw new Error('Empty backup');
  const safeName = name.replace(/[^A-Za-z0-9._-]/g, '_');
  const folder = backupFolder_();
  const file = folder.createFile(safeName, content, MimeType.PLAIN_TEXT);
  const all = [];
  const it = folder.getFiles();
  while (it.hasNext()) { const f = it.next(); all.push({ f: f, t: f.getDateCreated().getTime() }); }
  all.sort(function (a, b) { return b.t - a.t; });
  all.slice(KEEP_BACKUPS).forEach(function (x) { x.f.setTrashed(true); });
  return { id: file.getId(), name: file.getName(), size: file.getSize() };
}

/** Newest-first list of backup files. */
function listBackups_() {
  const out = [];
  const it = backupFolder_().getFiles();
  while (it.hasNext()) {
    const f = it.next();
    out.push({ id: f.getId(), name: f.getName(), size: f.getSize(), created: f.getDateCreated().toISOString() });
  }
  out.sort(function (a, b) { return b.created.localeCompare(a.created); });
  return out.slice(0, 50);
}

/** Return a backup's text — only files inside the backup folder can be read. */
function getBackup_(id) {
  const folder = backupFolder_();
  const it = folder.getFiles();
  while (it.hasNext()) {
    const f = it.next();
    if (f.getId() === id) return f.getBlob().getDataAsString();
  }
  throw new Error('Backup not found');
}

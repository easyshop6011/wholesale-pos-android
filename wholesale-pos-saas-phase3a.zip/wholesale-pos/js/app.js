/**
 * app.js — application bootstrap.
 *
 *   load settings → restore session → show setup / login / PIN lock / app shell
 *
 * Also registers the service worker (offline app shell), asks the browser to
 * keep our data, starts automatic sync and the idle auto-lock timer.
 */
import { h, mount } from './ui/dom.js';
import { settings, DEFAULTS } from './services/settings.js';
import { auth } from './services/auth.js';
import { bus } from './core/bus.js';
import { requestPersistence, useDatabase } from './core/db.js';
import { getCloud } from './cloud/index.js';
import { initLocale, t } from './core/i18n.js';
import { startAutoSync } from './services/sync.js';
import { backfillCodes } from './services/codes.js';
import { startAutoBackup } from './services/autobackup.js';
import { mountShell } from './ui/shell.js';
import { renderSetup, renderLogin, renderPinLock } from './ui/auth-screens.js';
import { toast } from './ui/components.js';
import { startAppearance } from './ui/appearance.js';

const root = document.getElementById('app');
let rendering = Promise.resolve();
let lastScreen = '';
/** Cloud (SaaS) mode handle — `{ enabled: false }` = the classic offline-only app. Set in boot(). */
let cloud = { enabled: false };

/** Choose which screen to show from the current auth state. */
async function renderApp() {
  let screen;
  if (await auth.needsSetup()) screen = 'setup';
  else if (!auth.user()) screen = cloud.enabled ? 'cloud-out' : 'login';
  else if (auth.isLocked()) screen = 'lock';
  else screen = `app:${auth.user().id}`;
  if (screen === lastScreen) return;
  lastScreen = screen;
  document.body.dataset.screen = screen.split(':')[0];
  if (screen === 'setup') renderSetup(root);
  else if (screen === 'login') renderLogin(root);
  else if (screen === 'lock') renderPinLock(root);
  else if (screen === 'cloud-out') cloudSignOutAndReload();
  else mountShell(root);
}

/** Cloud mode: "Sign out" in the app ends the cloud session of this device too, then starts over at the sign-in screen. */
async function cloudSignOutAndReload() {
  // replace the shell at once: a half-signed-out screen must not keep painting (or reacting to clicks)
  mount(root, h('div', { class: 'auth-wrap' }, h('div', { class: 'auth-card' }, h('p', { class: 'muted' }, t('common.loading')))));
  try {
    await cloud.client.auth.signOut({ scope: 'local' });
  } finally {
    location.reload();
  }
}

// Serialise renders so rapid auth events can't interleave.
const queueRender = () => {
  rendering = rendering.then(renderApp).catch((e) => console.error(e));
  return rendering;
};

/** Auto-lock after N idle minutes (0 = never) and whenever the app is hidden for a while. */
function setupIdleLock() {
  let timer;
  let hiddenAt = 0;
  const arm = () => {
    clearTimeout(timer);
    const mins = Number(settings.get('autoLockMinutes')) || 0;
    if (mins > 0 && auth.isSignedIn()) timer = setTimeout(() => auth.lock(), mins * 60000);
  };
  ['pointerdown', 'keydown', 'touchstart'].forEach((ev) => window.addEventListener(ev, arm, { passive: true }));
  bus.on('auth:changed', arm);
  bus.on('settings:changed', arm);
  document.addEventListener('visibilitychange', () => {
    const mins = Number(settings.get('autoLockMinutes')) || 0;
    if (document.hidden) hiddenAt = Date.now();
    else if (mins > 0 && hiddenAt && Date.now() - hiddenAt > mins * 60000) auth.lock();
  });
}

/** Register the service worker and surface "update available". */
async function registerServiceWorker() {
  if (!('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
  try {
    const reg = await navigator.serviceWorker.register('./sw.js');
    const offer = (worker) => {
      const bar = h(
        'div',
        { class: 'update-bar' },
        h('span', null, 'A new version is ready.'),
        h(
          'button',
          {
            class: 'btn btn-sm',
            onclick: () => {
              worker.postMessage('SKIP_WAITING');
            },
          },
          'Update now',
        ),
      );
      document.body.append(bar);
    };
    if (reg.waiting && navigator.serviceWorker.controller) offer(reg.waiting);
    reg.addEventListener('updatefound', () => {
      const w = reg.installing;
      w?.addEventListener('statechange', () => {
        if (w.state === 'installed' && navigator.serviceWorker.controller) offer(w);
      });
    });
    // Reload after an UPDATE only. On the very first visit the new worker simply claims the
    // page (controller goes null -> worker); reloading then would wipe what the user is typing.
    let reloaded = false;
    const hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (!reloaded && hadController) {
        reloaded = true;
        location.reload();
      }
    });
  } catch (e) {
    console.warn('Service worker registration failed', e);
  }
}

async function boot() {
  try {
    // Cloud (SaaS) mode: nobody reaches the POS before the SERVER has said so (sign in → approved business).
    // Not configured (no URL/key in js/cloud/config.js) = the classic offline-only app, unchanged.
    cloud = getCloud(); // throws when a secret key or a non-https URL was configured
    let gate = null;
    initLocale({ cloudEnabled: cloud.enabled, search: location.search, stored: (() => { try { return localStorage.getItem('pos:lang'); } catch { return null; } })() });
    if (cloud.enabled) {
      const { runCloudGate } = await import('./ui/cloud-screens.js');
      gate = await runCloudGate(root, cloud);
      useDatabase(`wholesale-pos:${gate.business.business_id}`); // one local database per business
    }
    await settings.load();
    await backfillCodes().catch((e) => console.warn('code backfill skipped', e?.message)); // short C-/P- codes for records created before they existed (idempotent)
    startAppearance();
    // Inside the Android app, default to direct native printing the first time.
    if (globalThis.Capacitor?.isNativePlatform?.() && globalThis.Capacitor.Plugins?.ThermalPrinter && settings.get('printTransport') === 'browser' && !localStorage.getItem('pos:transportChosen')) {
      await settings.set({ printTransport: 'native' });
    }
    await auth.init();
    if (gate) {
      const { enterBusiness } = await import('./cloud/bridge.js');
      await enterBusiness({ auth, client: cloud.client, gate }); // the server's role / permissions become the local session
      if (auth.can('settings') && settings.get('businessName') === DEFAULTS.businessName) await settings.set({ businessName: gate.business.name }).catch(() => {});
    }
    bus.on('auth:changed', queueRender);
    setupIdleLock();
    await queueRender();
    if (gate) {
      const ui = await import('./ui/cloud-screens.js');
      ui.showStatusBanner(gate);
      if (auth.needsPin()) ui.requirePin(); // the screen lock needs a quick-unlock PIN on this device
      const { startCloudWatch } = await import('./cloud/watch.js');
      // a suspended business / switched-off member / signed-out device must not keep running until the next start
      startCloudWatch({ client: cloud.client, storage: cloud.storage, intervalMs: cloud.cfg.watchMs, onBlocked: () => location.reload() });
    }
    startAutoSync();
    startAutoBackup();
    requestPersistence();
    registerServiceWorker();
  } catch (e) {
    console.error(e);
    mount(root, h('div', { class: 'auth-wrap' }, h('div', { class: 'auth-card' }, h('h2', null, 'Could not start the app'), h('p', { class: 'muted' }, e.message || String(e)), h('p', { class: 'small muted' }, 'Private/incognito windows and some embedded browsers block local storage. Open the app in a normal Chrome window.'))));
  }
}

window.addEventListener('unhandledrejection', (e) => {
  console.error(e.reason);
});
window.addEventListener('error', (e) => {
  if (e.message && !/ResizeObserver/.test(e.message)) toast(`Unexpected error: ${e.message}`, 'error');
});

boot();

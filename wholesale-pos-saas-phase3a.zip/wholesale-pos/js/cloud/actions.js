/**
 * actions.js — business registration and the Super Admin review calls.
 * Every function is a thin, typed wrapper over one database function / table of migration 0004–0005.
 */
import { fromBnDigits } from '../core/i18n.js';

/** "০১৭১২-৩৪৫৬৭৮", "+880 1712 345678" → "01712345678" (digits only, +88 removed). */
export function normalizeBdPhone(input) {
  const d = fromBnDigits(String(input ?? '')).replace(/[^0-9]/g, '');
  return /^8801\d{9}$/.test(d) ? d.slice(2) : d;
}
export const isBdMobile = (phone) => /^01[3-9]\d{8}$/.test(normalizeBdPhone(phone));

const clean = (s) => String(s ?? '').trim();

/** Submit a business application (status becomes "pending"). Returns the new business id. */
export function registerBusiness(client, f) {
  return client.rpc('register_business', {
    p_name: clean(f.name),
    p_owner_name: clean(f.ownerName),
    p_phone: normalizeBdPhone(f.phone),
    p_email: clean(f.email) || null,
    p_address: clean(f.address),
    p_district: clean(f.district),
    p_trade_license: clean(f.tradeLicense),
  });
}

/** The owner corrects the details of a rejected application (only these columns are writable for the owner). */
export function updateApplication(client, businessId, f) {
  return client.update('businesses', { id: `eq.${businessId}` }, {
    name: clean(f.name),
    owner_name: clean(f.ownerName),
    phone: normalizeBdPhone(f.phone),
    email: clean(f.email) || null,
    address: clean(f.address),
    district: clean(f.district),
    trade_license: clean(f.tradeLicense),
  });
}

export const resubmitBusiness = (client, businessId) => client.rpc('resubmit_business', { p_business: businessId });

// ---- Super Admin ------------------------------------------------------------------------------------------
const ADMIN_COLUMNS = 'id,name,owner_name,phone,email,address,district,trade_license,status,status_reason,submitted_at,reviewed_at,owner:profiles!owner_id(email,full_name)';

export const listBusinesses = (client, status) =>
  client.select('businesses', { columns: ADMIN_COLUMNS, filters: { status: `eq.${status}`, deleted_at: 'is.null' }, order: 'submitted_at.desc', limit: 200 });

export const reviewBusiness = (client, id, decision, reason = '') => client.rpc('review_business', { p_business: id, p_decision: decision, p_reason: reason });

export const setSuspension = (client, id, suspend, reason = '') => client.rpc('set_business_suspension', { p_business: id, p_suspend: suspend, p_reason: reason });

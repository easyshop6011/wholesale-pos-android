/**
 * bridge.js — turns "the SERVER says this person may use business B" into the local session of the POS.
 *
 * The cloud account is the credential. The local PIN is only a quick screen lock for a shared counter and never
 * replaces it (see auth.cloudSignIn). Roles and permissions are re-read from the server at every start; the
 * device's memory of them is never trusted over the server's answer.
 */

/**
 * @param {{auth: object, client: object, gate: object}} p   gate = the "ready" result of resolveGate()
 */
export async function enterBusiness({ auth, client, gate }) {
  const { user, business } = gate;

  // The other people of this business: keep the local copies of their role / on-off switch in step with the server.
  let members = [];
  if (!gate.offline) {
    try {
      members = await client.select('business_members', { columns: 'user_id,role,permissions,display_name,status', filters: { business_id: `eq.${business.business_id}` } });
    } catch (e) {
      if (e.code !== 'network') console.warn('could not refresh the member list', e.code || e.message);
    }
  }
  const me = members.find((m) => m.user_id === user.id);
  await auth.cloudSignIn({
    userId: user.id,
    email: user.email,
    displayName: me?.display_name || user.fullName || user.email,
    role: business.role,
    permissions: business.permissions,
    lockOnStart: !gate.fresh, // a cold start at a shared counter opens on the PIN screen; a fresh sign-in does not need it
  });
  if (members.length) await auth.cloudSyncMembers(members, { exceptId: user.id });
}

/**
 * client.js — a small, dependency-free client for Supabase Auth (GoTrue) and PostgREST.
 *
 * Why not supabase-js? The app has no bundler and no runtime dependencies, and must keep working offline
 * from its service-worker cache; a CDN import would break both. This client implements only what the app
 * uses and is tested against a fake server (tests/helpers/fake-supabase.mjs). It has NOT been run against a
 * real Supabase project yet — see docs/SAAS-PROGRESS.md.
 *
 *   • session: stored in storage, refreshed 60 s before expiry, ONE refresh at a time (refresh tokens are
 *     single-use) and a second tab that refreshed first is honoured instead of signing the user out
 *   • offline: a failed refresh because of the network keeps the session (returned with `stale: true`)
 *   • Google: OAuth with PKCE (code + verifier), never the implicit token-in-URL flow
 *   • MFA (TOTP): enroll → challenge → verify gives an aal2 session
 *   • rpc() / select() / update(): PostgREST calls with the user's token; one retry after a 401
 *
 * Only the PUBLISHABLE key is ever used. It travels in the `apikey` header; the user's own token travels
 * in `Authorization` once signed in.
 */
import { CloudError, authError, restError, networkError } from './errors.js';

export const SESSION_KEY = 'pos:cloud:session';
const PKCE_KEY = 'pos:cloud:pkce';
const REFRESH_MARGIN_S = 60;

const b64url = (bytes) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

/** Read the claims of a JWT (no signature check — the SERVER enforces; this is only for display / flow). */
export function decodeJwt(token) {
  try {
    const part = String(token).split('.')[1];
    const b64 = part.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(atob(b64.padEnd(Math.ceil(b64.length / 4) * 4, '=')));
  } catch {
    return null;
  }
}

export function memoryStorage() {
  const m = new Map();
  return { get: (k) => (m.has(k) ? m.get(k) : null), set: (k, v) => void m.set(k, String(v)), remove: (k) => void m.delete(k) };
}

export function browserStorage() {
  return {
    get: (k) => {
      try {
        return localStorage.getItem(k);
      } catch {
        return null;
      }
    },
    set: (k, v) => {
      try {
        localStorage.setItem(k, String(v));
      } catch {
        /* storage full / blocked */
      }
    },
    remove: (k) => {
      try {
        localStorage.removeItem(k);
      } catch {
        /* ignore */
      }
    },
  };
}

const normUser = (u = {}) => ({
  id: u.id || '',
  email: u.email || '',
  emailConfirmed: Boolean(u.email_confirmed_at || u.confirmed_at),
  fullName: u.user_metadata?.full_name || '',
  factors: (u.factors || []).map((f) => ({ id: f.id, type: f.factor_type, status: f.status, name: f.friendly_name || '' })),
});

/**
 * @param {{url: string, key: string, storage?: object, fetchImpl?: Function, now?: () => number, cryptoImpl?: Crypto}} opts
 */
export function createCloudClient({ url, key, storage = browserStorage(), fetchImpl, now = () => Date.now(), cryptoImpl = globalThis.crypto } = {}) {
  if (!url || !key) throw new CloudError('not_configured');
  const base = String(url).replace(/\/+$/, '');
  const listeners = new Set();
  let refreshing = null;

  const nowS = () => Math.floor(now() / 1000);
  const emit = (event, session) => {
    for (const fn of listeners) {
      try {
        fn(event, session);
      } catch (e) {
        console.error('cloud listener failed', e);
      }
    }
  };

  // ---- HTTP --------------------------------------------------------------------------------------------
  async function call(path, { method = 'GET', body, token, query, headers = {} } = {}) {
    const u = new URL(base + path);
    for (const [k, v] of Object.entries(query || {})) if (v !== undefined && v !== null) u.searchParams.set(k, v);
    const h = { apikey: key, 'Content-Type': 'application/json', Accept: 'application/json', ...headers };
    if (token) h.Authorization = `Bearer ${token}`;
    let res;
    try {
      res = await (fetchImpl || globalThis.fetch).call(globalThis, u.toString(), { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
    } catch (e) {
      throw networkError(e);
    }
    const text = await res.text();
    let data = null;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = { message: text.slice(0, 200) };
      }
    }
    if (!res.ok) throw path.startsWith('/auth/') ? authError(res.status, data) : restError(res.status, data);
    return data;
  }

  // ---- session -----------------------------------------------------------------------------------------
  function toSession(body) {
    if (!body?.access_token) return null;
    const claims = decodeJwt(body.access_token) || {};
    return {
      accessToken: body.access_token,
      refreshToken: body.refresh_token || '',
      expiresAt: body.expires_at ?? claims.exp ?? nowS() + (body.expires_in || 3600),
      aal: claims.aal || 'aal1',
      user: normUser(body.user || { id: claims.sub, email: claims.email }),
    };
  }
  function loadSession() {
    const raw = storage.get(SESSION_KEY);
    if (!raw) return null;
    try {
      const s = JSON.parse(raw);
      return s?.accessToken && s?.user?.id ? s : null;
    } catch {
      return null;
    }
  }
  const saveSession = (s) => storage.set(SESSION_KEY, JSON.stringify(s));
  const clearSession = () => storage.remove(SESSION_KEY);
  function adopt(body, event) {
    const s = toSession(body);
    if (!s) return null;
    saveSession(s);
    emit(event, s);
    return s;
  }

  async function refresh(session) {
    if (refreshing) return refreshing;
    refreshing = (async () => {
      try {
        const data = await call('/auth/v1/token', { method: 'POST', query: { grant_type: 'refresh_token' }, body: { refresh_token: session.refreshToken } });
        const next = toSession(data);
        if (!next) throw new CloudError('session_expired');
        saveSession(next);
        emit('TOKEN_REFRESHED', next);
        return next;
      } catch (e) {
        if (e.code === 'network') throw e; // offline: keep the session, the caller decides
        const latest = loadSession(); // another tab may have refreshed first (single-use tokens)
        if (latest && latest.accessToken !== session.accessToken) return latest;
        clearSession();
        emit('SIGNED_OUT', null);
        throw new CloudError('session_expired', undefined, { status: e.status });
      } finally {
        refreshing = null;
      }
    })();
    return refreshing;
  }

  const auth = {
    /** The current session, refreshed when it is about to expire. `null` = signed out. `stale` = offline with an old token. */
    async getSession({ forceRefresh = false } = {}) {
      const s = loadSession();
      if (!s) return null;
      if (!forceRefresh && s.expiresAt - nowS() >= REFRESH_MARGIN_S) return s;
      if (!s.refreshToken) {
        clearSession();
        emit('SIGNED_OUT', null);
        return null;
      }
      try {
        return await refresh(s);
      } catch (e) {
        return e.code === 'network' ? { ...s, stale: true } : null;
      }
    },

    onChange(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },

    async signUp({ email, password, fullName = '' }) {
      const data = await call('/auth/v1/signup', { method: 'POST', body: { email, password, data: { full_name: fullName } } });
      const session = adopt(data, 'SIGNED_IN'); // only when e-mail confirmation is switched off
      return { session, needsVerification: !session };
    },

    async signInWithPassword({ email, password }) {
      const data = await call('/auth/v1/token', { method: 'POST', query: { grant_type: 'password' }, body: { email, password } });
      return adopt(data, 'SIGNED_IN');
    },

    /** E-mail a 6-digit code. An unknown address is NOT revealed (no error, same answer). */
    async sendEmailOtp({ email, createUser = false }) {
      try {
        await call('/auth/v1/otp', { method: 'POST', body: { email, create_user: createUser } });
      } catch (e) {
        if (e.code !== 'signup_disabled') throw e;
      }
    },

    /** type: 'email' (sign in) · 'signup' (confirm a new account) · 'recovery' (password reset) */
    async verifyEmailOtp({ email, token, type = 'email' }) {
      const data = await call('/auth/v1/verify', { method: 'POST', body: { type, email, token: String(token).replace(/\s+/g, '') } });
      const s = adopt(data, type === 'recovery' ? 'PASSWORD_RECOVERY' : 'SIGNED_IN');
      if (!s) throw new CloudError('otp_expired');
      return s;
    },

    async resendSignupCode({ email }) {
      await call('/auth/v1/resend', { method: 'POST', body: { type: 'signup', email } });
    },

    async sendPasswordReset({ email }) {
      await call('/auth/v1/recover', { method: 'POST', body: { email } });
    },

    async updatePassword(password) {
      const s = await auth.getSession();
      if (!s) throw new CloudError('session_expired');
      await call('/auth/v1/user', { method: 'PUT', token: s.accessToken, body: { password } });
    },

    /** Google with PKCE. Returns the URL to open; the code comes back as ?code=… (see exchangeCode). */
    async signInWithGoogle({ redirectTo }) {
      const verifier = b64url(cryptoImpl.getRandomValues(new Uint8Array(48)));
      const digest = new Uint8Array(await cryptoImpl.subtle.digest('SHA-256', new TextEncoder().encode(verifier)));
      storage.set(PKCE_KEY, verifier);
      const u = new URL(`${base}/auth/v1/authorize`);
      u.searchParams.set('provider', 'google');
      u.searchParams.set('redirect_to', redirectTo);
      u.searchParams.set('code_challenge', b64url(digest));
      u.searchParams.set('code_challenge_method', 's256');
      return { url: u.toString() };
    },

    async exchangeCode(code) {
      const verifier = storage.get(PKCE_KEY);
      storage.remove(PKCE_KEY);
      if (!verifier) throw new CloudError('session_expired', 'missing PKCE verifier');
      const data = await call('/auth/v1/token', { method: 'POST', query: { grant_type: 'pkce' }, body: { auth_code: code, code_verifier: verifier } });
      const s = adopt(data, 'SIGNED_IN');
      if (!s) throw new CloudError('session_expired');
      return s;
    },

    /** scope: 'local' this device · 'global' every device · 'others' every other device. The local session is always cleared. */
    async signOut({ scope = 'local' } = {}) {
      const s = loadSession();
      clearSession();
      storage.remove(PKCE_KEY);
      emit('SIGNED_OUT', null);
      if (s) {
        try {
          await call('/auth/v1/logout', { method: 'POST', query: { scope }, token: s.accessToken });
        } catch {
          /* the device is signed out locally either way */
        }
      }
    },

    mfa: {
      async factors() {
        const s = await auth.getSession();
        if (!s) throw new CloudError('session_expired');
        return normUser(await call('/auth/v1/user', { token: s.accessToken })).factors;
      },
      /** Start TOTP enrolment: returns the QR (SVG data URI), the text key and the factor id. */
      async enroll() {
        const s = await auth.getSession();
        if (!s) throw new CloudError('session_expired');
        for (const f of await auth.mfa.factors()) {
          if (f.type === 'totp' && f.status !== 'verified') await call(`/auth/v1/factors/${f.id}`, { method: 'DELETE', token: s.accessToken }).catch(() => {});
        }
        const d = await call('/auth/v1/factors', { method: 'POST', token: s.accessToken, body: { factor_type: 'totp', friendly_name: `Wholesale POS ${new Date(now()).toISOString().slice(0, 10)}-${Math.floor(now() / 1000) % 100000}`, issuer: 'Wholesale POS' } });
        return { factorId: d.id, qrCode: d.totp?.qr_code || '', secret: d.totp?.secret || '', uri: d.totp?.uri || '' };
      },
      /** Challenge + verify in one step; success replaces the session with an aal2 one. */
      async verify({ factorId, code }) {
        const s = await auth.getSession();
        if (!s) throw new CloudError('session_expired');
        const ch = await call(`/auth/v1/factors/${factorId}/challenge`, { method: 'POST', token: s.accessToken, body: {} });
        const data = await call(`/auth/v1/factors/${factorId}/verify`, { method: 'POST', token: s.accessToken, body: { challenge_id: ch.id, code: String(code).replace(/\s+/g, '') } });
        const next = adopt(data, 'MFA_VERIFIED');
        if (!next) throw new CloudError('mfa_failed');
        return next;
      },
    },
  };

  // ---- PostgREST ------------------------------------------------------------------------------------------
  async function rest(path, opts = {}) {
    let s = await auth.getSession();
    if (!s) throw new CloudError('session_expired');
    try {
      return await call(path, { ...opts, token: s.accessToken });
    } catch (e) {
      if (e.code !== 'session_expired') throw e;
      s = await auth.getSession({ forceRefresh: true });
      if (!s) throw e;
      return call(path, { ...opts, token: s.accessToken });
    }
  }

  return {
    config: { url: base },
    auth,
    /** Call a database function: rpc('review_business', { p_business, p_decision }) */
    async rpc(name, args = {}) {
      return rest(`/rest/v1/rpc/${name}`, { method: 'POST', body: args });
    },
    /** GET rows. filters use PostgREST operators: { status: 'eq.pending' }. `columns` must be listed where cost columns are hidden. */
    async select(table, { columns = '*', filters = {}, order, limit } = {}) {
      const query = { select: columns, ...filters };
      if (order) query.order = order;
      if (limit) query.limit = limit;
      return (await rest(`/rest/v1/${table}`, { query })) || [];
    },
    /** PATCH rows that match `filters`; returns the changed rows ([] = nothing matched / no permission). */
    async update(table, filters, patch) {
      return (await rest(`/rest/v1/${table}`, { method: 'PATCH', query: filters, body: patch, headers: { Prefer: 'return=representation' } })) || [];
    },
  };
}

/** Parse what the browser URL holds after Google redirected back: {code} · {error} · {} */
export function readOAuthRedirect(search = '') {
  const q = new URLSearchParams(search);
  if (q.get('code')) return { code: q.get('code') };
  if (q.get('error') || q.get('error_description')) return { error: q.get('error_description') || q.get('error') };
  return {};
}

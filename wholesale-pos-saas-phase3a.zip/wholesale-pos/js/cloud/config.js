/**
 * config.js — where the app finds its Supabase project.
 *
 * PUBLIC values only: the project URL and the "anon" / "publishable" key. Row Level Security — not secrecy of
 * this key — protects the data. Leave `url` empty and the app runs exactly as the classic offline-only POS.
 *
 * A SECRET key must never be here (nor in the APK): `assertPublicKey` refuses a `sb_secret_…` key and any JWT
 * whose role claim is the service role, so a mistake stops the app instead of shipping the key to every device.
 */
export const CLOUD_DEFAULTS = Object.freeze({
  url: '', // e.g. 'https://abcdefgh.supabase.co'
  publishableKey: '', // Dashboard → Project Settings → API → anon / publishable key
});

function jwtPayload(part) {
  try {
    const b64 = part.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(atob(b64.padEnd(Math.ceil(b64.length / 4) * 4, '=')));
  } catch {
    return null;
  }
}

/** Refuse a secret / service-role key. */
export function assertPublicKey(key) {
  if (!key) return;
  if (/^sb_secret_/i.test(key)) throw new Error('A Supabase SECRET key was configured. Only the publishable/anon key may be used inside the app.');
  const parts = String(key).split('.');
  if (parts.length === 3 && jwtPayload(parts[1])?.role === 'service_role') {
    throw new Error('The service_role key was configured. It bypasses every security rule and must NEVER be inside the app — use the anon/publishable key.');
  }
}

/**
 * @param {{url?: string, publishableKey?: string, watchMs?: number}} [overrides]  tests / hosting may inject via window.__POS_CLOUD__
 */
export function cloudConfig(overrides = globalThis.__POS_CLOUD__) {
  const o = overrides || {};
  const url = String(o.url ?? CLOUD_DEFAULTS.url ?? '').trim().replace(/\/+$/, '');
  const publishableKey = String(o.publishableKey ?? CLOUD_DEFAULTS.publishableKey ?? '').trim();
  const enabled = Boolean(url && publishableKey);
  if (enabled) {
    assertPublicKey(publishableKey);
    const https = /^https:\/\//i.test(url);
    const local = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(url);
    if (!https && !local) throw new Error('The cloud URL must start with https:// (plain http is allowed only for localhost).');
  }
  const watchMs = Math.max(250, Number(o.watchMs) || 600000); // how often a running app re-checks its access (10 min)
  return { enabled, url, publishableKey, watchMs };
}

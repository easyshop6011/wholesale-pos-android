/**
 * errors.js — one error type for everything that talks to the cloud, and the words shown to the person.
 *
 *   Supabase Auth (GoTrue) errors, PostgREST / our own SQL function errors (the short codes raised in the
 *   migrations, e.g. "plan_limit:businesses") and network failures all become CloudError(code). The code is
 *   looked up as "err.<code>" in the dictionaries; anything unknown reads "Something went wrong".
 */
import { t } from '../core/i18n.js';

export class CloudError extends Error {
  constructor(code, message, { status = 0, sqlstate = '', details = '' } = {}) {
    super(message || code);
    this.name = 'CloudError';
    this.code = code;
    this.status = status;
    this.sqlstate = sqlstate;
    this.details = details;
  }
}

const GOTRUE_CODES = {
  invalid_credentials: 'invalid_credentials',
  email_not_confirmed: 'email_not_confirmed',
  otp_expired: 'otp_expired',
  weak_password: 'weak_password',
  user_already_exists: 'user_exists',
  email_exists: 'user_exists',
  same_password: 'same_password',
  over_email_send_rate_limit: 'rate_limit',
  over_request_rate_limit: 'rate_limit',
  over_sms_send_rate_limit: 'rate_limit',
  mfa_verification_failed: 'mfa_failed',
  mfa_challenge_expired: 'mfa_failed',
  session_not_found: 'session_expired',
  session_expired: 'session_expired',
  refresh_token_not_found: 'session_expired',
  refresh_token_already_used: 'session_expired',
  bad_jwt: 'session_expired',
  validation_failed: 'validation',
  email_address_invalid: 'invalid_email',
  signup_disabled: 'signup_disabled',
  otp_disabled: 'signup_disabled',
};

const TEXT_HINTS = [
  [/invalid login credentials/i, 'invalid_credentials'],
  [/email not confirmed/i, 'email_not_confirmed'],
  [/token has expired|otp.*expired|invalid.*otp|expired or is invalid/i, 'otp_expired'],
  [/already registered|already been registered/i, 'user_exists'],
  [/password should be|password is too weak|weak password/i, 'weak_password'],
  [/should be different from the old/i, 'same_password'],
  [/signups? not allowed|signup is disabled/i, 'signup_disabled'],
  [/rate limit|too many requests|for security purposes/i, 'rate_limit'],
  [/refresh token/i, 'session_expired'],
];

/** An error answer from /auth/v1/… */
export function authError(status, body) {
  const text = String(body?.msg || body?.message || body?.error_description || body?.error || '');
  let code = GOTRUE_CODES[body?.error_code];
  if (!code) code = TEXT_HINTS.find(([re]) => re.test(text))?.[1];
  if (!code && status === 429) code = 'rate_limit';
  if (!code && (status === 401 || status === 403)) code = 'session_expired';
  return new CloudError(code || 'unknown', text || `Auth error ${status}`, { status });
}

const MACHINE_CODE = /^[a-z_]+(:[a-z_]+)?$/;

/** An error answer from /rest/v1/… (PostgREST), including the codes our SQL functions raise. */
export function restError(status, body) {
  const message = String(body?.message || '');
  const sqlstate = String(body?.code || '');
  let code;
  if (MACHINE_CODE.test(message)) code = message; // our own raise exception 'plan_limit:businesses' …
  else if (/^PGRST30[1-3]$/.test(sqlstate) || /jwt (is )?expired/i.test(message)) code = 'session_expired';
  else if (sqlstate === '42501' || status === 403) code = 'permission_denied';
  else if (status === 401) code = 'session_expired';
  return new CloudError(code || 'unknown', message || `Request failed (${status})`, { status, sqlstate, details: String(body?.details || '') });
}

export const networkError = (cause) => new CloudError('network', cause?.message || 'network error');

/** The sentence shown to the person, in the active language. */
export function errorText(err) {
  const code = err instanceof CloudError ? err.code : 'unknown';
  const key = `err.${code}`;
  const s = t(key);
  return s === key ? t('err.unknown') : s;
}

/**
 * gate.js — what may this person do right now? One answer from the server decides the screen.
 *
 *   signed_out → (login) → my_access_state() → account_disabled | session_revoked | mfa_enroll | mfa_challenge
 *                                              | super_admin | no_business | pending | rejected | suspended
 *                                              | member_disabled | ready
 *
 * OFFLINE: the POS must keep working without internet. When the server cannot be reached, the LAST verified
 * answer is used for up to OFFLINE_GRACE_MS (7 days); after that the person must reconnect once. A business
 * that was suspended while the device was offline therefore stops at the latest a week later, on this device.
 */
export const ACCESS_KEY = 'pos:cloud:access';
export const BUSINESS_KEY = 'pos:cloud:businessId';
export const DEVICE_KEY = 'pos:cloud:deviceId';
export const OFFLINE_GRACE_MS = 7 * 24 * 60 * 60 * 1000;

const usable = (b) => b.status === 'approved' && b.member_status === 'active';

/**
 * Pure: the screen state for an answer of my_access_state().
 * @returns {{state: string, business?: object, readOnly?: boolean}}
 */
export function decideState(access, { storedBusinessId = '', hasVerifiedFactor = false } = {}) {
  if (!access.active) return { state: 'account_disabled' };
  if (access.session_revoked) return { state: 'session_revoked' };
  if (access.super_admin_candidate) {
    if (access.super_admin) return { state: 'super_admin' };
    return { state: hasVerifiedFactor ? 'mfa_challenge' : 'mfa_enroll' }; // the powers need MFA (aal2)
  }
  const list = access.businesses || [];
  if (!list.length) return { state: 'no_business' };
  const stored = list.find((b) => b.business_id === storedBusinessId);
  const business = (stored && usable(stored) && stored) || list.find(usable) || stored || list[0];
  if (usable(business)) return { state: 'ready', business, readOnly: !business.can_write };
  if (business.status === 'approved') return { state: 'member_disabled', business };
  return { state: business.status, business }; // pending | rejected | suspended
}

function readCached(storage, userId) {
  try {
    const c = JSON.parse(storage.get(ACCESS_KEY) || 'null');
    return c && c.userId === userId && c.access ? c : null;
  } catch {
    return null;
  }
}

/**
 * Ask the server (or, offline, the last verified answer) and decide the screen.
 * @param {ReturnType<import('./client.js').createCloudClient>} client
 */
export async function resolveGate(client, { storage, now = Date.now } = {}) {
  const session = await client.auth.getSession();
  if (!session) return { state: 'signed_out' };

  let access;
  let offline = false;
  try {
    access = await client.rpc('my_access_state');
    storage.set(ACCESS_KEY, JSON.stringify({ userId: session.user.id, at: now(), access }));
  } catch (e) {
    if (e.code === 'session_expired') return { state: 'signed_out' };
    if (e.code !== 'network') throw e;
    const cached = readCached(storage, session.user.id);
    if (!cached || now() - cached.at > OFFLINE_GRACE_MS) return { state: 'offline_blocked', user: session.user };
    access = cached.access;
    offline = true;
  }

  let hasVerifiedFactor = false;
  if (access.super_admin_candidate && !access.super_admin && !offline) {
    hasVerifiedFactor = (await client.auth.mfa.factors()).some((f) => f.type === 'totp' && f.status === 'verified');
  }
  const decided = decideState(access, { storedBusinessId: storage.get(BUSINESS_KEY) || '', hasVerifiedFactor });
  if (decided.state === 'session_revoked') await client.auth.signOut({ scope: 'local' });
  if (decided.state === 'ready') storage.set(BUSINESS_KEY, decided.business.business_id);
  return { ...decided, access, businesses: access.businesses || [], offline, user: session.user };
}

/** A stable id for this device/browser + a label for the "my devices" list. */
export function deviceIdentity(storage, env = globalThis) {
  let id = storage.get(DEVICE_KEY);
  if (!id || id.length < 8) {
    id = env.crypto?.randomUUID?.() || `dev-${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    storage.set(DEVICE_KEY, id);
  }
  const ua = env.navigator?.userAgent || '';
  const native = Boolean(env.Capacitor?.isNativePlatform?.());
  const label = native ? 'Android app' : /Android/i.test(ua) ? 'Android browser' : /iPhone|iPad/i.test(ua) ? 'iPhone / iPad' : /Windows/i.test(ua) ? 'Windows browser' : /Mac/i.test(ua) ? 'Mac browser' : 'Browser';
  return { id, platform: native ? 'android' : 'web', label, userAgent: ua.slice(0, 300) };
}

/** Tell the server this device signed in (new-device detection). Offline is not an error. */
export async function recordLogin(client, storage, env = globalThis) {
  const d = deviceIdentity(storage, env);
  try {
    return await client.rpc('record_login', { p_device_id: d.id, p_label: d.label, p_platform: d.platform, p_user_agent: d.userAgent });
  } catch (e) {
    if (e.code === 'network') return null;
    throw e;
  }
}

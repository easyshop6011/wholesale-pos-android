/**
 * index.js — the one place the app asks "is the cloud on, and what is the client?".
 * Off (no URL / key in config.js) = the classic offline-only POS, byte for byte.
 */
import { cloudConfig } from './config.js';
import { createCloudClient, browserStorage } from './client.js';

let handle = null;

/** @returns {{enabled: false} | {enabled: true, cfg: object, storage: object, client: object}} */
export function getCloud() {
  if (handle) return handle;
  const cfg = cloudConfig(); // throws when a secret key / non-https URL was configured
  if (!cfg.enabled) return (handle = { enabled: false });
  const storage = browserStorage();
  return (handle = { enabled: true, cfg, storage, client: createCloudClient({ url: cfg.url, key: cfg.publishableKey, storage }) });
}

/** Test hook. */
export const _resetCloudForTests = () => {
  handle = null;
};

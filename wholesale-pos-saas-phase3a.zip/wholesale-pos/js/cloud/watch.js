/**
 * watch.js — a running POS keeps asking the server "may this person still use this business?"
 *
 * Without it a business suspended (or a member switched off, or a session signed out remotely) would only be
 * stopped at the next start. The check runs every 10 minutes, when the tab becomes visible again and when the
 * internet comes back. Offline it uses the last verified answer (see gate.js), so the POS never stops merely
 * because the network is down. A blocked answer reloads the app, which then shows the matching screen.
 */
import { resolveGate } from './gate.js';

export const WATCH_INTERVAL_MS = 10 * 60 * 1000;

/** One check. @returns {Promise<{blocked: boolean, state: string}>} — an unexpected failure never blocks. */
export async function checkOnce(client, storage) {
  try {
    const g = await resolveGate(client, { storage });
    return { blocked: g.state !== 'ready', state: g.state };
  } catch (e) {
    if (e?.code !== 'network') console.warn('cloud check failed', e?.code || e?.message);
    return { blocked: false, state: 'unknown' };
  }
}

/** @returns {() => void} stop function */
export function startCloudWatch({ client, storage, onBlocked, intervalMs = WATCH_INTERVAL_MS, env = globalThis }) {
  let busy = false;
  let stopped = false;
  const run = async () => {
    if (busy || stopped) return;
    busy = true;
    try {
      const r = await checkOnce(client, storage);
      if (r.blocked && !stopped) {
        stopped = true;
        onBlocked(r.state);
      }
    } finally {
      busy = false;
    }
  };
  const timer = env.setInterval(run, intervalMs);
  const onVisible = () => env.document?.visibilityState === 'visible' && run();
  env.document?.addEventListener('visibilitychange', onVisible);
  env.addEventListener?.('online', run);
  return () => {
    stopped = true;
    env.clearInterval(timer);
    env.document?.removeEventListener('visibilitychange', onVisible);
    env.removeEventListener?.('online', run);
  };
}

/**
 * bus.js — a tiny publish/subscribe event bus.
 *
 * Events used across the app:
 *   settings:changed   (settings)        – any setting was saved
 *   data:changed       ({store})         – a service mutated data (UI may refresh)
 *   sync:status        (status)          – sync progress / pending counts changed
 *   auth:changed       ()                – login / logout / lock / unlock
 */
const listeners = new Map();

export const bus = {
  /** Subscribe. Returns an unsubscribe function. */
  on(event, fn) {
    if (!listeners.has(event)) listeners.set(event, new Set());
    listeners.get(event).add(fn);
    return () => listeners.get(event)?.delete(fn);
  },
  /** Publish an event; listener errors never break the publisher. */
  emit(event, payload) {
    for (const fn of listeners.get(event) || []) {
      try {
        fn(payload);
      } catch (e) {
        console.error(`[bus] listener for "${event}" failed`, e);
      }
    }
  },
};

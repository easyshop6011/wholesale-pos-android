/**
 * cache.js — tiny memo cache for expensive whole-table calculations (customer
 * balances, dashboard figures …).
 *
 * Entries are dropped automatically whenever any service announces
 * `data:changed`, so a cached value can never outlive the data it was computed
 * from. A computation that STARTED before a change is not stored (generation
 * check), which avoids caching stale results.
 */
import { bus } from './bus.js';

const entries = new Map(); // key -> Promise
let generation = 0;

/** Forget everything (also used by tests after wiping the database). */
export function clearCache() {
  generation += 1;
  entries.clear();
}

bus.on('data:changed', clearCache);
bus.on('settings:changed', clearCache);

/**
 * Return the cached value for `key`, computing it with `fn` on a miss.
 * Concurrent callers share one computation.
 * @template T
 * @param {string} key
 * @param {() => Promise<T>} fn
 * @returns {Promise<T>}
 */
export function cached(key, fn) {
  if (entries.has(key)) return entries.get(key);
  const gen = generation;
  const p = Promise.resolve()
    .then(fn)
    .catch((e) => {
      if (entries.get(key) === p) entries.delete(key);
      throw e;
    });
  if (gen === generation) entries.set(key, p);
  return p;
}

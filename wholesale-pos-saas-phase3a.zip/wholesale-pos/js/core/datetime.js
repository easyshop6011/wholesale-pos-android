/**
 * datetime.js — one place for "what time is it in the shop?".
 *
 * RULES
 *  - The reliable, canonical timestamp stored on every record is a UTC ISO string
 *    (`createdAt`). It is unambiguous whatever the phone's clock zone is set to.
 *  - The derived strings the app indexes and prints (`date` YYYY-MM-DD, `time`
 *    HH:MM:SS, `month` YYYY-MM — invoice numbers, daily reports, filters) are the
 *    BUSINESS time in Asia/Dhaka, NOT the device's zone. A phone accidentally set
 *    to another zone therefore cannot move a sale into the wrong business day.
 *  - Everything shown to people is converted to Asia/Dhaka here.
 *
 * Bangladesh has used a fixed UTC+6 since 2009. The Intl time-zone database is
 * used when available (so a future change is picked up); otherwise a fixed +06:00
 * offset is applied.
 */

export const TIME_ZONE = 'Asia/Dhaka';
const FALLBACK_OFFSET_MS = 6 * 3600 * 1000;

let formatter;
let useFallback = false;

function getFormatter() {
  if (formatter || useFallback) return formatter;
  try {
    formatter = new Intl.DateTimeFormat('en-GB', { timeZone: TIME_ZONE, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch {
    useFallback = true;
  }
  return formatter;
}

const pad = (n) => String(n).padStart(2, '0');

/** Wall-clock fields of an instant in Asia/Dhaka. */
export function dhakaFields(input = new Date()) {
  const d = input instanceof Date ? input : new Date(input);
  if (Number.isNaN(d.getTime())) return null;
  const f = getFormatter();
  if (f) {
    const o = {};
    for (const p of f.formatToParts(d)) if (p.type !== 'literal') o[p.type] = p.value;
    return { y: o.year, mo: o.month, d: o.day, h: o.hour === '24' ? '00' : o.hour, mi: o.minute, s: o.second };
  }
  const t = new Date(d.getTime() + FALLBACK_OFFSET_MS);
  return { y: String(t.getUTCFullYear()), mo: pad(t.getUTCMonth() + 1), d: pad(t.getUTCDate()), h: pad(t.getUTCHours()), mi: pad(t.getUTCMinutes()), s: pad(t.getUTCSeconds()) };
}

/**
 * The strings stored on records. `iso` is the real instant in UTC.
 * @param {Date|string|number} [input]
 */
export function dhakaParts(input = new Date()) {
  const d = input instanceof Date ? input : new Date(input);
  const f = dhakaFields(d);
  if (!f) throw new RangeError('Invalid date');
  return { date: `${f.y}-${f.mo}-${f.d}`, time: `${f.h}:${f.mi}:${f.s}`, month: `${f.y}-${f.mo}`, iso: d.toISOString() };
}

/** Dhaka calendar day (YYYY-MM-DD) of an ISO timestamp; '' when invalid. */
export function dhakaDate(iso) {
  const f = iso ? dhakaFields(iso) : null;
  return f ? `${f.y}-${f.mo}-${f.d}` : '';
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * "28 Oct 2026, 16:44" (or with seconds "28 Oct 2026, 16:44:09") in Asia/Dhaka.
 * @param {string|Date} iso
 * @param {{seconds?:boolean}} [o]
 */
export function fmtDhakaDateTime(iso, { seconds = false } = {}) {
  const f = iso ? dhakaFields(iso) : null;
  if (!f) return '';
  return `${Number(f.d)} ${MONTHS[Number(f.mo) - 1]} ${f.y}, ${f.h}:${f.mi}${seconds ? `:${f.s}` : ''}`;
}

/** "16:44" (or "16:44:09") in Asia/Dhaka. */
export function fmtDhakaTime(iso, { seconds = false } = {}) {
  const f = iso ? dhakaFields(iso) : null;
  return f ? `${f.h}:${f.mi}${seconds ? `:${f.s}` : ''}` : '';
}

/** "28 Oct 2026" in Asia/Dhaka. */
export function fmtDhakaDate(iso) {
  const f = iso ? dhakaFields(iso) : null;
  return f ? `${Number(f.d)} ${MONTHS[Number(f.mo) - 1]} ${f.y}` : '';
}

/**
 * Sortable "YYYY-MM-DD HH:MM:SS" Dhaka text for CSV files (Excel-friendly, unambiguous).
 */
export function csvDhakaStamp(iso) {
  const f = iso ? dhakaFields(iso) : null;
  return f ? `${f.y}-${f.mo}-${f.d} ${f.h}:${f.mi}:${f.s}` : '';
}

/** UTC instant for a Dhaka calendar day boundary: start (00:00:00.000) or end (23:59:59.999). */
export function dhakaDayBounds(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const start = Date.UTC(y, m - 1, d) - FALLBACK_OFFSET_MS; // Dhaka is a fixed +6 h today
  return { startIso: new Date(start).toISOString(), endIso: new Date(start + 86400000 - 1).toISOString() };
}

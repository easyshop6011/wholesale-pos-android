/**
 * db.js — the local database (IndexedDB) and a small promise-based wrapper.
 *
 * Why IndexedDB? It is built into every browser and Android WebView, works fully
 * offline, supports transactions and indexes, and needs no native plugin.
 * `docs/DATABASE.md` and `db/schema.sql` describe the equivalent relational
 * schema; every service talks to this module only through `run()` / helpers, so
 * swapping in SQLite (e.g. Capacitor SQLite) means re-implementing this file.
 *
 * HOW TO EXTEND: add a store/index to SCHEMA, bump DB_VERSION, and (if existing
 * rows need transforming) add an entry to MIGRATIONS.
 *
 * v3 (this version): customer/product codes, stock-history fields (previous stock,
 * Dhaka date, reference number, user, cost / supplier / batch, idempotency key),
 * sales returns and idempotency keys on invoices / payments. The upgrade only ADDS
 * stores, indexes and fields — it never deletes or rewrites existing business data.
 */

import { upgradeMovement } from './upgrade.js';

export const DB_NAME = 'wholesale-pos';
export const DB_VERSION = 3;

/** Declarative schema: store name -> key path + indexes. */
export const SCHEMA = {
  users: { keyPath: 'id', indexes: [{ name: 'usernameLower', keyPath: 'usernameLower', unique: true }] },
  settings: { keyPath: 'key', indexes: [] },
  meta: { keyPath: 'key', indexes: [] }, // counters such as invoice sequence numbers
  categories: { keyPath: 'id', indexes: [{ name: 'nameLower', keyPath: 'nameLower', unique: true }] },
  products: {
    keyPath: 'id',
    indexes: [
      { name: 'nameLower', keyPath: 'nameLower' },
      { name: 'categoryId', keyPath: 'categoryId' },
      { name: 'sku', keyPath: 'sku' },
    ],
  },
  customers: {
    keyPath: 'id',
    indexes: [
      { name: 'phone', keyPath: 'phone' },
      { name: 'nameLower', keyPath: 'nameLower' },
    ],
  },
  invoices: {
    keyPath: 'id', // globally unique UUID — the dedupe key for Google Sheets
    indexes: [
      { name: 'invoiceNo', keyPath: 'invoiceNo', unique: true },
      { name: 'date', keyPath: 'date' },
      { name: 'month', keyPath: 'month' },
      { name: 'customerId', keyPath: 'customerId' },
      { name: 'syncStatus', keyPath: 'syncStatus' },
      { name: 'requestId', keyPath: 'requestId', unique: true }, // v3: a double-submitted sale is saved once
    ],
  },
  invoiceItems: {
    keyPath: 'id',
    indexes: [
      { name: 'invoiceId', keyPath: 'invoiceId' },
      { name: 'productId', keyPath: 'productId' },
    ],
  },
  payments: {
    keyPath: 'id',
    indexes: [
      { name: 'customerId', keyPath: 'customerId' },
      { name: 'date', keyPath: 'date' },
      { name: 'syncStatus', keyPath: 'syncStatus' },
      { name: 'requestId', keyPath: 'requestId', unique: true }, // v3
    ],
  },
  // v2 -----------------------------------------------------------------
  auditLog: {
    keyPath: 'id', // who did what (sign-ins, voids, stock changes, user admin …)
    indexes: [
      { name: 'createdAt', keyPath: 'createdAt' },
      { name: 'userId', keyPath: 'userId' },
      { name: 'action', keyPath: 'action' },
    ],
  },
  syncLog: {
    keyPath: 'id', // one row per sync / reconcile run (newest 200 are kept)
    indexes: [{ name: 'createdAt', keyPath: 'createdAt' }],
  },
  stockMovements: {
    keyPath: 'id', // append-only: rows are never edited or deleted (corrections are NEW rows)
    indexes: [
      { name: 'productId', keyPath: 'productId' },
      { name: 'createdAt', keyPath: 'createdAt' },
      { name: 'type', keyPath: 'type' }, // v3
      { name: 'userId', keyPath: 'userId' }, // v3
      { name: 'date', keyPath: 'date' }, // v3: Asia/Dhaka calendar day
      { name: 'ref', keyPath: 'ref' }, // v3: related invoice / return id
      { name: 'opKey', keyPath: 'opKey', unique: true }, // v3: the same operation can never move stock twice
    ],
  },
  // v3 -----------------------------------------------------------------
  salesReturns: {
    keyPath: 'id', // goods taken back from a customer (stock in + credit / refund)
    indexes: [
      { name: 'returnNo', keyPath: 'returnNo', unique: true },
      { name: 'invoiceId', keyPath: 'invoiceId' },
      { name: 'customerId', keyPath: 'customerId' },
      { name: 'date', keyPath: 'date' },
      { name: 'syncStatus', keyPath: 'syncStatus' },
      { name: 'requestId', keyPath: 'requestId', unique: true },
    ],
  },
};

const round3 = (n) => Math.round(n * 1000) / 1000;

/** Run `fn(value, cursor)` for every row of a store inside the upgrade transaction. */
function eachRow(tx, storeName, fn) {
  return new Promise((resolve, reject) => {
    const req = tx.objectStore(storeName).openCursor();
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const cur = req.result;
      if (!cur) return resolve();
      try {
        fn(cur.value, cur);
      } catch (e) {
        return reject(e);
      }
      cur.continue();
    };
  });
}

/**
 * Data migrations: { version, up(tx) } — run when upgrading from an older DB.
 * `up` receives the raw versionchange transaction; it must be idempotent and must
 * only ADD information (never delete or overwrite business data).
 */
export const MIGRATIONS = [
  {
    version: 3,
    up(tx) {
      // 1. Stock movements: fill the new fields from facts already stored on the row.
      //    previousStock = balance − qty is exact arithmetic on stored values (nothing invented);
      //    `date` is the Asia/Dhaka calendar day of the stored createdAt;
      //    `refNo` is the invoice number already written in the reason text ("Sale INV-…").
      eachRow(tx, 'stockMovements', (m, cur) => {
        const next = upgradeMovement(m);
        if (next !== m) cur.update(next);
      });
      // 2. Short human-friendly codes (C-0001 / P-0001) for existing customers and products, oldest first.
      const codes = (storeName, prefix, seqKey) => {
        const rows = [];
        eachRow(tx, storeName, (r) => rows.push(r)).then(() => {
          const metaStore = tx.objectStore('meta');
          const settingsStore = tx.objectStore('settings');
          const devReq = settingsStore.get('deviceCode');
          devReq.onsuccess = () => {
            const dev = devReq.result?.value ? `${devReq.result.value}-` : '';
            const seqKeyFull = `${seqKey}:${devReq.result?.value || ''}`;
            const taken = rows.filter((r) => r.code).length;
            let n = taken;
            const todo = rows.filter((r) => !r.code).sort((a, b) => String(a.createdAt || '').localeCompare(String(b.createdAt || '')) || String(a.id).localeCompare(String(b.id)));
            const store = tx.objectStore(storeName);
            for (const r of todo) {
              n += 1;
              store.put({ ...r, code: `${prefix}-${dev}${String(n).padStart(4, '0')}` });
            }
            if (todo.length) metaStore.put({ key: seqKeyFull, value: n });
          };
        });
      };
      codes('customers', 'C', 'seq:customer');
      codes('products', 'P', 'seq:product');
    },
  },
];

let dbPromise = null;

/**
 * Cloud (SaaS) mode: every business gets its OWN local database, so two businesses signing in on one device can
 * never see each other's data. Must be called before the first openDB(); the classic app never calls it and
 * keeps using "wholesale-pos".
 */
let activeName = DB_NAME;
export function useDatabase(name) {
  if (dbPromise) throw new Error('useDatabase() must be called before the database is opened');
  activeName = name;
}
export const databaseName = () => activeName;


/** Open (and upgrade if needed) the database. The connection is cached. */
export function openDB(name = activeName) {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = globalThis.indexedDB.open(name, DB_VERSION);
    req.onupgradeneeded = (ev) => {
      const db = req.result;
      const tx = req.transaction;
      for (const [storeName, def] of Object.entries(SCHEMA)) {
        const store = db.objectStoreNames.contains(storeName)
          ? tx.objectStore(storeName)
          : db.createObjectStore(storeName, { keyPath: def.keyPath });
        for (const ix of def.indexes) {
          if (!store.indexNames.contains(ix.name)) store.createIndex(ix.name, ix.keyPath, { unique: !!ix.unique });
        }
      }
      for (const m of MIGRATIONS) if (m.version > ev.oldVersion && m.version <= DB_VERSION) m.up(tx);
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => db.close(); // another tab upgraded the schema
      resolve(db);
    };
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error('Database upgrade blocked — close other tabs of this app.'));
  });
  return dbPromise;
}

/** Test helper: forget the cached connection. */
export function _resetForTests() {
  dbPromise = null;
}

/** Promisify an IDBRequest. */
const wrap = (req) =>
  new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

/** Accept a plain key, an IDBKeyRange, or undefined. */
const asRange = (q) => (q === undefined || q instanceof globalThis.IDBKeyRange ? q : globalThis.IDBKeyRange.only(q));

/**
 * Transaction facade. All methods return promises. IMPORTANT: inside a
 * transaction callback only await these methods (not fetch/crypto/timers),
 * otherwise IndexedDB auto-commits the transaction early.
 */
class Tx {
  constructor(idbTx) {
    this.tx = idbTx;
    this.done = new Promise((resolve, reject) => {
      idbTx.oncomplete = () => resolve();
      idbTx.onerror = () => reject(idbTx.error);
      idbTx.onabort = () => reject(idbTx.error || new Error('Transaction aborted'));
    });
    this.done.catch(() => {}); // avoid unhandled-rejection noise; run() awaits it explicitly
  }
  store(n) {
    return this.tx.objectStore(n);
  }
  get(n, key) {
    return wrap(this.store(n).get(key));
  }
  put(n, value) {
    return wrap(this.store(n).put(value));
  }
  add(n, value) {
    return wrap(this.store(n).add(value));
  }
  delete(n, key) {
    return wrap(this.store(n).delete(key));
  }
  clear(n) {
    return wrap(this.store(n).clear());
  }
  getAll(n) {
    return wrap(this.store(n).getAll());
  }
  count(n) {
    return wrap(this.store(n).count());
  }
  /** All rows whose index value matches a key or IDBKeyRange. */
  getAllByIndex(n, index, query) {
    return wrap(this.store(n).index(index).getAll(asRange(query)));
  }
  countByIndex(n, index, query) {
    return wrap(this.store(n).index(index).count(asRange(query)));
  }
  /**
   * Line items of one invoice in the order they were entered. IndexedDB returns
   * rows in primary-key (random UUID) order, so we sort by the stored `line` number.
   */
  async getInvoiceLines(invoiceId) {
    const rows = await this.getAllByIndex('invoiceItems', 'invoiceId', invoiceId);
    return rows.sort((a, b) => (a.line || 0) - (b.line || 0));
  }
  /**
   * The newest `n` rows by an index (descending). Keeps walking until the last
   * index value is complete, so ties on the boundary are never cut in half —
   * callers then sort the few rows they get (e.g. by createdAt) and slice.
   */
  getLatest(storeName, index, n) {
    return new Promise((resolve, reject) => {
      const out = [];
      const req = this.store(storeName).index(index).openCursor(null, 'prev');
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        const cur = req.result;
        if (!cur) return resolve(out);
        if (out.length >= n && cur.key !== out[out.length - 1][index]) return resolve(out);
        out.push(cur.value);
        cur.continue();
      };
    });
  }
  /** First row for an index value (useful for unique indexes). */
  getByIndex(n, index, key) {
    return wrap(this.store(n).index(index).get(key));
  }
}

/**
 * Run `fn(tx)` inside one atomic transaction over the given stores.
 * If `fn` throws, every write made inside it is rolled back.
 * @template T
 * @param {string[]} stores
 * @param {'readonly'|'readwrite'} mode
 * @param {(tx: Tx) => Promise<T>} fn
 * @returns {Promise<T>}
 */
export async function run(stores, mode, fn) {
  const db = await openDB();
  const tx = new Tx(db.transaction(stores, mode));
  let result;
  try {
    result = await fn(tx);
  } catch (err) {
    try {
      tx.tx.abort();
    } catch {
      /* already finished */
    }
    await tx.done.catch(() => {});
    throw err;
  }
  await tx.done;
  return result;
}

// ---- Single-operation shortcuts -------------------------------------------
export const dbGet = (store, key) => run([store], 'readonly', (tx) => tx.get(store, key));
export const dbAll = (store) => run([store], 'readonly', (tx) => tx.getAll(store));
export const dbPut = (store, value) => run([store], 'readwrite', (tx) => tx.put(store, value));
export const dbDelete = (store, key) => run([store], 'readwrite', (tx) => tx.delete(store, key));
export const dbByIndex = (store, index, query) => run([store], 'readonly', (tx) => tx.getAllByIndex(store, index, query));
export const dbCount = (store) => run([store], 'readonly', (tx) => tx.count(store));

/** Key range helper for "between from and to inclusive". */
export const between = (from, to) => globalThis.IDBKeyRange.bound(from, to);

/** Ask the browser not to evict our data under storage pressure (important on Android). */
export async function requestPersistence() {
  try {
    if (navigator.storage?.persist) return await navigator.storage.persist();
  } catch {
    /* ignore */
  }
  return false;
}

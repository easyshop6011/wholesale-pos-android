/**
 * errors.js — error types shared by every layer.
 *
 *  - ValidationError     : a user-correctable problem; the message is shown as-is.
 *  - PermissionError     : the signed-in user may not do this (also a ValidationError
 *                          so the UI shows the message instead of "Something went wrong").
 *  - DuplicateOperation  : the same operation (same idempotency key) was submitted
 *                          twice; the second submission changed nothing.
 */
export class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ValidationError';
  }
}

export class PermissionError extends ValidationError {
  constructor(message = 'You do not have permission to do this.') {
    super(message);
    this.name = 'PermissionError';
  }
}

export class DuplicateOperationError extends ValidationError {
  constructor(message = 'This operation was already processed.') {
    super(message);
    this.name = 'DuplicateOperationError';
  }
}

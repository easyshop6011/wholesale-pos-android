/**
 * format.js — display formatting (money, quantity, dates) driven by settings.
 */
import { settings } from '../services/settings.js';
import { fmtQty } from './utils.js';
import { fmtDhakaDateTime, fmtDhakaTime, fmtDhakaDate } from './datetime.js';

/** An exact instant (ISO text) shown in Asia/Dhaka: "28 Oct 2026, 16:44" (or with seconds). */
export const fmtDateTime = fmtDhakaDateTime;
/** "16:44" in Asia/Dhaka. */
export const fmtClock = fmtDhakaTime;
/** "28 Oct 2026" in Asia/Dhaka. */
export const fmtDayOf = fmtDhakaDate;

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Number with thousands separators and 2 decimals (no currency symbol). */
export function num(n) {
  return (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** Money with the configured currency symbol, e.g. ৳1,250.00 */
export function money(n, symbol = settings.get('currency')) {
  const v = Number(n) || 0;
  return `${v < 0 ? '-' : ''}${symbol}${num(Math.abs(v))}`;
}

/** Quantity, trailing-zero free. */
export const qty = fmtQty;

/** "2026-10-26" -> "26 Oct 2026" (pure string handling, no timezone shifts). */
export function fmtDate(dateStr) {
  if (!dateStr) return '';
  const [y, m, d] = dateStr.split('-');
  return `${Number(d)} ${MONTHS[Number(m) - 1]} ${y}`;
}

/** "2026-10" -> "October 2026" */
export function fmtMonth(month) {
  if (!month) return '';
  const [y, m] = month.split('-');
  return `${new Date(Number(y), Number(m) - 1, 1).toLocaleString('en-US', { month: 'long' })} ${y}`;
}

/** Time "17:33:05" -> "17:33" */
export const fmtTime = (t) => (t || '').slice(0, 5);

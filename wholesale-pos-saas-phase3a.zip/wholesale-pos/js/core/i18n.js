/**
 * i18n.js — a tiny translation layer (no dependencies).
 *
 *   t('auth.login.title')                    → text in the active language
 *   t('auth.otp.sentInfo', { email })        → "{email}" placeholders; numbers become Bengali digits in "bn"
 *
 * Dictionaries are flat objects in js/i18n/{bn,en}.js. A missing key falls back to English, then to the
 * key itself (so a gap is visible, never a crash). A unit test keeps both dictionaries in step.
 *
 * Default language: Bengali when the cloud (SaaS) mode is on, English for the classic offline app until
 * its screens are translated. `?lang=bn|en` or localStorage "pos:lang" overrides it.
 */
import { en } from '../i18n/en.js';
import { bn } from '../i18n/bn.js';

const DICTS = { en, bn };
let locale = 'en';

export const LOCALES = Object.keys(DICTS);
export const getLocale = () => locale;

export function setLocale(next) {
  if (!DICTS[next]) throw new Error(`Unknown language: ${next}`);
  locale = next;
  if (typeof document !== 'undefined') document.documentElement.lang = next;
}

const BN_DIGITS = '০১২৩৪৫৬৭৮৯';
/** 1234 → ১২৩৪ */
export const toBnDigits = (v) => String(v).replace(/[0-9]/g, (d) => BN_DIGITS[Number(d)]);
/** ১২৩৪ → 1234 (for reading what a person typed) */
export const fromBnDigits = (v) => String(v).replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));
/** A number or digit string in the digits of the active language. */
export const nDigits = (v) => (locale === 'bn' ? toBnDigits(v) : String(v));

export function t(key, params) {
  const raw = DICTS[locale]?.[key] ?? DICTS.en[key] ?? key;
  if (!params) return raw;
  return raw.replace(/\{(\w+)\}/g, (whole, name) => {
    if (!(name in params)) return whole;
    const v = params[name];
    return typeof v === 'number' ? nDigits(v) : String(v);
  });
}

export const hasKey = (key) => Object.prototype.hasOwnProperty.call(DICTS[locale] || {}, key);

/** Choose the start-up language: explicit choice wins, otherwise Bengali in cloud mode. */
export function initLocale({ cloudEnabled = false, search = '', stored = null } = {}) {
  const fromUrl = new URLSearchParams(search).get('lang');
  const pick = [fromUrl, stored].find((l) => l && DICTS[l]) || (cloudEnabled ? 'bn' : 'en');
  setLocale(pick);
  return pick;
}

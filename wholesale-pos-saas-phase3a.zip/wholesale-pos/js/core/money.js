/**
 * money.js — exact-enough money and quantity arithmetic.
 *
 * WHY: JavaScript numbers are binary floating point, so `1.255 * 100` is
 * 125.49999999999999 and naive rounding turns ৳1.255 into ৳1.25. Every amount in
 * the app is a decimal with at most 2 places (money) or 3 places (quantity), so:
 *
 *   - rounding works on the SHORTEST DECIMAL STRING of the number (what the user
 *     typed / sees), half away from zero — never on the binary expansion;
 *   - sums are accumulated as INTEGER minor units (paisa) and converted back once;
 *   - line totals multiply scaled integers (thousandths × paisa) and round once.
 *
 * Pure functions, no DOM, no dependencies — unit-tested in Node.
 */
import { ValidationError } from './errors.js';

/** Largest amount / quantity accepted from the user (keeps every product exact in a double). */
export const MAX_AMOUNT = 1e9;

const BN_DIGITS = '০১২৩৪৫৬৭৮৯';

/** Bengali digits → ASCII, so "১২০.৫০" is understood like "120.50". */
export const normalizeDigits = (s) => String(s ?? '').replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));

/**
 * Round `n` to `digits` decimals, half away from zero, using its shortest decimal
 * representation: roundTo(1.005, 2) === 1.01, roundTo(2.675, 2) === 2.68.
 */
export function roundTo(n, digits = 2) {
  const x = Number(n);
  if (!Number.isFinite(x)) return 0;
  const sign = x < 0 ? -1 : 1;
  const a = Math.abs(x);
  const s = String(a);
  if (/e/i.test(s)) return sign * (Number(a.toFixed(digits)) || 0); // tiny / huge numbers
  const dot = s.indexOf('.');
  if (dot === -1 || s.length - dot - 1 <= digits) return sign * a || 0; // already short enough
  const scaled = Number(s.slice(0, dot) + s.slice(dot + 1, dot + 1 + digits)) + (s.charCodeAt(dot + 1 + digits) >= 53 ? 1 : 0);
  return sign * (scaled / 10 ** digits) || 0;
}

/** Money rounding (2 decimals). */
export const round2 = (n) => roundTo(n, 2);

/** Quantity rounding (3 decimals). */
export const round3 = (n) => roundTo(n, 3);

/** Money → integer paisa. */
export const toMinor = (n) => Math.round(round2(n) * 100);

/** Integer paisa → money. */
export const fromMinor = (i) => (Number(i) || 0) / 100;

/** Sum of money values, exact to the paisa. */
export function sum(arr) {
  let total = 0;
  for (const v of arr) total += toMinor(Number(v) || 0);
  return fromMinor(total);
}

/**
 * qty × unitPrice rounded once to the paisa (half up), computed on scaled integers
 * so 2.505 kg × ৳1.10 never drifts. Throws when the result cannot be exact.
 */
export function lineTotal(qty, unitPrice) {
  const q = Math.round(round3(qty) * 1000); // thousandths
  const p = toMinor(unitPrice); // paisa
  const prod = q * p; // 1e-5 currency units
  if (!Number.isSafeInteger(prod)) throw new ValidationError('That amount is too large.');
  const sign = prod < 0 ? -1 : 1;
  return fromMinor(sign * Math.floor((Math.abs(prod) + 500) / 1000));
}

/** Lenient parse for display code: "1,250.50" / "১২৫০.৫০" → number, garbage → 0. */
export function toNum(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  const n = Number(normalizeDigits(v).replace(/,/g, '').trim());
  return Number.isFinite(n) ? n : 0;
}

/**
 * Strict parse for anything that is saved. Empty → `empty` (default 0); text that is
 * not a number (or is Infinity/NaN) is REJECTED instead of silently becoming 0.
 * @param {*} v
 * @param {string} label  used in the error message ("Unit price")
 * @param {{min?:number, max?:number, empty?:number|null, decimals?:number}} [o]
 */
export function parseNumber(v, label, { min = 0, max = MAX_AMOUNT, empty = 0, decimals = 2 } = {}) {
  if (v === '' || v === null || v === undefined) {
    if (empty === null) throw new ValidationError(`${label} is required.`);
    return empty;
  }
  let n;
  if (typeof v === 'number') n = v;
  else {
    const t = normalizeDigits(v).replace(/,/g, '').trim();
    if (t === '') return empty ?? 0;
    n = /^[+-]?(\d+\.?\d*|\.\d+)$/.test(t) ? Number(t) : NaN;
  }
  if (!Number.isFinite(n)) throw new ValidationError(`${label} must be a number.`);
  if (n < min) throw new ValidationError(min === 0 ? `${label} cannot be negative.` : `${label} must be at least ${min}.`);
  if (n > max) throw new ValidationError(`${label} is too large.`);
  return roundTo(n, decimals);
}

/** Strict money parse (2 decimals). */
export const parseMoney = (v, label = 'Amount', o = {}) => parseNumber(v, label, { ...o, decimals: 2 });

/** Strict quantity parse (3 decimals); the result is always > 0 unless `allowZero`. */
export function parseQty(v, label = 'Quantity', { allowZero = false } = {}) {
  const q = parseNumber(v, label, { decimals: 3 });
  if (!allowZero && !(q > 0)) throw new ValidationError(`${label} must be greater than zero.`);
  return q;
}

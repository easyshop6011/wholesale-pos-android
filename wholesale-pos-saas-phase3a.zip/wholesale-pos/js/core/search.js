/**
 * search.js — pure text-search helpers shared by every list and the global
 * search palette (no DOM, no database → unit-tested in Node).
 *
 * Rules
 *  - Case-insensitive, accents ignored ("café" matches "cafe").
 *  - Bengali digits equal ASCII digits ("০১৭১১" matches "01711").
 *  - Several words = ALL of them must appear, in any order ("rice 25" finds "Basmati Rice 25kg").
 */

const BN_DIGITS = '০১২৩৪৫৬৭৮৯';

/** Lower-case, Bengali digits → ASCII, strip accents, collapse spaces. */
export function normalizeText(input) {
  let s = String(input ?? '').toLowerCase();
  s = s.replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));
  s = s.normalize('NFD').replace(/[̀-ͯ]/g, '');
  return s.replace(/\s+/g, ' ').trim();
}

/** Search words of a query (normalised, no empties). */
export function terms(query) {
  const n = normalizeText(query);
  return n ? n.split(' ') : [];
}

/**
 * Does `haystack` contain every word of `query`?
 * Pass a pre-normalised haystack (see {@link normalizeText}) in hot loops.
 */
export function matches(haystack, query) {
  const t = terms(query);
  if (!t.length) return true;
  const h = normalizeText(haystack);
  return t.every((w) => h.includes(w));
}

/**
 * Relevance score for ranking (higher = better): whole-field match > field
 * starts with query > a word starts with query > plain substring. 0 = no match.
 * @param {string[]} fields  most important field first
 */
export function score(fields, query) {
  const t = terms(query);
  if (!t.length) return 1;
  const norm = fields.map(normalizeText);
  const all = norm.join(' ');
  if (!t.every((w) => all.includes(w))) return 0;
  const q = t.join(' ');
  let best = 1;
  norm.forEach((f, i) => {
    const weight = Math.max(1, fields.length - i); // earlier fields count more
    if (f === q) best = Math.max(best, 100 * weight);
    else if (f.startsWith(q)) best = Math.max(best, 60 * weight);
    else if (f.split(' ').some((w) => w.startsWith(t[0]))) best = Math.max(best, 30 * weight);
    else if (f.includes(q)) best = Math.max(best, 10 * weight);
  });
  return best;
}

/** Filter + rank `items` by `query` using `fieldsOf(item)`; best first, stable for ties. */
export function rank(items, query, fieldsOf, limit = Infinity) {
  if (!terms(query).length) return items.slice(0, limit);
  return items
    .map((item, i) => ({ item, i, s: score(fieldsOf(item), query) }))
    .filter((r) => r.s > 0)
    .sort((a, b) => b.s - a.s || a.i - b.i)
    .slice(0, limit)
    .map((r) => r.item);
}

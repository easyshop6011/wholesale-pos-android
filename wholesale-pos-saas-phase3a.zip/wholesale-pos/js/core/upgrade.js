/**
 * upgrade.js — pure "bring an old row up to the current shape" helpers.
 *
 * Used by the IndexedDB migration (db.js) AND when restoring a backup made by an
 * older app version, so both paths produce identical rows. They only DERIVE values
 * from facts already stored on the row — nothing is invented and no old value is
 * overwritten.
 */
import { dhakaDate } from './datetime.js';

const round3 = (n) => Math.round(n * 1000) / 1000;

/** Add previousStock / date / refNo to a stock movement written before v3. Returns a new object (or the same one if nothing changed). */
export function upgradeMovement(m) {
  if (!m || typeof m !== 'object') return m;
  const patch = {};
  if (m.previousStock === undefined && Number.isFinite(m.balance) && Number.isFinite(m.qty)) patch.previousStock = round3(m.balance - m.qty);
  if (!m.date && m.createdAt) {
    const d = dhakaDate(m.createdAt);
    if (d) patch.date = d;
  }
  if (m.refNo === undefined) {
    const hit = /^(?:Sale|Void) (\S+)$/.exec(String(m.reason || ''));
    if (hit) patch.refNo = hit[1];
  }
  return Object.keys(patch).length ? { ...m, ...patch } : m;
}

/**
 * utils.js — small, dependency-free helpers shared by every layer.
 * Nothing here touches the DOM, so it also runs under Node (tests).
 */

import { ValidationError, PermissionError, DuplicateOperationError } from './errors.js';
import { round2, toNum, sum } from './money.js';
import { dhakaParts } from './datetime.js';

// Re-exported so every existing `import { … } from '../core/utils.js'` keeps working.
export { ValidationError, PermissionError, DuplicateOperationError, round2, toNum, sum };
export { round3, roundTo, lineTotal, parseMoney, parseQty, parseNumber, toMinor, fromMinor, normalizeDigits, MAX_AMOUNT } from './money.js';

/**
 * RFC-4122 v4 UUID. Uses crypto.randomUUID when available (secure contexts),
 * otherwise falls back to getRandomValues (works on plain http:// LAN hosts).
 * @returns {string}
 */
export function uuid() {
  const c = globalThis.crypto;
  if (c?.randomUUID) return c.randomUUID();
  const b = new Uint8Array(16);
  if (c?.getRandomValues) c.getRandomValues(b);
  else for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = [...b].map((x) => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

const pad2 = (n) => String(n).padStart(2, '0');

let lastStamp = 0;

/**
 * Current time that is strictly increasing within this session: two records
 * created in the same millisecond still get distinct, correctly ordered
 * `createdAt` values (so "newest first" lists and oldest-first sync never tie).
 * @returns {Date}
 */
export function monotonicNow() {
  lastStamp = Math.max(Date.now(), lastStamp + 1);
  return new Date(lastStamp);
}

/**
 * Break a Date into the strings the app stores and indexes: `date` (YYYY-MM-DD),
 * `time` (HH:MM:SS), `month` (YYYY-MM) in BUSINESS time (Asia/Dhaka — see
 * core/datetime.js) plus `iso`, the exact UTC instant. Without an argument it
 * uses {@link monotonicNow}.
 * @param {Date} [d]
 * @returns {{date:string,time:string,month:string,iso:string}}
 */
export function dateParts(d = monotonicNow()) {
  return dhakaParts(d);
}

/** Add `n` days to a YYYY-MM-DD string (pure calendar arithmetic — independent of any time zone). */
export function addDays(dateStr, n) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + n));
  return `${dt.getUTCFullYear()}-${pad2(dt.getUTCMonth() + 1)}-${pad2(dt.getUTCDate())}`;
}

/** First and last date (YYYY-MM-DD) of a YYYY-MM month. */
export function monthRange(month) {
  const [y, m] = month.split('-').map(Number);
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return { from: `${month}-01`, to: `${month}-${pad2(last)}` };
}

/** Keep digits and a leading "+" — used to compare/deduplicate phone numbers. */
export function normalizePhone(p) {
  const s = String(p ?? '')
    .replace(/[০-৯]/g, (d) => '০১২৩৪৫৬৭৮৯'.indexOf(d)) // Bengali digits → ASCII
    .trim();
  if (!s) return '';
  const plus = s.startsWith('+') ? '+' : '';
  return plus + s.replace(/[^\d]/g, '');
}

/** Trailing-zero-free quantity formatting (up to 3 decimals). */
export function fmtQty(n) {
  return String(Number((Number(n) || 0).toFixed(3)));
}

/** Simple debounce for search boxes. */
export function debounce(fn, ms = 200) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

/**
 * Convert rows (array of arrays) to CSV text. Cells beginning with = + - @ are
 * prefixed with a quote to stop spreadsheet formula injection.
 */
export function toCSV(rows) {
  const esc = (v) => {
    let s = v == null ? '' : String(v);
    if (/^[=+\-@]/.test(s) && Number.isNaN(Number(s))) s = `'${s}`;
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return rows.map((r) => r.map(esc).join(',')).join('\r\n');
}

/** Bytes -> base64 (works in browser and Node). */
export function bytesToBase64(bytes) {
  let s = '';
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  return btoa(s);
}

/** base64 -> Uint8Array. */
export function base64ToBytes(b64) {
  const s = atob(b64);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

/** Sleep helper used when pacing Bluetooth writes. */
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

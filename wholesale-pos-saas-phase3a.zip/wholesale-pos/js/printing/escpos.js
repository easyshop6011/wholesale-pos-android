/**
 * escpos.js — ESC/POS command builder and bitmap conversion.
 *
 * ESC/POS is the command language spoken by virtually every 58/80 mm thermal
 * receipt printer (Epson, Xprinter, Rongta, Zjiang, Sunmi, …). This module is
 * pure (no DOM) so it is unit-tested under Node.
 */

const ESC = 0x1b;
const GS = 0x1d;
const LF = 0x0a;

/** Map common non-ASCII symbols to printable ASCII; everything else becomes "?". */
const ASCII_MAP = { '৳': 'Tk', '₹': 'Rs', '€': 'EUR', '£': 'GBP', '¥': 'JPY', '–': '-', '—': '-', '‘': "'", '’': "'", '“': '"', '”': '"', '×': 'x', '•': '*', '…': '...', ' ': ' ' };

/** Make text safe for the printer's default code page (ASCII only). */
export function asciiize(str) {
  let out = '';
  for (const ch of String(str ?? '')) {
    if (ch in ASCII_MAP) out += ASCII_MAP[ch];
    else {
      const c = ch.codePointAt(0);
      out += c >= 0x20 && c < 0x7f ? ch : c === 0x0a ? '\n' : '?';
    }
  }
  return out;
}

/** Encode (already-asciiized) text to bytes. */
export function encodeAscii(str) {
  const s = asciiize(str);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

/**
 * 1-bit bitmap from RGBA pixels.
 * @param {Uint8ClampedArray|Uint8Array} rgba
 * @param {number} width
 * @param {number} height
 * @param {{threshold?:number, dither?:boolean}} [opts] threshold 0–255: pixels darker than this print black
 * @returns {{width:number,height:number,bytesPerRow:number,data:Uint8Array}} data is MSB-first, 1 = black
 */
export function bitmapFromRGBA(rgba, width, height, { threshold = 170, dither = false } = {}) {
  const bytesPerRow = Math.ceil(width / 8);
  const data = new Uint8Array(bytesPerRow * height);
  // Luminance on white background (transparent pixels count as white).
  const gray = new Float32Array(width * height);
  for (let i = 0, p = 0; i < gray.length; i++, p += 4) {
    const a = rgba[p + 3] / 255;
    const l = 0.299 * rgba[p] + 0.587 * rgba[p + 1] + 0.114 * rgba[p + 2];
    gray[i] = l * a + 255 * (1 - a);
  }
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x;
      const old = gray[i];
      const black = old < threshold;
      if (dither) {
        const err = old - (black ? 0 : 255);
        if (x + 1 < width) gray[i + 1] += (err * 7) / 16;
        if (y + 1 < height) {
          if (x > 0) gray[i + width - 1] += (err * 3) / 16;
          gray[i + width] += (err * 5) / 16;
          if (x + 1 < width) gray[i + width + 1] += err / 16;
        }
      }
      if (black) data[y * bytesPerRow + (x >> 3)] |= 0x80 >> (x & 7);
    }
  }
  return { width, height, bytesPerRow, data };
}

/** Concatenate Uint8Arrays. */
export function concatBytes(parts) {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

/** Fluent ESC/POS byte builder. */
export class EscPosBuilder {
  constructor() {
    this.parts = [];
  }
  raw(bytes) {
    this.parts.push(bytes instanceof Uint8Array ? bytes : Uint8Array.from(bytes));
    return this;
  }
  /** ESC @ — reset printer to defaults. */
  init() {
    return this.raw([ESC, 0x40]);
  }
  /** ESC a n — alignment. */
  align(a) {
    return this.raw([ESC, 0x61, { left: 0, center: 1, right: 2 }[a] ?? 0]);
  }
  /** ESC E n — bold. */
  bold(on) {
    return this.raw([ESC, 0x45, on ? 1 : 0]);
  }
  /** GS ! n — character size multiplier (1–8 each). */
  size(w = 1, h = 1) {
    return this.raw([GS, 0x21, ((w - 1) << 4) | (h - 1)]);
  }
  text(str) {
    return this.raw(encodeAscii(str));
  }
  line(str = '') {
    return this.text(str).raw([LF]);
  }
  /** ESC d n — print and feed n lines. */
  feed(n = 1) {
    return this.raw([ESC, 0x64, n]);
  }
  /** GS V 66 0 — feed to cutting position and partial cut. */
  cut() {
    return this.raw([GS, 0x56, 0x42, 0x00]);
  }
  /** ESC p — pulse cash drawer pin 2. */
  drawer() {
    return this.raw([ESC, 0x70, 0x00, 0x19, 0xfa]);
  }
  /**
   * GS v 0 — raster bit image, sent in bands so printers with small buffers
   * don't overflow.
   * @param {{width:number,height:number,bytesPerRow:number,data:Uint8Array}} bmp
   * @param {number} [bandRows]
   */
  raster(bmp, bandRows = 192) {
    for (let y = 0; y < bmp.height; y += bandRows) {
      const rows = Math.min(bandRows, bmp.height - y);
      this.raw([GS, 0x76, 0x30, 0x00, bmp.bytesPerRow & 0xff, bmp.bytesPerRow >> 8, rows & 0xff, rows >> 8]);
      this.raw(bmp.data.subarray(y * bmp.bytesPerRow, (y + rows) * bmp.bytesPerRow));
    }
    return this;
  }
  build() {
    return concatBytes(this.parts);
  }
}

/**
 * printer.js — printer transports and the print pipeline.
 *
 * Pipeline:  invoice → receipt model → (raster bitmap | ESC/POS text) → bytes → transport
 *
 * TRANSPORTS (choose in Settings → Printer)
 *   webbluetooth  Web Bluetooth (BLE printers) — Chrome/Edge on Android & desktop, HTTPS only
 *   webusb        WebUSB — USB printers; Chrome on Android (OTG cable) & desktop
 *   webserial     Web Serial — USB-serial / paired Bluetooth-classic COM ports (desktop Chrome)
 *   rawbt         Hand the bytes to the free "RawBT" Android app (any Bluetooth/USB/LAN printer)
 *   native        Android APK: DIRECT Bluetooth-classic (SPP) and USB-host printing through the
 *                 bundled ThermalPrinter Capacitor plugin (android-plugin/) — works fully offline
 *   capble        Native BLE via a Capacitor plugin (only inside an Android APK build)
 *   browser       System print dialog (works with any installed printer / Android print service)
 *
 * All transports are fully offline — nothing here touches the network.
 */
import { settings } from '../services/settings.js';
import { EscPosBuilder, bitmapFromRGBA, concatBytes } from './escpos.js';
import { buildReceiptModel, buildTextReceipt } from './receipt.js';
import { renderReceiptCanvas } from './receipt-canvas.js';
import { bytesToBase64, sleep } from '../core/utils.js';
import { dhakaParts } from '../core/datetime.js';

/** GATT services commonly exposed by BLE thermal printers (needed for Web Bluetooth). */
const BLE_SERVICES = [
  '000018f0-0000-1000-8000-00805f9b34fb',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000ff00-0000-1000-8000-00805f9b34fb',
  '0000fff0-0000-1000-8000-00805f9b34fb',
  '0000ae30-0000-1000-8000-00805f9b34fb',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  '38eb4a80-c570-11e3-9507-0002a5d5c51b',
];

const LS = {
  get: (k) => {
    try {
      return localStorage.getItem(k);
    } catch {
      return null;
    }
  },
  set: (k, v) => {
    try {
      localStorage.setItem(k, v);
    } catch {
      /* ignore */
    }
  },
};

export class PrinterError extends Error {}

/** Split bytes into chunks. */
function* chunks(bytes, size) {
  for (let i = 0; i < bytes.length; i += size) yield bytes.subarray(i, i + size);
}

// ---------------------------------------------------------------------------
// Transport implementations. Each has: supported(), name(), send(bytes), disconnect()
// ---------------------------------------------------------------------------

const webBluetooth = {
  id: 'webbluetooth',
  label: 'Bluetooth (BLE) — Web Bluetooth',
  device: null,
  characteristic: null,
  supported: () => typeof navigator !== 'undefined' && !!navigator.bluetooth,
  name() {
    return this.device?.name || LS.get('pos:btName') || '';
  },
  /** Pair (shows the browser chooser) and locate a writable characteristic. */
  async connect({ forcePick = false } = {}) {
    if (!this.device || forcePick) {
      this.device = await navigator.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: BLE_SERVICES });
      this.device.addEventListener('gattserverdisconnected', () => {
        this.characteristic = null;
      });
      LS.set('pos:btName', this.device.name || '');
    }
    if (this.characteristic && this.device.gatt.connected) return;
    const server = this.device.gatt.connected ? this.device.gatt : await this.device.gatt.connect();
    const services = await server.getPrimaryServices();
    let found = null;
    for (const svc of services) {
      for (const ch of await svc.getCharacteristics()) {
        if (ch.properties.writeWithoutResponse || ch.properties.write) {
          // Prefer the well-known printer characteristics, otherwise take the first writable one.
          if (!found || /2af1|ffe1|ff02|fff2|ae01|bef8d6c9|49535343-8841/.test(ch.uuid)) found = ch;
        }
      }
    }
    if (!found) throw new PrinterError('No writable Bluetooth characteristic found. This printer may be Bluetooth Classic (SPP) — use RawBT or a USB printer instead.');
    this.characteristic = found;
  },
  async send(bytes) {
    await this.connect();
    const size = Math.max(20, Number(settings.get('bleChunkSize')) || 100);
    const delay = Number(settings.get('bleDelayMs')) || 0;
    const ch = this.characteristic;
    for (const part of chunks(bytes, size)) {
      if (ch.properties.writeWithoutResponse && ch.writeValueWithoutResponse) await ch.writeValueWithoutResponse(part);
      else await ch.writeValueWithResponse(part);
      if (delay) await sleep(delay);
    }
  },
  disconnect() {
    try {
      this.device?.gatt?.disconnect();
    } catch {
      /* ignore */
    }
    this.characteristic = null;
  },
};

const webUsb = {
  id: 'webusb',
  label: 'USB — WebUSB',
  device: null,
  endpoint: null,
  supported: () => typeof navigator !== 'undefined' && !!navigator.usb,
  name() {
    return this.device ? this.device.productName || `USB ${this.device.vendorId.toString(16)}:${this.device.productId.toString(16)}` : LS.get('pos:usbName') || '';
  },
  async connect({ forcePick = false } = {}) {
    if (!this.device || forcePick) {
      const known = forcePick ? [] : await navigator.usb.getDevices(); // previously authorised devices reconnect silently
      this.device = known[0] || (await navigator.usb.requestDevice({ filters: [] }));
      this.endpoint = null;
    }
    const dev = this.device;
    if (!dev.opened) await dev.open();
    if (dev.configuration === null) await dev.selectConfiguration(1);
    if (this.endpoint) return;
    // Find a bulk-OUT endpoint, preferring the USB "Printer" class (7).
    let pick = null;
    for (const iface of dev.configuration.interfaces) {
      for (const alt of iface.alternates) {
        const ep = alt.endpoints.find((e) => e.direction === 'out' && e.type === 'bulk');
        if (ep && (!pick || alt.interfaceClass === 7)) pick = { iface: iface.interfaceNumber, alt: alt.alternateSetting, ep: ep.endpointNumber };
      }
    }
    if (!pick) throw new PrinterError('This USB device has no printable (bulk OUT) endpoint.');
    try {
      await dev.claimInterface(pick.iface);
    } catch (e) {
      throw new PrinterError(`Could not claim the USB printer interface (${e.message}). Close other apps using the printer and re-plug it.`);
    }
    if (pick.alt) await dev.selectAlternateInterface(pick.iface, pick.alt);
    this.endpoint = pick.ep;
    LS.set('pos:usbName', this.name());
  },
  async send(bytes) {
    await this.connect();
    for (const part of chunks(bytes, 16384)) await this.device.transferOut(this.endpoint, part);
  },
  disconnect() {
    try {
      this.device?.close();
    } catch {
      /* ignore */
    }
    this.endpoint = null;
  },
};

const webSerial = {
  id: 'webserial',
  label: 'Serial port — Web Serial (desktop)',
  port: null,
  supported: () => typeof navigator !== 'undefined' && !!navigator.serial,
  name: () => 'Serial port',
  async connect({ forcePick = false } = {}) {
    if (!this.port || forcePick) this.port = (!forcePick && (await navigator.serial.getPorts())[0]) || (await navigator.serial.requestPort());
    if (!this.port.readable) await this.port.open({ baudRate: Number(settings.get('serialBaud')) || 115200 });
  },
  async send(bytes) {
    await this.connect();
    const w = this.port.writable.getWriter();
    try {
      for (const part of chunks(bytes, 4096)) await w.write(part);
    } finally {
      w.releaseLock();
    }
  },
  async disconnect() {
    try {
      await this.port?.close();
    } catch {
      /* ignore */
    }
    this.port = null;
  },
};

/**
 * RawBT (https://rawbt.ru) is a free Android "print service" that talks to
 * Bluetooth-classic, USB and LAN printers. We hand it the ESC/POS bytes via its
 * `rawbt:` URL scheme. Best for Bluetooth-classic printers that Web Bluetooth
 * cannot reach. Prefer *Text mode* here — very long raster receipts can exceed
 * Android's intent size limit.
 */
const rawBt = {
  id: 'rawbt',
  label: 'RawBT app (Android: Bluetooth / USB / LAN)',
  supported: () => /android/i.test(navigator.userAgent),
  name: () => 'RawBT',
  async connect() {},
  async send(bytes) {
    if (bytes.length > 250000) throw new PrinterError('Receipt is too large for RawBT. Switch to Text mode in printer settings.');
    const a = document.createElement('a');
    a.href = `rawbt:base64,${bytesToBase64(bytes)}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    await sleep(300);
  },
  disconnect() {},
};

/**
 * Native BLE inside an Android APK built with Capacitor + @capacitor-community/bluetooth-le.
 * (Web Bluetooth does not exist inside a plain Android WebView.) See docs/ANDROID.md.
 */
const capBle = {
  id: 'capble',
  label: 'Bluetooth (BLE) — native app',
  deviceId: null,
  target: null,
  plugin: () => globalThis.Capacitor?.Plugins?.BluetoothLe,
  supported() {
    return !!this.plugin();
  },
  name: () => LS.get('pos:btName') || '',
  async connect({ forcePick = false } = {}) {
    const ble = this.plugin();
    if (!ble) throw new PrinterError('Bluetooth plugin missing — see docs/ANDROID.md.');
    await ble.initialize();
    if (!this.deviceId || forcePick) {
      const dev = await ble.requestDevice({ optionalServices: BLE_SERVICES });
      this.deviceId = dev.deviceId;
      LS.set('pos:btName', dev.name || dev.deviceId);
      this.target = null;
    }
    await ble.connect({ deviceId: this.deviceId });
    if (this.target) return;
    const { services } = await ble.getServices({ deviceId: this.deviceId });
    for (const s of services) {
      const c = s.characteristics.find((x) => x.properties.writeWithoutResponse || x.properties.write);
      if (c) {
        this.target = { service: s.uuid, characteristic: c.uuid, noResp: !!c.properties.writeWithoutResponse };
        break;
      }
    }
    if (!this.target) throw new PrinterError('No writable characteristic on this printer.');
  },
  async send(bytes) {
    await this.connect();
    const ble = this.plugin();
    const size = Math.max(20, Number(settings.get('bleChunkSize')) || 100);
    const hex = (u8) => [...u8].map((b) => b.toString(16).padStart(2, '0')).join('');
    for (const part of chunks(bytes, size)) {
      const args = { deviceId: this.deviceId, service: this.target.service, characteristic: this.target.characteristic, value: hex(part) };
      await (this.target.noResp ? ble.writeWithoutResponse(args) : ble.write(args));
      await sleep(Number(settings.get('bleDelayMs')) || 0);
    }
  },
  disconnect() {
    this.plugin()?.disconnect?.({ deviceId: this.deviceId }).catch?.(() => {});
  },
};


/**
 * Direct printing from the Android APK through the bundled `ThermalPrinter`
 * Capacitor plugin (android-plugin/ThermalPrinterPlugin.java). Supports the
 * paired Bluetooth-classic (SPP) printers that most 80 mm thermal printers are,
 * and USB printers connected with an OTG cable. No internet, no extra apps.
 * The chosen printer is remembered in localStorage (`pos:nativePrinter`).
 */
const nativePrinter = {
  id: 'native',
  label: 'Bluetooth / USB — Android app (direct)',
  plugin: () => globalThis.Capacitor?.Plugins?.ThermalPrinter,
  supported() {
    return !!this.plugin() && globalThis.Capacitor?.isNativePlatform?.() !== false;
  },
  selected() {
    try {
      return JSON.parse(LS.get('pos:nativePrinter') || 'null');
    } catch {
      return null;
    }
  },
  name() {
    return this.selected()?.name || '';
  },
  /** Paired Bluetooth printers + attached USB devices: [{type, address, name}]. */
  async listDevices() {
    const p = this.plugin();
    if (!p) throw new PrinterError('This is not the Android app build — see docs/ANDROID.md.');
    await p.ensurePermissions?.().catch(() => {});
    const [bt, usb] = await Promise.all([p.listBluetoothDevices().catch(() => ({ devices: [] })), p.listUsbDevices().catch(() => ({ devices: [] }))]);
    return [...(bt.devices || []).map((d) => ({ type: 'bluetooth', address: d.address, name: d.name || d.address })), ...(usb.devices || []).map((d) => ({ type: 'usb', address: d.address, name: d.name || d.address }))];
  },
  /** Remember the chosen printer and drop any open connection. */
  select(dev) {
    LS.set('pos:nativePrinter', JSON.stringify(dev));
    this.disconnect();
  },
  async connect({ forcePick = false } = {}) {
    const sel = this.selected();
    if (!sel) throw new PrinterError('No printer chosen. Open Settings → Printer and tap "Choose printer".');
    const p = this.plugin();
    if (forcePick) await p.disconnect().catch(() => {});
    const st = await p.isConnected().catch(() => ({ connected: false }));
    if (st.connected && !forcePick) return;
    try {
      await p.connect({ type: sel.type, address: sel.address });
    } catch (e) {
      throw new PrinterError(`Could not connect to ${sel.name}: ${e?.message || e}. Is the printer on, paired and in range?`);
    }
  },
  async send(bytes) {
    await this.connect();
    const p = this.plugin();
    for (const part of chunks(bytes, 3072)) await p.write({ data: bytesToBase64(part) });
  },
  disconnect() {
    this.plugin()?.disconnect?.().catch?.(() => {});
  },
};

/** Browser print dialog fallback: prints the receipt image at exactly 80 mm wide. */
const browserPrint = {
  id: 'browser',
  label: 'System print dialog (any installed printer)',
  supported: () => typeof window !== 'undefined' && !!window.print,
  name: () => 'System printer',
  async connect() {},
  /** For this transport `payload` is a canvas, not bytes. */
  async send(canvas) {
    const url = canvas.toDataURL('image/png');
    const frame = document.createElement('iframe');
    frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
    document.body.appendChild(frame);
    const doc = frame.contentDocument;
    doc.open();
    doc.write(`<!doctype html><html><head><meta charset="utf-8"><title>Receipt</title>
      <style>@page{size:80mm auto;margin:0}html,body{margin:0;padding:0;background:#fff}img{display:block;width:80mm;max-width:100%}</style></head>
      <body><img id="r" src="${url}"></body></html>`);
    doc.close();
    await new Promise((res) => {
      const img = doc.getElementById('r');
      if (img.complete) res();
      else img.onload = res;
    });
    frame.contentWindow.focus();
    frame.contentWindow.print();
    setTimeout(() => frame.remove(), 60000);
  },
  disconnect() {},
};

export const TRANSPORTS = [nativePrinter, webBluetooth, webUsb, webSerial, rawBt, capBle, browserPrint];
export const getTransport = (id) => TRANSPORTS.find((t) => t.id === id) || browserPrint;

/** Transport currently selected in settings. */
export const currentTransport = () => getTransport(settings.get('printTransport'));

// ---------------------------------------------------------------------------
// Print pipeline
// ---------------------------------------------------------------------------

/** Build the raster print job (ESC/POS bytes) from a receipt model; also returns the canvas. */
export async function buildRasterJob(model, s = settings.all()) {
  const canvas = await renderReceiptCanvas(model, { width: s.paperWidthDots });
  const img = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
  const bmp = bitmapFromRGBA(img.data, canvas.width, canvas.height, { threshold: s.printDensity });
  const b = new EscPosBuilder().init().align('left').raster(bmp).feed(s.feedLines ?? 3);
  if (s.cutPaper) b.cut();
  if (s.openDrawer) b.drawer();
  return { bytes: b.build(), canvas };
}

/** Send a receipt model to the selected printer. */
export async function printModel(model) {
  const s = settings.all();
  const transport = getTransport(s.printTransport);
  if (!transport.supported()) throw new PrinterError(`"${transport.label}" is not supported on this device/browser. Choose another printer type in Settings → Printer.`);
  const copies = Math.max(1, Number(s.copies) || 1);

  if (transport.id === 'browser') {
    const canvas = await renderReceiptCanvas(model, { width: s.paperWidthDots });
    for (let i = 0; i < copies; i++) await transport.send(canvas);
    return;
  }
  let job;
  if (s.printMode === 'text') job = buildTextReceipt(model, { columns: s.textColumns, cut: s.cutPaper, drawer: s.openDrawer, feedLines: s.feedLines });
  else job = (await buildRasterJob(model, s)).bytes;
  const bytes = copies > 1 ? concatBytes(Array.from({ length: copies }, () => job)) : job;
  try {
    await transport.send(bytes);
  } catch (err) {
    transport.disconnect?.(); // force a fresh connection next time
    if (err instanceof PrinterError) throw err;
    if (err?.name === 'NotFoundError' || err?.name === 'AbortError') throw new PrinterError('No printer selected.');
    throw new PrinterError(`Printing failed: ${err?.message || err}`);
  }
}

/** Print a saved invoice. */
export function printInvoice(invoice, items) {
  return printModel(buildReceiptModel(invoice, items, settings.all()));
}

/** Pair / choose the printer for the selected transport (must run from a click). */
export async function connectPrinter() {
  const t = currentTransport();
  if (!t.supported()) throw new PrinterError(`"${t.label}" is not supported on this device/browser.`);
  try {
    await t.connect({ forcePick: true });
  } catch (err) {
    if (err instanceof PrinterError) throw err;
    if (err?.name === 'NotFoundError' || err?.name === 'AbortError') throw new PrinterError('No printer selected.');
    throw new PrinterError(`Could not connect: ${err?.message || err}`);
  }
  return t.name();
}

/** A sample receipt for testing the printer and layout. */
export function sampleInvoice() {
  const now = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const items = [
    { name: 'Basmati Rice Premium 25kg', unit: 'bag', qty: 4, unitPrice: 2450, total: 9800 },
    { name: 'Soybean Oil 5L', unit: 'btl', qty: 12, unitPrice: 880, total: 10560 },
    { name: 'চিনি (Sugar) 1kg', unit: 'kg', qty: 50, unitPrice: 128.5, total: 6425 },
  ];
  return {
    invoice: {
      invoiceNo: 'TEST-000001',
      date: dhakaParts(now).date, // the shop's clock (Asia/Dhaka), like every real invoice
      time: dhakaParts(now).time,
      customerName: 'Sample Customer',
      customerPhone: '01700000000',
      createdByName: 'Test',
      subtotal: 26785,
      discount: 285,
      total: 26500,
      paid: 20000,
      due: 6500,
      previousDue: 1500,
      status: 'active',
      notes: '',
    },
    items,
  };
}

/** Print the sample receipt. */
export function printTest() {
  const { invoice, items } = sampleInvoice();
  return printInvoice(invoice, items);
}

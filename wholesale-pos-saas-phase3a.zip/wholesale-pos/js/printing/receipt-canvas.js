/**
 * receipt-canvas.js — draws the 80 mm receipt onto a <canvas>.
 *
 * WHY A CANVAS? Thermal printers only understand a tiny ASCII font in text mode.
 * By drawing the receipt as an image and sending it as an ESC/POS raster bitmap
 * we get, with ONE code path: the company logo, bold/large type, and ANY
 * language (Bengali, Arabic, Hindi, Chinese…) using the device's own fonts.
 * The same canvas is shown in the on-screen preview, so what you see is exactly
 * what prints. 80 mm paper = 576 printable dots at 203 dpi (some models: 512).
 */
import { fmtQty } from '../core/utils.js';

const FONT = '"Noto Sans Bengali","Noto Sans","Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';

const money2 = (n) => (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Load an image from a URL / data URL. */
function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Could not load logo image'));
    img.src = src;
  });
}

/**
 * Scale the logo to fit and convert it to pure black/white with Floyd–Steinberg
 * dithering so photos/gradients still look good on a 1-bit printer.
 */
async function prepareLogo(dataUrl, maxW, maxH) {
  const img = await loadImage(dataUrl);
  const scale = Math.min(maxW / img.width, maxH / img.height, 1);
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(img, 0, 0, w, h);
  const id = ctx.getImageData(0, 0, w, h);
  const g = new Float32Array(w * h);
  for (let i = 0, p = 0; i < g.length; i++, p += 4) g[i] = 0.299 * id.data[p] + 0.587 * id.data[p + 1] + 0.114 * id.data[p + 2];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const nv = g[i] < 128 ? 0 : 255;
      const err = g[i] - nv;
      if (x + 1 < w) g[i + 1] += (err * 7) / 16;
      if (y + 1 < h) {
        if (x > 0) g[i + w - 1] += (err * 3) / 16;
        g[i + w] += (err * 5) / 16;
        if (x + 1 < w) g[i + w + 1] += err / 16;
      }
      const p = i * 4;
      id.data[p] = id.data[p + 1] = id.data[p + 2] = nv;
      id.data[p + 3] = 255;
    }
  }
  ctx.putImageData(id, 0, 0);
  return c;
}

/**
 * Lay out (and optionally draw) the receipt. Called twice: once with a scratch
 * context to measure the height, once on the real canvas to draw.
 * @returns {number} total height in pixels
 */
function paint(ctx, m, W, draw, logo) {
  const P = 10; // side padding
  const IW = W - P * 2; // inner width
  const base = Math.round(W / 26); // ≈22px at 576
  const small = Math.round(base * 0.84);
  const big = Math.round(base * 1.5);
  const font = (px, weight = 600) => `${weight} ${px}px ${FONT}`;
  const lh = (px) => Math.round(px * 1.3);
  let y = 8;

  const seg = typeof Intl !== 'undefined' && Intl.Segmenter ? new Intl.Segmenter(undefined, { granularity: 'grapheme' }) : null;
  const chars = (s) => (seg ? [...seg.segment(s)].map((x) => x.segment) : Array.from(s));

  const setFont = (px, weight) => {
    ctx.font = font(px, weight);
  };
  const width = (s) => ctx.measureText(s).width;
  const text = (s, x, yy, { align = 'left', color = '#000' } = {}) => {
    if (!draw) return;
    ctx.textAlign = align;
    ctx.textBaseline = 'top';
    ctx.fillStyle = color;
    ctx.fillText(s, x, yy);
  };
  const rect = (x, yy, w, h, color = '#000') => {
    if (!draw) return;
    ctx.fillStyle = color;
    ctx.fillRect(x, yy, w, h);
  };
  /** Wrap text to maxW using the current font; breaks long words by grapheme. */
  const wrap = (str, maxW) => {
    const out = [];
    for (const para of String(str ?? '').split('\n')) {
      let line = '';
      for (const word of para.split(/\s+/).filter(Boolean)) {
        let w = word;
        if (width(w) > maxW) {
          if (line) {
            out.push(line);
            line = '';
          }
          let piece = '';
          for (const ch of chars(w)) {
            if (width(piece + ch) > maxW && piece) {
              out.push(piece);
              piece = '';
            }
            piece += ch;
          }
          w = piece;
        }
        const trial = line ? `${line} ${w}` : w;
        if (width(trial) <= maxW) line = trial;
        else {
          out.push(line);
          line = w;
        }
      }
      out.push(line);
    }
    return out;
  };

  const center = (s, px, weight = 600) => {
    setFont(px, weight);
    for (const l of wrap(s, IW)) {
      text(l, W / 2, y, { align: 'center' });
      y += lh(px);
    }
  };
  const row = (left, right, px, weight = 600, opts = {}) => {
    setFont(px, weight);
    const rw = width(right);
    const lines = wrap(left, IW - rw - 12);
    lines.forEach((l, i) => {
      text(l, P + (opts.indent || 0), y, { color: opts.color });
      if (i === 0) text(right, W - P, y, { align: 'right', color: opts.color });
      y += lh(px);
    });
  };
  const rule = (dash = true) => {
    y += 4;
    if (draw) {
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 2;
      ctx.setLineDash(dash ? [6, 5] : []);
      ctx.beginPath();
      ctx.moveTo(P, y);
      ctx.lineTo(W - P, y);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    y += 8;
  };

  // ---- Header: logo + business info ----
  if (logo) {
    if (draw) ctx.drawImage(logo, Math.round((W - logo.width) / 2), y);
    y += logo.height + 8;
  }
  center(m.business.name, big, 800);
  if (m.business.address) center(m.business.address, small, 500);
  if (m.business.phone) center(`Tel: ${m.business.phone}`, small, 500);
  if (m.business.email) center(m.business.email, small, 500);
  if (m.business.taxId) center(`Tax ID: ${m.business.taxId}`, small, 500);
  rule();

  if (m.status === 'void') {
    y += 2;
    center('*** VOID ***', big, 800);
    y += 2;
  }

  // ---- Invoice meta ----
  row('Invoice', m.meta.invoiceNo, base, 700);
  row('Date', `${m.meta.date}  ${m.meta.time}`, base, 500);
  if (m.meta.cashier) row('Served by', m.meta.cashier, base, 500);
  row('Customer', m.customer.name, base, 600);
  if (m.customer.phone) row('Phone', m.customer.phone, base, 500);
  rule(false);

  // ---- Items ----
  row('Item  ·  Qty × Price', 'Total', small, 700);
  y += 2;
  m.items.forEach((it, idx) => {
    setFont(base, 700);
    for (const l of wrap(`${idx + 1}. ${it.name}`, IW)) {
      text(l, P, y);
      y += lh(base);
    }
    const unit = it.unit ? ` ${it.unit}` : '';
    row(`${fmtQty(it.qty)}${unit} × ${money2(it.price)}`, money2(it.total), base, 500, { indent: 26 });
    y += 3;
  });
  rule();

  // ---- Totals ----
  const t = m.totals;
  const cur = m.currency || '';
  const amt = (n) => `${cur}${money2(n)}`;
  row('Subtotal', amt(t.subtotal), base, 500);
  if (t.discount > 0) row('Discount', `-${amt(t.discount)}`, base, 500);
  y += 4;
  // Grand total as an inverted (white-on-black) bar — prints crisp on thermal paper.
  setFont(big, 800);
  const barH = lh(big) + 8;
  rect(P - 2, y, IW + 4, barH);
  y += 4;
  text('TOTAL', P + 6, y, { color: '#fff' });
  text(amt(t.total), W - P - 6, y, { align: 'right', color: '#fff' });
  y += barH - 4 + 4;
  row('Paid', amt(t.paid), base, 600);
  row('Due', amt(t.due), big, 800);
  if (t.previousDue > 0) {
    row('Previous due', amt(t.previousDue), base, 500);
    row('Total due', amt(t.totalDue), base, 800);
  }
  if (m.notes) {
    rule();
    setFont(small, 500);
    for (const l of wrap(`Note: ${m.notes}`, IW)) {
      text(l, P, y);
      y += lh(small);
    }
  }
  rule();

  // ---- Footer ----
  if (m.footer) center(m.footer, base, 600);
  y += 36; // bottom margin so the cutter never clips the last line
  return y;
}

/**
 * Render a receipt model to a canvas.
 * @param {object} model from buildReceiptModel()
 * @param {{width?:number}} [opts] printable width in dots (576 for 80 mm)
 * @returns {Promise<HTMLCanvasElement>}
 */
export async function renderReceiptCanvas(model, { width = 576 } = {}) {
  const logo = model.business.logo ? await prepareLogo(model.business.logo, Math.round(width * 0.5), 150).catch(() => null) : null;
  const scratch = document.createElement('canvas').getContext('2d');
  const height = Math.ceil(paint(scratch, model, width, false, logo));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, width, height);
  paint(ctx, model, width, true, logo);
  return canvas;
}

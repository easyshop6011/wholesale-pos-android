/**
 * receipt.js — turns an invoice into a printable "receipt model" and into
 * ESC/POS *text-mode* bytes. (The pixel-perfect raster renderer is in
 * receipt-canvas.js; both use the same model so they always agree.)
 */
import { EscPosBuilder, asciiize } from './escpos.js';
import { fmtQty, round2 } from '../core/utils.js';

/**
 * Build the neutral receipt model.
 * @param {object} invoice  invoice record
 * @param {object[]} items  invoice line items
 * @param {object} s        settings snapshot
 */
export function buildReceiptModel(invoice, items, s) {
  const previousDue = s.showPreviousDue ? invoice.previousDue || 0 : 0;
  return {
    business: { name: s.businessName, address: s.address, phone: s.phone, email: s.email, taxId: s.taxId, logo: s.logo },
    meta: { invoiceNo: invoice.invoiceNo, date: invoice.date, time: invoice.time.slice(0, 5), cashier: invoice.createdByName || '' },
    customer: { name: invoice.customerName, phone: invoice.customerPhone || '' },
    items: items.map((i) => ({ name: i.name, qty: i.qty, unit: i.unit || '', price: i.unitPrice, total: i.total })),
    totals: {
      subtotal: invoice.subtotal,
      discount: invoice.discount,
      total: invoice.total,
      paid: invoice.paid,
      due: invoice.due,
      previousDue,
      totalDue: round2(previousDue + invoice.due),
    },
    status: invoice.status,
    notes: invoice.notes || '',
    footer: s.footer,
    currency: s.currency,
  };
}

// ---- text helpers -----------------------------------------------------------
const money2 = (n) => (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Word-wrap `text` to `width` columns (hard-breaks very long words). */
export function wrapText(text, width) {
  const lines = [];
  for (const para of String(text).split('\n')) {
    let line = '';
    for (const word of para.split(/\s+/).filter(Boolean)) {
      let w = word;
      while (w.length > width) {
        if (line) {
          lines.push(line);
          line = '';
        }
        lines.push(w.slice(0, width));
        w = w.slice(width);
      }
      if (!line) line = w;
      else if (line.length + 1 + w.length <= width) line += ` ${w}`;
      else {
        lines.push(line);
        line = w;
      }
    }
    lines.push(line);
  }
  return lines;
}

/** Left text + right text on one line of `cols` characters. */
export function leftRight(left, right, cols) {
  const gap = cols - left.length - right.length;
  return gap >= 1 ? left + ' '.repeat(gap) + right : `${left.slice(0, Math.max(0, cols - right.length - 1))} ${right}`;
}

/**
 * Build ESC/POS bytes for text-mode printing (fast, ASCII only).
 * @param {object} model from buildReceiptModel
 * @param {{columns?:number, cut?:boolean, drawer?:boolean, feedLines?:number}} [opts]
 * @returns {Uint8Array}
 */
export function buildTextReceipt(model, opts = {}) {
  const cols = opts.columns || 48;
  const cur = asciiize(model.currency || '');
  const m = (n) => `${cur}${money2(n)}`;
  const hr = '-'.repeat(cols);
  const b = new EscPosBuilder().init();
  const A = asciiize;

  b.align('center').bold(true);
  const nm = A(model.business.name);
  if (nm.length * 2 <= cols) b.size(2, 2).line(nm).size(1, 1);
  else for (const l of wrapText(nm, cols)) b.line(l);
  b.bold(false);
  for (const l of wrapText(A(model.business.address || ''), cols)) if (l) b.line(l);
  if (model.business.phone) b.line(`Tel: ${A(model.business.phone)}`);
  if (model.business.email) b.line(A(model.business.email));
  if (model.business.taxId) b.line(`Tax ID: ${A(model.business.taxId)}`);
  b.line(hr).align('left');

  if (model.status === 'void') b.align('center').bold(true).size(2, 2).line('** VOID **').size(1, 1).bold(false).align('left');
  b.line(leftRight('Invoice:', A(model.meta.invoiceNo), cols));
  b.line(leftRight('Date:', `${model.meta.date}  ${model.meta.time}`, cols));
  if (model.meta.cashier) b.line(leftRight('Served by:', A(model.meta.cashier), cols));
  b.line(leftRight('Customer:', A(model.customer.name), cols));
  if (model.customer.phone) b.line(leftRight('Phone:', A(model.customer.phone), cols));
  b.line(hr);
  b.bold(true).line(leftRight('Item / Qty x Price', 'Total', cols)).bold(false).line(hr);

  model.items.forEach((it, idx) => {
    for (const l of wrapText(`${idx + 1}. ${A(it.name)}`, cols)) b.line(l);
    const unit = it.unit ? ` ${A(it.unit)}` : '';
    b.line(leftRight(`   ${fmtQty(it.qty)}${unit} x ${money2(it.price)}`, money2(it.total), cols));
  });
  b.line(hr);

  const t = model.totals;
  b.line(leftRight('Subtotal:', m(t.subtotal), cols));
  if (t.discount > 0) b.line(leftRight('Discount:', `-${m(t.discount)}`, cols));
  b.bold(true).size(1, 2).line(leftRight('TOTAL:', m(t.total), cols)).size(1, 1).bold(false);
  b.line(leftRight('Paid:', m(t.paid), cols));
  b.bold(true).line(leftRight('DUE:', m(t.due), cols)).bold(false);
  if (t.previousDue > 0) {
    b.line(leftRight('Previous due:', m(t.previousDue), cols));
    b.bold(true).line(leftRight('Total due:', m(t.totalDue), cols)).bold(false);
  }
  if (model.notes) b.line(hr).line(`Note: ${A(model.notes)}`);
  b.line(hr).align('center');
  for (const l of wrapText(A(model.footer || ''), cols)) if (l) b.line(l);

  b.feed(opts.feedLines ?? 3);
  if (opts.cut !== false) b.cut();
  if (opts.drawer) b.drawer();
  return b.build();
}

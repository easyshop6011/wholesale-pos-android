/**
 * audit.js — "who did what, when". An append-only activity log shown to admins
 * (Settings → Activity) so every sign-in, void, stock change or user change on
 * a shared counter can be traced to a person.
 *
 * Design rules
 *  - Logging must NEVER break the action being logged: every error is swallowed.
 *  - It runs in its own small transaction, after the business transaction commits.
 *  - Secrets (passwords, PINs, sync token) are never written into `detail`.
 *  - The signed-in user is found through a provider registered by auth.js
 *    (avoids a circular import).
 */
import { run, dbAll } from '../core/db.js';
import { uuid, monotonicNow } from '../core/utils.js';
import { dhakaDate } from '../core/datetime.js';
import { authorize } from './guard.js';

export const AUDIT_KEEP = 5000;

let actorProvider = () => null;

/** auth.js registers how to find the current user. */
export function setActorProvider(fn) {
  actorProvider = fn;
}

/**
 * Record one activity.
 * @param {string} action  dotted verb, e.g. 'invoice.void', 'auth.login', 'stock.adjust'
 * @param {{target?:string, detail?:string, actor?:{id:string,displayName:string}|null}} [info]
 *        `actor` overrides the signed-in user (e.g. a failed login has no user yet).
 */
export async function logAction(action, { target = '', detail = '', actor } = {}) {
  try {
    const who = actor === undefined ? actorProvider() : actor;
    await run(['auditLog'], 'readwrite', (tx) =>
      tx.put('auditLog', {
        id: uuid(),
        createdAt: monotonicNow().toISOString(),
        userId: who?.id || null,
        userName: who?.displayName || who?.username || '',
        action,
        target: String(target || '').slice(0, 120),
        detail: String(detail || '').slice(0, 400),
      }),
    );
  } catch {
    /* auditing must never block real work */
  }
}

/**
 * Activity list, newest first.
 * @param {{from?:string,to?:string,userId?:string,action?:string,search?:string,limit?:number}} [f]
 *   `from`/`to` are YYYY-MM-DD (local days); `action` matches a prefix ('invoice' matches 'invoice.void').
 */
export async function listAudit({ from, to, userId, action, search = '', limit = 300 } = {}) {
  authorize('audit');
  const q = search.trim().toLowerCase();
  const rows = (await dbAll('auditLog')).filter((r) => {
    const day = localDay(r.createdAt);
    return (!from || day >= from) && (!to || day <= to) && (!userId || r.userId === userId) && (!action || r.action === action || r.action.startsWith(`${action}.`)) && (!q || `${r.userName} ${r.action} ${r.target} ${r.detail}`.toLowerCase().includes(q));
  });
  return rows.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit);
}

/** Local YYYY-MM-DD of an ISO timestamp. */
export function localDay(iso) {
  return dhakaDate(iso); // the shop's calendar day (Asia/Dhaka), whatever the device clock zone is
}

/** Delete the oldest entries so at most `keep` remain. Returns how many were removed. */
export async function trimAudit(keep = AUDIT_KEEP) {
  try {
    return await run(['auditLog'], 'readwrite', async (tx) => {
      const rows = await tx.getAll('auditLog');
      if (rows.length <= keep) return 0;
      const drop = rows.sort((a, b) => a.createdAt.localeCompare(b.createdAt)).slice(0, rows.length - keep);
      for (const r of drop) await tx.delete('auditLog', r.id);
      return drop.length;
    });
  } catch {
    return 0;
  }
}

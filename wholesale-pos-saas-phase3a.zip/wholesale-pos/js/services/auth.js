/**
 * auth.js — users, roles, password login, PIN lock and permissions.
 *
 * Security model (be aware of the limits):
 *  - Secrets are stored as salted PBKDF2-SHA256 hashes (never in clear text).
 *  - The PIN lock is a *screen lock* for shared counters. Anyone with physical
 *    access to the unlocked device's browser profile could still read the local
 *    database; use the device's own screen lock / encryption for real protection.
 *
 * Roles: "admin" (everything), "manager" (sell + stock + reports, no settings) and
 * "employee"/Cashier (sell, customers, view stock). Any non-admin user can also get a
 * custom permission list (see PERMISSION_LIST). Fast user switching uses each
 * person's own PIN. Important actions are written to the audit log (audit.js).
 */
import { dbAll, dbGet, dbPut, run } from '../core/db.js';
import { uuid, bytesToBase64, base64ToBytes, ValidationError } from '../core/utils.js';
import { sha256 } from '../core/sha256.js';
import { bus } from '../core/bus.js';
import { logAction, setActorProvider } from './audit.js';
import { PERMISSION_LIST, ROLES, PERMISSIONS, effectivePermissions, userCan, cleanPerms } from './permissions.js';
import { setSessionProvider, authorizeAdmin, currentActor } from './guard.js';

// The permission catalogue lives in permissions.js (pure, unit-tested); re-exported for old imports.
export { PERMISSION_LIST, ROLES, PERMISSIONS, effectivePermissions };

const enc = new TextEncoder();
let PBKDF2_ITER = 150000;
const FALLBACK_ITER = 5000;

/** Test hook: use a cheap work factor so test suites that sign in many times stay fast. Never used by the app. */
export function _setHashIterationsForTests(n) {
  PBKDF2_ITER = n;
}

// ---- hashing ---------------------------------------------------------------

/** Derive a hash for `secret`. Uses PBKDF2 when WebCrypto exists, else iterated SHA-256. */
async function derive(secret, salt, algo, iter) {
  if (algo === 'pbkdf2') {
    const key = await crypto.subtle.importKey('raw', enc.encode(secret), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, key, 256);
    return new Uint8Array(bits);
  }
  const sec = enc.encode(secret);
  let h = sha256(new Uint8Array([...salt, ...sec]));
  for (let i = 0; i < iter; i++) h = sha256(new Uint8Array([...h, ...salt, ...sec]));
  return h;
}

/** Create a storable hash record for a password or PIN. */
export async function hashSecret(secret) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const algo = crypto?.subtle ? 'pbkdf2' : 'sha256-iter';
  const iter = algo === 'pbkdf2' ? PBKDF2_ITER : FALLBACK_ITER;
  const hash = await derive(secret, salt, algo, iter);
  return { algo, iter, salt: bytesToBase64(salt), hash: bytesToBase64(hash) };
}

/** Constant-time check of `secret` against a stored hash record. */
export async function verifySecret(secret, rec) {
  if (!rec) return false;
  const hash = await derive(secret, base64ToBytes(rec.salt), rec.algo, rec.iter);
  const want = base64ToBytes(rec.hash);
  if (hash.length !== want.length) return false;
  let diff = 0;
  for (let i = 0; i < hash.length; i++) diff |= hash[i] ^ want[i];
  return diff === 0;
}

// ---- session state ---------------------------------------------------------
let current = null; // the signed-in user record
let locked = false; // true => PIN required
const LAST_USER_KEY = 'pos:lastUser';
const FAIL_KEY = 'pos:authFails';

const store = {
  get: (k) => {
    try {
      return localStorage.getItem(k);
    } catch {
      return null;
    }
  },
  set: (k, v) => {
    try {
      localStorage.setItem(k, v);
    } catch {
      /* ignore */
    }
  },
  del: (k) => {
    try {
      localStorage.removeItem(k);
    } catch {
      /* ignore */
    }
  },
};

/** Brute-force throttle: 5 failures => 30 s cool-down (doubling afterwards). */
function checkThrottle() {
  const f = JSON.parse(store.get(FAIL_KEY) || '{"count":0,"until":0}');
  if (f.until > Date.now()) {
    throw new ValidationError(`Too many attempts. Try again in ${Math.ceil((f.until - Date.now()) / 1000)} s.`);
  }
}
function recordFailure() {
  const f = JSON.parse(store.get(FAIL_KEY) || '{"count":0,"until":0}');
  f.count += 1;
  if (f.count >= 5) f.until = Date.now() + 30000 * 2 ** Math.min(f.count - 5, 5);
  store.set(FAIL_KEY, JSON.stringify(f));
}
const clearFailures = () => store.del(FAIL_KEY);

const publicUser = (u) => (u ? { id: u.id, username: u.username, displayName: u.displayName, role: u.role, active: u.active, permissions: Array.isArray(u.permissions) ? [...u.permissions] : null, lastLoginAt: u.lastLoginAt || '' } : null);

function validateCredentials({ username, password, pin }, { requireAll = true } = {}) {
  if (username !== undefined && !/^[A-Za-z0-9._-]{3,32}$/.test(username || '')) {
    throw new ValidationError('Username must be 3–32 letters, numbers, dot, dash or underscore.');
  }
  if (password !== undefined && (requireAll || password) && String(password).length < 6) {
    throw new ValidationError('Password must be at least 6 characters.');
  }
  if (pin !== undefined && (requireAll || pin) && !/^\d{4,6}$/.test(String(pin))) {
    throw new ValidationError('PIN must be 4 to 6 digits.');
  }
}

/** Remember when a user last signed in (shown in Settings → Users). */
async function touchLogin(u) {
  const next = { ...u, lastLoginAt: new Date().toISOString() };
  try {
    await dbPut('users', next);
  } catch {
    return u;
  }
  return next;
}

setActorProvider(() => publicUser(current));
// Service-layer authorization (guard.js) only recognises a user who is signed in AND not on the PIN lock screen.
setSessionProvider(() => (current && !locked ? publicUser(current) : null));

/** Build (but do not save) a user record. Hashing is async, so it must not run inside a DB transaction. */
async function buildUser({ username, displayName, role = 'employee', password, pin, permissions = null }) {
  validateCredentials({ username, password, pin });
  if (!ROLES[role]) throw new ValidationError('Invalid role.');
  return {
    id: uuid(),
    username,
    usernameLower: username.toLowerCase(),
    displayName: (displayName || username).trim(),
    role,
    permissions: role === 'admin' || !Array.isArray(permissions) ? null : cleanPerms(permissions),
    active: true,
    passHash: await hashSecret(password),
    pinHash: await hashSecret(String(pin)),
    createdAt: new Date().toISOString(),
  };
}

export const auth = {
  /** True when no user exists yet (first run => show the setup wizard). */
  async needsSetup() {
    return (await dbAll('users')).length === 0;
  },

  /** Restore the previous user after a cold start; the app opens on the PIN screen. */
  async init() {
    current = null;
    locked = false;
    const id = store.get(LAST_USER_KEY);
    if (id) {
      const u = await dbGet('users', id);
      if (u?.active) {
        current = u;
        locked = true;
      }
    }
    bus.emit('auth:changed');
  },

  user: () => publicUser(current),
  isLocked: () => locked,
  isSignedIn: () => !!current && !locked,

  /** Does the signed-in user have permission `perm`? (False on the PIN lock screen.) */
  can(perm) {
    if (!current || locked) return false;
    return userCan(current, perm);
  },

  /**
   * Create a user. Administrators only — enforced here, not just by hiding the button.
   * (The very first administrator is created by {@link auth.setupAdmin}.)
   */
  async createUser(input) {
    const actor = authorizeAdmin();
    const user = await buildUser(input);
    await run(['users'], 'readwrite', async (tx) => {
      if (await tx.getByIndex('users', 'usernameLower', user.usernameLower)) throw new ValidationError('That username is already taken.');
      await tx.put('users', user);
    });
    await logAction('user.create', { target: user.username, detail: `role ${user.role}`, actor });
    return publicUser(user);
  },

  /** First-run: create the administrator and sign in. Only possible while NO user exists (checked atomically). */
  async setupAdmin(input) {
    const user = await buildUser({ ...input, role: 'admin' });
    await run(['users'], 'readwrite', async (tx) => {
      if ((await tx.count('users')) > 0) throw new ValidationError('Setup already completed.');
      await tx.put('users', user);
    });
    current = await dbGet('users', user.id);
    locked = false;
    store.set(LAST_USER_KEY, current.id);
    bus.emit('auth:changed');
    await logAction('user.create', { target: user.username, detail: 'role admin (first-run setup)' });
    return publicUser(user);
  },

  /**
   * CLOUD MODE — the cloud account (verified by the SERVER) is the credential. Creates / refreshes the local
   * user that stands for this person in this business. Role and permissions come from the server's answer on
   * every call, never from what the device remembers. The local PIN is only a quick screen lock.
   *
   * `lockOnStart`: open on the PIN screen when a PIN exists (cold start at a shared counter).
   */
  async cloudSignIn({ userId, email = '', displayName = '', role, permissions = [], lockOnStart = false }) {
    if (!userId) throw new ValidationError('A cloud user id is required.');
    const localRole = role === 'owner' || role === 'admin' ? 'admin' : role === 'manager' ? 'manager' : 'employee';
    const existing = await dbGet('users', userId);
    const username = existing?.username || `cloud-${String(userId).slice(0, 8)}`;
    const user = {
      ...(existing || { id: userId, username, usernameLower: username.toLowerCase(), passHash: null, pinHash: null, createdAt: new Date().toISOString() }),
      displayName: String(displayName || email || username).trim(),
      email,
      cloud: true,
      role: localRole,
      permissions: localRole === 'admin' ? null : cleanPerms(permissions || []),
      active: true,
    };
    await dbPut('users', user);
    current = user;
    locked = !!lockOnStart && !!user.pinHash;
    store.set(LAST_USER_KEY, user.id);
    bus.emit('auth:changed');
    return publicUser(user);
  },

  /** Cloud mode: has this person chosen a quick-unlock PIN on this device yet? (Locking needs one.) */
  needsPin: () => !!current && !!current.cloud && !current.pinHash,

  /** Cloud mode: choose / change the quick-unlock PIN of the signed-in person (device-local; 4–6 digits). */
  async setOwnPin(pin) {
    if (!current) throw new ValidationError('No user signed in.');
    if (!/^\d{4,6}$/.test(String(pin))) throw new ValidationError('The PIN must be 4–6 digits.');
    const next = { ...current, pinHash: await hashSecret(String(pin)) };
    await dbPut('users', next);
    current = next;
    await logAction('user.pin_set', { target: next.displayName });
  },

  /**
   * Cloud mode: align the local copies of the OTHER people with the server's member list (role, permissions,
   * on/off switch, name). People who never signed in on this device are not created here.
   */
  async cloudSyncMembers(members, { exceptId = '' } = {}) {
    for (const m of members || []) {
      if (m.user_id === exceptId) continue;
      const u = await dbGet('users', m.user_id);
      if (!u) continue;
      const role = m.role === 'owner' || m.role === 'admin' ? 'admin' : m.role === 'manager' ? 'manager' : 'employee';
      await dbPut('users', {
        ...u,
        role,
        permissions: role === 'admin' || !Array.isArray(m.permissions) ? null : cleanPerms(m.permissions),
        active: m.status === 'active',
        displayName: m.display_name || u.displayName,
      });
    }
  },

  /** Sign in with username + password. */
  async login(username, password) {
    checkThrottle();
    const rows = await dbAll('users');
    const u = rows.find((x) => x.usernameLower === String(username || '').trim().toLowerCase());
    if (!u || !u.active || !(await verifySecret(password || '', u.passHash))) {
      recordFailure();
      await logAction('auth.login_failed', { target: String(username || '').slice(0, 40), actor: null });
      throw new ValidationError('Invalid username or password.');
    }
    clearFailures();
    current = await touchLogin(u);
    locked = false;
    store.set(LAST_USER_KEY, u.id);
    bus.emit('auth:changed');
    await logAction('auth.login');
    return publicUser(current);
  },

  /** Unlock the screen with the current user's PIN. */
  async unlock(pin) {
    checkThrottle();
    if (!current) throw new ValidationError('No user signed in.');
    if (!(await verifySecret(String(pin), current.pinHash))) {
      recordFailure();
      throw new ValidationError('Incorrect PIN.');
    }
    clearFailures();
    locked = false;
    bus.emit('auth:changed');
  },

  /** Lock the screen (PIN required to continue). */
  lock() {
    if (current && !locked) {
      locked = true;
      bus.emit('auth:changed');
    }
  },

  /** Sign out completely (password required next time). */
  logout() {
    if (current) logAction('auth.logout');
    current = null;
    locked = false;
    store.del(LAST_USER_KEY);
    bus.emit('auth:changed');
  },

  /**
   * People who can be chosen on the lock screen ("Switch user"): active users,
   * id/name/role only — never any secret.
   */
  async loginChoices() {
    return (await dbAll('users')).filter((u) => u.active).map((u) => ({ id: u.id, displayName: u.displayName, role: u.role })).sort((a, b) => a.displayName.localeCompare(b.displayName));
  },

  /**
   * Fast user switching at a shared counter: pick a person and enter THEIR PIN.
   * (Brute-force throttling applies exactly like the normal unlock.)
   */
  async switchUser(userId, pin) {
    checkThrottle();
    const u = await dbGet('users', userId);
    if (!u || !u.active || !(await verifySecret(String(pin), u.pinHash))) {
      recordFailure();
      await logAction('auth.switch_failed', { target: u?.displayName || '', actor: null });
      throw new ValidationError('Incorrect PIN.');
    }
    clearFailures();
    const from = current?.displayName;
    current = await touchLogin(u);
    locked = false;
    store.set(LAST_USER_KEY, u.id);
    bus.emit('auth:changed');
    await logAction('auth.switch', { detail: from ? `from ${from}` : '' });
    return publicUser(current);
  },

  /** Administrators: the full user list (usernames, roles, permissions). */
  async listUsers() {
    authorizeAdmin();
    return (await dbAll('users')).map(publicUser).sort((a, b) => a.username.localeCompare(b.username));
  },

  /** Any signed-in user: just ids and display names (for "created by" filters). Never any secret or permission. */
  async listUserNames() {
    if (!currentActor()) throw new ValidationError('Please sign in to continue.');
    return (await dbAll('users')).map((u) => ({ id: u.id, displayName: u.displayName })).sort((a, b) => a.displayName.localeCompare(b.displayName));
  },

  /**
   * Administrators: change display name / role / permissions / active flag.
   * Never leaves zero active administrators, and nobody can disable their own account.
   */
  async updateUser(id, patch) {
    const actor = authorizeAdmin();
    if ('active' in patch && !patch.active && id === actor.id) throw new ValidationError('You cannot disable your own account.');
    let changed = null;
    await run(['users'], 'readwrite', async (tx) => {
      const all = await tx.getAll('users');
      const u = all.find((x) => x.id === id);
      if (!u) throw new ValidationError('User not found.');
      const next = { ...u, ...('displayName' in patch ? { displayName: String(patch.displayName).trim() || u.displayName } : {}) };
      if ('role' in patch) {
        if (!ROLES[patch.role]) throw new ValidationError('Invalid role.');
        next.role = patch.role;
      }
      if ('active' in patch) next.active = !!patch.active;
      if ('permissions' in patch) next.permissions = patch.permissions === null ? null : cleanPerms(patch.permissions);
      if (next.role === 'admin') next.permissions = null;
      const admins = all.filter((x) => (x.id === id ? next : x).role === 'admin' && (x.id === id ? next : x).active);
      if (!admins.length) throw new ValidationError('At least one active administrator is required.');
      await tx.put('users', next);
      if (current?.id === id) current = next;
      changed = { u, next };
    });
    const bits = [];
    if (changed.u.role !== changed.next.role) bits.push(`role ${changed.u.role} → ${changed.next.role}`);
    if (changed.u.active !== changed.next.active) bits.push(changed.next.active ? 'enabled' : 'disabled');
    if (JSON.stringify(changed.u.permissions ?? null) !== JSON.stringify(changed.next.permissions ?? null)) bits.push('permissions changed');
    await logAction('user.update', { target: changed.next.username, detail: bits.join(', '), actor });
    bus.emit('auth:changed');
  },

  /**
   * Change a password and/or PIN.
   *  - your own account: allowed for any signed-in user;
   *  - someone else's account: administrators only;
   *  - ALWAYS requires `currentPassword` — the signed-in person's own password
   *    (step-up check, so a counter left unlocked cannot be used to take over an account).
   * Wrong attempts are throttled exactly like sign-in.
   */
  async setCredentials(id, { password, pin, currentPassword } = {}) {
    const actor = currentActor();
    if (!actor) throw new ValidationError('Please sign in to continue.');
    if (actor.id !== id) authorizeAdmin();
    validateCredentials({ password, pin }, { requireAll: false });
    if (!password && !pin) throw new ValidationError('Enter a new password or PIN.');
    checkThrottle();
    const me = await dbGet('users', actor.id);
    if (!currentPassword || !me || !(await verifySecret(String(currentPassword), me.passHash))) {
      recordFailure();
      await logAction('user.credentials_denied', { target: id === actor.id ? actor.username : id, detail: 'wrong confirmation password', actor });
      throw new ValidationError('Your current password is required and was not correct.');
    }
    clearFailures();
    const u = await dbGet('users', id);
    if (!u) throw new ValidationError('User not found.');
    const next = { ...u };
    if (password) next.passHash = await hashSecret(password);
    if (pin) next.pinHash = await hashSecret(String(pin));
    await dbPut('users', next);
    if (current?.id === id) current = next;
    await logAction('user.credentials', { target: u.username, detail: `${[password ? 'password' : '', pin ? 'PIN' : ''].filter(Boolean).join(' + ')} changed`, actor });
  },

  /**
   * After a restore / import the stored users may differ from the session in memory.
   * Re-read the signed-in user; if they no longer exist (or are disabled) sign out.
   */
  async revalidate() {
    if (!current) return;
    const u = await dbGet('users', current.id).catch(() => null);
    if (!u || !u.active) {
      this.logout();
      return;
    }
    current = u;
    bus.emit('auth:changed');
  },

  /** Verify the signed-in user's current password (used before sensitive changes). */
  async verifyPassword(password) {
    return !!current && (await verifySecret(password, current.passHash));
  },
};

/**
 * autobackup.js — automatic backups, with no one having to remember.
 *
 * THREE SAFETY NETS (each one optional in Settings → Backup)
 *  1. Local snapshots  — a full copy of the database is saved every N hours
 *     (and after N new invoices) into a SEPARATE IndexedDB database
 *     (`wholesale-pos-backups`). Because it is separate, restoring / importing /
 *     clearing the main database never touches the snapshots. The newest
 *     `autoBackupKeep` are kept; older ones are deleted automatically.
 *  2. Google Drive     — when online and Sync is configured, the same backup is
 *     uploaded to the "POS Backups" Drive folder (see backup.js). A failure is
 *     remembered and retried at the next check; it never interrupts selling.
 *  3. Device file      — inside the Android app, the newest backup is also
 *     written to the phone's Documents folder (best effort).
 *
 * A "safety" snapshot is always taken right before any restore/import, so a
 * wrong restore can be undone from the snapshot list.
 *
 * WHEN IT RUNS: shortly after the app starts, every 10 minutes while open, when
 * the app goes to the background, and after a sale if enough invoices piled up.
 * `backupDue()` below is a pure function (unit-tested) that decides.
 */
import { run, between } from '../core/db.js';
import { settings } from './settings.js';
import { exportDatabase, backupToDrive, backupFileName, importDatabase, getSessionBackupPassphrase } from './backup.js';
import { bus } from '../core/bus.js';
import { uuid, monotonicNow, dateParts } from '../core/utils.js';
import { authorize } from './guard.js';

export const SNAP_DB = 'wholesale-pos-backups';
const SNAP_STORE = 'snapshots';
const SAFETY_KEEP = 3; // how many "before restore" safety snapshots to keep
const HOUR = 3600000;

// ---- pure decision logic ------------------------------------------------------

/**
 * Is a new automatic backup due?
 * @param {{now:number, lastAt:string, everyHours:number, invoicesSince:number, afterSales:number, enabled:boolean}} s
 * @returns {{due:boolean, reason:''|'first'|'time'|'sales'}}
 */
export function backupDue({ now, lastAt, everyHours, invoicesSince = 0, afterSales = 0, enabled = true }) {
  if (!enabled) return { due: false, reason: '' };
  if (!lastAt) return { due: true, reason: 'first' };
  const last = Date.parse(lastAt);
  if (!Number.isFinite(last)) return { due: true, reason: 'first' };
  if (everyHours > 0 && now - last >= everyHours * HOUR) return { due: true, reason: 'time' };
  if (afterSales > 0 && invoicesSince >= afterSales) return { due: true, reason: 'sales' };
  return { due: false, reason: '' };
}

/** Ids of snapshots to delete: keeps the newest `keep` automatic/manual ones and the newest SAFETY_KEEP safety ones. */
export function snapshotsToPrune(list, keep) {
  const newest = (arr) => [...arr].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const safety = newest(list.filter((s) => s.reason === 'before-restore'));
  const normal = newest(list.filter((s) => s.reason !== 'before-restore'));
  return [...normal.slice(Math.max(1, keep)), ...safety.slice(SAFETY_KEEP)].map((s) => s.id);
}

// ---- the snapshot database ----------------------------------------------------

let snapDb = null;

function openSnapDb() {
  if (snapDb) return snapDb;
  snapDb = new Promise((resolve, reject) => {
    const req = globalThis.indexedDB.open(SNAP_DB, 1);
    req.onupgradeneeded = () => {
      const s = req.result.createObjectStore(SNAP_STORE, { keyPath: 'id' });
      s.createIndex('createdAt', 'createdAt');
    };
    req.onsuccess = () => {
      req.result.onversionchange = () => req.result.close();
      resolve(req.result);
    };
    req.onerror = () => reject(req.error);
  });
  return snapDb;
}

/** Run one request against the snapshot store. */
async function snapOp(mode, fn) {
  const db = await openSnapDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(SNAP_STORE, mode);
    const out = fn(tx.objectStore(SNAP_STORE));
    tx.oncomplete = () => resolve(out?.result);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('Snapshot transaction aborted'));
  });
}

/** Test helper: close and forget the snapshot database. */
export async function _resetSnapshotsForTests() {
  try {
    (await openSnapDb()).close();
  } catch {
    /* none yet */
  }
  snapDb = null;
  await new Promise((res) => {
    const r = globalThis.indexedDB.deleteDatabase(SNAP_DB);
    r.onsuccess = r.onerror = r.onblocked = () => res();
  });
}

const countsOf = (data) => Object.fromEntries(Object.entries(data.stores).map(([k, v]) => [k, v.length]));

// ---- snapshots ---------------------------------------------------------------

/**
 * Save a snapshot of the whole database now.
 * @param {'auto'|'manual'|'before-restore'} [reason]
 * @returns {Promise<{id:string,createdAt:string,reason:string,bytes:number,counts:Record<string,number>}>}
 */
export async function takeSnapshot(reason = 'manual') {
  const data = await exportDatabase();
  const json = JSON.stringify(data);
  const meta = { id: uuid(), createdAt: monotonicNow().toISOString(), reason, bytes: json.length, counts: countsOf(data) };
  await snapOp('readwrite', (s) => s.put({ ...meta, json }));
  if (reason === 'auto') await settings.set({ lastAutoBackupAt: meta.createdAt });
  await pruneSnapshots();
  bus.emit('backup:status', await getBackupStatus());
  return meta;
}

/** Internal: the raw stored row (no permission check — used by the background job itself). */
async function readSnapshotRow(id) {
  return snapOp('readonly', (st) => st.get(id));
}

/** Snapshot list WITHOUT the (large) data, newest first. */
export async function listSnapshots() {
  const rows = await snapOp('readonly', (s) => s.getAll());
  return rows.map(({ json, ...meta }) => meta).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

/** One snapshot including its parsed backup object, or null. Contains password hashes, so it needs `settings`. */
export async function getSnapshot(id) {
  authorize('settings');
  const row = await snapOp('readonly', (s) => s.get(id));
  return row ? { ...row, data: JSON.parse(row.json) } : null;
}

export async function deleteSnapshot(id) {
  authorize('settings');
  await snapOp('readwrite', (s) => s.delete(id));
  bus.emit('backup:status', await getBackupStatus());
}

/** Delete old snapshots according to `autoBackupKeep`. */
export async function pruneSnapshots(keep = Number(settings.get('autoBackupKeep')) || 10) {
  const ids = snapshotsToPrune(await listSnapshots(), keep);
  for (const id of ids) await snapOp('readwrite', (s) => s.delete(id));
  return ids.length;
}

/**
 * Restore a snapshot (replaces ALL current data). A safety snapshot of the
 * current data is taken first so the restore itself can be undone.
 */
export async function restoreSnapshot(id) {
  authorize('settings');
  const snap = await getSnapshot(id);
  if (!snap) throw new Error('Snapshot not found.');
  return importDatabase(snap.data); // importDatabase takes the 'before-restore' safety snapshot itself
}

// ---- running a backup --------------------------------------------------------

const state = { running: false, lastError: '', driveError: '', timer: null };

/** Number of invoices created after `iso` (uses the date index, so it is cheap). */
export async function invoicesSince(iso) {
  if (!iso) return 0;
  const from = dateParts(new Date(Date.parse(iso) - 86400000)).date; // a day of slack for timezones
  const rows = await run(['invoices'], 'readonly', (tx) => tx.getAllByIndex('invoices', 'date', between(from, '9999-12-31')));
  return rows.filter((i) => i.createdAt > iso).length;
}

/** Best-effort copy of the newest backup into the phone's Documents folder (Android app only). */
async function writeDeviceCopy(json) {
  const fs = globalThis.Capacitor?.Plugins?.Filesystem;
  if (!globalThis.Capacitor?.isNativePlatform?.() || !fs) return false;
  try {
    await fs.writeFile({ path: 'WholesalePOS/latest-backup.json', data: json, directory: 'DOCUMENTS', encoding: 'utf8', recursive: true });
    return true;
  } catch {
    return false;
  }
}

/**
 * Take an automatic backup if one is due (or `force`). Never throws — problems
 * are reported through `getBackupStatus().lastError`.
 * @param {{force?:boolean, fetchImpl?:typeof fetch, online?:boolean}} [o]
 * @returns {Promise<{snapshot:object|null, drive:boolean, device:boolean, skipped?:string}>}
 */
export async function runAutoBackup({ force = false, fetchImpl, online = globalThis.navigator?.onLine !== false } = {}) {
  const out = { snapshot: null, drive: false, device: false };
  if (state.running) return { ...out, skipped: 'busy' };
  state.running = true;
  try {
    const enabled = !!settings.get('autoBackupEnabled');
    const lastAt = settings.get('lastAutoBackupAt');
    const everyHours = Number(settings.get('autoBackupEveryHours')) || 24;
    const decision = backupDue({ now: Date.now(), lastAt, everyHours, invoicesSince: enabled && lastAt ? await invoicesSince(lastAt) : 0, afterSales: Number(settings.get('autoBackupAfterSales')) || 0, enabled });
    if (enabled && (force || decision.due)) {
      try {
        out.snapshot = await takeSnapshot('auto');
        state.lastError = '';
      } catch (e) {
        state.lastError = e?.message || String(e);
      }
    }
    // Drive + device copy follow their own clocks so a failed upload is retried
    const driveWanted = enabled && settings.get('autoBackupToDrive') && settings.get('syncUrl') && settings.get('syncToken');
    const lastDrive = settings.get('lastDriveBackupAt');
    const driveDue = driveWanted && online && (force || !lastDrive || Date.now() - Date.parse(lastDrive) >= everyHours * HOUR);
    // When "encrypt Drive backups" is on, the passphrase must have been typed this session; WITHOUT it we
    // upload nothing (never a plain copy) and say so, instead of storing the passphrase anywhere.
    const needPass = !!settings.get('autoBackupEncrypt');
    const pass = needPass ? getSessionBackupPassphrase() : '';
    if (driveDue && needPass && !pass) {
      state.driveError = 'Encrypted Drive backup is waiting: an administrator must enter the backup passphrase (Settings → Backup) once after the app starts.';
    } else if (driveDue && (out.snapshot || (await listSnapshots()).length)) {
      try {
        await backupToDrive({ fetchImpl, passphrase: pass, requireAuth: false });
        await settings.set({ lastDriveBackupAt: new Date().toISOString() });
        out.drive = true;
        state.driveError = '';
      } catch (e) {
        state.driveError = e?.message || String(e);
      }
    }
    if (out.snapshot && settings.get('autoBackupToDevice') !== false) {
      const newest = await readSnapshotRow(out.snapshot.id);
      out.device = newest ? await writeDeviceCopy(newest.json) : false;
    }
    return out;
  } finally {
    state.running = false;
    bus.emit('backup:status', await getBackupStatus().catch(() => null));
  }
}

/** Status for the UI. */
export async function getBackupStatus() {
  const snaps = await listSnapshots().catch(() => []);
  return {
    enabled: !!settings.get('autoBackupEnabled'),
    running: state.running,
    lastError: state.lastError,
    driveError: state.driveError,
    lastAutoBackupAt: settings.get('lastAutoBackupAt'),
    lastDriveBackupAt: settings.get('lastDriveBackupAt'),
    count: snaps.length,
    newest: snaps[0] || null,
    nextDueAt: settings.get('lastAutoBackupAt') ? new Date(Date.parse(settings.get('lastAutoBackupAt')) + (Number(settings.get('autoBackupEveryHours')) || 24) * HOUR).toISOString() : '',
  };
}

/** Start the background checks (idempotent). Call once at app start. */
export function startAutoBackup() {
  if (state.timer || typeof window === 'undefined') return;
  const check = () => runAutoBackup().catch(() => {});
  setTimeout(check, 5000); // shortly after start, once the UI is up
  state.timer = setInterval(check, 10 * 60000);
  document.addEventListener('visibilitychange', () => document.hidden && check());
  window.addEventListener('online', check);
}

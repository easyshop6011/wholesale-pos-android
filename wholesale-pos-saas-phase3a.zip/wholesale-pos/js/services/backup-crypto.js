/**
 * backup-crypto.js — passphrase encryption for backup files (WebCrypto only).
 *
 * Design (the point is that the KEY NEVER TRAVELS WITH THE FILE):
 *   passphrase ──PBKDF2-SHA256 (310 000 rounds, random 16-byte salt)──► 256-bit AES key
 *   AES-256-GCM (random 12-byte IV) encrypts the backup JSON.
 * The file stores only the salt, the IV, the round count and the ciphertext — none of
 * which helps without the passphrase. The passphrase itself is typed by a person and
 * is never written to disk, to settings, to the activity log or to Google Drive.
 *
 * AES-GCM also authenticates: a wrong passphrase, a flipped bit or an edited header
 * all make decryption FAIL (nothing is ever half-decrypted). The header is bound to
 * the ciphertext as "additional authenticated data", so the round count / salt cannot
 * be altered undetected.
 *
 * WebCrypto needs HTTPS or localhost. On plain http:// there is no safe fallback, so
 * encryption is reported as unavailable instead of silently weakened.
 */
import { bytesToBase64, base64ToBytes } from '../core/utils.js';
import { ValidationError } from '../core/errors.js';

export const ENCRYPTED_FORMAT = 'wholesale-pos-backup-encrypted';
export const ENCRYPTED_VERSION = 1;
export const KDF_ITERATIONS = 310000;
export const MIN_PASSPHRASE = 8;
const MIN_ITER = 100000;
const MAX_ITER = 2000000;

const enc = new TextEncoder();
const dec = new TextDecoder();

/** Is WebCrypto available (secure context)? */
export const encryptionAvailable = () => !!globalThis.crypto?.subtle && typeof globalThis.crypto.getRandomValues === 'function';

function needCrypto() {
  if (!encryptionAvailable()) throw new ValidationError('Encryption needs a secure connection (HTTPS or localhost). Open the app from its https:// address or install the Android app.');
}

/** Thrown when an encrypted file is opened without a passphrase, so the UI can ask for one. */
export class PassphraseRequired extends ValidationError {
  constructor() {
    super('This backup is encrypted. Enter its passphrase.');
    this.name = 'PassphraseRequired';
    this.code = 'passphrase-required';
  }
}

/** Is this parsed JSON an encrypted backup envelope? */
export const isEncryptedBackup = (obj) => !!obj && typeof obj === 'object' && obj.format === ENCRYPTED_FORMAT;

const header = (iterations, salt, iv) => ({ format: ENCRYPTED_FORMAT, version: ENCRYPTED_VERSION, kdf: { name: 'PBKDF2', hash: 'SHA-256', iterations, salt: bytesToBase64(salt) }, cipher: { name: 'AES-GCM', iv: bytesToBase64(iv) } });
const aadOf = (h) => enc.encode(JSON.stringify([h.format, h.version, h.kdf.name, h.kdf.hash, h.kdf.iterations, h.kdf.salt, h.cipher.name, h.cipher.iv]));

async function deriveKey(passphrase, salt, iterations, usage) {
  const base = await crypto.subtle.importKey('raw', enc.encode(String(passphrase).normalize('NFKC')), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, base, { name: 'AES-GCM', length: 256 }, false, [usage]);
}

/**
 * Encrypt text with a passphrase.
 * @param {string} plaintext
 * @param {string} passphrase  at least 8 characters
 * @param {{iterations?:number}} [o]
 * @returns {Promise<object>} the envelope (JSON-serialisable)
 */
export async function encryptText(plaintext, passphrase, { iterations = KDF_ITERATIONS } = {}) {
  needCrypto();
  if (typeof passphrase !== 'string' || [...passphrase].length < MIN_PASSPHRASE) throw new ValidationError(`The passphrase must be at least ${MIN_PASSPHRASE} characters.`);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const h = header(iterations, salt, iv);
  const key = await deriveKey(passphrase, salt, iterations, 'encrypt');
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: aadOf(h) }, key, enc.encode(plaintext)));
  return { ...h, data: bytesToBase64(ct) };
}

/**
 * Decrypt an envelope. Throws a ValidationError for a wrong passphrase or any change to the file.
 * @param {object} env
 * @param {string} passphrase
 * @returns {Promise<string>}
 */
export async function decryptEnvelope(env, passphrase) {
  needCrypto();
  if (!passphrase) throw new PassphraseRequired();
  const bad = () => new ValidationError('The encrypted backup is damaged or not in a supported format.');
  if (!isEncryptedBackup(env) || env.version !== ENCRYPTED_VERSION || env.kdf?.name !== 'PBKDF2' || env.kdf?.hash !== 'SHA-256' || env.cipher?.name !== 'AES-GCM' || typeof env.data !== 'string') throw bad();
  const iterations = Number(env.kdf.iterations);
  if (!Number.isInteger(iterations) || iterations < MIN_ITER || iterations > MAX_ITER) throw bad(); // also stops a hostile file from freezing the app
  let salt;
  let iv;
  let ct;
  try {
    salt = base64ToBytes(env.kdf.salt);
    iv = base64ToBytes(env.cipher.iv);
    ct = base64ToBytes(env.data);
  } catch {
    throw bad();
  }
  if (salt.length !== 16 || iv.length !== 12 || ct.length < 17) throw bad();
  try {
    const key = await deriveKey(passphrase, salt, iterations, 'decrypt');
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: aadOf(env) }, key, ct);
    return dec.decode(plain);
  } catch {
    throw new ValidationError('Wrong passphrase, or the backup file was changed or damaged.');
  }
}

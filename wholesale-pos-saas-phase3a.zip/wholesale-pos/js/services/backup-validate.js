/**
 * backup-validate.js — decides, BEFORE anything is written, whether a backup file is
 * safe to restore. Pure (no database, no DOM) so every rule is unit-tested in Node.
 *
 * It checks, for every store and every record:
 *   • structure     — the file is an object, every store is an array of plain objects
 *   • required data — the fields each record type cannot work without, with their types
 *   • keys          — primary keys present and unique; unique indexes (invoice numbers,
 *                     usernames …) really unique, so the restore cannot fail half-way
 *   • relationships — invoice lines → invoice, invoice/payment/return → customer,
 *                     return → invoice, stock history → product
 *   • money         — total = subtotal − discount, due = total − paid, lines add up
 *   • safety        — at least one active administrator exists (no lock-out)
 *
 * `errors` BLOCK the restore. `warnings` are reported but allowed (e.g. a product whose
 * stock was never fully tracked by the history).
 */
import { SCHEMA } from '../core/db.js';
import { ROLES } from './permissions.js';
import { MOVEMENT_TYPES } from './stockledger.js';
import { round2 } from '../core/money.js';
import { ValidationError } from '../core/errors.js';

export const BACKUP_FORMAT = 'wholesale-pos-backup';
export const BACKUP_VERSION = 2;

/** Stores every backup must contain (as arrays, possibly empty). */
export const CORE_STORES = ['users', 'settings', 'meta', 'categories', 'products', 'customers', 'invoices', 'invoiceItems', 'payments', 'auditLog', 'syncLog', 'stockMovements'];

const MAX_REPORTED = 40;

const isObj = (v) => !!v && typeof v === 'object' && !Array.isArray(v);
const str = (v) => typeof v === 'string' && v.length > 0;
const strOrEmpty = (v) => typeof v === 'string';
const num = (v) => typeof v === 'number' && Number.isFinite(v);
const money = (v) => num(v) && v >= 0;
const bool = (v) => typeof v === 'boolean';
const day = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(`${v}T00:00:00Z`));
const iso = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v) && !Number.isNaN(Date.parse(v));
const hashRec = (v) => isObj(v) && str(v.algo) && num(v.iter) && v.iter > 0 && str(v.salt) && str(v.hash);
const near = (a, b, tol = 0.006) => Math.abs(a - b) <= tol;

/** Per-store field rules: [field, test, human description]. */
const RULES = {
  users: [['id', str, 'text'], ['username', str, 'text'], ['usernameLower', str, 'text'], ['role', (v) => !!ROLES[v], 'a known role'], ['active', bool, 'true/false'], ['passHash', hashRec, 'a password hash'], ['pinHash', hashRec, 'a PIN hash']],
  settings: [['key', str, 'text']],
  meta: [['key', str, 'text']],
  categories: [['id', str, 'text'], ['name', str, 'text'], ['nameLower', str, 'text']],
  products: [['id', str, 'text'], ['name', str, 'text'], ['nameLower', str, 'text'], ['unit', str, 'text'], ['stock', num, 'a number'], ['lowStockLevel', num, 'a number'], ['costPrice', money, 'an amount ≥ 0'], ['defaultPrice', money, 'an amount ≥ 0'], ['active', bool, 'true/false']],
  customers: [['id', str, 'text'], ['name', str, 'text'], ['nameLower', str, 'text'], ['phone', strOrEmpty, 'text']],
  invoices: [['id', str, 'text'], ['invoiceNo', str, 'text'], ['date', day, 'a date (YYYY-MM-DD)'], ['time', str, 'a time'], ['createdAt', iso, 'a timestamp'], ['subtotal', money, 'an amount ≥ 0'], ['discount', money, 'an amount ≥ 0'], ['total', money, 'an amount ≥ 0'], ['paid', money, 'an amount ≥ 0'], ['due', money, 'an amount ≥ 0'], ['status', (v) => v === 'active' || v === 'void', '"active" or "void"']],
  invoiceItems: [['id', str, 'text'], ['invoiceId', str, 'text'], ['productId', str, 'text'], ['qty', (v) => num(v) && v > 0, 'a number > 0'], ['unitPrice', money, 'an amount ≥ 0'], ['total', money, 'an amount ≥ 0']],
  payments: [['id', str, 'text'], ['customerId', str, 'text'], ['amount', (v) => num(v) && v > 0, 'an amount > 0'], ['date', day, 'a date (YYYY-MM-DD)'], ['createdAt', iso, 'a timestamp']],
  auditLog: [['id', str, 'text'], ['createdAt', iso, 'a timestamp'], ['action', str, 'text']],
  syncLog: [['id', str, 'text'], ['createdAt', iso, 'a timestamp']],
  stockMovements: [['id', str, 'text'], ['productId', str, 'text'], ['type', (v) => !!MOVEMENT_TYPES[v], 'a known movement type'], ['qty', num, 'a number'], ['balance', num, 'a number'], ['createdAt', iso, 'a timestamp']],
  salesReturns: [['id', str, 'text'], ['returnNo', str, 'text'], ['invoiceId', str, 'text'], ['items', (v) => Array.isArray(v) && v.length > 0, 'a list of items'], ['amount', money, 'an amount ≥ 0'], ['creditApplied', money, 'an amount ≥ 0'], ['refund', money, 'an amount ≥ 0'], ['createdAt', iso, 'a timestamp'], ['date', day, 'a date (YYYY-MM-DD)']],
};

/**
 * Inspect a parsed backup object.
 * @param {any} obj
 * @returns {{ok:boolean, errors:string[], warnings:string[], counts:Record<string,number>, version:number}}
 */
export function inspectBackup(obj) {
  const errors = [];
  const warnings = [];
  let counts = {};
  let extra = 0;
  const err = (m) => (errors.length < MAX_REPORTED ? errors.push(m) : (extra += 1));
  const warn = (m) => warnings.length < MAX_REPORTED && warnings.push(m);

  if (!isObj(obj) || obj.format !== BACKUP_FORMAT || !isObj(obj.stores)) {
    return { ok: false, errors: ['This is not a Wholesale POS backup file.'], warnings, counts: {}, version: 0 };
  }
  const version = obj.version;
  if (!Number.isInteger(version) || version < 1) return { ok: false, errors: ['The backup has no valid version number — the file is damaged.'], warnings, counts: {}, version: 0 };
  if (version > BACKUP_VERSION) return { ok: false, errors: ['This backup was made by a newer version of the app. Update the app first.'], warnings, counts: {}, version };
  if (obj.exportedAt !== undefined && !iso(obj.exportedAt)) warn('The backup date is missing or unreadable.');

  // ---- structure ---------------------------------------------------------------
  for (const n of Object.keys(obj.stores)) if (!SCHEMA[n]) err(`Unknown data set "${n}" in the backup.`);
  const need = version >= 2 ? [...CORE_STORES, 'salesReturns'] : CORE_STORES;
  for (const n of need) if (!Array.isArray(obj.stores[n])) err(`The "${n}" data is ${obj.stores[n] === undefined ? 'missing' : 'not a list'} — the backup is incomplete or damaged.`);
  if (errors.length) return finish();

  const S = (n) => (Array.isArray(obj.stores[n]) ? obj.stores[n] : []);
  counts = Object.fromEntries(Object.keys(SCHEMA).map((n) => [n, S(n).length]));

  // ---- every record: object, required fields, unique keys / indexes ---------------
  for (const [name, def] of Object.entries(SCHEMA)) {
    const rows = S(name);
    const seenKey = new Set();
    const uniq = def.indexes.filter((i) => i.unique).map((i) => ({ ...i, seen: new Map() }));
    rows.forEach((row, idx) => {
      const where = `${name} #${idx + 1}`;
      if (!isObj(row)) return err(`${where} is not a valid record.`);
      for (const [f, ok, desc] of RULES[name] || []) if (!ok(row[f])) err(`${where}${str(row.id) ? ` (${row.id.slice(0, 8)}…)` : ''}: "${f}" must be ${desc}.`);
      const key = row[def.keyPath];
      if (key !== undefined) {
        if (seenKey.has(key)) err(`${where}: the ${def.keyPath} "${String(key).slice(0, 40)}" appears twice.`);
        seenKey.add(key);
      }
      for (const u of uniq) {
        const v = row[u.keyPath];
        if (v === undefined || v === null) continue; // not indexed
        if (u.seen.has(v)) err(`${where}: ${u.keyPath} "${String(v).slice(0, 40)}" is used by two records.`);
        u.seen.set(v, true);
      }
    });
  }
  if (errors.length) return finish();

  // ---- relationships ---------------------------------------------------------------
  const ids = (n) => new Set(S(n).map((r) => r.id));
  const customers = ids('customers');
  const invoices = ids('invoices');
  const products = ids('products');
  const linesOf = new Map();
  for (const it of S('invoiceItems')) {
    if (!invoices.has(it.invoiceId)) err(`An invoice line (${it.id.slice(0, 8)}…) belongs to an invoice that is not in the backup.`);
    else (linesOf.get(it.invoiceId) || linesOf.set(it.invoiceId, []).get(it.invoiceId)).push(it);
    if (!products.has(it.productId)) warn(`An invoice line refers to product ${String(it.productId).slice(0, 8)}… which is not in the backup (history is kept, the product is gone).`);
  }
  for (const i of S('invoices')) {
    if (i.customerId && !customers.has(i.customerId)) err(`Invoice ${i.invoiceNo} belongs to a customer who is not in the backup.`);
    const lines = linesOf.get(i.id) || [];
    if (!lines.length) err(`Invoice ${i.invoiceNo} has no product lines.`);
    // money identities
    if (!near(round2(i.subtotal - i.discount), i.total)) err(`Invoice ${i.invoiceNo}: total ${i.total} ≠ subtotal ${i.subtotal} − discount ${i.discount}.`);
    if (!near(round2(i.total - i.paid), i.due)) err(`Invoice ${i.invoiceNo}: due ${i.due} ≠ total ${i.total} − paid ${i.paid}.`);
    if (lines.length && !near(round2(lines.reduce((a, l) => a + l.total, 0)), i.subtotal, 0.011)) err(`Invoice ${i.invoiceNo}: the lines add up to ${round2(lines.reduce((a, l) => a + l.total, 0))}, not ${i.subtotal}.`);
    if (i.due > 0 && !i.customerId && i.status !== 'void') err(`Invoice ${i.invoiceNo} has a due amount but no customer.`);
  }
  for (const p of S('payments')) if (!customers.has(p.customerId)) err(`A payment of ${p.amount} belongs to a customer who is not in the backup.`);
  for (const r of S('salesReturns')) {
    if (!invoices.has(r.invoiceId)) err(`Return ${r.returnNo} belongs to an invoice that is not in the backup.`);
    if (r.customerId && !customers.has(r.customerId)) err(`Return ${r.returnNo} belongs to a customer who is not in the backup.`);
    if (!near(round2(r.creditApplied + r.refund), r.amount, 0.011)) err(`Return ${r.returnNo}: credit ${r.creditApplied} + refund ${r.refund} ≠ value ${r.amount}.`);
  }
  const lastBalance = new Map();
  for (const m of [...S('stockMovements')].sort((a, b) => a.createdAt.localeCompare(b.createdAt))) {
    if (!products.has(m.productId)) err(`A stock-history row (${MOVEMENT_TYPES[m.type]?.label || m.type}) belongs to a product that is not in the backup.`);
    lastBalance.set(m.productId, m.balance);
  }
  for (const p of S('products')) if (lastBalance.has(p.id) && Math.abs(lastBalance.get(p.id) - p.stock) > 0.0005) warn(`Product "${p.name}": stock ${p.stock} differs from its last recorded stock-history balance ${lastBalance.get(p.id)}.`);

  // ---- safety -------------------------------------------------------------------------
  if (!S('users').some((u) => u.role === 'admin' && u.active)) err('The backup contains no active administrator — restoring it would lock everyone out.');

  return finish();

  function finish() {
    if (extra) errors.push(`…and ${extra} more problem(s).`);
    return { ok: errors.length === 0, errors, warnings, counts, version };
  }
}

/**
 * Throwing form: returns the inspection when the backup is safe, otherwise a
 * ValidationError that lists the first few problems.
 */
export function validateBackup(obj) {
  const r = inspectBackup(obj);
  if (!r.ok) {
    const first = r.errors.slice(0, 5).join(' ');
    throw new ValidationError(r.errors.length === 1 && /^This (is not|backup was)/.test(r.errors[0]) ? r.errors[0] : `This backup cannot be restored — nothing was changed. ${first}${r.errors.length > 5 ? ` (${r.errors.length} problems in total)` : ''}`);
  }
  return r;
}

/**
 * backup.js — export / import of the whole database and Google Drive backup.
 *
 * A backup is ONE JSON document with every store (users, products, invoices, stock
 * history, counters, settings …), optionally wrapped in a passphrase-encrypted
 * envelope (backup-crypto.js). It contains password hashes, so treat the file as
 * sensitive. The Google Sheets secret token is NEVER written into a backup: it is a
 * device setting, kept on the device and preserved across a restore.
 *
 * RESTORE IS ALL-OR-NOTHING
 *   1. read the file (decrypt if needed) and validate it completely — structure,
 *      required fields, unique keys, relationships, money arithmetic, at least one
 *      administrator (backup-validate.js). A damaged file stops HERE, nothing touched;
 *   2. save a "before restore" snapshot of the current data — if that fails the
 *      restore is refused rather than risked;
 *   3. replace every store inside ONE IndexedDB transaction: if anything fails the
 *      browser rolls the whole transaction back and the old data is still there;
 *   4. re-read settings, codes and the signed-in user.
 *
 * Google Drive backup goes through the same Apps Script web app used for Sheets (no
 * OAuth screen): the script runs as the sheet owner and saves the file into a
 * "POS Backups" folder in THEIR Drive.
 */
import { SCHEMA, run } from '../core/db.js';
import { settings } from './settings.js';
import { postToScript } from './sync.js';
import { ValidationError } from '../core/errors.js';
import { dhakaParts } from '../core/datetime.js';
import { upgradeMovement } from '../core/upgrade.js';
import { bus } from '../core/bus.js';
import { authorize } from './guard.js';
import { logAction } from './audit.js';
import { backfillCodes } from './codes.js';
import { auth } from './auth.js';
import { BACKUP_FORMAT, BACKUP_VERSION, inspectBackup, validateBackup } from './backup-validate.js';
import { encryptText, decryptEnvelope, isEncryptedBackup } from './backup-crypto.js';

export { BACKUP_FORMAT, BACKUP_VERSION, inspectBackup, validateBackup };

/** Settings that stay on the device and are never exported (secrets). */
const DEVICE_SECRETS = ['syncToken'];

// ---- session passphrase (memory only) ------------------------------------------------
// Lets the AUTOMATIC Google Drive upload stay encrypted without ever storing the passphrase:
// an administrator enters it once per session; it is forgotten on sign-out / app restart.
let sessionPassphrase = '';
export const setSessionBackupPassphrase = (p) => {
  sessionPassphrase = String(p || '');
};
export const hasSessionBackupPassphrase = () => !!sessionPassphrase;
export const getSessionBackupPassphrase = () => sessionPassphrase;
bus.on('auth:changed', () => {
  if (!auth.user()) sessionPassphrase = '';
});

/**
 * Read every store into one object (internal — used by snapshots and exports).
 * Device secrets are blanked.
 */
export async function exportDatabase() {
  const names = Object.keys(SCHEMA);
  const stores = await run(names, 'readonly', async (tx) => {
    const out = {};
    for (const n of names) out[n] = await tx.getAll(n);
    return out;
  });
  stores.settings = stores.settings.map((r) => (DEVICE_SECRETS.includes(r.key) ? { ...r, value: '' } : r));
  return { format: BACKUP_FORMAT, version: BACKUP_VERSION, exportedAt: new Date().toISOString(), stores };
}

/** Pretty file name such as pos-backup-2026-10-26-1733.json (Asia/Dhaka time; .enc.json when encrypted). */
export function backupFileName(d = new Date(), encrypted = false) {
  const p = dhakaParts(d);
  return `pos-backup-${p.date}-${p.time.slice(0, 2)}${p.time.slice(3, 5)}${encrypted ? '.enc' : ''}.json`;
}

/**
 * Turn a backup object into the text that is saved / uploaded — encrypted when a
 * passphrase is given, plain JSON otherwise.
 */
export async function serializeBackup(data, passphrase = '') {
  const json = JSON.stringify(data);
  return passphrase ? JSON.stringify(await encryptText(json, passphrase)) : json;
}

/**
 * Create a backup FILE for the user. Needs the `settings` permission.
 * @param {{passphrase?:string}} [o]
 * @returns {Promise<{text:string, fileName:string, encrypted:boolean, counts:Record<string,number>}>}
 */
export async function createBackupFile({ passphrase = '' } = {}) {
  const actor = authorize('settings');
  const data = await exportDatabase();
  const text = await serializeBackup(data, passphrase);
  const encrypted = !!passphrase;
  await settings.set({ lastBackupAt: new Date().toISOString() });
  await logAction('backup.export', { detail: encrypted ? 'encrypted file' : 'plain file', actor });
  return { text, fileName: backupFileName(new Date(), encrypted), encrypted, counts: Object.fromEntries(Object.entries(data.stores).map(([k, v]) => [k, v.length])) };
}

/**
 * Parse (and decrypt) backup text WITHOUT touching any data.
 * Throws PassphraseRequired for an encrypted file opened without a passphrase.
 */
export async function parseBackup(input, { passphrase = '' } = {}) {
  let obj = input;
  if (typeof input === 'string') {
    try {
      obj = JSON.parse(input);
    } catch {
      throw new ValidationError('This file is not valid JSON, so it cannot be a backup (it may be cut off or damaged). Nothing was changed.');
    }
  }
  if (isEncryptedBackup(obj)) {
    const text = await decryptEnvelope(obj, passphrase);
    try {
      obj = JSON.parse(text);
    } catch {
      throw new ValidationError('The decrypted backup is damaged. Nothing was changed.');
    }
  }
  return obj;
}

/**
 * Replace ALL local data with the contents of a backup, safely (see the file header).
 * Needs the `settings` permission.
 * @param {object|string} input  parsed object or JSON text (plain or encrypted)
 * @param {{passphrase?:string}} [o]
 * @returns {Promise<{stores:Record<string,number>, warnings:string[]}>}
 */
export async function importDatabase(input, { passphrase = '' } = {}) {
  const actor = authorize('settings');
  // 1. read + validate — nothing is written if this fails
  const obj = await parseBackup(input, { passphrase });
  const report = validateBackup(obj);

  // 2. a safety copy of the CURRENT data; no copy => no restore
  try {
    await (await import('./autobackup.js')).takeSnapshot('before-restore');
  } catch (e) {
    throw new ValidationError(`Could not save a safety copy of your current data, so the restore was cancelled and nothing was changed. (${e?.message || e})`);
  }

  // 3. prepare rows: bring old-format rows up to date, keep this device's secrets
  const names = Object.keys(SCHEMA);
  const rows = Object.fromEntries(names.map((n) => [n, obj.stores[n] || []]));
  rows.stockMovements = rows.stockMovements.map(upgradeMovement);
  for (const key of DEVICE_SECRETS) {
    const mine = settings.get(key);
    const theirs = rows.settings.find((r) => r.key === key);
    if (mine && (!theirs || !theirs.value)) rows.settings = [...rows.settings.filter((r) => r.key !== key), { key, value: mine }];
  }

  // 4. ONE transaction: either everything is replaced or nothing is
  await run(names, 'readwrite', async (tx) => {
    for (const n of names) {
      await tx.clear(n);
      for (const row of rows[n]) await tx.put(n, row);
    }
  });

  await settings.load();
  await backfillCodes();
  await auth.revalidate();
  bus.emit('data:changed', { store: '*' });
  await logAction('backup.restore', { detail: `${report.counts.invoices || 0} invoices, ${report.counts.products || 0} products, ${report.counts.customers || 0} customers`, actor: auth.user() || actor });
  return { stores: Object.fromEntries(names.map((n) => [n, rows[n].length])), warnings: report.warnings };
}

// ---- Google Drive (via Apps Script) -----------------------------------------

function cfg() {
  const url = settings.get('syncUrl');
  const token = settings.get('syncToken');
  if (!url || !token) throw new ValidationError('Configure Google Sheets sync (Settings → Sync) first — Drive backup uses the same web app.');
  return { url, token };
}

/**
 * Upload a full backup to the "POS Backups" folder in Google Drive.
 * @param {{fetchImpl?:typeof fetch, passphrase?:string, requireAuth?:boolean}} [o]
 *   `passphrase` encrypts the upload. `requireAuth:false` is only for the app's own
 *   background backup (no one is typing), never for buttons.
 */
export async function backupToDrive({ fetchImpl, passphrase = '', requireAuth = true } = {}) {
  if (requireAuth) authorize('settings');
  const { url, token } = cfg();
  const data = await exportDatabase();
  const content = await serializeBackup(data, passphrase);
  const res = await postToScript(url, { action: 'backup', token, name: backupFileName(new Date(), !!passphrase), content }, { fetchImpl });
  const now = new Date().toISOString();
  await settings.set({ lastBackupAt: now, lastDriveBackupAt: now });
  return res.file;
}

/** List backups stored in Drive (newest first). */
export async function listDriveBackups({ fetchImpl } = {}) {
  authorize('settings');
  const { url, token } = cfg();
  const res = await postToScript(url, { action: 'listBackups', token }, { fetchImpl });
  return res.files || [];
}

/** Download a Drive backup and restore it (replaces local data). */
export async function restoreFromDrive(fileId, { fetchImpl, passphrase = '' } = {}) {
  authorize('settings');
  const { url, token } = cfg();
  const res = await postToScript(url, { action: 'getBackup', token, id: fileId }, { fetchImpl });
  return importDatabase(res.content, { passphrase });
}

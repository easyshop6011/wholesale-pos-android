/**
 * catalog.js — products and categories.
 */
import { dbAll, dbGet, run } from '../core/db.js';
import { uuid, ValidationError } from '../core/utils.js';
import { parseMoney, parseQty, toNum } from '../core/money.js';
import { settings } from './settings.js';
import { bus } from '../core/bus.js';
import { logAction } from './audit.js';
import { terms, rank } from '../core/search.js';
import { authorize } from './guard.js';
import { recordMovement } from './stockledger.js';
import { nextCode } from './codes.js';

/** Stock state of a product: 'out' (≤ 0), 'low' (≤ its warning level) or 'ok'. */
export const stockState = (p) => (p.stock <= 0 ? 'out' : p.stock <= p.lowStockLevel ? 'low' : 'ok');

const PRODUCT_SORTS = {
  name: (a, b) => a.nameLower.localeCompare(b.nameLower),
  'stock-asc': (a, b) => a.stock - b.stock || PRODUCT_SORTS.name(a, b),
  'stock-desc': (a, b) => b.stock - a.stock || PRODUCT_SORTS.name(a, b),
  'price-asc': (a, b) => a.defaultPrice - b.defaultPrice || PRODUCT_SORTS.name(a, b),
  'price-desc': (a, b) => b.defaultPrice - a.defaultPrice || PRODUCT_SORTS.name(a, b),
  newest: (a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')),
};

/**
 * List products (active by default) with their category name attached.
 * Search matches name, SKU and category — several words must ALL match, accents
 * and Bengali digits are ignored (see core/search.js). Results are ranked by
 * relevance when searching, otherwise by `sort`.
 * @param {{search?:string, categoryId?:string|null, includeInactive?:boolean, lowOnly?:boolean,
 *          stock?:''|'out'|'low'|'ok'|'attention', minPrice?:number|string, maxPrice?:number|string,
 *          sort?:keyof typeof PRODUCT_SORTS}} [opts]
 *   `stock: 'attention'` = out of stock OR low.
 */
export async function listProducts({ search = '', categoryId = null, includeInactive = false, lowOnly = false, stock = '', minPrice = '', maxPrice = '', sort = 'name' } = {}) {
  const [products, cats] = await Promise.all([dbAll('products'), dbAll('categories')]);
  const catName = new Map(cats.map((c) => [c.id, c.name]));
  const min = minPrice === '' || minPrice == null ? null : toNum(minPrice);
  const max = maxPrice === '' || maxPrice == null ? null : toNum(maxPrice);
  const want = lowOnly && !stock ? 'attention' : stock;
  const rows = products
    .filter((p) => includeInactive || p.active)
    .filter((p) => !categoryId || p.categoryId === categoryId)
    .filter((p) => !want || (want === 'attention' ? stockState(p) !== 'ok' : stockState(p) === want))
    .filter((p) => (min === null || p.defaultPrice >= min) && (max === null || p.defaultPrice <= max))
    .map((p) => ({ ...p, categoryName: catName.get(p.categoryId) || 'Uncategorized' }));
  if (terms(search).length) return rank(rows, search, (p) => [p.name, p.sku || '', p.categoryName]);
  return rows.sort(PRODUCT_SORTS[sort] || PRODUCT_SORTS.name);
}

export const getProduct = (id) => dbGet('products', id);

/**
 * Create or update a product. Stock is NOT editable here for existing products
 * (use inventory.js so every change is logged). A NEW product writes, in the same
 * transaction as the product itself:
 *   • a "Product created" stock-history row, and
 *   • (when an opening quantity is given) an "Opening stock" row.
 * Needs the `products.edit` permission.
 * @param {object} input   `requestId` (optional) makes a double-submitted "Add product" safe.
 */
export async function saveProduct(input, _user = null) {
  const actor = authorize('products.edit');
  const name = String(input.name || '').trim();
  if (!name) throw new ValidationError('Product name is required.');
  const costPrice = parseMoney(input.costPrice, 'Cost price');
  const defaultPrice = parseMoney(input.defaultPrice, 'Default price');
  const lowStockLevel = input.lowStockLevel === '' || input.lowStockLevel == null ? settings.get('lowStockDefault') : parseQty(input.lowStockLevel, 'Low-stock level', { allowZero: true });
  const opening = input.id ? 0 : parseQty(input.stock, 'Opening stock', { allowZero: true });
  const requestId = input.requestId ? String(input.requestId).slice(0, 80) : '';
  const now = new Date().toISOString();

  const saved = await run(['products', 'stockMovements', 'meta'], 'readwrite', async (tx) => {
    if (requestId) {
      const done = await tx.getByIndex('stockMovements', 'opKey', `create:${requestId}`);
      if (done) return { ...(await tx.get('products', done.productId)), _duplicate: true };
    }
    const all = await tx.getAll('products');
    const dup = all.find((p) => p.active && p.nameLower === name.toLowerCase() && p.id !== input.id);
    if (dup) throw new ValidationError(`A product named "${dup.name}" already exists.`);

    if (input.id) {
      const old = await tx.get('products', input.id);
      if (!old) throw new ValidationError('Product not found.');
      const next = {
        ...old,
        name,
        nameLower: name.toLowerCase(),
        sku: String(input.sku || '').trim(),
        categoryId: input.categoryId || null,
        unit: String(input.unit || 'pcs').trim() || 'pcs',
        costPrice,
        defaultPrice,
        lowStockLevel,
        active: input.active ?? old.active,
        updatedAt: now,
      };
      if (!next.code) next.code = await nextCode(tx, 'product');
      await tx.put('products', next);
      return { ...next, _changes: [old.costPrice !== costPrice && `cost ${old.costPrice} → ${costPrice}`, old.defaultPrice !== defaultPrice && `price ${old.defaultPrice} → ${defaultPrice}`, old.name !== name && `renamed from "${old.name}"`].filter(Boolean) };
    }

    // New product: stock starts at 0, then the opening quantity is added through the ledger.
    const p = {
      id: uuid(),
      code: await nextCode(tx, 'product'),
      name,
      nameLower: name.toLowerCase(),
      sku: String(input.sku || '').trim(),
      categoryId: input.categoryId || null,
      unit: String(input.unit || 'pcs').trim() || 'pcs',
      costPrice,
      defaultPrice,
      stock: 0,
      lowStockLevel,
      active: true,
      createdAt: now,
      updatedAt: now,
    };
    await tx.put('products', p);
    let cur = (await recordMovement(tx, { product: p, type: 'created', qty: 0, reason: 'Product created', actor, opKey: requestId ? `create:${requestId}` : '' })).product;
    if (opening > 0) {
      cur = (await recordMovement(tx, { product: cur, type: 'initial', qty: opening, reason: 'Opening stock', actor, unitCost: costPrice || null, opKey: requestId ? `initial:${requestId}` : '' })).product;
    }
    return cur;
  });
  const { _duplicate, _changes, ...product } = saved;
  bus.emit('data:changed', { store: 'products' });
  if (!_duplicate) await logAction(input.id ? 'product.update' : 'product.create', { target: product.name, detail: (_changes || []).join('; '), actor });
  return product;
}

/**
 * "Delete" a product. Its stock history must never be lost, so a product that has
 * ANY stock movement or appears on any invoice is archived (hidden from selection
 * lists; its history, invoices and reports stay intact). Only a legacy product with
 * no history at all is physically removed. Needs `products.edit`.
 * @returns {Promise<{archived:boolean}>}
 */
export async function deleteProduct(id) {
  const actor = authorize('products.edit');
  const result = await run(['products', 'invoiceItems', 'stockMovements'], 'readwrite', async (tx) => {
    const p = await tx.get('products', id);
    if (!p) throw new ValidationError('Product not found.');
    const used = await tx.countByIndex('invoiceItems', 'productId', id);
    const moved = await tx.countByIndex('stockMovements', 'productId', id);
    if (used > 0 || moved > 0) {
      await tx.put('products', { ...p, active: false, updatedAt: new Date().toISOString() });
      return { archived: true, name: p.name, reason: used > 0 ? 'has sales history' : 'has stock history' };
    }
    await tx.delete('products', id);
    return { archived: false, name: p.name, reason: 'no history' };
  });
  bus.emit('data:changed', { store: 'products' });
  await logAction('product.delete', { target: result.name, detail: result.archived ? `archived (${result.reason})` : 'removed', actor });
  return result;
}

// ---- categories -------------------------------------------------------------

export async function listCategories() {
  return (await dbAll('categories')).sort((a, b) => a.nameLower.localeCompare(b.nameLower));
}

/** Create or rename a category (names are unique, case-insensitive). */
export async function saveCategory({ id, name }) {
  authorize('products.edit');
  const n = String(name || '').trim();
  if (!n) throw new ValidationError('Category name is required.');
  const cat = await run(['categories'], 'readwrite', async (tx) => {
    const clash = await tx.getByIndex('categories', 'nameLower', n.toLowerCase());
    if (clash && clash.id !== id) throw new ValidationError('That category already exists.');
    const c = { id: id || uuid(), name: n, nameLower: n.toLowerCase() };
    await tx.put('categories', c);
    return c;
  });
  bus.emit('data:changed', { store: 'categories' });
  return cat;
}

/** Delete a category; its products become "Uncategorized". */
export async function deleteCategory(id) {
  authorize('products.edit');
  await run(['categories', 'products'], 'readwrite', async (tx) => {
    for (const p of await tx.getAllByIndex('products', 'categoryId', id)) await tx.put('products', { ...p, categoryId: null });
    await tx.delete('categories', id);
  });
  bus.emit('data:changed', { store: 'categories' });
}

/**
 * codes.js — short human-friendly IDs next to the UUIDs: customers C-0001, products
 * P-0001 (with the device code in the middle when several devices are used, e.g.
 * C-B-0001). The UUID stays the real unique key; the code is what staff say aloud
 * and what appears on screens, printouts and CSV files.
 */
import { run } from '../core/db.js';
import { settings } from './settings.js';

const PREFIX = { customer: 'C', product: 'P' };

/** Allocate the next code inside an open transaction that includes the `meta` store. */
export async function nextCode(tx, kind, deviceCode = settings.get('deviceCode') || '') {
  const key = `seq:${kind}:${deviceCode}`;
  const row = await tx.get('meta', key);
  const n = (row?.value || 0) + 1;
  await tx.put('meta', { key, value: n });
  return `${PREFIX[kind]}-${deviceCode ? `${deviceCode}-` : ''}${String(n).padStart(4, '0')}`;
}

/**
 * Give a code to every customer / product that has none (data restored from a
 * backup made before codes existed). Idempotent; returns how many rows were updated.
 */
export async function backfillCodes() {
  return run(['customers', 'products', 'meta'], 'readwrite', async (tx) => {
    let count = 0;
    for (const [store, kind] of [['customers', 'customer'], ['products', 'product']]) {
      const rows = (await tx.getAll(store)).filter((r) => !r.code).sort((a, b) => String(a.createdAt || '').localeCompare(String(b.createdAt || '')) || String(a.id).localeCompare(String(b.id)));
      for (const r of rows) {
        await tx.put(store, { ...r, code: await nextCode(tx, kind) });
        count += 1;
      }
    }
    return count;
  });
}

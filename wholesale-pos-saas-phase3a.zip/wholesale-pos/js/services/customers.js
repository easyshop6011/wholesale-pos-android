/**
 * customers.js — customers, their balances (due), payments, ledger and the full
 * customer profile / history.
 *
 * BALANCE MODEL (computed from the real transactions every time, never stored)
 *   balance = Σ(due of ACTIVE invoices) − Σ(payments received) − Σ(credit applied by returns)
 * Invoices are immutable once saved (paid/due are fixed at the time of sale); later
 * collections are separate `payments`, goods taken back are separate `salesReturns`.
 * This keeps synced Google Sheets rows valid forever and gives a clean audit trail.
 * A negative balance means the customer has CREDIT with the shop (paid for something
 * that was later voided / returned).
 *
 * IDENTITY (checked in the profile): balance = netPurchases − netPaid, where
 *   netPurchases = Σ active invoice totals − Σ returned value
 *   netPaid      = Σ paid at the counter + Σ later payments − Σ cash refunds
 */
import { dbAll, dbGet, run } from '../core/db.js';
import { uuid, normalizePhone, dateParts } from '../core/utils.js';
import { round2, sum, toMinor, fromMinor, parseMoney, round3 } from '../core/money.js';
import { ValidationError } from '../core/errors.js';
import { dhakaDate, csvDhakaStamp } from '../core/datetime.js';
import { toCSV } from '../core/utils.js';
import { bus } from '../core/bus.js';
import { cached } from '../core/cache.js';
import { terms, rank } from '../core/search.js';
import { logAction } from './audit.js';
import { authorize, authorizeAny } from './guard.js';
import { nextCode } from './codes.js';
import { normalizeMethod, methodLabel } from './payment-methods.js';

/**
 * PURE: balance of every customer from raw rows. Every part of the app that needs a
 * balance (lists, dashboard, sync, backups checks) goes through this one function.
 * @returns {Map<string, number>}
 */
export function computeBalances(invoices, payments, returns = []) {
  const minor = new Map();
  const add = (id, v) => minor.set(id, (minor.get(id) || 0) + v);
  for (const i of invoices) if (i.customerId && i.status !== 'void') add(i.customerId, toMinor(i.due));
  for (const p of payments) add(p.customerId, -toMinor(p.amount));
  for (const r of returns) if (r.customerId) add(r.customerId, -toMinor(r.creditApplied || 0));
  return new Map([...minor].map(([k, v]) => [k, fromMinor(v)]));
}

/** Balance for one customer, computed inside an existing transaction (it must include `salesReturns`). */
export async function balanceInTx(tx, customerId) {
  const [invs, pays, rets] = await Promise.all([tx.getAllByIndex('invoices', 'customerId', customerId), tx.getAllByIndex('payments', 'customerId', customerId), tx.getAllByIndex('salesReturns', 'customerId', customerId)]);
  return computeBalances(invs, pays, rets).get(customerId) || 0;
}

/** Map of customerId -> balance for every customer (one pass over the data; cached until data changes). */
export function allBalances() {
  return cached('balances', async () => {
    const [invs, pays, rets] = await Promise.all([dbAll('invoices'), dbAll('payments'), dbAll('salesReturns')]);
    return computeBalances(invs, pays, rets);
  });
}

/** Purchase totals per customer (cached until data changes). */
function customerStats() {
  return cached('customer-stats', async () => {
    const stats = new Map();
    for (const i of await dbAll('invoices')) {
      if (!i.customerId || i.status === 'void') continue;
      const s = stats.get(i.customerId) || { total: 0, count: 0, last: '' };
      s.total += i.total;
      s.count += 1;
      if (i.date > s.last) s.last = i.date;
      stats.set(i.customerId, s);
    }
    return stats;
  });
}

const CUSTOMER_SORTS = {
  name: (a, b) => a.nameLower.localeCompare(b.nameLower),
  'due-desc': (a, b) => b.due - a.due || CUSTOMER_SORTS.name(a, b),
  'purchases-desc': (a, b) => b.totalPurchases - a.totalPurchases || CUSTOMER_SORTS.name(a, b),
  recent: (a, b) => b.lastPurchase.localeCompare(a.lastPurchase) || CUSTOMER_SORTS.name(a, b),
  oldest: (a, b) => (a.lastPurchase || '9999').localeCompare(b.lastPurchase || '9999') || CUSTOMER_SORTS.name(a, b),
};

/**
 * List customers with computed due, purchase totals and invoice counts.
 * Search matches name, phone (any format, Bengali digits too) and address.
 * @param {{search?:string, due?:''|'has'|'none', minDue?:number|string, notBoughtSince?:string,
 *          sort?:keyof typeof CUSTOMER_SORTS}} [opts]
 *   `notBoughtSince` (YYYY-MM-DD) keeps customers whose last purchase is before that day (or never).
 */
export async function listCustomers({ search = '', due = '', minDue = '', notBoughtSince = '', sort = 'name' } = {}) {
  authorizeAny(['customers', 'pos']);
  const [customers, stats, balances] = await Promise.all([dbAll('customers'), customerStats(), allBalances()]);
  const min = minDue === '' || minDue == null ? null : Number(minDue) || 0;
  const qPhone = normalizePhone(search);
  let rows = customers.map((c) => ({
    ...c,
    due: balances.get(c.id) || 0,
    totalPurchases: round2(stats.get(c.id)?.total || 0),
    invoiceCount: stats.get(c.id)?.count || 0,
    lastPurchase: stats.get(c.id)?.last || '',
  }));
  rows = rows.filter((c) => (due === 'has' ? c.due > 0 : due === 'none' ? c.due <= 0 : true) && (min === null || c.due >= min) && (!notBoughtSince || !c.lastPurchase || c.lastPurchase < notBoughtSince));
  if (terms(search).length) {
    const byText = rank(rows, search, (c) => [c.name, c.phone || '', c.address || '']);
    const digits = qPhone.replace(/\D/g, '');
    if (digits.length < 3) return byText;
    // phone typed with dashes/spaces ("01711-000") still finds "01711000001"
    const seen = new Set(byText.map((c) => c.id));
    return byText.concat(rows.filter((c) => !seen.has(c.id) && (c.phone || '').replace(/\D/g, '').includes(digits)));
  }
  return rows.sort(CUSTOMER_SORTS[sort] || CUSTOMER_SORTS.name);
}

export async function getCustomer(id) {
  authorizeAny(['customers', 'pos']);
  return dbGet('customers', id);
}

/** Create or update a customer. Phone numbers must be unique when provided. A new customer gets a short code (C-0001). */
export async function saveCustomer(input) {
  const actor = input.id ? authorize('customers') : authorizeAny(['customers', 'pos']);
  const name = String(input.name || '').trim();
  if (!name) throw new ValidationError('Customer name is required.');
  const phone = normalizePhone(input.phone);
  const saved = await run(['customers', 'meta'], 'readwrite', async (tx) => {
    if (phone) {
      const clash = (await tx.getAllByIndex('customers', 'phone', phone)).find((c) => c.id !== input.id);
      if (clash) throw new ValidationError(`Phone ${phone} already belongs to "${clash.name}".`);
    }
    const old = input.id ? await tx.get('customers', input.id) : null;
    if (input.id && !old) throw new ValidationError('Customer not found.');
    const c = {
      id: old?.id || uuid(),
      code: old?.code || (await nextCode(tx, 'customer')),
      name,
      nameLower: name.toLowerCase(),
      phone,
      address: String(input.address || '').trim(),
      notes: String(input.notes || '').trim(),
      createdAt: old?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await tx.put('customers', c);
    return { c, created: !old };
  });
  bus.emit('data:changed', { store: 'customers' });
  await logAction(saved.created ? 'customer.create' : 'customer.update', { target: saved.c.name, detail: saved.c.code, actor });
  return saved.c;
}

/** Delete a customer — only allowed if they have no invoices, payments or returns. Needs `customers.delete`. */
export async function deleteCustomer(id) {
  const actor = authorize('customers.delete');
  let name = '';
  await run(['customers', 'invoices', 'payments', 'salesReturns'], 'readwrite', async (tx) => {
    const n = (await tx.countByIndex('invoices', 'customerId', id)) + (await tx.countByIndex('payments', 'customerId', id)) + (await tx.countByIndex('salesReturns', 'customerId', id));
    if (n > 0) throw new ValidationError('This customer has transaction history and cannot be deleted.');
    name = (await tx.get('customers', id))?.name || '';
    await tx.delete('customers', id);
  });
  bus.emit('data:changed', { store: 'customers' });
  await logAction('customer.delete', { target: name, actor });
}

/** All invoices of a customer, newest first (purchase history). */
export async function customerInvoices(customerId) {
  authorizeAny(['customers', 'invoices']);
  const rows = await run(['invoices'], 'readonly', (tx) => tx.getAllByIndex('invoices', 'customerId', customerId));
  return rows.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

/**
 * Due history: credit sales (+), payments received (−) and credit from returns (−)
 * with a running balance. (Voided invoices are left out here — the full audit view
 * that keeps them is {@link customerProfile}.)
 * @returns {Promise<{balance:number, entries:Array}>}
 */
export async function customerLedger(customerId) {
  authorizeAny(['customers', 'invoices']);
  const { invs, pays, rets } = await run(['invoices', 'payments', 'salesReturns'], 'readonly', async (tx) => ({
    invs: await tx.getAllByIndex('invoices', 'customerId', customerId),
    pays: await tx.getAllByIndex('payments', 'customerId', customerId),
    rets: await tx.getAllByIndex('salesReturns', 'customerId', customerId),
  }));
  const rows = [
    ...invs
      .filter((i) => i.status !== 'void' && i.due > 0)
      .map((i) => ({ kind: 'invoice', id: i.id, at: i.createdAt, date: i.date, time: i.time, ref: i.invoiceNo, note: `Invoice total ${i.total}, paid ${i.paid}`, debit: i.due, credit: 0 })),
    ...pays.map((p) => ({ kind: 'payment', id: p.id, at: p.createdAt, date: p.date, time: p.time, ref: 'Payment', note: [methodLabel(p.method) !== '—' ? methodLabel(p.method) : '', p.note].filter(Boolean).join(' · '), debit: 0, credit: p.amount })),
    ...rets.filter((r) => r.creditApplied > 0).map((r) => ({ kind: 'return', id: r.id, at: r.createdAt, date: r.date, time: r.time, ref: r.returnNo, note: `Goods returned from ${r.invoiceNo}`, debit: 0, credit: r.creditApplied })),
  ].sort((a, b) => a.at.localeCompare(b.at));
  let bal = 0;
  for (const r of rows) {
    bal = round2(bal + r.debit - r.credit);
    r.balance = bal;
  }
  return { balance: bal, entries: rows };
}

/**
 * Record a payment against a customer's outstanding due. Needs `customers`.
 * IDEMPOTENT: a repeated `requestId` returns the first payment (`duplicate: true`) and records nothing new.
 * @param {{customerId:string, amount:number|string, note?:string, method?:string, requestId?:string}} input
 */
export async function receivePayment({ customerId, amount, note = '', method = 'cash', requestId = '' }, _user = null) {
  const actor = authorize('customers');
  const amt = parseMoney(amount, 'Payment amount');
  if (!(amt > 0)) throw new ValidationError('Enter a payment amount greater than zero.');
  const rid = requestId ? String(requestId).slice(0, 80) : '';
  const payment = await run(['payments', 'invoices', 'customers', 'salesReturns'], 'readwrite', async (tx) => {
    if (rid) {
      const done = await tx.getByIndex('payments', 'requestId', rid);
      if (done) return { ...done, duplicate: true };
    }
    const c = await tx.get('customers', customerId);
    if (!c) throw new ValidationError('Customer not found.');
    const bal = await balanceInTx(tx, customerId);
    if (amt > bal) throw new ValidationError(`Payment exceeds the outstanding due (${bal}).`);
    const parts = dateParts();
    const p = {
      id: uuid(),
      customerId,
      customerName: c.name,
      customerPhone: c.phone,
      amount: amt,
      method: normalizeMethod(method),
      note: String(note).trim(),
      date: parts.date,
      time: parts.time,
      month: parts.month,
      createdAt: parts.iso,
      userId: actor.id,
      userName: actor.displayName || '',
      syncStatus: 'pending',
      syncAttempts: 0,
      syncError: '',
    };
    if (rid) p.requestId = rid;
    await tx.put('payments', p);
    return p;
  });
  if (!payment.duplicate) {
    bus.emit('data:changed', { store: 'payments' });
    await logAction('payment.receive', { target: payment.customerName, detail: `${payment.amount} via ${methodLabel(payment.method)}${payment.note ? ` — ${payment.note}` : ''}`, actor });
  }
  return payment;
}

// =============================================================================
// Customer profile & full history
// =============================================================================

/**
 * PURE: split an invoice-level discount across its lines in proportion to their value
 * (the last line absorbs the rounding) so the shares add up to the discount exactly.
 * @param {{total:number}[]} items
 * @param {number} discount
 * @returns {{discountShare:number, net:number}[]}
 */
export function allocateDiscount(items, discount) {
  const gross = sum(items.map((i) => i.total));
  let left = toMinor(discount);
  return items.map((it, idx) => {
    const share = idx === items.length - 1 || gross <= 0 ? left : Math.min(left, Math.round((toMinor(it.total) * toMinor(discount)) / toMinor(gross)));
    left -= share;
    return { discountShare: fromMinor(share), net: fromMinor(toMinor(it.total) - share) };
  });
}

/**
 * PURE: how much of each ACTIVE invoice's due has been settled by later payments and
 * credit from returns, using the same "oldest invoice first" rule as the due-ageing
 * report. Derived for display only — it never changes the balance.
 * @returns {Map<string, {laterPaid:number, remainingDue:number}>}
 */
export function allocateSettlements(activeInvoices, creditMinor) {
  const open = activeInvoices.filter((i) => i.due > 0).sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map((i) => ({ id: i.id, left: toMinor(i.due), taken: 0 }));
  let pool = creditMinor;
  for (const o of open) {
    const take = Math.min(pool, o.left);
    o.taken = take;
    pool -= take;
  }
  return new Map(open.map((o) => [o.id, { laterPaid: fromMinor(o.taken), remainingDue: fromMinor(o.left - o.taken) }]));
}

/**
 * The complete picture of one customer. Needs `customers`.
 *
 * `entries` is the audit-style history, NEWEST FIRST — nothing is ever removed from it:
 *   invoice (with every product line, discount share, paid at the counter, method),
 *   payment (each partial / later payment with time, amount, method),
 *   return  (goods taken back), void (reason, who, when, refund owed).
 * Every entry carries the running `balance` after it, so the history can be checked
 * line by line against the balance.
 *
 * @param {string} customerId
 * @param {{from?:string, to?:string}} [range]  Asia/Dhaka days (YYYY-MM-DD) limiting `entries` and `period`
 */
export async function customerProfile(customerId, { from = '', to = '' } = {}) {
  authorize('customers');
  const data = await run(['customers', 'invoices', 'invoiceItems', 'payments', 'salesReturns'], 'readonly', async (tx) => {
    const customer = await tx.get('customers', customerId);
    if (!customer) return null;
    const invs = await tx.getAllByIndex('invoices', 'customerId', customerId);
    const withItems = [];
    for (const inv of invs) withItems.push({ ...inv, items: await tx.getInvoiceLines(inv.id) });
    return { customer, invs: withItems, pays: await tx.getAllByIndex('payments', 'customerId', customerId), rets: await tx.getAllByIndex('salesReturns', 'customerId', customerId) };
  });
  if (!data) throw new ValidationError('Customer not found.');
  const { customer, invs, pays, rets } = data;
  const active = invs.filter((i) => i.status !== 'void');
  const voided = invs.filter((i) => i.status === 'void');

  // 1. who owes what, from the raw transactions
  const balance = computeBalances(invs, pays, rets).get(customerId) || 0;
  const totalPurchases = sum(active.map((i) => i.total));
  const paidAtSale = sum(active.map((i) => i.paid));
  const paymentsReceived = sum(pays.map((p) => p.amount));
  const returnsValue = sum(rets.map((r) => r.amount));
  const refunds = sum(rets.map((r) => r.refund));
  const creditFromReturns = sum(rets.map((r) => r.creditApplied));
  const netPurchases = round2(totalPurchases - returnsValue);
  const netPaid = round2(paidAtSale + paymentsReceived - refunds);
  const lastInv = [...active].sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0] || null;

  // 2. derived settlement per active invoice
  const settle = allocateSettlements(active, toMinor(paymentsReceived) + toMinor(creditFromReturns));

  // 3. events in time order with the running balance
  const events = [];
  for (const inv of invs) {
    const shares = allocateDiscount(inv.items, inv.discount || 0);
    const st = inv.status === 'void' ? null : settle.get(inv.id) || { laterPaid: 0, remainingDue: 0 };
    events.push({
      kind: 'invoice',
      id: inv.id,
      at: inv.createdAt,
      ref: inv.invoiceNo,
      status: inv.status,
      debit: inv.due,
      credit: 0,
      invoice: {
        ...inv,
        items: inv.items.map((it, i) => ({ ...it, discountShare: shares[i].discountShare, net: shares[i].net })),
        laterPaid: st ? st.laterPaid : 0,
        remainingDue: st ? st.remainingDue : 0,
        state: inv.status === 'void' ? 'void' : inv.due <= 0 ? 'paid' : st.remainingDue <= 0 ? 'settled-later' : inv.paid > 0 || st.laterPaid > 0 ? 'partial' : 'unpaid',
      },
    });
    if (inv.status === 'void') events.push({ kind: 'void', id: `${inv.id}:void`, at: inv.voidedAt || inv.createdAt, ref: inv.invoiceNo, debit: 0, credit: inv.due, void: { reason: inv.voidReason || '', by: inv.voidedBy || '', refundOwed: inv.voidRefund ?? inv.paid, invoiceTotal: inv.total, invoiceId: inv.id } });
  }
  for (const p of pays) events.push({ kind: 'payment', id: p.id, at: p.createdAt, ref: 'Payment', debit: 0, credit: p.amount, payment: p });
  for (const r of rets) events.push({ kind: 'return', id: r.id, at: r.createdAt, ref: r.returnNo, debit: 0, credit: r.creditApplied, return: r });
  const order = { invoice: 0, payment: 1, return: 1, void: 2 };
  events.sort((a, b) => a.at.localeCompare(b.at) || order[a.kind] - order[b.kind] || a.id.localeCompare(b.id));
  let bal = 0;
  for (const e of events) {
    e.opening = bal;
    bal = fromMinor(toMinor(bal) + toMinor(e.debit) - toMinor(e.credit));
    e.balance = bal;
    e.date = dhakaDate(e.at);
  }

  // 4. optional date range (Dhaka days)
  const inRange = (e) => (!from || e.date >= from) && (!to || e.date <= to);
  const chosen = events.filter(inRange);
  const before = from ? events.filter((e) => e.date < from) : [];
  const openingBalance = before.length ? before[before.length - 1].balance : 0;
  const period = {
    from,
    to,
    openingBalance,
    closingBalance: chosen.length ? chosen[chosen.length - 1].balance : openingBalance,
    invoices: chosen.filter((e) => e.kind === 'invoice' && e.status !== 'void').length,
    sales: sum(chosen.filter((e) => e.kind === 'invoice' && e.status !== 'void').map((e) => e.invoice.total)),
    paidAtSale: sum(chosen.filter((e) => e.kind === 'invoice' && e.status !== 'void').map((e) => e.invoice.paid)),
    paymentsReceived: sum(chosen.filter((e) => e.kind === 'payment').map((e) => e.payment.amount)),
    returns: sum(chosen.filter((e) => e.kind === 'return').map((e) => e.return.amount)),
    voids: chosen.filter((e) => e.kind === 'void').length,
  };

  return {
    customer,
    summary: {
      customerId: customer.id,
      code: customer.code || '',
      totalPurchases,
      paidAtSale,
      paymentsReceived,
      totalPaid: round2(paidAtSale + paymentsReceived),
      refunds,
      returnsValue,
      creditFromReturns,
      netPurchases,
      netPaid,
      currentDue: balance,
      invoiceCount: active.length,
      voidedCount: voided.length,
      returnCount: rets.length,
      paymentCount: pays.length,
      lastPurchase: lastInv ? { at: lastInv.createdAt, date: lastInv.date, time: lastInv.time, invoiceNo: lastInv.invoiceNo } : null,
      // the identity from the file header — a mismatch would mean corrupted data
      reconciles: round2(netPurchases - netPaid) === balance,
    },
    period,
    entries: chosen.reverse(),
  };
}

/**
 * CSV of a customer's history (UTF-8 — add a BOM when saving so Excel shows Bengali
 * text correctly). One row per invoice line / payment / return / void; times are Asia/Dhaka.
 * @param {Awaited<ReturnType<typeof customerProfile>>} profile
 */
export function customerHistoryToCSV(profile) {
  const head = ['Customer ID', 'Customer code', 'Customer', 'Phone', 'Date & time (Asia/Dhaka)', 'Type', 'Reference', 'Status', 'Product', 'Qty', 'Unit', 'Unit price', 'Line total', 'Discount share', 'Line net', 'Invoice total', 'Paid at sale', 'Due at sale', 'Payment / refund method', 'Note / reason', 'Balance after'];
  const c = profile.customer;
  const lead = [c.id, c.code || '', c.name, c.phone || ''];
  const rows = [];
  for (const e of [...profile.entries].reverse()) {
    const when = csvDhakaStamp(e.at);
    if (e.kind === 'invoice') {
      const inv = e.invoice;
      const lines = inv.items.length ? inv.items : [null];
      lines.forEach((it, i) => {
        rows.push([...lead, when, 'Invoice', inv.invoiceNo, inv.status === 'void' ? 'Void' : 'Active', it?.name ?? '', it?.qty ?? '', it?.unit ?? '', it?.unitPrice ?? '', it?.total ?? '', it?.discountShare ?? '', it?.net ?? '', i === 0 ? inv.total : '', i === 0 ? inv.paid : '', i === 0 ? inv.due : '', i === 0 ? methodLabel(inv.paymentMethod) : '', i === 0 ? inv.notes || '' : '', i === 0 ? e.balance : '']);
      });
    } else if (e.kind === 'payment') {
      rows.push([...lead, when, 'Payment received', 'Payment', '', '', '', '', '', '', '', '', '', e.payment.amount, '', methodLabel(e.payment.method), e.payment.note || '', e.balance]);
    } else if (e.kind === 'return') {
      const r = e.return;
      r.items.forEach((it, i) => {
        rows.push([...lead, when, 'Return', r.returnNo, '', it.name, it.qty, it.unit, it.unitPrice, it.amount, '', '', i === 0 ? r.amount : '', i === 0 ? r.creditApplied : '', '', i === 0 ? methodLabel(r.refundMethod) : '', i === 0 ? `${r.reason} (invoice ${r.invoiceNo}; refund ${r.refund})` : '', i === 0 ? e.balance : '']);
      });
    } else {
      rows.push([...lead, when, 'Void', e.ref, 'Void', '', '', '', '', '', '', '', e.void.invoiceTotal, '', '', '', `${e.void.reason} (by ${e.void.by}; refund owed ${e.void.refundOwed})`, e.balance]);
    }
  }
  return toCSV([head, ...rows]);
}

/**
 * demo.js — optional sample data so a new user can try the app immediately.
 */
import { saveProduct, saveCategory } from './catalog.js';
import { saveCustomer } from './customers.js';

/** Insert a handful of categories, products and customers. */
export async function seedDemoData() {
  const food = await saveCategory({ name: 'Grocery' });
  const oil = await saveCategory({ name: 'Oil & Ghee' });
  const bev = await saveCategory({ name: 'Beverages' });
  const rows = [
    { name: 'Basmati Rice 25kg', categoryId: food.id, unit: 'bag', costPrice: 2300, defaultPrice: 2450, stock: 80, lowStockLevel: 10 },
    { name: 'Sugar 50kg', categoryId: food.id, unit: 'bag', costPrice: 6100, defaultPrice: 6400, stock: 40, lowStockLevel: 8 },
    { name: 'Red Lentils (Masoor) 1kg', categoryId: food.id, unit: 'kg', costPrice: 105, defaultPrice: 120, stock: 300, lowStockLevel: 50 },
    { name: 'Soybean Oil 5L', categoryId: oil.id, unit: 'btl', costPrice: 810, defaultPrice: 880, stock: 120, lowStockLevel: 20 },
    { name: 'Ghee 1kg', categoryId: oil.id, unit: 'tin', costPrice: 1050, defaultPrice: 1180, stock: 6, lowStockLevel: 10 },
    { name: 'Mineral Water 500ml (carton)', categoryId: bev.id, unit: 'ctn', costPrice: 185, defaultPrice: 220, stock: 200, lowStockLevel: 30 },
  ];
  for (const r of rows) await saveProduct(r);
  await saveCustomer({ name: 'Rahim Traders', phone: '01711000001', address: 'Karwan Bazar, Dhaka' });
  await saveCustomer({ name: 'Karim Store', phone: '01811000002', address: 'Mirpur 10, Dhaka' });
  await saveCustomer({ name: 'Sathi Enterprise', phone: '01911000003', address: 'Savar, Dhaka' });
}

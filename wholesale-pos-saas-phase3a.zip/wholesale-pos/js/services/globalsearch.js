/**
 * globalsearch.js — one search box for everything (products, customers,
 * invoices). Used by the Ctrl/⌘+K palette in the top bar.
 */
import { listProducts } from './catalog.js';
import { listCustomers } from './customers.js';
import { queryInvoices } from './sales.js';

/**
 * @param {string} query
 * @param {{limit?:number, can?:(perm:string)=>boolean}} [o]
 *   `can` hides result types the signed-in user may not open.
 * @returns {Promise<{products:object[], customers:object[], invoices:object[]}>}
 */
export async function globalSearch(query, { limit = 6, can = () => true } = {}) {
  if (!String(query || '').trim()) return { products: [], customers: [], invoices: [] };
  const [products, customers, invoices] = await Promise.all([
    can('products.view') ? listProducts({ search: query }) : [],
    can('customers') ? listCustomers({ search: query }) : [],
    can('invoices') ? queryInvoices({ search: query, limit }).then((r) => r.rows) : [],
  ]);
  return { products: products.slice(0, limit), customers: customers.slice(0, limit), invoices };
}

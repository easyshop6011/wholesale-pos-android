/**
 * guard.js — authorization INSIDE the service layer.
 *
 * Hiding a button is not security: any bug, browser console or second tab can call
 * a service function directly. So every sensitive service function starts with
 *
 *     const actor = authorize('invoices.void');
 *
 * which throws a PermissionError unless a user is signed in (and NOT on the PIN
 * lock screen) and holds that permission. The returned actor — not a `user`
 * argument supplied by the caller — is who gets recorded as the author of the change.
 *
 * LIMIT (see docs/SECURITY.md): the app has no server. Everything runs in the
 * user's own browser, so someone who can open developer tools on an UNLOCKED device
 * can still edit IndexedDB directly. These checks stop mistakes, other users of the
 * app, and UI bypasses — they cannot stop an attacker with full control of the device.
 *
 * auth.js registers the session through `setSessionProvider` (kept here so this file
 * has no dependency on auth.js and cannot create an import cycle).
 */
import { PermissionError } from '../core/errors.js';
import { userCan, permLabel } from './permissions.js';
import { logAction } from './audit.js';

let provider = () => null;

/** auth.js tells the guard how to find the signed-in, unlocked user. */
export function setSessionProvider(fn) {
  provider = fn;
}

/** The signed-in (unlocked) user record, or null. */
export const currentActor = () => provider();

/** Record a denied attempt in the activity log (never throws). */
function denied(actor, perm, why) {
  logAction('security.denied', { target: perm, detail: why, actor: actor ? { id: actor.id, displayName: actor.displayName } : null });
}

/**
 * Require a signed-in user holding `perm`.
 * @param {string} perm  a key from PERMISSION_LIST
 * @returns {object} the acting user
 * @throws {PermissionError}
 */
export function authorize(perm) {
  const actor = provider();
  if (!actor) {
    denied(null, perm, 'not signed in');
    throw new PermissionError('Please sign in to continue.');
  }
  if (!userCan(actor, perm)) {
    denied(actor, perm, 'permission missing');
    throw new PermissionError(`You are not allowed to do this (needs: ${permLabel(perm)}).`);
  }
  return actor;
}

/** Require a signed-in user holding AT LEAST ONE of `perms` (e.g. someone who can sell may also read the invoice they just made). */
export function authorizeAny(perms) {
  const actor = provider();
  if (!actor) {
    denied(null, perms.join('|'), 'not signed in');
    throw new PermissionError('Please sign in to continue.');
  }
  if (!perms.some((p) => userCan(actor, p))) {
    denied(actor, perms.join('|'), 'permission missing');
    throw new PermissionError(`You are not allowed to do this (needs: ${perms.map(permLabel).join(' or ')}).`);
  }
  return actor;
}

/** Require a signed-in Administrator (user and role management). */
export function authorizeAdmin() {
  const actor = provider();
  if (!actor) {
    denied(null, 'admin', 'not signed in');
    throw new PermissionError('Please sign in to continue.');
  }
  if (actor.role !== 'admin') {
    denied(actor, 'admin', 'not an administrator');
    throw new PermissionError('Only an administrator can do this.');
  }
  return actor;
}

/** Attribution fields written onto records. */
export const who = (actor) => ({ userId: actor?.id || null, userName: actor?.displayName || actor?.username || '' });

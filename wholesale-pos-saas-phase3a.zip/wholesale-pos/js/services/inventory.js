/**
 * inventory.js — manual stock changes and the stock history ("movement log").
 *
 * Stock is reduced automatically by sales.createInvoice and restored by
 * sales.voidInvoice / returns.returnSale; this module covers what a person does by
 * hand — receive a delivery, correct a count, write off damaged goods — and the
 * reading side: filtering, exporting and CHECKING the history.
 *
 * Every change goes through stockledger.recordMovement, so each one leaves an
 * append-only history row (before / change / after / time / user / reason / reference).
 * History rows are never edited or deleted; a mistake is corrected with a NEW row.
 */
import { dbAll, dbGet, run, between } from '../core/db.js';
import { toCSV } from '../core/utils.js';
import { parseQty, parseMoney, round3 } from '../core/money.js';
import { ValidationError, DuplicateOperationError } from '../core/errors.js';
import { csvDhakaStamp } from '../core/datetime.js';
import { upgradeMovement } from '../core/upgrade.js';
import { bus } from '../core/bus.js';
import { logAction } from './audit.js';
import { authorize, currentActor } from './guard.js';
import { userCan } from './permissions.js';
import { recordMovement, MOVEMENT_TYPES, checkProductLedger } from './stockledger.js';
import { terms, rank } from '../core/search.js';

export { MOVEMENT_TYPES };

const opKeyOf = (kind, requestId) => (requestId ? `${kind}:${String(requestId).slice(0, 80)}` : '');

/** Run one manual stock operation; a repeated `requestId` returns the first result instead of moving stock twice. */
async function manual({ productId, type, change, reason, requestId, unitCost = null, supplier = '', batchNo = '', patch = {} }) {
  const actor = authorize('inventory.adjust');
  const opKey = opKeyOf(type, requestId);
  const result = await run(['products', 'stockMovements'], 'readwrite', async (tx) => {
    if (opKey) {
      const done = await tx.getByIndex('stockMovements', 'opKey', opKey);
      if (done) return { duplicate: true, productId, balance: done.balance, delta: done.qty, name: done.productName, movement: done };
    }
    const p = await tx.get('products', productId);
    if (!p) throw new ValidationError('Product not found.');
    const { movement, product } = await recordMovement(tx, { product: p, type, qty: change(p), reason, actor, unitCost, supplier, batchNo, opKey, patch });
    return { duplicate: false, productId, balance: product.stock, delta: movement.qty, name: product.name, movement };
  });
  if (!result.duplicate) {
    bus.emit('data:changed', { store: 'products' });
    await logAction(type === 'receive' ? 'stock.receive' : type === 'damage' ? 'stock.damage' : 'stock.adjust', {
      target: result.name || productId,
      detail: `${result.delta > 0 ? '+' : ''}${result.delta} → ${result.balance}${result.movement.reason ? ` (${result.movement.reason})` : ''}`,
      actor,
    });
  }
  return result;
}

/**
 * Record a delivery / purchase: stock goes UP, with the purchase cost, supplier and
 * batch kept on the history row. Needs `inventory.adjust`.
 * @param {{productId:string, qty:number|string, unitCost?:number|string, supplier?:string, batchNo?:string, note?:string, updateCostPrice?:boolean, requestId?:string}} input
 */
export async function receiveStock({ productId, qty, unitCost = '', supplier = '', batchNo = '', note = '', updateCostPrice = false, requestId = '' }) {
  authorize('inventory.adjust'); // refuse first — before validating (or revealing anything about) the input
  const q = parseQty(qty, 'Quantity received');
  const cost = unitCost === '' || unitCost == null ? null : parseMoney(unitCost, 'Purchase cost');
  return manual({
    productId,
    type: 'receive',
    change: () => q,
    reason: String(note || '').trim() || 'Stock received',
    requestId,
    unitCost: cost,
    supplier,
    batchNo,
    patch: updateCostPrice && cost !== null ? { costPrice: cost } : {},
  });
}

/**
 * Write off damaged / lost / expired goods: stock goes DOWN. Needs `inventory.adjust`.
 * @param {{productId:string, qty:number|string, reason?:string, requestId?:string}} input
 */
export async function writeOffStock({ productId, qty, reason = '', requestId = '' }) {
  authorize('inventory.adjust'); // refuse first — before validating (or revealing anything about) the input
  const q = parseQty(qty, 'Quantity');
  return manual({ productId, type: 'damage', change: () => -q, reason: String(reason || '').trim() || 'Damaged / lost goods', requestId });
}

/**
 * Correct stock after a count. `mode`: 'add' | 'remove' | 'set' (set = the exact counted quantity).
 * Writes a new "Stock correction" row; old rows are never touched. Needs `inventory.adjust`.
 * @param {{productId:string, mode:'add'|'remove'|'set', qty:number|string, reason?:string, requestId?:string}} input
 */
export async function adjustStock({ productId, mode, qty, reason = '', requestId = '' }, _user = null) {
  authorize('inventory.adjust'); // refuse first — before validating (or revealing anything about) the input
  if (!['add', 'remove', 'set'].includes(mode)) throw new ValidationError('Choose how to adjust the stock.');
  const q = parseQty(qty, mode === 'set' ? 'Counted stock' : 'Quantity', { allowZero: mode === 'set' });
  const why = String(reason || '').trim() || (mode === 'set' ? 'Stock count' : 'Manual adjustment');
  // 'set' to the value already in stock changes nothing, so it writes no row.
  if (mode === 'set') {
    const p = await dbGet('products', productId);
    if (!p) throw new ValidationError('Product not found.');
    if (round3(p.stock) === round3(q)) return { duplicate: false, unchanged: true, productId, balance: p.stock, delta: 0, name: p.name };
  }
  return manual({ productId, type: 'adjustment', change: (p) => (mode === 'add' ? q : mode === 'remove' ? -q : round3(q - p.stock)), reason: why, requestId });
}

// ---- reading the history ---------------------------------------------------------

/** Hide the purchase cost from people who may not see cost figures. */
function present(rows) {
  const actor = currentActor();
  const seeCost = !!actor && userCan(actor, 'reports.profit');
  return rows.map((r) => {
    const m = upgradeMovement(r);
    return seeCost ? m : { ...m, unitCost: null };
  });
}

/**
 * Stock history, NEWEST FIRST, filtered and paged. Needs `inventory.view`.
 * @param {{from?:string,to?:string,productId?:string,type?:string,userId?:string,search?:string,limit?:number,offset?:number}} [f]
 *   `from` / `to` are Asia/Dhaka calendar days (YYYY-MM-DD).
 * @returns {Promise<{rows:object[], total:number, unitsIn:number, unitsOut:number}>}
 */
export async function queryMovements({ from, to, productId, type = '', userId = '', search = '', limit = 200, offset = 0 } = {}) {
  authorize('inventory.view');
  let rows = await run(['stockMovements'], 'readonly', (tx) => {
    if (productId) return tx.getAllByIndex('stockMovements', 'productId', productId);
    if (from && to) return tx.getAllByIndex('stockMovements', 'date', between(from, to));
    return tx.getAll('stockMovements');
  });
  rows = present(rows).filter((m) => (!from || m.date >= from) && (!to || m.date <= to) && (!type || m.type === type) && (!userId || m.userId === userId));
  if (terms(search).length) {
    const ranked = rank(rows, search, (m) => [m.productName, m.productCode || '', m.refNo || '', m.reason || '', m.userName || '', m.supplier || '', m.batchNo || '']);
    rows = ranked.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } else rows.sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id));
  const sum = (arr) => round3(arr.reduce((a, m) => a + m.qty, 0));
  return { rows: rows.slice(offset, offset + limit), total: rows.length, unitsIn: sum(rows.filter((m) => m.qty > 0)), unitsOut: round3(-sum(rows.filter((m) => m.qty < 0))) };
}

/**
 * Simple form kept for older callers: newest-first rows, optionally for one product.
 * @param {{productId?:string, limit?:number}} [opts]
 */
export async function listMovements({ productId, limit = 300 } = {}) {
  return (await queryMovements({ productId, limit })).rows;
}

/**
 * One product's whole history plus an honest statement of what is and is not known.
 * `untracked` is stock that existed before the first recorded movement (products
 * created before stock history was added): it is reported, never invented.
 */
export async function productHistory(productId) {
  authorize('inventory.view');
  const { product, rows } = await run(['products', 'stockMovements'], 'readonly', async (tx) => ({
    product: await tx.get('products', productId),
    rows: await tx.getAllByIndex('stockMovements', 'productId', productId),
  }));
  if (!product) throw new ValidationError('Product not found.');
  const moves = present(rows).sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id));
  return { product, movements: moves, check: checkProductLedger(product, moves) };
}

/**
 * Audit every product: does the recorded history add up to the stock on hand?
 * Needs `inventory.view`.
 * @returns {Promise<{checked:number, ok:number, problems:object[], untracked:object[]}>}
 */
export async function verifyStockLedger() {
  authorize('inventory.view');
  const { products, moves } = await run(['products', 'stockMovements'], 'readonly', async (tx) => ({ products: await tx.getAll('products'), moves: await tx.getAll('stockMovements') }));
  const by = new Map();
  for (const m of moves) (by.get(m.productId) || by.set(m.productId, []).get(m.productId)).push(upgradeMovement(m));
  const out = { checked: products.length, ok: 0, problems: [], untracked: [] };
  for (const p of products) {
    const res = checkProductLedger(p, by.get(p.id) || []);
    if (res.ok) out.ok += 1;
    else out.problems.push({ productId: p.id, name: p.name, problems: res.problems });
    if (res.untracked) out.untracked.push({ productId: p.id, name: p.name, untracked: res.untracked });
  }
  return out;
}

/** Active products at or below their low-stock level. */
export async function lowStockProducts() {
  return (await dbAll('products')).filter((p) => p.active && p.stock <= p.lowStockLevel).sort((a, b) => a.stock - b.stock);
}

/**
 * CSV text of history rows (UTF-8; the caller adds a BOM when saving so Excel reads
 * Bengali product names correctly). Times are Asia/Dhaka.
 * @param {object[]} rows
 * @param {{cost?:boolean}} [o]  include the purchase-cost column
 */
export function movementsToCSV(rows, { cost = false } = {}) {
  const head = ['Date & time (Asia/Dhaka)', 'Product ID', 'Product code', 'Product', 'Type', 'Previous stock', 'Change', 'New stock', 'Reason / note', 'Reference', 'User', ...(cost ? ['Purchase cost', 'Supplier', 'Batch'] : [])];
  const body = rows.map((m) => [csvDhakaStamp(m.createdAt), m.productId, m.productCode || '', m.productName, MOVEMENT_TYPES[m.type]?.label || m.type, m.previousStock ?? '', m.qty, m.balance, m.reason || '', m.refNo || '', m.userName || '', ...(cost ? [m.unitCost ?? '', m.supplier || '', m.batchNo || ''] : [])]);
  return toCSV([head, ...body]);
}

/**
 * payment-methods.js — how a customer paid. Stored as the short `id` on invoices
 * (`paymentMethod`, for the amount paid at the counter) and on later payments
 * (`method`). Shown with `methodLabel`.
 */
export const PAYMENT_METHODS = [
  { id: 'cash', label: 'Cash' },
  { id: 'bkash', label: 'bKash' },
  { id: 'nagad', label: 'Nagad' },
  { id: 'rocket', label: 'Rocket' },
  { id: 'bank', label: 'Bank transfer' },
  { id: 'card', label: 'Card' },
  { id: 'cheque', label: 'Cheque' },
  { id: 'other', label: 'Other' },
];

/** Label for a stored id; unknown / old records show "—" (the method was never recorded). */
export const methodLabel = (id) => (id ? PAYMENT_METHODS.find((m) => m.id === id)?.label || String(id) : '—');

/** A valid method id (defaults to cash). */
export function normalizeMethod(id) {
  const v = String(id || 'cash').toLowerCase();
  return PAYMENT_METHODS.some((m) => m.id === v) ? v : 'cash';
}

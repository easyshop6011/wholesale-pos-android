/**
 * permissions.js — the permission catalogue, the three roles and the pure
 * functions that answer "may this user do X?". No database, no DOM, so the whole
 * permission matrix is unit-tested in Node.
 *
 * Roles: "admin" (everything), "manager" (sell + stock + reports, no settings /
 * users) and "employee" = Cashier (sell, customers, view stock). Any non-admin
 * user can also carry a custom permission list that replaces the role defaults.
 *
 * To add a permission: add it to PERMISSION_LIST, give it to the roles below that
 * should have it, guard the service function with `authorize('key')` (guard.js)
 * AND hide the UI control with `auth.can('key')`.
 */

export const PERMISSION_LIST = [
  { key: 'dashboard', label: 'See the dashboard', group: 'Sales' },
  { key: 'pos', label: 'Make sales (New Sale)', group: 'Sales' },
  { key: 'invoices', label: 'View and re-print invoices', group: 'Sales' },
  { key: 'invoices.void', label: 'Void invoices', group: 'Sales' },
  { key: 'invoices.return', label: 'Take back goods (sales returns)', group: 'Sales' },
  { key: 'customers', label: 'Add / edit customers, receive payments, see customer history', group: 'Customers' },
  { key: 'customers.delete', label: 'Delete customers', group: 'Customers' },
  { key: 'products.view', label: 'View products', group: 'Stock' },
  { key: 'products.edit', label: 'Add / edit / delete products', group: 'Stock' },
  { key: 'inventory.view', label: 'View inventory and stock history', group: 'Stock' },
  { key: 'inventory.adjust', label: 'Receive, adjust and write off stock', group: 'Stock' },
  { key: 'reports', label: 'See reports', group: 'Management' },
  { key: 'reports.profit', label: 'See cost and profit figures', group: 'Management' },
  { key: 'audit', label: 'See the activity log', group: 'Management' },
  { key: 'printer', label: 'Printer settings', group: 'Management' },
  { key: 'settings', label: 'Business, sync and backup settings', group: 'Administration' },
];

/** Roles and their default permissions. `employee` is shown as "Cashier" (id kept for old data). */
export const ROLES = {
  admin: { label: 'Administrator', permissions: ['*'] },
  manager: {
    label: 'Manager',
    permissions: ['dashboard', 'pos', 'invoices', 'invoices.void', 'invoices.return', 'customers', 'products.view', 'products.edit', 'inventory.view', 'inventory.adjust', 'reports', 'reports.profit', 'audit', 'printer'],
  },
  employee: { label: 'Cashier', permissions: ['dashboard', 'pos', 'invoices', 'customers', 'products.view', 'inventory.view', 'printer'] },
};

/** Backwards-compatible map role -> permission list. */
export const PERMISSIONS = Object.fromEntries(Object.entries(ROLES).map(([k, v]) => [k, v.permissions]));

/** Keep only known permission keys (no duplicates). */
export const cleanPerms = (list) => [...new Set((list || []).filter((k) => PERMISSION_LIST.some((p) => p.key === k)))];

/** The permissions a user effectively has: admin = all; otherwise the custom list if set, else the role's. */
export function effectivePermissions(user) {
  if (!user) return [];
  if (user.role === 'admin') return ['*'];
  return Array.isArray(user.permissions) ? user.permissions : PERMISSIONS[user.role] || [];
}

/** May `user` do `perm`? (Pure — knows nothing about sessions or locks.) */
export function userCan(user, perm) {
  const list = effectivePermissions(user);
  return list.includes('*') || list.includes(perm);
}

/** Human label of a permission key (for error messages). */
export const permLabel = (perm) => PERMISSION_LIST.find((p) => p.key === perm)?.label || perm;

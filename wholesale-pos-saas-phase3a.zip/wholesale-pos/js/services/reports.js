/**
 * reports.js — dashboard figures and all reports. Every function is read-only
 * and returns plain data so views can render it and export it to CSV.
 *
 * Definitions:
 *   Sales          = Σ invoice.total (after discount) of ACTIVE invoices
 *   Cash collected = Σ invoice.paid + Σ payments received that day
 *   Total due      = Σ max(0, customer balance)  (see customers.js)
 *
 * SALES RETURNS (returns.js): `Sales` above stays the value INVOICED. Returned goods are
 * reported next to it — `returnsValue` / `netAfterReturns` in the daily and monthly
 * reports and the dashboard — and are subtracted in the profit report, the product
 * sales report and cash collected. The other analytics (trend, top customers, category
 * share, staff, busy hours) show invoiced sales and do not deduct returns.
 */
import { dbAll, run, between } from '../core/db.js';
import { round2, sum, dateParts, addDays, monthRange } from '../core/utils.js';
import { lineTotal } from '../core/money.js';
import { allBalances } from './customers.js';
import { cached } from '../core/cache.js';
import { authorize, authorizeAny, currentActor } from './guard.js';
import { userCan } from './permissions.js';

const active = (rows) => rows.filter((i) => i.status !== 'void');

/**
 * Top-selling products among the given invoices (voided ones must already be removed).
 * @param {object} tx  an open transaction that includes `invoiceItems`
 * @param {object[]} invs
 * @param {number} limit
 */
async function topProductsOf(tx, invs, limit) {
  const map = new Map();
  for (const inv of invs) {
    for (const it of await tx.getAllByIndex('invoiceItems', 'invoiceId', inv.id)) {
      const r = map.get(it.productId) || { productId: it.productId, name: it.name, unit: it.unit, qty: 0, revenue: 0 };
      r.qty += it.qty;
      r.revenue += it.total;
      map.set(it.productId, r);
    }
  }
  return [...map.values()].map((r) => ({ ...r, qty: Math.round(r.qty * 1000) / 1000, revenue: round2(r.revenue) })).sort((a, b) => b.revenue - a.revenue).slice(0, limit);
}

/**
 * Headline numbers + small datasets for the dashboard.
 * Extra fields (v2): `last30` (daily sales + invoice counts), `yesterdaySales`,
 * `topToday` / `topMonth` (top-5 products by revenue).
 */
export function dashboard() {
  authorize('dashboard');
  return cached(`dashboard:${dateParts().date}`, computeDashboard);
}

async function computeDashboard() {
  const now = dateParts();
  const days30 = Array.from({ length: 30 }, (_, k) => addDays(now.date, k - 29));
  const week = days30.slice(-7);
  const data = await run(['invoices', 'invoiceItems', 'products', 'customers', 'payments', 'salesReturns'], 'readonly', async (tx) => {
    const returnsToday = await tx.getAllByIndex('salesReturns', 'date', now.date);
    const range30 = await tx.getAllByIndex('invoices', 'date', between(days30[0], now.date));
    const monthInv = await tx.getAllByIndex('invoices', 'month', now.month);
    return {
      returnsToday,
      range30,
      monthInv,
      products: await tx.getAll('products'),
      customers: await tx.count('customers'),
      invPending: await tx.countByIndex('invoices', 'syncStatus', 'pending'),
      payPending: await tx.countByIndex('payments', 'syncStatus', 'pending'),
      recent: (await tx.getLatest('invoices', 'date', 6)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 6),
      topToday: await topProductsOf(tx, active(range30).filter((i) => i.date === now.date), 5),
      topMonth: await topProductsOf(tx, active(monthInv), 5),
    };
  });
  const balances = await allBalances();
  const ok30 = active(data.range30);
  const dayTotal = (d) => sum(ok30.filter((i) => i.date === d).map((i) => i.total));
  const todayInv = ok30.filter((i) => i.date === now.date);
  const products = data.products.filter((p) => p.active);
  const lowStock = products.filter((p) => p.stock <= p.lowStockLevel).sort((a, b) => a.stock - b.stock);
  return {
    todaySales: sum(todayInv.map((i) => i.total)),
    todayCount: todayInv.length,
    todayReturns: sum(data.returnsToday.map((r) => r.amount)),
    yesterdaySales: dayTotal(days30[28]),
    monthSales: sum(active(data.monthInv).map((i) => i.total)),
    totalDue: round2([...balances.values()].filter((v) => v > 0).reduce((a, b) => a + b, 0)),
    totalCustomers: data.customers,
    totalProducts: products.length,
    lowStock,
    unsynced: data.invPending + data.payPending,
    last7: week.map((d) => ({ date: d, sales: dayTotal(d) })),
    last30: days30.map((d) => ({ date: d, sales: dayTotal(d), invoices: ok30.filter((i) => i.date === d).length })),
    topToday: data.topToday,
    topMonth: data.topMonth,
    recent: data.recent,
  };
}

/** One day's sales summary and invoice list (returns are shown next to sales, see the file header). */
export async function dailyReport(date) {
  authorizeAny(['reports', 'invoices']);
  const { invs, pays, rets } = await run(['invoices', 'payments', 'salesReturns'], 'readonly', async (tx) => ({
    invs: await tx.getAllByIndex('invoices', 'date', date),
    pays: await tx.getAllByIndex('payments', 'date', date),
    rets: await tx.getAllByIndex('salesReturns', 'date', date),
  }));
  const ok = active(invs);
  const summary = {
    invoices: ok.length,
    voided: invs.length - ok.length,
    grossSales: sum(ok.map((i) => i.subtotal)),
    discount: sum(ok.map((i) => i.discount)),
    netSales: sum(ok.map((i) => i.total)),
    paidAtSale: sum(ok.map((i) => i.paid)),
    dueCreated: sum(ok.map((i) => i.due)),
    paymentsReceived: sum(pays.map((p) => p.amount)),
    returnsCount: rets.length,
    returnsValue: sum(rets.map((r) => r.amount)),
    refunds: sum(rets.map((r) => r.refund)),
  };
  summary.netAfterReturns = round2(summary.netSales - summary.returnsValue);
  summary.cashCollected = round2(summary.paidAtSale + summary.paymentsReceived - summary.refunds);
  return { date, summary, invoices: invs.sort((a, b) => a.createdAt.localeCompare(b.createdAt)), payments: pays, returns: rets.sort((a, b) => a.createdAt.localeCompare(b.createdAt)) };
}

/** Per-day breakdown for a month (YYYY-MM) plus totals. */
export async function monthlyReport(month) {
  authorizeAny(['reports', 'invoices']);
  const { from, to } = monthRange(month);
  const { invs, pays, rets } = await run(['invoices', 'payments', 'salesReturns'], 'readonly', async (tx) => ({
    invs: await tx.getAllByIndex('invoices', 'month', month),
    pays: await tx.getAllByIndex('payments', 'date', between(from, to)),
    rets: await tx.getAllByIndex('salesReturns', 'date', between(from, to)),
  }));
  const days = new Map();
  const row = (d) => {
    if (!days.has(d)) days.set(d, { date: d, invoices: 0, sales: 0, discount: 0, paid: 0, due: 0, paymentsReceived: 0, returnsValue: 0 });
    return days.get(d);
  };
  for (const i of active(invs)) {
    const r = row(i.date);
    r.invoices += 1;
    r.sales += i.total;
    r.discount += i.discount;
    r.paid += i.paid;
    r.due += i.due;
  }
  for (const p of pays) row(p.date).paymentsReceived += p.amount;
  for (const r of rets) row(r.date).returnsValue += r.amount;
  const rows = [...days.values()].map((r) => ({ ...r, sales: round2(r.sales), discount: round2(r.discount), paid: round2(r.paid), due: round2(r.due), paymentsReceived: round2(r.paymentsReceived), returnsValue: round2(r.returnsValue) })).sort((a, b) => a.date.localeCompare(b.date));
  const totals = rows.reduce((t, r) => ({ invoices: t.invoices + r.invoices, sales: round2(t.sales + r.sales), discount: round2(t.discount + r.discount), paid: round2(t.paid + r.paid), due: round2(t.due + r.due), paymentsReceived: round2(t.paymentsReceived + r.paymentsReceived), returnsValue: round2(t.returnsValue + r.returnsValue) }), { invoices: 0, sales: 0, discount: 0, paid: 0, due: 0, paymentsReceived: 0, returnsValue: 0 });
  return { month, rows, totals };
}

/** Customers who owe money, largest first. */
export async function customerDueReport() {
  authorizeAny(['reports', 'customers']);
  const [customers, balances, invs] = await Promise.all([dbAll('customers'), allBalances(), dbAll('invoices')]);
  const lastBuy = new Map();
  for (const i of invs) if (i.customerId && i.status !== 'void' && i.date > (lastBuy.get(i.customerId) || '')) lastBuy.set(i.customerId, i.date);
  const rows = customers
    .map((c) => ({ id: c.id, name: c.name, phone: c.phone, due: balances.get(c.id) || 0, lastPurchase: lastBuy.get(c.id) || '' }))
    .filter((r) => r.due > 0)
    .sort((a, b) => b.due - a.due);
  return { rows, total: sum(rows.map((r) => r.due)) };
}

/** Quantity / revenue (and profit where cost is known) per product in a date range, net of goods returned in the same range. */
export async function productSalesReport({ from, to }) {
  authorize('reports');
  const { invs, items, rets, lineOf } = await run(['invoices', 'invoiceItems', 'salesReturns'], 'readonly', async (tx) => {
    const rets = await tx.getAllByIndex('salesReturns', 'date', between(from, to));
    const items = await tx.getAll('invoiceItems');
    return { invs: await tx.getAllByIndex('invoices', 'date', between(from, to)), items, rets, lineOf: new Map(items.map((i) => [i.id, i])) };
  });
  const ids = new Set(active(invs).map((i) => i.id));
  const map = new Map();
  const row = (it) => map.get(it.productId) || { productId: it.productId, name: it.name, unit: it.unit, qty: 0, revenue: 0, cost: 0, invoices: new Set() };
  for (const it of items) {
    if (!ids.has(it.invoiceId)) continue;
    const r = row(it);
    r.qty += it.qty;
    r.revenue += it.total;
    r.cost += (it.costPrice || 0) * it.qty;
    r.invoices.add(it.invoiceId);
    map.set(it.productId, r);
  }
  for (const ret of rets) {
    for (const x of ret.items) {
      const orig = lineOf.get(x.itemId);
      const r = row({ productId: x.productId, name: x.name, unit: x.unit });
      r.qty -= x.qty;
      r.revenue -= lineTotal(x.qty, x.unitPrice);
      r.cost -= (orig?.costPrice || 0) * x.qty;
      map.set(x.productId, r);
    }
  }
  const rows = [...map.values()]
    .map((r) => ({ productId: r.productId, name: r.name, unit: r.unit, qty: Math.round(r.qty * 1000) / 1000, revenue: round2(r.revenue), avgPrice: r.qty ? round2(r.revenue / r.qty) : 0, profit: round2(r.revenue - r.cost), invoices: r.invoices.size }))
    .sort((a, b) => b.revenue - a.revenue);
  return { from, to, rows, totals: { qty: rows.reduce((a, r) => a + r.qty, 0), revenue: sum(rows.map((r) => r.revenue)), profit: sum(rows.map((r) => r.profit)) } };
}

/** Current stock with cost/retail valuation and status. */
export async function inventoryReport() {
  authorizeAny(['reports', 'inventory.view']);
  const [products, cats] = await Promise.all([dbAll('products'), dbAll('categories')]);
  const catName = new Map(cats.map((c) => [c.id, c.name]));
  const rows = products
    .filter((p) => p.active)
    .map((p) => ({
      id: p.id,
      name: p.name,
      sku: p.sku,
      category: catName.get(p.categoryId) || 'Uncategorized',
      unit: p.unit,
      stock: p.stock,
      lowStockLevel: p.lowStockLevel,
      costValue: round2(p.stock * (p.costPrice || 0)),
      retailValue: round2(p.stock * (p.defaultPrice || 0)),
      status: p.stock <= 0 ? 'Out of stock' : p.stock <= p.lowStockLevel ? 'Low' : 'OK',
    }))
    .sort((a, b) => a.name.localeCompare(b.name));
  return { rows, totals: { items: rows.length, costValue: sum(rows.map((r) => r.costValue)), retailValue: sum(rows.map((r) => r.retailValue)), low: rows.filter((r) => r.status !== 'OK').length } };
}


// =============================================================================
// v2 analytics — all read-only, voided invoices are always excluded.
// =============================================================================

const pad2 = (n) => String(n).padStart(2, '0');

/** Monday (YYYY-MM-DD) of the week containing `date`. */
function weekStart(date) {
  const [y, m, d] = date.split('-').map(Number);
  const dow = (new Date(y, m - 1, d).getDay() + 6) % 7; // Mon = 0
  return addDays(date, -dow);
}

/** Bucket key of a date for a granularity. */
const bucketKey = (date, g) => (g === 'month' ? date.slice(0, 7) : g === 'week' ? weekStart(date) : date);

/** All bucket keys between two dates (inclusive), in order. */
function bucketKeys(from, to, g) {
  const keys = [];
  if (g === 'month') {
    let [y, m] = from.slice(0, 7).split('-').map(Number);
    const [ey, em] = to.slice(0, 7).split('-').map(Number);
    while (y < ey || (y === ey && m <= em)) {
      keys.push(`${y}-${pad2(m)}`);
      m += 1;
      if (m > 12) [y, m] = [y + 1, 1];
    }
    return keys;
  }
  for (let d = g === 'week' ? weekStart(from) : from; d <= to; d = addDays(d, g === 'week' ? 7 : 1)) keys.push(d);
  return keys;
}

/** Load invoices (all + active) and payments for an inclusive date range. */
async function loadRange(from, to, withItems = false) {
  return run(['invoices', 'payments', 'invoiceItems'], 'readonly', async (tx) => {
    const invs = await tx.getAllByIndex('invoices', 'date', between(from, to));
    const pays = await tx.getAllByIndex('payments', 'date', between(from, to));
    const ok = active(invs);
    let items = [];
    if (withItems) for (const inv of ok) for (const it of await tx.getAllByIndex('invoiceItems', 'invoiceId', inv.id)) items.push({ it, inv });
    else items = null;
    return { invs, ok, pays, items };
  });
}

/**
 * Sales per day / week (Mon-based) / month with EMPTY BUCKETS FILLED WITH ZEROS,
 * so charts have a continuous axis.
 * @param {{from:string,to:string,granularity?:'day'|'week'|'month'}} o
 * @returns {Promise<{granularity:string, buckets:{key:string,from:string,invoices:number,sales:number,discount:number,paid:number,due:number,paymentsReceived:number,cashCollected:number}[], totals:object}>}
 */
export async function salesTrend({ from, to, granularity = 'day' }) {
  authorize('reports');
  const { ok, pays } = await loadRange(from, to);
  const map = new Map(bucketKeys(from, to, granularity).map((k) => [k, { key: k, from: k.length === 7 ? `${k}-01` : k, invoices: 0, sales: 0, discount: 0, paid: 0, due: 0, paymentsReceived: 0 }]));
  for (const i of ok) {
    const b = map.get(bucketKey(i.date, granularity));
    if (!b) continue;
    b.invoices += 1;
    b.sales += i.total;
    b.discount += i.discount;
    b.paid += i.paid;
    b.due += i.due;
  }
  for (const p of pays) {
    const b = map.get(bucketKey(p.date, granularity));
    if (b) b.paymentsReceived += p.amount;
  }
  const buckets = [...map.values()].map((b) => ({ ...b, sales: round2(b.sales), discount: round2(b.discount), paid: round2(b.paid), due: round2(b.due), paymentsReceived: round2(b.paymentsReceived), cashCollected: round2(b.paid + b.paymentsReceived) }));
  const t = (k) => round2(buckets.reduce((a, b) => a + b[k], 0));
  return { granularity, buckets, totals: { invoices: buckets.reduce((a, b) => a + b.invoices, 0), sales: t('sales'), discount: t('discount'), paid: t('paid'), due: t('due'), paymentsReceived: t('paymentsReceived'), cashCollected: t('cashCollected') } };
}

/** Last `months` calendar months (including the current one), zero-filled. */
export async function monthlyTrend(months = 12) {
  const now = dateParts();
  let [y, m] = now.month.split('-').map(Number);
  m -= months - 1;
  while (m < 1) [y, m] = [y - 1, m + 12];
  return salesTrend({ from: `${y}-${pad2(m)}-01`, to: now.date, granularity: 'month' });
}

/**
 * Best customers by sales in a period (walk-in sales are not ranked).
 * @returns {Promise<{rows:{customerId:string,name:string,phone:string,invoices:number,sales:number,paid:number,due:number}[]}>}
 */
export async function topCustomers({ from, to, limit = 10 }) {
  authorize('reports');
  const { ok } = await loadRange(from, to);
  const map = new Map();
  for (const i of ok) {
    if (!i.customerId) continue;
    const r = map.get(i.customerId) || { customerId: i.customerId, name: i.customerName, phone: i.customerPhone, invoices: 0, sales: 0, paid: 0, due: 0 };
    r.invoices += 1;
    r.sales += i.total;
    r.paid += i.paid;
    r.due += i.due;
    map.set(i.customerId, r);
  }
  const rows = [...map.values()].map((r) => ({ ...r, sales: round2(r.sales), paid: round2(r.paid), due: round2(r.due) })).sort((a, b) => b.sales - a.sales).slice(0, limit);
  return { from, to, rows };
}

/**
 * Revenue by product category. Revenue is NET of the invoice discount (each
 * line gets its proportional share), so the rows add up to net sales.
 * @returns {Promise<{rows:{category:string,revenue:number,qty:number,share:number}[], total:number}>}
 */
export async function categoryShare({ from, to }) {
  authorize('reports');
  const [{ items }, products, cats] = await Promise.all([loadRange(from, to, true), dbAll('products'), dbAll('categories')]);
  const catOf = new Map(products.map((p) => [p.id, p.categoryId]));
  const name = new Map(cats.map((c) => [c.id, c.name]));
  const map = new Map();
  for (const { it, inv } of items) {
    const factor = inv.subtotal > 0 ? inv.total / inv.subtotal : 1;
    const cat = name.get(catOf.get(it.productId)) || 'Uncategorized';
    const r = map.get(cat) || { category: cat, revenue: 0, qty: 0 };
    r.revenue += it.total * factor;
    r.qty += it.qty;
    map.set(cat, r);
  }
  const rows = [...map.values()].map((r) => ({ ...r, revenue: round2(r.revenue), qty: Math.round(r.qty * 1000) / 1000 })).sort((a, b) => b.revenue - a.revenue);
  const total = sum(rows.map((r) => r.revenue));
  return { from, to, rows: rows.map((r) => ({ ...r, share: total ? round2((r.revenue / total) * 100) : 0 })), total };
}

/**
 * Gross-profit report. Uses the cost price saved on each invoice line at sale
 * time. The invoice discount is spread over its lines in proportion to their
 * value, so `revenue` is net of discounts: revenue − cost = profit.
 * `missingCostLines` counts lines sold with cost price 0 (profit is overstated for them).
 */
export async function profitReport({ from, to }) {
  authorize('reports.profit');
  const { ok, items } = await loadRange(from, to, true);
  const rets = await run(['salesReturns', 'invoiceItems'], 'readonly', async (tx) => {
    const list = await tx.getAllByIndex('salesReturns', 'date', between(from, to));
    const out = [];
    for (const r of list) for (const x of r.items) out.push({ r, x, orig: await tx.get('invoiceItems', x.itemId) });
    return out;
  });
  const prod = new Map();
  const day = new Map();
  let gross = 0;
  let revenue = 0;
  let cost = 0;
  let missing = 0;
  for (const { it, inv } of items) {
    const factor = inv.subtotal > 0 ? inv.total / inv.subtotal : 1;
    const rev = it.total * factor;
    const c = (it.costPrice || 0) * it.qty;
    if (!(it.costPrice > 0)) missing += 1;
    gross += it.total;
    revenue += rev;
    cost += c;
    const p = prod.get(it.productId) || { productId: it.productId, name: it.name, unit: it.unit, qty: 0, revenue: 0, cost: 0 };
    p.qty += it.qty;
    p.revenue += rev;
    p.cost += c;
    prod.set(it.productId, p);
    const d = day.get(inv.date) || { date: inv.date, revenue: 0, cost: 0 };
    d.revenue += rev;
    d.cost += c;
    day.set(inv.date, d);
  }
  // goods taken back in the period: revenue (net of the invoice discount) and cost go DOWN
  for (const { r, x, orig } of rets) {
    const c = (orig?.costPrice || 0) * x.qty;
    revenue -= x.amount;
    cost -= c;
    const p = prod.get(x.productId) || { productId: x.productId, name: x.name, unit: x.unit, qty: 0, revenue: 0, cost: 0 };
    p.qty -= x.qty;
    p.revenue -= x.amount;
    p.cost -= c;
    prod.set(x.productId, p);
    const d = day.get(r.date) || { date: r.date, revenue: 0, cost: 0 };
    d.revenue -= x.amount;
    d.cost -= c;
    day.set(r.date, d);
  }
  const fin = (r) => ({ ...r, revenue: round2(r.revenue), cost: round2(r.cost), profit: round2(r.revenue - r.cost), margin: r.revenue ? round2(((r.revenue - r.cost) / r.revenue) * 100) : 0 });
  const discount = sum(ok.map((i) => i.discount));
  const totals = fin({ revenue, cost });
  return {
    from,
    to,
    totals: { ...totals, grossSales: round2(gross), discount, discountPct: gross ? round2((discount / gross) * 100) : 0, missingCostLines: missing, lines: items.length },
    byProduct: [...prod.values()].map((r) => ({ ...fin(r), qty: Math.round(r.qty * 1000) / 1000 })).sort((a, b) => b.profit - a.profit),
    byDay: bucketKeys(from, to, 'day').map((d) => fin(day.get(d) || { date: d, revenue: 0, cost: 0 })),
  };
}

/**
 * Sales per user (who created the invoice), best first.
 * `voided` counts that user's voided invoices (not part of sales).
 */
export async function salesByUser({ from, to }) {
  authorize('reports');
  const { invs } = await loadRange(from, to);
  const map = new Map();
  for (const i of invs) {
    const key = i.createdBy || i.createdByName || 'unknown';
    const r = map.get(key) || { userId: i.createdBy || null, name: i.createdByName || 'Unknown', invoices: 0, sales: 0, discount: 0, paid: 0, due: 0, voided: 0 };
    if (i.status === 'void') r.voided += 1;
    else {
      r.invoices += 1;
      r.sales += i.total;
      r.discount += i.discount;
      r.paid += i.paid;
      r.due += i.due;
    }
    map.set(key, r);
  }
  const rows = [...map.values()].map((r) => ({ ...r, sales: round2(r.sales), discount: round2(r.discount), paid: round2(r.paid), due: round2(r.due), avgInvoice: r.invoices ? round2(r.sales / r.invoices) : 0 })).sort((a, b) => b.sales - a.sales);
  return { from, to, rows, totals: { invoices: rows.reduce((a, r) => a + r.invoices, 0), sales: sum(rows.map((r) => r.sales)) } };
}

/**
 * Cash picture for a period: money received at the counter vs. credit given
 * vs. old dues collected.
 */
export async function paymentMix({ from, to }) {
  authorize('reports');
  const { ok, pays } = await loadRange(from, to);
  const rets = await run(['salesReturns'], 'readonly', (tx) => tx.getAllByIndex('salesReturns', 'date', between(from, to)));
  const paidAtSale = sum(ok.map((i) => i.paid));
  const duesCollected = sum(pays.map((p) => p.amount));
  const dueCreated = sum(ok.map((i) => i.due));
  const refunds = sum(rets.map((r) => r.refund));
  return { from, to, paidAtSale, duesCollected, dueCreated, refunds, cashCollected: round2(paidAtSale + duesCollected - refunds), netDueChange: round2(dueCreated - duesCollected - sum(rets.map((r) => r.creditApplied))) };
}

/** Sales by hour of day (24 buckets, zero-filled) — shows the shop's busy hours. */
export async function hourlySales({ from, to }) {
  authorize('reports');
  const { ok } = await loadRange(from, to);
  const hours = Array.from({ length: 24 }, (_, hour) => ({ hour, invoices: 0, sales: 0 }));
  for (const i of ok) {
    const b = hours[Number(String(i.time).slice(0, 2)) || 0];
    b.invoices += 1;
    b.sales += i.total;
  }
  return { from, to, hours: hours.map((h) => ({ ...h, sales: round2(h.sales) })) };
}

/**
 * KPI summary of a period, used by the Overview tab (and for the
 * "vs previous period" comparison).
 */
export async function periodSummary({ from, to }) {
  authorize('reports');
  const seeProfit = !!currentActor() && userCan(currentActor(), 'reports.profit');
  const [t, mix, pr] = await Promise.all([salesTrend({ from, to, granularity: 'month' }), paymentMix({ from, to }), seeProfit ? profitReport({ from, to }) : Promise.resolve({ totals: { profit: 0, margin: 0 } })]);
  const sales = t.totals.sales;
  const invoices = t.totals.invoices;
  return { from, to, sales, invoices, avgInvoice: invoices ? round2(sales / invoices) : 0, discount: t.totals.discount, profit: pr.totals.profit, margin: pr.totals.margin, cashCollected: mix.cashCollected, duesCollected: mix.duesCollected, dueCreated: mix.dueCreated };
}


// =============================================================================
// v3 — receivables ageing and reorder suggestions
// =============================================================================

/** Whole days between two YYYY-MM-DD dates (b − a). */
function daysBetween(a, b) {
  const [y1, m1, d1] = a.split('-').map(Number);
  const [y2, m2, d2] = b.split('-').map(Number);
  return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / 86400000);
}

export const AGE_BUCKETS = [
  { key: 'd0', label: '0–30 days', max: 30 },
  { key: 'd31', label: '31–60 days', max: 60 },
  { key: 'd61', label: '61–90 days', max: 90 },
  { key: 'd90', label: 'Over 90 days', max: Infinity },
];

/**
 * Receivables ageing: how old is the money customers owe?
 * Payments are applied to the OLDEST unpaid invoices first (FIFO), the usual way
 * a shopkeeper thinks about "which bill is still open". What remains of each
 * invoice is placed in an age bucket by invoice date.
 * @param {{today?:string}} [o]
 * @returns {Promise<{rows:{id:string,name:string,phone:string,total:number,oldestDays:number,d0:number,d31:number,d61:number,d90:number}[], totals:Record<string,number>}>}
 */
export async function dueAging({ today = dateParts().date } = {}) {
  authorize('reports');
  const [customers, invs, pays, rets] = await Promise.all([dbAll('customers'), dbAll('invoices'), dbAll('payments'), dbAll('salesReturns')]);
  const byCust = new Map();
  for (const i of invs) {
    if (!i.customerId || i.status === 'void' || !(i.due > 0)) continue;
    if (!byCust.has(i.customerId)) byCust.set(i.customerId, []);
    byCust.get(i.customerId).push(i);
  }
  const paidBy = new Map();
  for (const p of pays) paidBy.set(p.customerId, (paidBy.get(p.customerId) || 0) + p.amount);
  for (const r of rets) if (r.customerId) paidBy.set(r.customerId, (paidBy.get(r.customerId) || 0) + (r.creditApplied || 0));
  const rows = [];
  for (const c of customers) {
    const list = (byCust.get(c.id) || []).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    let credit = paidBy.get(c.id) || 0;
    const row = { id: c.id, name: c.name, phone: c.phone || '', total: 0, oldestDays: 0, d0: 0, d31: 0, d61: 0, d90: 0 };
    for (const i of list) {
      let open = i.due;
      const used = Math.min(open, credit);
      open -= used;
      credit -= used;
      if (open <= 0.004) continue;
      const age = Math.max(0, daysBetween(i.date, today));
      const bucket = AGE_BUCKETS.find((b) => age <= b.max);
      row[bucket.key] += open;
      row.total += open;
      row.oldestDays = Math.max(row.oldestDays, age);
    }
    if (row.total > 0.004) rows.push({ ...row, total: round2(row.total), d0: round2(row.d0), d31: round2(row.d31), d61: round2(row.d61), d90: round2(row.d90) });
  }
  rows.sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));
  const t = (k) => round2(rows.reduce((a, r) => a + r[k], 0));
  return { rows, totals: { total: t('total'), d0: t('d0'), d31: t('d31'), d61: t('d61'), d90: t('d90') } };
}

/**
 * Which products should be re-ordered soon? Looks at what really sold in the
 * last `days` days: daily rate → how many days the stock will last → how much to
 * buy to cover `coverDays`. Products already at/below their low-stock level are
 * always listed.
 * @param {{days?:number,coverDays?:number,today?:string}} [o]
 */
export async function reorderSuggestions({ days = 30, coverDays = 14, today = dateParts().date } = {}) {
  authorize('reports');
  const from = addDays(today, -(days - 1));
  const [{ ok, items }, products] = await Promise.all([loadRange(from, today, true), dbAll('products')]);
  void ok;
  const sold = new Map();
  for (const { it } of items) sold.set(it.productId, (sold.get(it.productId) || 0) + it.qty);
  const rows = [];
  for (const p of products) {
    if (!p.active) continue;
    const qty = sold.get(p.id) || 0;
    const perDay = qty / days;
    const daysLeft = perDay > 0 ? p.stock / perDay : Infinity;
    const low = p.stock <= p.lowStockLevel;
    if (!(low || daysLeft <= coverDays)) continue;
    rows.push({
      id: p.id,
      name: p.name,
      unit: p.unit,
      stock: p.stock,
      lowStockLevel: p.lowStockLevel,
      soldQty: Math.round(qty * 1000) / 1000,
      perDay: Math.round(perDay * 100) / 100,
      daysLeft: Number.isFinite(daysLeft) ? Math.max(0, Math.round(daysLeft * 10) / 10) : null,
      suggest: Math.max(0, Math.ceil(perDay * coverDays - p.stock)),
      status: p.stock <= 0 ? 'Out of stock' : low ? 'Low' : 'Running out',
    });
  }
  rows.sort((a, b) => (a.daysLeft ?? 1e9) - (b.daysLeft ?? 1e9) || a.name.localeCompare(b.name));
  return { days, coverDays, rows };
}

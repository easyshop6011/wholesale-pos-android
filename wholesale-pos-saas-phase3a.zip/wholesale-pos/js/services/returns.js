/**
 * returns.js — goods a customer brings back (sales returns).
 *
 * A return is its own append-only record (`salesReturns`); the original invoice is
 * never edited. One return, in ONE transaction:
 *
 *   • puts the goods back into stock through the stock history ("Customer return" row
 *     per product, with the return number as reference);
 *   • works out the money value of what came back (the invoice discount is shared out
 *     in proportion, so a fully returned invoice returns exactly what was charged);
 *   • applies that value FIRST to what the customer still owes (`creditApplied`
 *     reduces their due) and hands back the rest in cash (`refund`).
 *
 * Customer balance = Σ due of active invoices − Σ payments − Σ creditApplied.
 * Rules: only an ACTIVE invoice can have returns; you cannot take back more than was
 * sold (counting earlier returns); the same request is never processed twice.
 */
import { run } from '../core/db.js';
import { uuid, dateParts } from '../core/utils.js';
import { ValidationError } from '../core/errors.js';
import { parseQty, round2, round3, sum, lineTotal } from '../core/money.js';
import { settings } from './settings.js';
import { balanceInTx } from './customers.js';
import { bus } from '../core/bus.js';
import { logAction } from './audit.js';
import { authorize, authorizeAny } from './guard.js';
import { recordMovement } from './stockledger.js';
import { normalizeMethod } from './payment-methods.js';

/** RET-[DEVICE-]YYMMDD-NNNN, allocated inside the return's own transaction. */
async function nextReturnNumber(tx, parts, s) {
  const day = parts.date.replace(/-/g, '').slice(2);
  const key = `retseq:${s.deviceCode || ''}:${day}`;
  const row = await tx.get('meta', key);
  const n = (row?.value || 0) + 1;
  await tx.put('meta', { key, value: n });
  return `RET-${s.deviceCode ? `${s.deviceCode}-` : ''}${day}-${String(n).padStart(4, '0')}`;
}

/** Quantity already returned per invoice line (`itemId`) across a list of returns. */
export function returnedQtyByItem(returns) {
  const map = new Map();
  for (const r of returns) for (const it of r.items) map.set(it.itemId, round3((map.get(it.itemId) || 0) + it.qty));
  return map;
}

/**
 * Take goods back. Needs `invoices.return`.
 * @param {{invoiceId:string, items:{itemId:string, qty:number|string}[], reason:string, refundMethod?:string, requestId?:string}} input
 * @returns {Promise<object>} the saved return (`duplicate: true` when this request was already processed)
 */
export async function returnSale({ invoiceId, items, reason, refundMethod = 'cash', requestId = '' }, _user = null) {
  const actor = authorize('invoices.return');
  const why = String(reason || '').trim();
  if (why.length < 3) throw new ValidationError('Enter the reason for the return (at least 3 characters).');
  const asked = (items || []).filter((i) => i && i.itemId && String(i.qty ?? '').trim() !== '').map((i) => ({ itemId: i.itemId, qty: parseQty(i.qty, 'Return quantity') }));
  if (!asked.length) throw new ValidationError('Choose at least one item to take back.');
  const rid = requestId ? String(requestId).slice(0, 80) : '';
  const s = settings.all();
  const parts = dateParts();

  const saved = await run(['invoices', 'invoiceItems', 'products', 'stockMovements', 'meta', 'customers', 'payments', 'salesReturns'], 'readwrite', async (tx) => {
    if (rid) {
      const done = await tx.getByIndex('salesReturns', 'requestId', rid);
      if (done) return { ...done, duplicate: true };
    }
    const inv = await tx.get('invoices', invoiceId);
    if (!inv) throw new ValidationError('Invoice not found.');
    if (inv.status === 'void') throw new ValidationError('A voided invoice cannot have returns.');
    const lines = await tx.getInvoiceLines(invoiceId);
    const previous = await tx.getAllByIndex('salesReturns', 'invoiceId', invoiceId);
    const already = returnedQtyByItem(previous);

    // 1. validate every requested line against what is still returnable
    const chosen = new Map();
    for (const a of asked) {
      const line = lines.find((l) => l.id === a.itemId);
      if (!line) throw new ValidationError('One of the items is not on this invoice.');
      const qty = round3((chosen.get(a.itemId)?.qty || 0) + a.qty);
      const left = round3(line.qty - (already.get(line.id) || 0));
      if (qty > left) throw new ValidationError(`Only ${left} ${line.unit || ''} of "${line.name}" can still be taken back.`.replace(/\s+/g, ' '));
      chosen.set(line.id, { line, qty });
    }

    // 2. value of the goods: line value × (invoice total ÷ subtotal) — the discount is shared out in proportion
    const factor = inv.subtotal > 0 ? inv.total / inv.subtotal : 1;
    const rows = [...chosen.values()].map(({ line, qty }) => ({ line, qty, amount: round2(lineTotal(qty, line.unitPrice) * factor) }));
    const maxReturnable = round2(inv.total - sum(previous.map((r) => r.amount)));
    const everythingLeftComesBack = lines.every((l) => round3(l.qty - (already.get(l.id) || 0)) === round3(chosen.get(l.id)?.qty || 0));
    let amount = sum(rows.map((r) => r.amount));
    if (everythingLeftComesBack) {
      // absorb rounding differences so a completely returned invoice returns exactly what it was charged
      const diff = round2(maxReturnable - amount);
      if (diff !== 0 && rows.length) rows[rows.length - 1].amount = round2(rows[rows.length - 1].amount + diff);
      amount = maxReturnable;
    }
    if (amount > maxReturnable) amount = maxReturnable;
    if (!(amount >= 0)) throw new ValidationError('Nothing left to return on this invoice.');

    // 3. money: reduce what the customer owes first, hand back the rest
    const customer = inv.customerId ? await tx.get('customers', inv.customerId) : null;
    const balance = customer ? await balanceInTx(tx, customer.id) : 0;
    const creditApplied = customer ? round2(Math.min(amount, Math.max(0, balance))) : 0;
    const refund = round2(amount - creditApplied);

    // 4. stock back in, one history row per product
    const returnId = uuid();
    const returnNo = await nextReturnNumber(tx, parts, s);
    const perProduct = new Map();
    for (const r of rows) perProduct.set(r.line.productId, round3((perProduct.get(r.line.productId) || 0) + r.qty));
    for (const [pid, q] of perProduct) {
      const p = await tx.get('products', pid);
      if (!p) continue; // legacy product that was physically deleted
      await recordMovement(tx, { product: p, type: 'return', qty: q, reason: `Return ${returnNo} (invoice ${inv.invoiceNo}): ${why}`, ref: returnId, refNo: returnNo, actor, allowNegative: true, opKey: rid ? `return:${rid}:${pid}` : '', at: parts.iso });
    }

    const rec = {
      id: returnId,
      returnNo,
      invoiceId: inv.id,
      invoiceNo: inv.invoiceNo,
      customerId: customer?.id || null,
      customerName: inv.customerName,
      customerPhone: inv.customerPhone || '',
      items: rows.map((r) => ({ itemId: r.line.id, productId: r.line.productId, name: r.line.name, unit: r.line.unit || '', qty: r.qty, unitPrice: r.line.unitPrice, amount: r.amount })),
      amount,
      creditApplied,
      refund,
      refundMethod: refund > 0 ? normalizeMethod(refundMethod) : '',
      reason: why,
      date: parts.date,
      time: parts.time,
      month: parts.month,
      createdAt: parts.iso,
      createdBy: actor.id,
      createdByName: actor.displayName || '',
      syncStatus: 'pending',
      syncAttempts: 0,
      syncError: '',
    };
    if (rid) rec.requestId = rid;
    await tx.put('salesReturns', rec);
    return rec;
  });

  if (!saved.duplicate) {
    bus.emit('data:changed', { store: 'salesReturns' });
    await logAction('invoice.return', { target: saved.invoiceNo, detail: `${saved.returnNo} — value ${saved.amount} (credit ${saved.creditApplied}, refund ${saved.refund}) — ${saved.reason}`, actor });
  }
  return saved;
}

/**
 * Returns, newest first. Needs `invoices`, `customers` or `reports`.
 * @param {{invoiceId?:string, customerId?:string, from?:string, to?:string}} [f]  dates are Asia/Dhaka days
 */
export async function listReturns({ invoiceId, customerId, from, to } = {}) {
  authorizeAny(['invoices', 'customers', 'reports']);
  const rows = await run(['salesReturns'], 'readonly', (tx) => {
    if (invoiceId) return tx.getAllByIndex('salesReturns', 'invoiceId', invoiceId);
    if (customerId) return tx.getAllByIndex('salesReturns', 'customerId', customerId);
    return tx.getAll('salesReturns');
  });
  return rows.filter((r) => (!from || r.date >= from) && (!to || r.date <= to)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

/** What can still be returned on an invoice: each line with sold / returned / remaining quantities. */
export async function returnableLines(invoiceId) {
  authorizeAny(['invoices', 'pos']);
  return run(['invoices', 'invoiceItems', 'salesReturns'], 'readonly', async (tx) => {
    const inv = await tx.get('invoices', invoiceId);
    if (!inv) return null;
    const lines = await tx.getInvoiceLines(invoiceId);
    const already = returnedQtyByItem(await tx.getAllByIndex('salesReturns', 'invoiceId', invoiceId));
    return { invoice: inv, lines: lines.map((l) => ({ ...l, returned: already.get(l.id) || 0, remaining: round3(l.qty - (already.get(l.id) || 0)) })) };
  });
}

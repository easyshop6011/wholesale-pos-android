/**
 * sales.js — creating, listing and voiding invoices.
 *
 * `createInvoice` is the heart of the POS. Everything that must stay consistent
 * — the invoice, its lines, stock reduction, stock movement log and the invoice
 * number counter — is written in ONE transaction: either all of it is saved or
 * none of it is, even if the app is closed mid-sale.
 */
import { run, between } from '../core/db.js';
import { uuid, dateParts, fmtQty } from '../core/utils.js';
import { ValidationError } from '../core/errors.js';
import { parseMoney, parseQty, round2, sum, lineTotal, round3, toNum } from '../core/money.js';
import { settings } from './settings.js';
import { balanceInTx } from './customers.js';
import { bus } from '../core/bus.js';
import { terms, rank } from '../core/search.js';
import { logAction } from './audit.js';
import { authorize, authorizeAny } from './guard.js';
import { recordMovement } from './stockledger.js';
import { normalizeMethod } from './payment-methods.js';

/** Revision of an invoice record; bumped by every change after creation (void). Sync uses it to detect "changed while uploading". */
export const revOf = (inv) => inv.rev || (inv.status === 'void' ? 2 : 1);

/**
 * Allocate the next invoice number: PREFIX-[DEVICE-]YYMMDD-NNNN.
 * The counter lives in the same transaction as the invoice so it never skips or repeats.
 */
async function nextInvoiceNumber(tx, parts, s) {
  const day = parts.date.replace(/-/g, '').slice(2);
  const key = `invseq:${s.deviceCode || ''}:${day}`;
  const row = await tx.get('meta', key);
  const n = (row?.value || 0) + 1;
  await tx.put('meta', { key, value: n });
  const dev = s.deviceCode ? `${s.deviceCode}-` : '';
  return `${s.invoicePrefix || 'INV'}-${dev}${day}-${String(n).padStart(4, '0')}`;
}

/**
 * Create and save an invoice. Needs the `pos` permission.
 *
 * Everything that must stay consistent — the invoice, its lines, the stock reduction,
 * the stock-history rows and the invoice-number counter — is ONE transaction.
 *
 * IDEMPOTENT: pass a `requestId` (the New Sale screen creates one per sale). If the
 * same request arrives again — double tap, two tabs, a retry after a crash — the
 * invoice that was already saved is returned (`duplicate: true`) and NOTHING else
 * changes: no second invoice, no second stock deduction, no skipped number.
 *
 * @param {object} input
 * @param {string|null} input.customerId   null for a walk-in customer
 * @param {{productId:string, qty:number|string, unitPrice:number|string}[]} input.items
 * @param {number|string} [input.discount]  absolute amount
 * @param {number|string} [input.paid]
 * @param {string} [input.paymentMethod]    how the paid amount was received (cash, bkash …)
 * @param {string} [input.notes]
 * @param {string} [input.requestId]
 * @returns {Promise<object>} the saved invoice with an `items` array
 */
export async function createInvoice(input, _user = null) {
  const actor = authorize('pos');
  const s = settings.all();
  if (!(input.items || []).length) throw new ValidationError('Add at least one product.');
  const lines = input.items.map((i) => {
    if (!i.productId) throw new ValidationError('Select a product for every line.');
    return { productId: i.productId, qty: parseQty(i.qty, 'Quantity'), unitPrice: parseMoney(i.unitPrice, 'Unit price') };
  });
  const discount = parseMoney(input.discount, 'Discount');
  const paid = parseMoney(input.paid, 'Paid amount');
  const requestId = input.requestId ? String(input.requestId).slice(0, 80) : '';
  const parts = dateParts();

  const result = await run(
    ['invoices', 'invoiceItems', 'products', 'stockMovements', 'meta', 'customers', 'payments', 'salesReturns'],
    'readwrite',
    async (tx) => {
      if (requestId) {
        const done = await tx.getByIndex('invoices', 'requestId', requestId);
        if (done) return { ...done, items: await tx.getInvoiceLines(done.id), duplicate: true };
      }
      let customer = null;
      if (input.customerId) {
        customer = await tx.get('customers', input.customerId);
        if (!customer) throw new ValidationError('Selected customer no longer exists.');
      }

      // Load products and verify stock (aggregated per product across lines).
      const need = new Map();
      for (const l of lines) need.set(l.productId, round3((need.get(l.productId) || 0) + l.qty));
      const products = new Map();
      for (const pid of need.keys()) {
        const p = await tx.get('products', pid);
        if (!p || !p.active) throw new ValidationError('A selected product is no longer available.');
        products.set(pid, p);
      }
      if (!s.allowNegativeStock) {
        for (const [pid, q] of need) {
          const p = products.get(pid);
          if (q > p.stock + 1e-9) throw new ValidationError(`Not enough stock for "${p.name}" — available ${fmtQty(p.stock)} ${p.unit}.`);
        }
      }

      const items = lines.map((l) => {
        const p = products.get(l.productId);
        return { ...l, name: p.name, unit: p.unit, costPrice: p.costPrice || 0, total: lineTotal(l.qty, l.unitPrice) };
      });
      const subtotal = sum(items.map((i) => i.total));
      if (discount < 0 || discount > subtotal) throw new ValidationError('Discount must be between zero and the subtotal.');
      const total = round2(subtotal - discount);
      if (paid > total) throw new ValidationError('Paid amount cannot exceed the invoice total.');
      const due = round2(total - paid);
      if (due > 0 && !customer) throw new ValidationError('Select a customer to sell on credit (due amount).');

      const previousDue = customer ? await balanceInTx(tx, customer.id) : 0;
      const invoiceNo = await nextInvoiceNumber(tx, parts, s);
      const id = uuid(); // globally unique — also the Google Sheets dedupe key

      const inv = {
        id,
        invoiceNo,
        date: parts.date,
        time: parts.time,
        month: parts.month,
        createdAt: parts.iso,
        customerId: customer?.id || null,
        customerName: customer?.name || 'Walk-in Customer',
        customerPhone: customer?.phone || '',
        subtotal,
        discount,
        total,
        paid,
        paymentMethod: paid > 0 ? normalizeMethod(input.paymentMethod) : '',
        due,
        previousDue: Math.max(0, previousDue),
        status: 'active',
        notes: String(input.notes || '').trim(),
        createdBy: actor.id,
        createdByName: actor.displayName || '',
        deviceCode: s.deviceCode || '',
        rev: 1,
        syncStatus: 'pending',
        syncAttempts: 0,
        syncError: '',
      };
      if (requestId) inv.requestId = requestId;
      await tx.put('invoices', inv);

      for (const [n, it] of items.entries()) {
        await tx.put('invoiceItems', { id: uuid(), invoiceId: id, line: n + 1, productId: it.productId, name: it.name, unit: it.unit, qty: it.qty, unitPrice: it.unitPrice, costPrice: it.costPrice, total: it.total });
      }
      // Reduce stock + write ONE history row per product (several lines of one product are summed).
      for (const [pid, q] of need) {
        await recordMovement(tx, {
          product: products.get(pid),
          type: 'sale',
          qty: -q,
          reason: `Sale ${invoiceNo}`,
          ref: id,
          refNo: invoiceNo,
          actor,
          allowNegative: !!s.allowNegativeStock,
          opKey: requestId ? `sale:${requestId}:${pid}` : '',
          at: parts.iso,
        });
      }
      return { ...inv, items: items.map((i) => ({ ...i })) };
    },
  );
  if (!result.duplicate) bus.emit('data:changed', { store: 'invoices' });
  return result;
}

/** Load one invoice together with its line items. */
export async function getInvoice(id) {
  authorizeAny(['invoices', 'pos']);
  return run(['invoices', 'invoiceItems'], 'readonly', async (tx) => {
    const inv = await tx.get('invoices', id);
    if (!inv) return null;
    const items = await tx.getInvoiceLines(id);
    return { ...inv, items };
  });
}

const INVOICE_SORTS = {
  newest: (a, b) => b.createdAt.localeCompare(a.createdAt),
  oldest: (a, b) => a.createdAt.localeCompare(b.createdAt),
  'total-desc': (a, b) => b.total - a.total || INVOICE_SORTS.newest(a, b),
  'total-asc': (a, b) => a.total - b.total || INVOICE_SORTS.newest(a, b),
  'due-desc': (a, b) => b.due - a.due || INVOICE_SORTS.newest(a, b),
};

/** Payment state of an invoice: 'paid' (due 0), 'unpaid' (nothing paid) or 'partial'. */
export const paymentState = (i) => (i.due <= 0 ? 'paid' : i.paid <= 0 ? 'unpaid' : 'partial');

/**
 * Query invoices with filters, sorting and paging. Returns the page plus totals
 * over ALL matches (so the UI can show "128 invoices · ৳4,52,000" while only
 * rendering the first 50).
 * @param {{from?:string,to?:string,search?:string,customerId?:string,
 *          status?:''|'active'|'void', sync?:''|'pending'|'synced'|'failed',
 *          userId?:string, payment?:''|'paid'|'due'|'unpaid'|'partial',
 *          min?:number|string, max?:number|string, sort?:keyof typeof INVOICE_SORTS,
 *          limit?:number, offset?:number}} [f]
 *   `payment: 'due'` = unpaid or partial. `min`/`max` bound the invoice total.
 * @returns {Promise<{rows:object[], total:number, sumTotal:number, sumDue:number}>}
 */
export async function queryInvoices({ from, to, search = '', customerId, status = '', sync = '', userId = '', payment = '', min = '', max = '', sort = 'newest', limit = 50, offset = 0 } = {}) {
  authorizeAny(['invoices', 'pos', 'customers']);
  let rows = await run(['invoices'], 'readonly', (tx) => {
    if (customerId) return tx.getAllByIndex('invoices', 'customerId', customerId);
    if (from && to) return tx.getAllByIndex('invoices', 'date', between(from, to));
    if (from) return tx.getAllByIndex('invoices', 'date', globalThis.IDBKeyRange.lowerBound(from));
    if (to) return tx.getAllByIndex('invoices', 'date', globalThis.IDBKeyRange.upperBound(to));
    return tx.getAll('invoices');
  });
  const lo = min === '' || min == null ? null : toNum(min);
  const hi = max === '' || max == null ? null : toNum(max);
  rows = rows.filter(
    (i) =>
      (!customerId || ((!from || i.date >= from) && (!to || i.date <= to))) &&
      (!status || i.status === status) &&
      (!sync || (sync === 'failed' ? i.syncStatus === 'failed' : i.status !== 'void' && i.syncStatus === sync)) &&
      (!userId || i.createdBy === userId) &&
      (!payment || (payment === 'due' ? i.due > 0 : paymentState(i) === payment)) &&
      (lo === null || i.total >= lo) &&
      (hi === null || i.total <= hi),
  );
  if (terms(search).length) rows = rank(rows, search, (i) => [i.invoiceNo, i.customerName, i.customerPhone || '', i.createdByName || '']);
  else rows.sort(INVOICE_SORTS[sort] || INVOICE_SORTS.newest);
  const live = rows.filter((i) => i.status !== 'void');
  return { rows: rows.slice(offset, offset + limit), total: rows.length, sumTotal: sum(live.map((i) => i.total)), sumDue: sum(live.map((i) => i.due)) };
}

/**
 * List invoices, newest first (simple form of {@link queryInvoices}).
 * @param {{from?:string,to?:string,search?:string,customerId?:string,status?:string,limit?:number}} [f]
 */
export async function listInvoices({ limit = 500, ...f } = {}) {
  return (await queryInvoices({ ...f, limit })).rows;
}

/**
 * Void an invoice. Needs `invoices.void`.
 *
 *  - a reason is REQUIRED and kept (with who and when) on the invoice;
 *  - stock goes back through the stock history (one "Void" row per product);
 *  - the invoice stops counting in sales and in the customer's due (the record itself
 *    is kept for the audit trail and shows as Void everywhere, including Google Sheets);
 *  - the amount the customer paid at the counter is remembered as `voidRefund`
 *    (money to give back — the app does not move cash);
 *  - an invoice that already has returns cannot be voided (the returned goods and
 *    credit would be counted twice) — take back the remaining goods instead.
 */
export async function voidInvoice(id, reason, _user = null) {
  const actor = authorize('invoices.void');
  const why = String(reason || '').trim();
  if (why.length < 3) throw new ValidationError('Enter the reason for voiding this invoice (at least 3 characters).');
  const parts = dateParts();
  const result = await run(['invoices', 'invoiceItems', 'products', 'stockMovements', 'salesReturns'], 'readwrite', async (tx) => {
    const inv = await tx.get('invoices', id);
    if (!inv) throw new ValidationError('Invoice not found.');
    if (inv.status === 'void') throw new ValidationError('Invoice is already void.');
    if ((await tx.countByIndex('salesReturns', 'invoiceId', id)) > 0) throw new ValidationError('This invoice already has returned goods, so it cannot be voided. Take back the remaining goods instead.');
    const items = await tx.getInvoiceLines(id);
    const back = new Map();
    for (const it of items) back.set(it.productId, round3((back.get(it.productId) || 0) + it.qty));
    for (const [pid, q] of back) {
      const p = await tx.get('products', pid);
      if (!p) continue; // legacy product that was physically deleted — nothing to restore
      await recordMovement(tx, { product: p, type: 'void', qty: q, reason: `Void ${inv.invoiceNo}: ${why}`, ref: id, refNo: inv.invoiceNo, actor, allowNegative: true, opKey: `void:${id}:${pid}`, at: parts.iso });
    }
    const next = { ...inv, status: 'void', voidReason: why, voidedAt: parts.iso, voidedBy: actor.displayName || '', voidedById: actor.id, voidRefund: inv.paid, rev: revOf(inv) + 1, syncStatus: 'pending', syncError: '' };
    await tx.put('invoices', next);
    return next;
  });
  bus.emit('data:changed', { store: 'invoices' });
  await logAction('invoice.void', { target: result.invoiceNo, detail: `${result.total} — ${result.voidReason}`, actor });
  return result;
}

/**
 * Most recent unit price per product for a customer — shown as a tap-to-fill
 * hint in the POS (prices are still entered manually per sale).
 * @returns {Promise<Map<string, number>>}
 */
export async function lastPricesFor(customerId) {
  if (!customerId) return new Map();
  return run(['invoices', 'invoiceItems'], 'readonly', async (tx) => {
    const invs = (await tx.getAllByIndex('invoices', 'customerId', customerId)).filter((i) => i.status !== 'void').sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    const map = new Map();
    for (const inv of invs) for (const it of await tx.getInvoiceLines(inv.id)) map.set(it.productId, it.unitPrice);
    return map;
  });
}

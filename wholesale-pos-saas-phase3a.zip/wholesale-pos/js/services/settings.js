/**
 * settings.js — persistent key/value application settings with an in-memory
 * cache so views can read values synchronously (`settings.get('currency')`).
 */
import { dbAll, run } from '../core/db.js';
import { bus } from '../core/bus.js';
import { authorize } from './guard.js';
import { logAction } from './audit.js';

const PRINTER_KEYS = new Set(['printTransport', 'printMode', 'paperWidthDots', 'textColumns', 'printDensity', 'copies', 'autoPrint', 'cutPaper', 'openDrawer', 'feedLines', 'bleChunkSize', 'bleDelayMs', 'serialBaud']);
const APPEARANCE_KEYS = new Set(['theme', 'density']);

/** Every setting and its default. Add new settings here. */
export const DEFAULTS = {
  // Business profile (printed on receipts)
  businessName: 'My Wholesale Store',
  logo: '', // data URL (resized + stored locally)
  address: '',
  phone: '',
  email: '',
  taxId: '',
  footer: 'Thank you for your business!',
  currency: '৳',

  // Invoicing / inventory
  invoicePrefix: 'INV',
  deviceCode: '', // set a different letter on every device to keep invoice numbers unique across devices
  showPreviousDue: true,
  allowNegativeStock: false,
  lowStockDefault: 10,

  // Printing
  printTransport: 'browser', // webbluetooth | webusb | webserial | rawbt | capble | browser
  printMode: 'raster', // raster (any language + logo) | text (fast, ASCII only)
  paperWidthDots: 576, // 80mm @203dpi = 576 printable dots (use 512 for some models)
  textColumns: 48,
  printDensity: 170, // raster darkness threshold (higher = darker)
  copies: 1,
  autoPrint: false,
  cutPaper: true,
  openDrawer: false,
  feedLines: 3,
  bleChunkSize: 100,
  bleDelayMs: 20,
  serialBaud: 115200,

  // Security
  autoLockMinutes: 5,

  // Sync / Google
  syncEnabled: true,
  syncUrl: '', // Google Apps Script web-app URL
  syncToken: '', // shared secret checked by the script
  lastSyncAt: '',
  syncCatalog: true, // also upsert products (with stock) and customers into Google Sheets
  lastBackupAt: '',

  // Appearance
  theme: 'auto', // auto | light | dark
  density: 'comfortable', // comfortable | compact

  // Automatic backup (local snapshots + Google Drive)
  autoBackupEnabled: true,
  autoBackupEveryHours: 24,
  autoBackupKeep: 10, // local snapshots to keep
  autoBackupToDrive: true, // upload to Drive when online and sync is configured
  autoBackupEncrypt: false, // encrypt the Drive copy with a passphrase typed per session (never stored)
  autoBackupToDevice: true, // Android app: also write the newest backup to the Documents folder
  autoBackupAfterSales: 30, // also snapshot after this many new invoices (0 = off)
  lastAutoBackupAt: '',
  lastDriveBackupAt: '',
};

let cache = { ...DEFAULTS };

export const settings = {
  /** Load all stored settings into the cache (call once at boot). */
  async load() {
    const rows = await dbAll('settings');
    cache = { ...DEFAULTS };
    for (const r of rows) cache[r.key] = r.value;
    bus.emit('settings:changed', cache);
    return cache;
  },
  /** Synchronous read from cache. */
  get(key) {
    return cache[key];
  },
  /** Copy of every setting. */
  all() {
    return { ...cache };
  },
  /**
   * Change settings on behalf of a person (the Settings screens). Printer settings need
   * `printer`, everything else needs `settings`. The sync token is never logged.
   * @param {Record<string, any>} patch
   */
  async update(patch) {
    const keys = Object.keys(patch);
    const perm = keys.length && keys.every((k) => PRINTER_KEYS.has(k) || APPEARANCE_KEYS.has(k)) ? 'printer' : 'settings';
    const actor = authorize(perm);
    await this.set(patch);
    const changed = keys.filter((k) => cache[k] !== undefined);
    await logAction('settings.update', { target: changed.join(', ').slice(0, 120), detail: changed.includes('syncToken') ? 'sync token changed' : '', actor });
  },

  /**
   * Save one or more settings atomically (internal — used by the app itself,
   * e.g. "last sync time"; people go through {@link settings.update}).
   * @param {Record<string, any>} patch
   */
  async set(patch) {
    await run(['settings'], 'readwrite', async (tx) => {
      for (const [key, value] of Object.entries(patch)) await tx.put('settings', { key, value });
    });
    Object.assign(cache, patch);
    bus.emit('settings:changed', cache);
  },
};

/**
 * stockledger.js — the ONLY way stock quantities change.
 *
 * Every change to `products.stock` — a new product, a delivery, a sale, a void, a
 * return, a count correction, damaged goods — goes through `recordMovement`, which
 * writes, in the CALLER'S transaction:
 *
 *   1. the new stock on the product, and
 *   2. one append-only `stockMovements` row (what / how many / before / after /
 *      when / who / why / which invoice / cost / supplier / batch).
 *
 * Because both writes share the transaction of the business operation (the sale,
 * the void …), either everything is saved or nothing is — the history can never
 * disagree with the stock. Movement rows are NEVER edited or deleted; a mistake is
 * fixed with a new `adjustment` row.
 *
 * IDEMPOTENCY: `opKey` is a unique index. Re-running an operation (double tap,
 * retry after a crash) hits the same key and is refused with DuplicateOperationError
 * instead of moving stock twice.
 */
import { uuid, monotonicNow } from '../core/utils.js';
import { round3 } from '../core/money.js';
import { ValidationError, DuplicateOperationError } from '../core/errors.js';
import { dhakaDate } from '../core/datetime.js';

/**
 * Movement types. `sign`: +1 stock in, −1 stock out, 0 either / none.
 * `label` is what the UI shows.
 */
export const MOVEMENT_TYPES = {
  created: { label: 'Product created', sign: 0 },
  initial: { label: 'Opening stock', sign: 1 },
  receive: { label: 'Stock received', sign: 1 },
  sale: { label: 'Sale', sign: -1 },
  void: { label: 'Void (stock restored)', sign: 1 },
  return: { label: 'Customer return', sign: 1 },
  adjustment: { label: 'Stock correction', sign: 0 },
  damage: { label: 'Damaged / lost', sign: -1 },
};

/**
 * Change a product's stock and log it. MUST be called inside a read-write
 * transaction that includes the `products` and `stockMovements` stores.
 *
 * @param {object} tx  the open transaction
 * @param {object} o
 * @param {object} o.product      the product row as just read in THIS transaction
 * @param {keyof typeof MOVEMENT_TYPES} o.type
 * @param {number} o.qty          signed change (0 only for type 'created')
 * @param {string} [o.reason]     human explanation / note
 * @param {string|null} [o.ref]   id of the related invoice / return
 * @param {string} [o.refNo]      its human number (INV-…, RET-…)
 * @param {{id?:string,displayName?:string,username?:string}|null} [o.actor]
 * @param {number|null} [o.unitCost]  purchase cost per unit (deliveries)
 * @param {string} [o.supplier]
 * @param {string} [o.batchNo]
 * @param {string} [o.opKey]      idempotency key (unique across all movements)
 * @param {boolean} [o.allowNegative]  permit stock below zero (overselling setting)
 * @param {string} [o.at]         ISO instant; defaults to a strictly increasing "now"
 * @param {object} [o.patch]      extra fields to merge into the product row
 * @returns {Promise<{product:object, movement:object}>}
 */
export async function recordMovement(tx, { product, type, qty, reason = '', ref = null, refNo = '', actor = null, unitCost = null, supplier = '', batchNo = '', opKey = '', allowNegative = false, at, patch = {} }) {
  const def = MOVEMENT_TYPES[type];
  if (!def) throw new ValidationError(`Unknown stock movement type "${type}".`);
  if (!product?.id) throw new ValidationError('Product not found.');
  const change = round3(Number(qty) || 0);
  if (type !== 'created' && change === 0) throw new ValidationError('The stock change cannot be zero.');
  if (def.sign > 0 && change < 0) throw new ValidationError(`${def.label} must add stock.`);
  if (def.sign < 0 && change > 0) throw new ValidationError(`${def.label} must remove stock.`);

  if (opKey) {
    const clash = await tx.getByIndex('stockMovements', 'opKey', opKey);
    if (clash) throw new DuplicateOperationError('This stock operation was already processed.');
  }

  const previousStock = round3(product.stock || 0);
  const balance = round3(previousStock + change);
  if (balance < 0 && !allowNegative) {
    throw new ValidationError(`Not enough stock for "${product.name}" — available ${previousStock} ${product.unit || ''}.`.trim());
  }

  // History must read in the order it happened even if the device clock was moved backwards:
  // a product's rows never get a time at or before its previous row.
  let iso = at || monotonicNow().toISOString();
  if (product.lastMoveAt && iso <= product.lastMoveAt) iso = new Date(Date.parse(product.lastMoveAt) + 1).toISOString();
  const nextProduct = { ...product, ...patch, stock: balance, updatedAt: iso, lastMoveAt: iso };
  await tx.put('products', nextProduct);

  const movement = {
    id: uuid(),
    productId: product.id,
    productName: product.name,
    productCode: product.code || '',
    type,
    qty: change,
    previousStock,
    balance,
    reason: String(reason || '').trim(),
    ref: ref || null,
    refNo: refNo || '',
    userId: actor?.id || null,
    userName: actor?.displayName || actor?.username || '',
    unitCost: unitCost === null || unitCost === undefined ? null : Number(unitCost),
    supplier: String(supplier || '').trim(),
    batchNo: String(batchNo || '').trim(),
    createdAt: iso,
    date: dhakaDate(iso),
  };
  if (opKey) movement.opKey = opKey;
  await tx.put('stockMovements', movement);
  return { product: nextProduct, movement };
}

/**
 * Pure check of one product's history. Movements must chain: each row's
 * `previousStock` equals the previous row's `balance`, `balance = previousStock + qty`,
 * and the last `balance` equals the product's current stock.
 *
 * Products that existed before stock history was introduced may legitimately have
 * stock that no recorded movement explains: that is reported as `untracked` (the
 * known limitation), NOT invented.
 *
 * @param {{stock:number}} product
 * @param {{qty:number, previousStock?:number, balance:number, createdAt:string}[]} moves
 * @returns {{ok:boolean, problems:string[], untracked:number, firstRecordedAt:string, count:number}}
 */
export function checkProductLedger(product, moves) {
  const rows = [...moves].sort((a, b) => a.createdAt.localeCompare(b.createdAt) || (a.id || '').localeCompare(b.id || ''));
  const problems = [];
  let expectedPrev = null;
  rows.forEach((m, i) => {
    const prev = m.previousStock ?? round3(m.balance - m.qty);
    if (round3(prev + m.qty) !== round3(m.balance)) problems.push(`Row ${i + 1}: ${prev} + ${m.qty} ≠ ${m.balance}`);
    if (expectedPrev !== null && round3(prev) !== round3(expectedPrev)) problems.push(`Row ${i + 1}: starts at ${prev} but the previous row ended at ${expectedPrev}`);
    expectedPrev = m.balance;
  });
  const last = rows.length ? rows[rows.length - 1].balance : null;
  const first = rows[0];
  const startsAt = first ? (first.previousStock ?? round3(first.balance - first.qty)) : 0;
  // Stock that existed before the first recorded movement (only possible for pre-history products).
  const untracked = first ? round3(startsAt) : round3(product.stock || 0);
  if (last !== null && round3(last) !== round3(product.stock || 0)) problems.push(`Current stock ${product.stock} differs from the last recorded balance ${last}`);
  return { ok: problems.length === 0, problems, untracked, firstRecordedAt: first?.createdAt || '', count: rows.length };
}

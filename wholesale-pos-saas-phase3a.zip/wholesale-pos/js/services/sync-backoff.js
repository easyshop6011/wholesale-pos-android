/**
 * sync-backoff.js — pure, dependency-free helpers for the sync engine
 * (kept separate so they can be unit-tested in plain Node).
 */

/** Delay schedule for automatic retries: 30 s, 1 min, 2 min, 4 min … capped at 15 min. */
export const BACKOFF = { baseMs: 30000, capMs: 15 * 60000, jitter: 0.2 };

/** How many sync-log rows are kept. */
export const LOG_KEEP = 200;

/**
 * Milliseconds to wait before the next AUTOMATIC attempt after `failures`
 * consecutive failures (0 failures => 0). Jitter (±20 %) spreads out devices that
 * all lose the network at the same moment. Never exceeds the cap.
 * @param {number} failures
 * @param {{baseMs?:number,capMs?:number,jitter?:number,rand?:()=>number}} [o]
 */
export function nextDelayMs(failures, { baseMs = BACKOFF.baseMs, capMs = BACKOFF.capMs, jitter = BACKOFF.jitter, rand = Math.random } = {}) {
  if (!(failures > 0)) return 0;
  const raw = Math.min(capMs, baseMs * 2 ** Math.min(failures - 1, 20));
  const spread = 1 + (rand() * 2 - 1) * jitter;
  return Math.max(0, Math.min(capMs, Math.round(raw * spread)));
}

/** True when an automatic attempt is allowed now (online and back-off elapsed). */
export function isAttemptDue({ now, nextAttemptAt = 0, online = true }) {
  return online !== false && now >= nextAttemptAt;
}

/** The server (older Code.gs) does not know the requested action. */
export function isUnsupportedActionError(message) {
  return /unknown|not supported|bad request/i.test(String(message || ''));
}

/** Ids of the log rows to delete so only the newest `keep` remain. */
export function logIdsToTrim(rows, keep = LOG_KEEP) {
  if (rows.length <= keep) return [];
  return [...rows].sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt))).slice(0, rows.length - keep).map((r) => r.id);
}

/** Minimum wait after Google says "quota / too many requests" — hammering makes it worse. */
export const QUOTA_COOLDOWN_MS = 30 * 60000;

/**
 * Did Google refuse because a daily quota / rate limit was hit (Apps Script
 * "Service invoked too many times", HTTP 429 …)?
 */
export function isQuotaError(message) {
  return /quota|too many times|too many requests|rate.?limit|service invoked|exceeded|try again later|\b429\b/i.test(String(message || ''));
}

/** Delay before the next automatic attempt: normal back-off, but at least {@link QUOTA_COOLDOWN_MS} after a quota error. */
export function retryDelayMs(failures, message, opts) {
  const base = nextDelayMs(failures, opts);
  return isQuotaError(message) ? Math.max(base, QUOTA_COOLDOWN_MS) : base;
}

/**
 * Remove secrets (the sync token, the web-app URL) from text before it is stored in a
 * log / shown on screen / put in an error record. Tokens are replaced wherever they appear.
 * @param {string} text
 * @param {(string|undefined|null)[]} secrets
 */
export function redactSecrets(text, secrets = []) {
  let out = String(text ?? '');
  for (const s of secrets) {
    if (!s || String(s).length < 4) continue;
    out = out.split(String(s)).join('[hidden]');
  }
  // Apps Script URLs carry the deployment id — hide any script URL even if it is not the configured one.
  return out.replace(/https:\/\/script\.google(?:usercontent)?\.com\/[^\s"')]+/g, '[script-url]');
}

/**
 * sync.js — offline-first synchronisation to Google Sheets.
 *
 * The local database is the source of truth. A sale is complete the moment it is
 * saved on the device; uploading is a background job that may be late, fail or be
 * repeated without any harm.
 *
 * WHAT IS SYNCED
 *   invoices   → sheet "Invoices"  (one row per product line; also re-sent when voided)
 *   payments   → sheet "Payments"  (customer due collections)
 *   catalog    → sheets "Products" / "Customers" (upserted by id; products carry live
 *                stock). Only records that CHANGED since the last confirmed upload are sent.
 *
 * HOW DUPLICATES ARE PREVENTED (independent layers)
 *  1. Every invoice/payment has a UUID created at sale time.
 *  2. A record is marked `synced` only AFTER the server confirms it; if the app dies
 *     mid-request it simply stays `pending`.
 *  3. The Apps Script (integrations/google-apps-script/Code.gs) keeps the UUID in a
 *     column and answers "duplicate" for an id it already has, under a script lock —
 *     a retry after a lost response cannot add a second row.
 *  4. A Web Lock stops several tabs of this device from syncing at once.
 *
 * HOW FAILURES ARE HANDLED
 *  - Automatic attempts back off exponentially (30 s → 15 min, with jitter) so a bad
 *    network or a mis-configured script is not hammered; "Sync now" always tries at once.
 *  - After a timeout the batch size is halved (down to 1) and grows back on success.
 *  - Records the server rejects are flagged `failed` (they do not block the queue) and can
 *    be re-queued with "Retry failed".
 *  - Every run that did something (or failed) is written to the sync log (Settings → Sync).
 *  - "Verify" asks the server which already-uploaded invoices it really has and
 *    re-queues any that are missing (e.g. rows deleted from the sheet by mistake).
 *  - An older Code.gs without catalog/verify actions is detected and those parts are skipped
 *    with a notice, while invoices keep syncing.
 *
 * CHANGED WHILE UPLOADING: every invoice carries a revision number (`rev`, bumped by a
 * void). A response only marks an invoice `synced` if its revision is still the one that
 * was sent — a void made DURING the upload keeps the invoice `pending`, so the void is
 * uploaded next. Quota / rate-limit errors from Google wait at least 30 minutes.
 *
 * TWO DEVICES: both can upload to one sheet. Invoices cannot clash (UUID ids); the script
 * rejects a reused invoice NUMBER (two devices with the same Device code) as a `conflict`;
 * and it reports when a product's stock was last written by a DIFFERENT device. Each device
 * keeps its own stock — see docs/SYNC.md "Working on two devices".
 *
 * SECRETS: the token and URL are removed from every message that is stored or shown.
 *
 * TRIGGERS: app start, the `online` event, returning to the app, network-type change,
 * every 60 s, after each sale/payment/return, and the "Sync now" button.
 */
import { run, dbByIndex, dbAll } from '../core/db.js';
import { settings } from './settings.js';
import { bus } from '../core/bus.js';
import { uuid, monotonicNow } from '../core/utils.js';
import { nextDelayMs, retryDelayMs, isAttemptDue, isUnsupportedActionError, logIdsToTrim, redactSecrets, LOG_KEEP } from './sync-backoff.js';
import { authorize } from './guard.js';
import { computeBalances } from './customers.js';
import { revOf } from './sales.js';
import { methodLabel } from './payment-methods.js';

const BATCH_MAX = 15; // invoices per request (small requests survive bad networks)
const CATALOG_BATCH = 100;
const TIMEOUT_MS = 30000;
const VERIFY_CHUNK = 300;

const state = {
  running: false,
  lastError: '',
  lastRunAt: '',
  pendingInvoices: 0,
  pendingPayments: 0,
  pendingReturns: 0,
  failedRecords: 0,
  catalogPending: 0,
  conflicts: 0, // products last written by another device (see header)
  online: true,
  timer: null,
  failures: 0, // consecutive failed runs
  nextAttemptAt: 0, // epoch ms; automatic attempts wait until then
  batch: BATCH_MAX,
  catalogSupported: true,
  verifySupported: true,
  returnsSupported: true,
  notice: '', // non-fatal information, e.g. "update Code.gs for catalog sync"
};

/** Text safe to store or show: the token and script URL are removed. */
const safe = (e) => redactSecrets(typeof e === 'string' ? e : e?.message || String(e || ''), [settings.get('syncToken'), settings.get('syncUrl')]);

/** Test helper: back to a clean engine. */
export function _resetSyncForTests() {
  Object.assign(state, { running: false, lastError: '', lastRunAt: '', failures: 0, nextAttemptAt: 0, batch: BATCH_MAX, catalogSupported: true, verifySupported: true, returnsSupported: true, notice: '', pendingInvoices: 0, pendingPayments: 0, pendingReturns: 0, failedRecords: 0, catalogPending: 0, conflicts: 0 });
}

// ---- payload builders ---------------------------------------------------------

/** Shape one invoice (+ lines) into the JSON the Apps Script expects. `rev` lets the script ignore an out-of-date copy. */
export function buildInvoicePayload(inv, items) {
  return {
    id: inv.id,
    invoiceNo: inv.invoiceNo,
    date: inv.date,
    time: inv.time,
    customer: inv.customerName,
    phone: inv.customerPhone || '',
    status: inv.status === 'void' ? 'Void' : 'Active',
    discount: inv.discount,
    total: inv.total,
    paid: inv.paid,
    due: inv.due,
    method: methodLabel(inv.paymentMethod),
    rev: revOf(inv),
    voidReason: inv.status === 'void' ? inv.voidReason || '' : '',
    voidedAt: inv.status === 'void' ? inv.voidedAt || '' : '',
    items: items.map((i) => ({ name: i.name, qty: i.qty, unitPrice: i.unitPrice, total: i.total })),
  };
}

/** Shape a customer payment for the "Payments" sheet tab. */
export function buildPaymentPayload(p) {
  return { id: p.id, date: p.date, time: p.time, customer: p.customerName, phone: p.customerPhone || '', amount: p.amount, method: methodLabel(p.method), note: p.note || '' };
}

/** Shape a sales return for the "Returns" sheet tab. */
export function buildReturnPayload(r) {
  return {
    id: r.id,
    returnNo: r.returnNo,
    invoiceNo: r.invoiceNo,
    date: r.date,
    time: r.time,
    customer: r.customerName,
    phone: r.customerPhone || '',
    amount: r.amount,
    creditApplied: r.creditApplied,
    refund: r.refund,
    method: methodLabel(r.refundMethod),
    reason: r.reason,
    items: r.items.map((i) => ({ name: i.name, qty: i.qty, unitPrice: i.unitPrice, amount: i.amount })),
  };
}

/** Product row for the "Products" sheet (`device` lets the script notice two devices writing the same stock). */
export function buildProductPayload(p, categoryName = '', device = '') {
  return { id: p.id, code: p.code || '', name: p.name, sku: p.sku || '', category: categoryName, unit: p.unit || '', costPrice: p.costPrice || 0, defaultPrice: p.defaultPrice || 0, stock: p.stock, lowStockLevel: p.lowStockLevel, status: p.active ? 'Active' : 'Archived', device };
}

/** Customer row for the "Customers" sheet (balance = current due; negative = credit). */
export function buildCustomerPayload(c, due = 0) {
  return { id: c.id, code: c.code || '', name: c.name, phone: c.phone || '', address: c.address || '', due };
}

/** A stable id for THIS installation (not the invoice "Device code" letter). Created on first use. */
export async function getDeviceId() {
  return run(['meta'], 'readwrite', async (tx) => {
    const row = await tx.get('meta', 'deviceId');
    if (row?.value) return row.value;
    const id = `d${uuid().slice(0, 8)}`; // starts with a letter: Sheets must never read it as a number
    await tx.put('meta', { key: 'deviceId', value: id });
    return id;
  });
}

/** Small, stable string hash (FNV-1a) used to detect "this record changed since the last upload". */
export function hashOf(obj) {
  const s = JSON.stringify(obj);
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(36) + s.length.toString(36);
}

// ---- transport -----------------------------------------------------------------

/**
 * POST JSON to the Apps Script web app. Content-Type is text/plain on purpose:
 * it is a CORS "simple request", so the browser sends no pre-flight OPTIONS
 * (which Apps Script cannot answer).
 * @param {string} url
 * @param {object} body
 * @param {{fetchImpl?:typeof fetch, timeoutMs?:number}} [opts]
 */
export async function postToScript(url, body, { fetchImpl = globalThis.fetch, timeoutMs = TIMEOUT_MS } = {}) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetchImpl(url, { method: 'POST', redirect: 'follow', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body), signal: ctrl?.signal });
    if (!res.ok) throw new Error(`Server returned HTTP ${res.status}`);
    const text = await res.text();
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      throw new Error('Unexpected response from Google Apps Script (is the web app deployed for "Anyone"?)');
    }
    if (!json.ok) throw new Error(json.error || 'Google Apps Script reported an error');
    return json;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

// ---- status ----------------------------------------------------------------------

/** Count records waiting to sync and publish the status. */
export async function refreshStatus() {
  const [inv, pay, ret, invFailed, payFailed, retFailed] = await Promise.all([dbByIndex('invoices', 'syncStatus', 'pending'), dbByIndex('payments', 'syncStatus', 'pending'), dbByIndex('salesReturns', 'syncStatus', 'pending'), dbByIndex('invoices', 'syncStatus', 'failed'), dbByIndex('payments', 'syncStatus', 'failed'), dbByIndex('salesReturns', 'syncStatus', 'failed')]);
  state.pendingInvoices = inv.length;
  state.pendingPayments = pay.length;
  state.pendingReturns = ret.length;
  state.failedRecords = invFailed.length + payFailed.length + retFailed.length;
  publish();
  return getSyncStatus();
}

function publish() {
  bus.emit('sync:status', getSyncStatus());
}

/** Current sync status snapshot for the UI. */
export function getSyncStatus() {
  return {
    configured: !!(settings.get('syncUrl') && settings.get('syncToken')),
    enabled: !!settings.get('syncEnabled'),
    running: state.running,
    lastError: state.lastError,
    lastSyncAt: settings.get('lastSyncAt'),
    pending: state.pendingInvoices + state.pendingPayments + state.pendingReturns,
    pendingInvoices: state.pendingInvoices,
    pendingPayments: state.pendingPayments,
    pendingReturns: state.pendingReturns,
    failed: state.failedRecords,
    conflicts: state.conflicts,
    catalogPending: state.catalogPending,
    consecutiveFailures: state.failures,
    nextRetryAt: state.nextAttemptAt > Date.now() ? new Date(state.nextAttemptAt).toISOString() : '',
    batchSize: state.batch,
    catalogSupported: state.catalogSupported,
    notice: state.notice,
  };
}

/** Verify the URL + token by calling the script's "ping" action. Resolves with the server info. */
export async function testConnection({ url = settings.get('syncUrl'), token = settings.get('syncToken'), fetchImpl } = {}) {
  authorize('settings');
  if (!url || !token) throw new Error('Enter the Web App URL and the secret token first.');
  let res;
  try {
    res = await postToScript(url, { action: 'ping', token }, { fetchImpl });
  } catch (e) {
    throw new Error(redactSecrets(e?.message || String(e), [token, url]));
  }
  const caps = res.capabilities || [];
  state.catalogSupported = caps.length ? caps.includes('catalog') : state.catalogSupported;
  state.verifySupported = caps.length ? caps.includes('verify') : state.verifySupported;
  state.returnsSupported = caps.length ? caps.includes('returns') : state.returnsSupported;
  state.notice = caps.length && !caps.includes('catalog') ? 'Your Google script is an older version — update Code.gs to sync products, customers and stock.' : '';
  publish();
  return res;
}

// ---- sync log --------------------------------------------------------------------

/** Append one row to the sync log (never throws) and trim old rows. */
async function writeLog(entry) {
  try {
    await run(['syncLog'], 'readwrite', async (tx) => {
      await tx.put('syncLog', { id: uuid(), createdAt: monotonicNow().toISOString(), ...entry });
      const rows = await tx.getAll('syncLog');
      for (const id of logIdsToTrim(rows, LOG_KEEP)) await tx.delete('syncLog', id);
    });
  } catch {
    /* logging must never break syncing */
  }
}

/** Newest-first sync log rows. */
export async function getSyncLog(limit = 50) {
  authorize('settings');
  return (await dbAll('syncLog')).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit);
}

export async function clearSyncLog() {
  authorize('settings');
  await run(['syncLog'], 'readwrite', (tx) => tx.clear('syncLog'));
}

/**
 * The queue: invoices/payments that are still waiting (or were rejected), oldest first,
 * for the Sync health screen.
 * @returns {Promise<{kind:'invoice'|'payment', id:string, label:string, createdAt:string, status:string, error:string, attempts:number}[]>}
 */
export async function getQueue(limit = 100) {
  authorize('settings');
  const [inv, pay, ret] = await Promise.all([dbAll('invoices'), dbAll('payments'), dbAll('salesReturns')]);
  const waiting = (r) => r.syncStatus === 'pending' || r.syncStatus === 'failed';
  const rows = [
    ...inv.filter(waiting).map((i) => ({ kind: 'invoice', id: i.id, label: `${i.invoiceNo} · ${i.customerName}${i.status === 'void' ? ' (void)' : ''}`, createdAt: i.createdAt, status: i.syncStatus, error: i.syncError || '', attempts: i.syncAttempts || 0 })),
    ...pay.filter(waiting).map((p) => ({ kind: 'payment', id: p.id, label: `Payment · ${p.customerName}`, createdAt: p.createdAt, status: p.syncStatus, error: p.syncError || '', attempts: p.syncAttempts || 0 })),
    ...ret.filter(waiting).map((r) => ({ kind: 'return', id: r.id, label: `${r.returnNo} · ${r.customerName}`, createdAt: r.createdAt, status: r.syncStatus, error: r.syncError || '', attempts: r.syncAttempts || 0 })),
  ];
  return rows.sort((a, b) => a.createdAt.localeCompare(b.createdAt)).slice(0, limit);
}

// ---- helpers for marking results -------------------------------------------------

/** Mark a set of records as synced (or record an error on them). */
async function markResults(store, ids, patch) {
  await run([store], 'readwrite', async (tx) => {
    for (const id of ids) {
      const row = await tx.get(store, id);
      if (row) await tx.put(store, { ...row, ...patch(row) });
    }
  });
}

/** Count a network/timeout failure on the records of the batch that was in flight. */
async function noteAttempt(store, ids, message) {
  await markResults(store, ids, (r) => ({ syncAttempts: (r.syncAttempts || 0) + 1, syncError: safe(message).slice(0, 200) }));
}

// ---- catalog (products + customers) ----------------------------------------------

const catKey = (kind, id) => `catsync:${kind}:${id}`;

/** Products/customers whose payload differs from the last confirmed upload. */
async function changedCatalog() {
  const [products, cats, customers, invs, pays, rets, metas] = await Promise.all([dbAll('products'), dbAll('categories'), dbAll('customers'), dbAll('invoices'), dbAll('payments'), dbAll('salesReturns'), dbAll('meta')]);
  const seen = new Map(metas.filter((m) => m.key.startsWith('catsync:')).map((m) => [m.key, m.value]));
  const catName = new Map(cats.map((c) => [c.id, c.name]));
  const balance = computeBalances(invs, pays, rets); // the same single formula the whole app uses
  const device = await getDeviceId();
  const out = { products: [], customers: [] };
  for (const p of products) {
    const payload = buildProductPayload(p, catName.get(p.categoryId) || '', device);
    const hash = hashOf(payload);
    if (seen.get(catKey('p', p.id)) !== hash) out.products.push({ payload, hash });
  }
  for (const c of customers) {
    const payload = buildCustomerPayload(c, balance.get(c.id) || 0);
    const hash = hashOf(payload);
    if (seen.get(catKey('c', c.id)) !== hash) out.customers.push({ payload, hash });
  }
  return out;
}

/** Send changed products/customers; remember the hash of every record the server confirmed. */
async function syncCatalog(url, token, fetchImpl, out) {
  if (!settings.get('syncCatalog') || !state.catalogSupported) return;
  const changed = await changedCatalog();
  state.catalogPending = changed.products.length + changed.customers.length;
  for (const [kind, action, key, list] of [
    ['p', 'upsertProducts', 'products', changed.products],
    ['c', 'upsertCustomers', 'customers', changed.customers],
  ]) {
    for (let i = 0; i < list.length; i += CATALOG_BATCH) {
      const part = list.slice(i, i + CATALOG_BATCH);
      let res;
      try {
        res = await postToScript(url, { action, token, [key]: part.map((x) => x.payload) }, { fetchImpl });
      } catch (e) {
        if (isUnsupportedActionError(e.message)) {
          // Old Code.gs: not an error for the user's invoices — skip catalog sync and say why.
          state.catalogSupported = false;
          state.notice = 'Your Google script is an older version — update Code.gs to also sync products, customers and stock.';
          return;
        }
        throw e;
      }
      const okIds = new Set((res.results || []).filter((r) => ['inserted', 'updated', 'unchanged'].includes(r.result)).map((r) => r.id));
      if (kind === 'p') {
        const n = (res.results || []).filter((r) => r.conflict).length;
        if (n) {
          state.conflicts = n;
          state.notice = `Stock of ${n} product(s) in Google Sheets was last written by ANOTHER device. Each device keeps its own stock — see docs/SYNC.md before using two devices.`;
        }
      }
      await run(['meta'], 'readwrite', async (tx) => {
        for (const x of part) if (okIds.has(x.payload.id)) await tx.put('meta', { key: catKey(kind, x.payload.id), value: x.hash });
      });
      out.catalog += okIds.size;
      state.catalogPending = Math.max(0, state.catalogPending - okIds.size);
    }
  }
}

// ---- the sync run -------------------------------------------------------------------

/**
 * Upload everything that is pending. Safe to call at any time and from
 * multiple places — concurrent calls collapse into one.
 * @param {{fetchImpl?:typeof fetch, auto?:boolean}} [opts]
 *   `auto: true` = triggered by a timer/event, so exponential back-off is respected.
 * @returns {Promise<{sent:number, duplicates:number, catalog:number, failed:boolean, skipped?:string}>}
 */
export async function syncNow({ fetchImpl, auto = false } = {}) {
  const url = settings.get('syncUrl');
  const token = settings.get('syncToken');
  const idle = { sent: 0, duplicates: 0, catalog: 0, failed: false };
  if (!settings.get('syncEnabled') || !url || !token) {
    await refreshStatus();
    return idle;
  }
  if (state.running) return idle;
  if (auto && !isAttemptDue({ now: Date.now(), nextAttemptAt: state.nextAttemptAt, online: globalThis.navigator?.onLine !== false })) return { ...idle, skipped: 'backoff' };

  const exec = async () => {
    state.running = true;
    state.lastError = '';
    publish();
    const started = Date.now();
    const out = { sent: 0, duplicates: 0, catalog: 0, failed: false };
    let rejected = 0;
    try {
      // ---- invoices (oldest first so the sheet stays chronological) ----
      for (;;) {
        const pending = (await dbByIndex('invoices', 'syncStatus', 'pending')).sort((a, b) => a.createdAt.localeCompare(b.createdAt)).slice(0, state.batch);
        if (!pending.length) break;
        const payload = await run(['invoiceItems'], 'readonly', async (tx) => {
          const list = [];
          for (const inv of pending) list.push(buildInvoicePayload(inv, await tx.getInvoiceLines(inv.id)));
          return list;
        });
        // Remember which revision of every invoice goes out. If the invoice is voided WHILE this
        // request is in flight its revision changes, and it must stay `pending` so the void is sent next.
        const sentRev = new Map(pending.map((i) => [i.id, revOf(i)]));
        let res;
        try {
          res = await postToScript(url, { action: 'syncInvoices', token, invoices: payload }, { fetchImpl });
        } catch (e) {
          await noteAttempt('invoices', pending.map((p) => p.id), e?.name === 'AbortError' ? 'Timed out' : e?.message || 'Network error');
          if (e?.name === 'AbortError' && state.batch > 1) state.batch = Math.max(1, Math.floor(state.batch / 2)); // smaller requests on a weak network
          throw e;
        }
        const ok = new Set();
        const invalid = new Map();
        for (const r of res.results || []) {
          if (['inserted', 'duplicate', 'updated'].includes(r.result)) {
            ok.add(r.id);
            if (r.result === 'duplicate') out.duplicates += 1;
            else out.sent += 1;
          } else if (r.result === 'invalid') invalid.set(r.id, 'Rejected by server');
          else if (r.result === 'conflict') invalid.set(r.id, safe(r.message || 'Invoice number already used by another device — give each device its own Device code').slice(0, 160));
        }
        if (!ok.size && !invalid.size) throw new Error('Server accepted no invoices');
        await markResults('invoices', [...ok], (row) => (revOf(row) === sentRev.get(row.id) ? { syncStatus: 'synced', syncedAt: new Date().toISOString(), syncError: '' } : {}));
        if (invalid.size) {
          // Explicitly rejected: park them as 'failed' so they never block the queue (even if the whole batch was bad).
          rejected += invalid.size;
          await markResults('invoices', [...invalid.keys()], (r) => ({ syncStatus: 'failed', syncError: invalid.get(r.id), syncAttempts: (r.syncAttempts || 0) + 1 }));
        }
        if (state.batch < BATCH_MAX) state.batch += 1; // recover gradually after a smaller batch worked
      }
      // ---- customer payments ----
      for (;;) {
        const pending = (await dbByIndex('payments', 'syncStatus', 'pending')).sort((a, b) => a.createdAt.localeCompare(b.createdAt)).slice(0, 50);
        if (!pending.length) break;
        let res;
        try {
          res = await postToScript(url, { action: 'syncPayments', token, payments: pending.map(buildPaymentPayload) }, { fetchImpl });
        } catch (e) {
          await noteAttempt('payments', pending.map((p) => p.id), e?.message || 'Network error');
          throw e;
        }
        const ok = new Set((res.results || []).filter((r) => ['inserted', 'duplicate'].includes(r.result)).map((r) => r.id));
        const invalid = new Set((res.results || []).filter((r) => r.result === 'invalid').map((r) => r.id));
        if (!ok.size && !invalid.size) throw new Error('Server accepted no payments');
        await markResults('payments', [...ok], () => ({ syncStatus: 'synced', syncedAt: new Date().toISOString(), syncError: '' }));
        out.sent += ok.size;
        if (invalid.size) {
          rejected += invalid.size;
          await markResults('payments', [...invalid], (r) => ({ syncStatus: 'failed', syncError: 'Rejected by server', syncAttempts: (r.syncAttempts || 0) + 1 }));
        }
      }
      // ---- sales returns (an older Code.gs without "syncReturns" just leaves them pending, with a notice) ----
      while (state.returnsSupported) {
        const pending = (await dbByIndex('salesReturns', 'syncStatus', 'pending')).sort((a, b) => a.createdAt.localeCompare(b.createdAt)).slice(0, 50);
        if (!pending.length) break;
        let res;
        try {
          res = await postToScript(url, { action: 'syncReturns', token, returns: pending.map(buildReturnPayload) }, { fetchImpl });
        } catch (e) {
          if (isUnsupportedActionError(e.message)) {
            state.returnsSupported = false;
            state.notice = 'Your Google script is an older version — update Code.gs to also sync sales returns. They stay queued until then.';
            break;
          }
          await noteAttempt('salesReturns', pending.map((p) => p.id), e?.message || 'Network error');
          throw e;
        }
        const ok = new Set((res.results || []).filter((r) => ['inserted', 'duplicate'].includes(r.result)).map((r) => r.id));
        const invalid = new Set((res.results || []).filter((r) => r.result === 'invalid').map((r) => r.id));
        if (!ok.size && !invalid.size) throw new Error('Server accepted no returns');
        await markResults('salesReturns', [...ok], () => ({ syncStatus: 'synced', syncedAt: new Date().toISOString(), syncError: '' }));
        out.sent += ok.size;
        if (invalid.size) {
          rejected += invalid.size;
          await markResults('salesReturns', [...invalid], (r) => ({ syncStatus: 'failed', syncError: 'Rejected by server', syncAttempts: (r.syncAttempts || 0) + 1 }));
        }
      }
      // ---- products & customers (changed ones only) ----
      await syncCatalog(url, token, fetchImpl, out);

      state.lastRunAt = new Date().toISOString();
      state.failures = 0;
      state.nextAttemptAt = 0;
      await settings.set({ lastSyncAt: state.lastRunAt });
    } catch (err) {
      out.failed = true;
      state.lastError = err?.name === 'AbortError' ? 'Timed out — will retry' : safe(err);
      state.failures += 1;
      state.nextAttemptAt = Date.now() + retryDelayMs(state.failures, state.lastError); // Google quota errors wait at least 30 minutes
      // A network failure is normal when offline; records stay 'pending' and are retried.
    } finally {
      state.running = false;
      await refreshStatus();
    }
    if (out.sent || out.duplicates || out.catalog || out.failed || rejected) {
      await writeLog({ kind: 'sync', ok: !out.failed, sent: out.sent, duplicates: out.duplicates, catalog: out.catalog, rejected, ms: Date.now() - started, error: out.failed ? state.lastError : '', auto });
    }
    return out;
  };

  // Cross-tab mutual exclusion (no-op where Web Locks are unavailable, e.g. Node tests).
  if (globalThis.navigator?.locks?.request) {
    return globalThis.navigator.locks.request('pos-sync', { ifAvailable: true }, (lock) => (lock ? exec() : idle));
  }
  return exec();
}

/** Re-queue records that were flagged 'failed' (e.g. after fixing the script). */
export async function retryFailed({ fetchImpl } = {}) {
  authorize('settings');
  for (const store of ['invoices', 'payments', 'salesReturns']) {
    const failed = await dbByIndex(store, 'syncStatus', 'failed');
    await markResults(store, failed.map((f) => f.id), () => ({ syncStatus: 'pending', syncError: '' }));
  }
  state.failures = 0;
  state.nextAttemptAt = 0;
  await refreshStatus();
  return syncNow({ fetchImpl });
}

/**
 * Ask the server which of our already-uploaded invoices it really has, and
 * re-queue the missing ones (they are then uploaded again by the normal sync).
 * @returns {Promise<{checked:number, missing:number, unsupported?:boolean}>}
 */
export async function verifyUploaded({ fetchImpl } = {}) {
  authorize('settings');
  const url = settings.get('syncUrl');
  const token = settings.get('syncToken');
  if (!url || !token) throw new Error('Enter the Web App URL and the secret token first.');
  const synced = (await dbByIndex('invoices', 'syncStatus', 'synced')).filter((i) => i.status !== 'void');
  const started = Date.now();
  let missing = 0;
  try {
    for (let i = 0; i < synced.length; i += VERIFY_CHUNK) {
      const ids = synced.slice(i, i + VERIFY_CHUNK).map((x) => x.id);
      const res = await postToScript(url, { action: 'verifyInvoices', token, ids }, { fetchImpl });
      const gone = new Set(res.missing || []);
      if (gone.size) {
        missing += gone.size;
        await markResults('invoices', [...gone], () => ({ syncStatus: 'pending', syncError: 'Missing in Google Sheet — re-queued' }));
      }
    }
  } catch (e) {
    if (isUnsupportedActionError(e.message)) {
      state.verifySupported = false;
      return { checked: 0, missing: 0, unsupported: true };
    }
    throw new Error(safe(e));
  }
  await writeLog({ kind: 'verify', ok: true, sent: 0, duplicates: 0, catalog: 0, rejected: 0, checked: synced.length, missing, ms: Date.now() - started, error: '' });
  await refreshStatus();
  if (missing) await syncNow({ fetchImpl });
  return { checked: synced.length, missing };
}

/** Force the next catalog sync to resend every product and customer. */
export async function resetCatalogSync() {
  authorize('settings');
  await run(['meta'], 'readwrite', async (tx) => {
    for (const m of await tx.getAll('meta')) if (m.key.startsWith('catsync:')) await tx.delete('meta', m.key);
  });
  state.catalogSupported = true;
  state.notice = '';
  await refreshStatus();
}

/**
 * Start automatic syncing (idempotent). Call once at app start.
 */
export function startAutoSync() {
  if (state.timer || typeof window === 'undefined') return;
  const kick = () => {
    state.online = navigator.onLine;
    syncNow({ auto: true });
  };
  window.addEventListener('online', () => {
    state.nextAttemptAt = 0; // network is back: no reason to keep waiting
    kick();
  });
  window.addEventListener('offline', () => {
    state.online = false;
    publish();
  });
  document.addEventListener('visibilitychange', () => !document.hidden && kick());
  navigator.connection?.addEventListener?.('change', () => navigator.onLine && kick());
  bus.on('data:changed', ({ store } = {}) => {
    if (store === 'invoices' || store === 'payments' || store === 'products' || store === 'customers' || store === 'salesReturns' || store === '*') {
      refreshStatus().then(() => navigator.onLine && syncNow({ auto: true }));
    }
  });
  state.timer = setInterval(() => {
    if (navigator.onLine) syncNow({ auto: true });
  }, 60000);
  refreshStatus().then(kick);
}

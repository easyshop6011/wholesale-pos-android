/**
 * appearance.js — theme (auto/light/dark) and density (comfortable/compact).
 * The choice is mirrored into localStorage so index.html can apply it before the
 * first paint (no light-mode flash for dark-mode users).
 */
import { settings } from '../services/settings.js';
import { bus } from '../core/bus.js';

const KEY = 'pos:appearance';

export function applyAppearance() {
  const theme = settings.get('theme') || 'auto';
  const density = settings.get('density') || 'comfortable';
  const root = document.documentElement;
  if (theme === 'auto') root.removeAttribute('data-theme');
  else root.dataset.theme = theme;
  root.dataset.density = density;
  const dark = theme === 'dark' || (theme === 'auto' && matchMedia?.('(prefers-color-scheme: dark)').matches);
  document.querySelector('meta[name=theme-color]')?.setAttribute('content', dark ? '#181b30' : '#4f46e5');
  try {
    localStorage.setItem(KEY, JSON.stringify({ theme, density }));
  } catch {
    /* storage blocked — fine */
  }
}

export function startAppearance() {
  applyAppearance();
  bus.on('settings:changed', applyAppearance);
}

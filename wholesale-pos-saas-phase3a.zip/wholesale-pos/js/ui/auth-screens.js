/**
 * auth-screens.js — first-run setup wizard, sign-in form and the PIN lock screen.
 */
import { h, mount, icon } from './dom.js';
import { field, guard, toast } from './components.js';
import { auth } from '../services/auth.js';
import { settings } from '../services/settings.js';
import { seedDemoData } from '../services/demo.js';

const card = (...children) => h('div', { class: 'auth-wrap' }, h('div', { class: 'auth-card' }, children));

/** First run: business name, currency and the administrator account. */
export function renderSetup(root) {
  const f = {
    business: h('input', { class: 'input', value: settings.get('businessName'), required: true, autocomplete: 'organization' }),
    currency: h('input', { class: 'input', value: settings.get('currency'), maxlength: 6, required: true }),
    name: h('input', { class: 'input', placeholder: 'Your name', required: true, autocomplete: 'name' }),
    username: h('input', { class: 'input', value: 'admin', required: true, autocomplete: 'username', autocapitalize: 'none' }),
    password: h('input', { class: 'input', type: 'password', required: true, minlength: 6, autocomplete: 'new-password' }),
    password2: h('input', { class: 'input', type: 'password', required: true, autocomplete: 'new-password' }),
    pin: h('input', { class: 'input', type: 'password', inputmode: 'numeric', pattern: '\\d{4,6}', maxlength: 6, required: true, placeholder: '4–6 digits' }),
    demo: h('input', { type: 'checkbox' }),
  };
  const submit = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Create account & start');
  const form = h(
    'form',
    {
      class: 'stack',
      onsubmit: (e) => {
        e.preventDefault();
        if (f.password.value !== f.password2.value) return toast('Passwords do not match.', 'error');
        guard(async () => {
          // create (and sign in) the administrator FIRST — changing settings needs a signed-in user
          await auth.setupAdmin({ username: f.username.value.trim(), displayName: f.name.value.trim(), password: f.password.value, pin: f.pin.value });
          await settings.update({ businessName: f.business.value.trim() || 'My Wholesale Store', currency: f.currency.value.trim() || '৳' });
          if (f.demo.checked) await seedDemoData();
        }, submit);
      },
    },
    h('div', { class: 'auth-brand' }, h('div', { class: 'brand-mark lg' }, 'P'), h('h1', null, 'Welcome'), h('p', { class: 'muted' }, 'Set up your point of sale. Everything is stored on this device and works offline.')),
    field('Business name', f.business),
    h('div', { class: 'grid-2' }, field('Currency symbol', f.currency), field('Your name', f.name)),
    h('hr'),
    h('div', { class: 'field-label strong' }, 'Administrator account'),
    field('Username', f.username),
    h('div', { class: 'grid-2' }, field('Password (min 6)', f.password), field('Repeat password', f.password2)),
    field('Quick-unlock PIN', f.pin, 'Used to unlock the screen quickly.'),
    h('label', { class: 'check' }, f.demo, h('span', null, 'Load sample products & customers so I can try the app')),
    submit,
  );
  mount(root, card(form));
}

/** Sign-in with username and password. */
export function renderLogin(root) {
  const user = h('input', { class: 'input', autocomplete: 'username', autocapitalize: 'none', required: true, autofocus: true });
  const pass = h('input', { class: 'input', type: 'password', autocomplete: 'current-password', required: true });
  const btn = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Sign in');
  mount(
    root,
    card(
      h(
        'form',
        {
          class: 'stack',
          onsubmit: (e) => {
            e.preventDefault();
            guard(() => auth.login(user.value, pass.value), btn);
          },
        },
        h('div', { class: 'auth-brand' }, h('div', { class: 'brand-mark lg' }, 'P'), h('h1', null, settings.get('businessName')), h('p', { class: 'muted' }, 'Sign in to continue')),
        field('Username', user),
        field('Password', pass),
        btn,
      ),
    ),
  );
  setTimeout(() => user.focus(), 50);
}

/** Numeric keypad PIN screen shown after a cold start or when the screen locks. */
export function renderPinLock(root) {
  const me = auth.user();
  let target = me; // who is unlocking (the locked user, or another person at a shared counter)
  let pin = '';
  const heading = h('h1', null, `Hi, ${me.displayName}`);
  const usersRow = h('div', { class: 'lock-users' });
  const paintUsers = async () => {
    const all = await auth.loginChoices();
    if (all.length < 2) return;
    mount(usersRow, all.map((u) => h('button', { type: 'button', class: `lock-user ${u.id === target.id ? 'active' : ''}`, onclick: () => { target = u; pin = ''; msg.textContent = ''; heading.textContent = `Hi, ${u.displayName}`; paint(); paintUsers(); } }, h('span', { class: 'avatar', style: { width: '28px', height: '28px', fontSize: '13px' } }, u.displayName.slice(0, 1).toUpperCase()), u.displayName)));
  };
  const dots = h('div', { class: 'pin-dots', 'aria-live': 'polite' });
  const msg = h('div', { class: 'pin-msg' });
  const paint = () => {
    mount(dots, ...Array.from({ length: Math.max(4, pin.length) }, (_, i) => h('span', { class: i < pin.length ? 'on' : '' })));
  };
  const submit = async () => {
    if (pin.length < 4) return;
    try {
      if (target.id === me.id) await auth.unlock(pin);
      else await auth.switchUser(target.id, pin);
    } catch (e) {
      msg.textContent = e.message;
      pin = '';
      paint();
      dots.classList.add('shake');
      setTimeout(() => dots.classList.remove('shake'), 400);
    }
  };
  const press = (d) => {
    if (pin.length >= 6) return;
    msg.textContent = '';
    pin += d;
    paint();
  };
  const back = () => {
    pin = pin.slice(0, -1);
    paint();
  };
  const key = (label, onClick, cls = '') => h('button', { class: `key ${cls}`, type: 'button', onclick: onClick }, label);
  const keys = h(
    'div',
    { class: 'keypad' },
    ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => key(String(n), () => press(String(n)))),
    key('⌫', back, 'ghost'),
    key('0', () => press('0')),
    key(icon('check', 24), submit, 'ok'),
  );
  const onKey = (e) => {
    if (/^\d$/.test(e.key)) press(e.key);
    else if (e.key === 'Backspace') back();
    else if (e.key === 'Enter') submit();
  };
  document.addEventListener('keydown', onKey);
  const stop = new MutationObserver(() => {
    if (!document.body.contains(dots)) {
      document.removeEventListener('keydown', onKey);
      stop.disconnect();
    }
  });
  stop.observe(document.body, { childList: true, subtree: true });

  paint();
  paintUsers();
  mount(
    root,
    card(
      h('div', { class: 'auth-brand' }, h('div', { class: 'brand-mark lg' }, icon('lock', 28)), heading, h('p', { class: 'muted' }, 'Enter your PIN to unlock')),
      usersRow,
      dots,
      msg,
      keys,
      h('button', { class: 'btn btn-link', type: 'button', onclick: () => auth.logout() }, 'Sign in with password instead'),
    ),
  );
}

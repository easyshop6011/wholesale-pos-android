/**
 * chart-math.js — pure geometry/number helpers for the SVG charts (no DOM, so
 * they are unit-tested in Node).
 */

/**
 * A "nice" axis: round maximum and step so gridlines fall on 1/2/2.5/5 × 10ⁿ.
 * @param {number} max   largest data value (≥ 0)
 * @param {number} [target]  desired number of intervals
 * @returns {{max:number, step:number, ticks:number[]}}
 */
export function niceScale(max, target = 4) {
  const m = Number.isFinite(max) && max > 0 ? max : 1;
  const raw = m / target;
  const pow = 10 ** Math.floor(Math.log10(raw));
  const f = raw / pow;
  const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * pow;
  const top = Math.ceil(m / step - 1e-9) * step;
  const ticks = [];
  for (let v = 0; v <= top + step / 1e6; v += step) ticks.push(Math.round(v * 1e6) / 1e6);
  return { max: top, step, ticks };
}

/** Short number for axes: 950 → "950", 12 400 → "12.4k", 3 200 000 → "3.2M". */
export function compact(n) {
  const v = Number(n) || 0;
  const a = Math.abs(v);
  const f = (x) => String(Number(x.toFixed(x >= 100 ? 0 : x >= 10 ? 1 : 2)));
  if (a >= 1e9) return `${f(v / 1e9)}B`;
  if (a >= 1e6) return `${f(v / 1e6)}M`;
  if (a >= 1e3) return `${f(v / 1e3)}k`;
  return f(v);
}

/** Pixel position of index `i` of `n` points across [x0, x1] (one point = centred). */
export const xAt = (i, n, x0, x1) => (n <= 1 ? (x0 + x1) / 2 : x0 + ((x1 - x0) * i) / (n - 1));

/** Pixel y of `value` on a 0…max axis drawn between y0 (bottom) and y1 (top). */
export const yAt = (value, max, y0, y1) => (max > 0 ? y0 - ((y0 - y1) * value) / max : y0);

/**
 * SVG path for a line through points; `smooth` uses a monotone-ish curve that
 * never overshoots the data (control points share the neighbour's y level).
 */
export function linePath(points, smooth = true) {
  if (!points.length) return '';
  const r = (n) => Math.round(n * 100) / 100;
  let d = `M${r(points[0][0])},${r(points[0][1])}`;
  for (let i = 1; i < points.length; i++) {
    const [x0, y0] = points[i - 1];
    const [x1, y1] = points[i];
    if (smooth) {
      const mx = (x0 + x1) / 2;
      d += `C${r(mx)},${r(y0)} ${r(mx)},${r(y1)} ${r(x1)},${r(y1)}`;
    } else d += `L${r(x1)},${r(y1)}`;
  }
  return d;
}

/** Closed area path under a line down to `baseY`. */
export function areaPath(points, baseY, smooth = true) {
  if (!points.length) return '';
  const last = points[points.length - 1];
  return `${linePath(points, smooth)}L${Math.round(last[0] * 100) / 100},${baseY}L${Math.round(points[0][0] * 100) / 100},${baseY}Z`;
}

/** Index of the point whose x is nearest to `x`. */
export function nearestIndex(xs, x) {
  let best = 0;
  for (let i = 1; i < xs.length; i++) if (Math.abs(xs[i] - x) < Math.abs(xs[best] - x)) best = i;
  return best;
}

/**
 * Donut slices: each gets start/end angles (radians, 12 o'clock, clockwise) and
 * a percentage. Tiny slices are merged into "Other" so the ring stays readable.
 * @param {{label:string,value:number}[]} items
 * @param {{maxSlices?:number, minShare?:number}} [o]
 */
export function donutSlices(items, { maxSlices = 6, minShare = 0.03 } = {}) {
  const pos = items.filter((i) => i.value > 0).sort((a, b) => b.value - a.value);
  const total = pos.reduce((a, i) => a + i.value, 0);
  if (!total) return [];
  let keep = pos.filter((i, idx) => idx < maxSlices - 1 || pos.length <= maxSlices).filter((i) => i.value / total >= minShare || pos.length <= 2);
  const rest = pos.filter((i) => !keep.includes(i));
  if (rest.length) keep = [...keep, { label: 'Other', value: rest.reduce((a, i) => a + i.value, 0) }];
  let angle = 0;
  return keep.map((i) => {
    const share = i.value / total;
    const start = angle;
    angle += share * Math.PI * 2;
    return { ...i, share, pct: Math.round(share * 1000) / 10, start, end: angle };
  });
}

/** SVG arc path of a donut segment (outer radius R, inner radius r) around (cx, cy). */
export function arcPath(cx, cy, R, r, start, end) {
  const full = end - start >= Math.PI * 2 - 1e-6;
  const e = full ? start + Math.PI * 2 - 1e-4 : end;
  const pt = (rad, rr) => [cx + rr * Math.sin(rad), cy - rr * Math.cos(rad)];
  const [x1, y1] = pt(start, R);
  const [x2, y2] = pt(e, R);
  const [x3, y3] = pt(e, r);
  const [x4, y4] = pt(start, r);
  const large = e - start > Math.PI ? 1 : 0;
  const f = (n) => Math.round(n * 100) / 100;
  return `M${f(x1)},${f(y1)}A${R},${R} 0 ${large} 1 ${f(x2)},${f(y2)}L${f(x3)},${f(y3)}A${r},${r} 0 ${large} 0 ${f(x4)},${f(y4)}Z`;
}

/** Percentage change, or null when there is no base to compare with. */
export function pctChange(now, before) {
  if (!(before > 0)) return null;
  return Math.round(((now - before) / before) * 1000) / 10;
}

/** Choose at most `max` evenly spaced label indexes, always including the LAST (today) point. */
export function labelIndexes(n, max = 7) {
  if (n <= max) return Array.from({ length: n }, (_, i) => i);
  const step = Math.ceil((n - 1) / (max - 1));
  const out = [];
  for (let i = n - 1; i >= 0; i -= step) out.unshift(i);
  return out;
}

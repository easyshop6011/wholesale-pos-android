/**
 * charts.js — small dependency-free SVG charts that follow the app theme.
 *
 *   lineChart({ labels, series:[{label, values, color?}], format, area:true })
 *   barChart({ labels, series:[...], format, highlightLast:true })
 *   hBars([{label, value, sub}], { format })          // ranked list with bars (HTML)
 *   donut(items, { format, centre })                   // share of a whole + legend
 *   sparkline(values)                                  // tiny trend line
 *   delta(now, before)                                 // "▲ 12.5%" badge
 *
 * Charts measure their container and redraw when it is resized, hover/touch shows
 * a tooltip, and every chart has an aria-label plus a visually-hidden data summary.
 * All geometry lives in chart-math.js (unit-tested).
 */
import { h } from './dom.js';
import { niceScale, compact, xAt, yAt, linePath, areaPath, nearestIndex, donutSlices, arcPath, pctChange, labelIndexes } from './chart-math.js';

const NS = 'http://www.w3.org/2000/svg';
const COLORS = ['var(--c1)', 'var(--c2)', 'var(--c3)', 'var(--c4)', 'var(--c5)', 'var(--c6)'];

/** Create an SVG element with attributes. */
function s(tag, attrs = {}, ...kids) {
  const el = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) if (v !== undefined && v !== null) el.setAttribute(k, v);
  for (const k of kids.flat()) if (k) el.append(k);
  return el;
}
const text = (x, y, str, attrs = {}) => {
  const t = s('text', { x, y, ...attrs });
  t.textContent = str;
  return t;
};

/** Run `draw(width)` now and again whenever `box` changes width. */
function responsive(box, draw) {
  let last = 0;
  const paint = () => {
    const w = Math.floor(box.clientWidth || 0);
    if (!w || w === last) return;
    last = w;
    draw(w);
  };
  if (typeof ResizeObserver !== 'undefined') {
    const ro = new ResizeObserver(paint);
    ro.observe(box);
  }
  // first paint once attached; the observer covers later changes
  requestAnimationFrame(paint);
  setTimeout(paint, 60);
}

/** Visually hidden table of the numbers (screen readers, and a fallback). */
function srTable(labels, series, format) {
  return h(
    'table',
    { class: 'sr-only' },
    h('thead', null, h('tr', null, h('th', null, ''), series.map((x) => h('th', null, x.label)))),
    h('tbody', null, labels.map((l, i) => h('tr', null, h('td', null, l), series.map((x) => h('td', null, format(x.values[i])))))),
  );
}

/**
 * Shared cartesian plot: axes, gridlines, hover tooltip. `kind` is 'line' or 'bar'.
 * @param {{labels:string[], series:{label:string,values:number[],color?:string}[], format?:(n:number)=>string, kind:'line'|'bar', height?:number, area?:boolean, smooth?:boolean, highlightLast?:boolean, title?:string, tipTitle?:(i:number)=>string}} o
 */
function cartesian(o) {
  const { labels, series, kind, height = 220, format = (n) => compact(n), area = true, smooth = true, highlightLast = false, title = '', tipTitle = (i) => labels[i] } = o;
  const box = h('div', { class: 'chart', style: { height: `${height}px` } });
  const tip = h('div', { class: 'chart-tip hidden' });
  box.append(tip);
  if (!labels.length || series.every((x) => x.values.every((v) => !v))) {
    box.className = 'chart chart-empty';
    box.style.height = '';
    box.replaceChildren(h('div', { class: 'muted small' }, 'No data for this period.'));
    return box;
  }
  const draw = (W) => {
    const H = height;
    const pad = { l: 40, r: 10, t: 10, b: 24 };
    const maxV = Math.max(0, ...series.flatMap((x) => x.values));
    const scale = niceScale(maxV, H < 160 ? 3 : 4);
    const x0 = pad.l;
    const x1 = W - pad.r;
    const y0 = H - pad.b;
    const y1 = pad.t;
    const n = labels.length;
    const svg = s('svg', { width: W, height: H, viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': title || 'Chart' });
    // gridlines + y labels
    for (const t of scale.ticks) {
      const y = yAt(t, scale.max, y0, y1);
      svg.append(s('line', { x1: x0, x2: x1, y1: y, y2: y, class: t === 0 ? 'ax-base' : 'grid' }), text(x0 - 6, y + 4, compact(t), { class: 'ax', 'text-anchor': 'end' }));
    }
    // x labels
    const slot = kind === 'bar' ? (x1 - x0) / n : 0;
    const xPos = (i) => (kind === 'bar' ? x0 + slot * i + slot / 2 : xAt(i, n, x0 + 6, x1 - 6));
    const maxLabels = Math.max(2, Math.floor((x1 - x0) / 58));
    for (const i of labelIndexes(n, maxLabels)) svg.append(text(xPos(i), H - 6, labels[i], { class: 'ax', 'text-anchor': i === 0 && kind === 'line' ? 'start' : i === n - 1 && kind === 'line' ? 'end' : 'middle' }));
    const hit = [];
    if (kind === 'line') {
      series.forEach((sr, si) => {
        const color = sr.color || COLORS[si % COLORS.length];
        const pts = sr.values.map((v, i) => [xPos(i), yAt(v, scale.max, y0, y1)]);
        if (area && si === 0) {
          const gid = `g${Math.random().toString(36).slice(2, 8)}`;
          svg.append(s('defs', {}, s('linearGradient', { id: gid, x1: 0, x2: 0, y1: 0, y2: 1 }, s('stop', { offset: '0%', 'stop-color': color, 'stop-opacity': 0.28 }), s('stop', { offset: '100%', 'stop-color': color, 'stop-opacity': 0.02 }))));
          svg.append(s('path', { d: areaPath(pts, y0, smooth), fill: `url(#${gid})` }));
        }
        svg.append(s('path', { d: linePath(pts, smooth), class: 'ln', stroke: color }));
        if (n <= 31) for (const [px, py] of pts) svg.append(s('circle', { cx: px, cy: py, r: 2.6, fill: color, class: 'pt' }));
      });
    } else {
      const k = series.length;
      const bw = Math.min(34, (slot * 0.72) / k);
      series.forEach((sr, si) => {
        const color = sr.color || COLORS[si % COLORS.length];
        sr.values.forEach((v, i) => {
          const bh = Math.max(v > 0 ? 2 : 0, y0 - yAt(v, scale.max, y0, y1));
          const x = xPos(i) - (bw * k) / 2 + bw * si;
          const last = highlightLast && i === n - 1;
          svg.append(s('rect', { x, y: y0 - bh, width: Math.max(2, bw - 2), height: bh, rx: Math.min(5, bw / 3), fill: color, opacity: highlightLast && !last ? 0.45 : 1 }));
        });
      });
    }
    const cross = s('line', { y1, y2: y0, class: 'cross hidden' });
    svg.append(cross);
    box.querySelector('svg')?.remove();
    box.querySelector('.sr-only')?.remove();
    box.prepend(svg);
    box.append(srTable(labels, series, format));
    // hover / touch
    const xs = labels.map((_, i) => xPos(i));
    const show = (ev) => {
      const r = svg.getBoundingClientRect();
      const px = (ev.touches?.[0]?.clientX ?? ev.clientX) - r.left;
      const i = nearestIndex(xs, px);
      cross.setAttribute('x1', xs[i]);
      cross.setAttribute('x2', xs[i]);
      cross.classList.remove('hidden');
      tip.replaceChildren(h('div', { class: 'tip-title' }, tipTitle(i)), ...series.map((sr, si) => h('div', { class: 'tip-row' }, h('i', { style: { background: sr.color || COLORS[si % COLORS.length] } }), h('span', null, sr.label), h('b', null, format(sr.values[i])))));
      tip.classList.remove('hidden');
      const tw = tip.offsetWidth;
      tip.style.left = `${Math.max(4, Math.min(W - tw - 4, xs[i] - tw / 2))}px`;
    };
    const hide = () => {
      tip.classList.add('hidden');
      cross.classList.add('hidden');
    };
    svg.addEventListener('pointermove', show);
    svg.addEventListener('pointerdown', show);
    svg.addEventListener('pointerleave', hide);
    void hit;
  };
  responsive(box, draw);
  return box;
}

export const lineChart = (o) => cartesian({ ...o, kind: 'line' });
export const barChart = (o) => cartesian({ ...o, kind: 'bar', area: false });

/** Legend for multi-series charts. */
export function legend(series) {
  return h('div', { class: 'legend' }, series.map((x, i) => h('span', null, h('i', { style: { background: x.color || COLORS[i % COLORS.length] } }), x.label)));
}

/**
 * Ranked horizontal bars as plain HTML (wraps long names, no overflow on phones).
 * @param {{label:string, value:number, sub?:string, href?:string}[]} rows
 */
export function hBars(rows, { format = (n) => compact(n), color = 'var(--c1)', empty = 'No data for this period.' } = {}) {
  if (!rows.length) return h('div', { class: 'muted small pad' }, empty);
  const max = Math.max(...rows.map((r) => r.value), 1);
  return h(
    'ul',
    { class: 'hbars' },
    rows.map((r) =>
      h(
        r.href ? 'a' : 'li',
        { class: 'hbar', href: r.href },
        h('div', { class: 'hbar-top' }, h('span', { class: 'hbar-label' }, r.label), h('b', null, format(r.value))),
        h('div', { class: 'hbar-track' }, h('div', { class: 'hbar-fill', style: { width: `${Math.max(2, (r.value / max) * 100)}%`, background: color } })),
        r.sub ? h('div', { class: 'hbar-sub' }, r.sub) : null,
      ),
    ),
  );
}

/** Donut chart with a legend; `items` = [{label, value}]. */
export function donut(items, { format = (n) => compact(n), centre = '', centreSub = '', size = 168 } = {}) {
  const slices = donutSlices(items);
  if (!slices.length) return h('div', { class: 'muted small pad' }, 'No data for this period.');
  const R = size / 2 - 2;
  const r = R * 0.64;
  const c = size / 2;
  const svg = s('svg', { width: size, height: size, viewBox: `0 0 ${size} ${size}`, role: 'img', 'aria-label': slices.map((x) => `${x.label} ${x.pct}%`).join(', ') });
  slices.forEach((x, i) => svg.append(s('path', { d: arcPath(c, c, R, r, x.start, x.end), fill: COLORS[i % COLORS.length], class: 'slice' }, s('title', {}, `${x.label}: ${format(x.value)} (${x.pct}%)`))));
  if (centre) svg.append(text(c, c + 2, centre, { class: 'donut-c', 'text-anchor': 'middle' }), text(c, c + 18, centreSub, { class: 'ax', 'text-anchor': 'middle' }));
  return h(
    'div',
    { class: 'donut' },
    svg,
    h('ul', { class: 'donut-legend' }, slices.map((x, i) => h('li', null, h('i', { style: { background: COLORS[i % COLORS.length] } }), h('span', { class: 'grow truncate' }, x.label), h('b', null, `${x.pct}%`), h('span', { class: 'muted small' }, format(x.value))))),
  );
}

/** Tiny trend line for KPI tiles. */
export function sparkline(values, { width = 96, height = 30, color = 'var(--c1)' } = {}) {
  const n = values.length;
  if (n < 2 || values.every((v) => !v)) return h('span');
  const max = Math.max(...values, 1);
  const pts = values.map((v, i) => [xAt(i, n, 2, width - 2), yAt(v, max, height - 3, 3)]);
  return s('svg', { class: 'spark', width, height, viewBox: `0 0 ${width} ${height}`, 'aria-hidden': 'true' }, s('path', { d: areaPath(pts, height, true), fill: color, opacity: 0.14 }), s('path', { d: linePath(pts, true), class: 'ln', stroke: color }));
}

/** "▲ 12.5%" / "▼ 3%" badge comparing `now` with `before`. `inverse` = lower is better (e.g. dues). */
export function delta(now, before, { inverse = false, label = 'vs previous' } = {}) {
  const p = pctChange(now, before);
  if (p === null) return now > 0 ? h('span', { class: 'delta flat', title: label }, 'new') : h('span');
  if (p === 0) return h('span', { class: 'delta flat', title: label }, '＝ 0%');
  const good = inverse ? p < 0 : p > 0;
  return h('span', { class: `delta ${good ? 'up' : 'down'}`, title: label }, `${p > 0 ? '▲' : '▼'} ${Math.abs(p)}%`);
}

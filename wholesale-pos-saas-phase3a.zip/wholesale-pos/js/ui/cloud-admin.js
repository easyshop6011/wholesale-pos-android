/**
 * cloud-admin.js — the Super Admin's review panel: business applications by state, with approve / reject
 * (reason required) / suspend (reason required) / reinstate. Every button is one database function; the
 * SERVER decides whether the caller is really the platform administrator with two-step security.
 * (Counts, plans and system health come with the dashboard in the next step.)
 */
import { h, mount } from './dom.js';
import { segmented, badge, toast, promptDialog, confirmDialog } from './components.js';
import { t, nDigits } from '../core/i18n.js';
import { CloudError, errorText } from '../cloud/errors.js';
import { fmtDhakaDateTime } from '../core/datetime.js';
import * as actions from '../cloud/actions.js';

const KIND = { pending: 'warn', approved: 'ok', rejected: 'danger', suspended: 'danger' };
const TABS = ['pending', 'approved', 'rejected', 'suspended'];

async function attempt(fn) {
  try {
    await fn();
    return true;
  } catch (e) {
    if (!(e instanceof CloudError)) console.error(e);
    toast(errorText(e), 'error', 6000);
    return false;
  }
}

/**
 * @param {HTMLElement} root
 * @param {{client: object, onSignOut: () => void}} o
 */
export function renderAdminPanel(root, { client, onSignOut }) {
  let tab = 'pending';
  const list = h('div', { class: 'stack', dataset: { list: 'businesses' } });

  const card = (b) => {
    const row = (label, value) => (value ? [h('dt', null, label), h('dd', null, value)] : []);
    const act = (label, cls, key, handler) => h('button', { class: `btn btn-sm ${cls}`, type: 'button', dataset: { act: key }, onclick: handler }, label);
    const done = (key) => async (ok) => {
      if (ok) {
        toast(t(`admin.done.${key}`), 'success');
        await load();
      }
    };

    const buttons = [];
    if (b.status === 'pending') {
      buttons.push(
        act(t('admin.approve'), 'btn-primary', 'approve', async () => {
          if (await confirmDialog({ title: t('admin.approve'), message: b.name, confirmText: t('admin.approve'), cancelText: t('common.cancel') })) {
            await done('approve')(await attempt(() => actions.reviewBusiness(client, b.id, 'approve')));
          }
        }),
        act(t('admin.reject'), 'btn-danger', 'reject', async () => {
          const reason = await promptDialog({ title: t('admin.reject'), label: t('admin.reasonPrompt'), confirmText: t('admin.reject'), cancelText: t('common.cancel') });
          if (reason !== null) await done('reject')(await attempt(() => actions.reviewBusiness(client, b.id, 'reject', reason)));
        }),
      );
    } else if (b.status === 'approved') {
      buttons.push(
        act(t('admin.suspend'), 'btn-danger', 'suspend', async () => {
          const reason = await promptDialog({ title: t('admin.suspend'), label: t('admin.reasonPrompt'), confirmText: t('admin.suspend'), cancelText: t('common.cancel') });
          if (reason !== null) await done('suspend')(await attempt(() => actions.setSuspension(client, b.id, true, reason)));
        }),
      );
    } else if (b.status === 'suspended') {
      buttons.push(
        act(t('admin.reinstate'), 'btn-primary', 'reinstate', async () => {
          if (await confirmDialog({ title: t('admin.reinstate'), message: b.name, confirmText: t('admin.reinstate'), cancelText: t('common.cancel') })) {
            await done('reinstate')(await attempt(() => actions.setSuspension(client, b.id, false)));
          }
        }),
      );
    }

    return h(
      'div',
      { class: 'cloud-biz', dataset: { business: b.name } },
      h('div', { class: 'cloud-biz-head' }, h('h3', null, b.name), badge(t(`gate.status.${b.status}`), KIND[b.status] || 'neutral')),
      h(
        'dl',
        null,
        ...row(t('admin.owner'), [b.owner_name, b.owner?.email].filter(Boolean).join(' · ')),
        ...row(t('admin.phone'), nDigits(b.phone || '')),
        ...row(t('biz.address'), [b.address, b.district].filter(Boolean).join(', ')),
        ...row(t('biz.license'), b.trade_license),
        ...row(t('admin.submitted'), b.submitted_at ? nDigits(fmtDhakaDateTime(b.submitted_at)) : ''),
      ),
      b.status_reason ? h('div', { class: 'cloud-note' }, `${t('common.reason')}: ${b.status_reason}`) : null,
      buttons.length ? h('div', { class: 'cloud-actions' }, buttons) : null,
    );
  };

  async function load() {
    mount(list, h('p', { class: 'muted' }, t('common.loading')));
    try {
      const rows = await actions.listBusinesses(client, tab);
      mount(list, rows.length ? rows.map(card) : h('p', { class: 'muted', dataset: { empty: '1' } }, t('admin.empty')));
    } catch (e) {
      if (!(e instanceof CloudError)) console.error(e);
      mount(list, h('div', { class: 'cloud-note danger' }, errorText(e)));
    }
  }

  const tabs = segmented(TABS.map((v) => ({ value: v, label: t(`admin.tab.${v}`) })), tab, (v) => {
    tab = v;
    load();
  });

  mount(
    root,
    h(
      'div',
      { class: 'cloud-admin' },
      h('div', { class: 'cloud-admin-top' }, h('h2', null, `${t('admin.title')} — ${t('admin.review.title')}`), h('button', { class: 'btn btn-sm', type: 'button', dataset: { act: 'signout' }, onclick: onSignOut }, t('common.signOut'))),
      tabs,
      list,
    ),
  );
  load();
}

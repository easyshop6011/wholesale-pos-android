/**
 * cloud-screens.js — every screen of the SaaS start-up flow, in the active language (Bengali by default).
 *
 *   runCloudGate(root, cloud)  shows login / registration / e-mail code / password reset / business application /
 *   "waiting for approval" / rejected / suspended / MFA … until the SERVER says the person may use a business,
 *   then resolves with that answer. (Super Admins get the review panel instead and never resolve.)
 *
 * Nothing here decides who may do what: each screen only reports what the server answered
 * (see js/cloud/gate.js). Every control has a data-act attribute so tests do not depend on the language.
 */
import { h, mount } from './dom.js';
import { field, segmented, toast, openModal, badge } from './components.js';
import { t, fromBnDigits } from '../core/i18n.js';
import { CloudError, errorText } from '../cloud/errors.js';
import { readOAuthRedirect } from '../cloud/client.js';
import { resolveGate, recordLogin } from '../cloud/gate.js';
import * as actions from '../cloud/actions.js';
import { auth } from '../services/auth.js';
import { renderAdminPanel } from './cloud-admin.js';

const RESEND_SECONDS = 60;

function ensureStyles() {
  if (document.getElementById('cloud-css')) return;
  document.head.append(h('link', { id: 'cloud-css', rel: 'stylesheet', href: 'css/cloud.css' }));
}

// ---- small building blocks ------------------------------------------------------------------------------------
const wrap = (...children) => h('div', { class: 'auth-wrap' }, h('div', { class: 'auth-card' }, children));
const brand = (title, sub) => h('div', { class: 'auth-brand' }, h('div', { class: 'brand-mark lg' }, 'P'), h('h1', null, title), sub ? h('p', { class: 'muted' }, sub) : null);
const note = (text, kind = '') => h('div', { class: `cloud-note ${kind}`.trim(), role: kind === 'danger' ? 'alert' : 'status' }, text);
const linkBtn = (text, onclick, act) => h('button', { class: 'cloud-link', type: 'button', onclick, dataset: act ? { act } : undefined }, text);
const input = (name, props = {}) => h('input', { class: 'input', name, ...props });
const primary = (text, act) => h('button', { class: 'btn btn-primary btn-block', type: 'submit', dataset: { act } }, text);
const plain = (text, act, onclick) => h('button', { class: 'btn btn-block', type: 'button', dataset: { act }, onclick }, text);

/** Run a cloud action; a failure becomes a sentence in the person's language. Resolves the action's value (undefined on failure). */
async function run(fn, btn) {
  if (btn) btn.disabled = true;
  try {
    return await fn();
  } catch (e) {
    if (!(e instanceof CloudError)) console.error(e);
    toast(errorText(e), 'error', 6000);
    return undefined;
  } finally {
    if (btn) btn.disabled = false;
  }
}

function show(ctx, ...children) {
  for (const stop of ctx.cleanups.splice(0)) stop();
  mount(ctx.root, ...children);
}

// ---- the controller --------------------------------------------------------------------------------------------

/**
 * @param {HTMLElement} root
 * @param {{client: object, storage: object}} cloud
 * @returns {Promise<object>} the "ready" answer of resolveGate() plus `fresh` (true when the person just signed in)
 */
export function runCloudGate(root, cloud, env = {}) {
  ensureStyles();
  const ctx = {
    root,
    client: cloud.client,
    storage: cloud.storage,
    cleanups: [],
    fresh: false,
    navigate: env.navigate || ((url) => location.assign(url)),
    redirectTo: env.redirectTo || `${location.origin}${location.pathname}`,
  };
  return new Promise((resolve) => {
    ctx.done = resolve;
    start(ctx, env.search ?? location.search);
  });
}

async function start(ctx, search) {
  show(ctx, loadingScreen());
  const back = readOAuthRedirect(search);
  if (back.code || back.error) {
    history.replaceState(null, '', location.pathname + location.hash); // never leave the one-time code in the address bar
    if (back.code) {
      try {
        await ctx.client.auth.exchangeCode(back.code);
        ctx.fresh = true;
        await recordLogin(ctx.client, ctx.storage);
      } catch (e) {
        toast(errorText(e), 'error', 6000);
      }
    } else toast(t('err.unknown'), 'error', 6000);
  }
  await refresh(ctx);
}

async function refresh(ctx) {
  show(ctx, loadingScreen());
  let gate;
  try {
    gate = await resolveGate(ctx.client, { storage: ctx.storage });
  } catch (e) {
    if (!(e instanceof CloudError)) console.error(e);
    return show(ctx, wrap(brand(t('app.name')), note(errorText(e), 'danger'), plain(t('common.retry'), 'retry', () => refresh(ctx)), signOutLink(ctx)));
  }
  return route(ctx, gate);
}

function route(ctx, g) {
  switch (g.state) {
    case 'ready':
      return ctx.done({ ...g, fresh: ctx.fresh });
    case 'signed_out':
      return loginScreen(ctx);
    case 'no_business':
      return applyScreen(ctx, g);
    case 'pending':
      return pendingScreen(ctx, g);
    case 'rejected':
      return rejectedScreen(ctx, g);
    case 'suspended':
      return infoScreen(ctx, { state: g.state, title: t('gate.suspended.title'), text: t('gate.suspended.text', { name: g.business.name }), reason: g.business.status_reason, extra: t('gate.suspended.contact'), action: ['refresh', t('common.refresh')] });
    case 'member_disabled':
      return infoScreen(ctx, { state: g.state, title: t('gate.memberDisabled.title'), text: t('gate.memberDisabled.text', { name: g.business.name }), action: ['refresh', t('common.refresh')] });
    case 'account_disabled':
      return infoScreen(ctx, { state: g.state, title: t('gate.disabled.title'), text: t('gate.disabled.text') });
    case 'session_revoked':
      return infoScreen(ctx, { state: g.state, title: t('gate.revoked.title'), text: t('gate.revoked.text'), action: ['login', t('auth.login.submit')] });
    case 'offline_blocked':
      return infoScreen(ctx, { state: g.state, title: t('gate.offline.title'), text: t('gate.offline.text'), kind: 'warn', action: ['retry', t('common.retry')] });
    case 'mfa_enroll':
      return mfaEnrollScreen(ctx);
    case 'mfa_challenge':
      return mfaChallengeScreen(ctx);
    case 'super_admin':
      return renderAdminPanel(ctx.root, { client: ctx.client, onSignOut: () => signOut(ctx) });
    default:
      return infoScreen(ctx, { state: g.state, title: t('app.name'), text: t('err.unknown'), action: ['retry', t('common.retry')] });
  }
}

async function signOut(ctx) {
  await ctx.client.auth.signOut({ scope: 'local' });
  ctx.fresh = false;
  await refresh(ctx);
}
const signOutLink = (ctx) => h('div', { class: 'cloud-center' }, linkBtn(t('common.signOut'), () => signOut(ctx), 'signout'));
const loadingScreen = () => wrap(brand(t('app.name')), h('p', { class: 'muted cloud-center' }, t('common.loading')));

async function finishSignIn(ctx) {
  await recordLogin(ctx.client, ctx.storage);
  ctx.fresh = true;
}

// ---- sign in -----------------------------------------------------------------------------------------------------

async function startGoogle(ctx) {
  const { url } = await ctx.client.auth.signInWithGoogle({ redirectTo: ctx.redirectTo });
  ctx.navigate(url);
}

function loginScreen(ctx, { tab = 'password', email = '' } = {}) {
  let emailValue = email;
  const body = h('div', { class: 'stack' });
  const emailInput = () =>
    input('email', {
      type: 'email',
      required: true,
      autocomplete: 'email',
      inputmode: 'email',
      autocapitalize: 'none',
      placeholder: t('auth.email.placeholder'),
      value: emailValue,
      oninput: (e) => (emailValue = e.target.value),
    });

  function passwordForm() {
    const pass = input('password', { type: 'password', required: true, autocomplete: 'current-password' });
    const btn = primary(t('auth.login.submit'), 'login-submit');
    return h(
      'form',
      {
        class: 'stack',
        onsubmit: async (e) => {
          e.preventDefault();
          const address = emailValue.trim();
          const outcome = await run(async () => {
            try {
              await ctx.client.auth.signInWithPassword({ email: address, password: pass.value });
            } catch (err) {
              if (err.code === 'email_not_confirmed') {
                await ctx.client.auth.resendSignupCode({ email: address });
                return 'verify';
              }
              throw err;
            }
            await finishSignIn(ctx);
            return 'in';
          }, btn);
          if (outcome === 'in') await refresh(ctx);
          else if (outcome === 'verify') verifyScreen(ctx, { email: address, type: 'signup' });
        },
      },
      field(t('common.email'), emailInput()),
      field(t('common.password'), pass),
      btn,
      h('div', { class: 'cloud-center' }, linkBtn(t('auth.login.forgot'), () => forgotScreen(ctx, { email: emailValue }), 'forgot')),
    );
  }

  function otpForm() {
    const btn = primary(t('auth.otp.send'), 'otp-send');
    return h(
      'form',
      {
        class: 'stack',
        onsubmit: async (e) => {
          e.preventDefault();
          const address = emailValue.trim();
          const ok = await run(async () => {
            await ctx.client.auth.sendEmailOtp({ email: address });
            return true;
          }, btn);
          if (ok) verifyScreen(ctx, { email: address, type: 'email', info: t('auth.otp.sentInfo', { email: address }) });
        },
      },
      field(t('common.email'), emailInput()),
      btn,
    );
  }

  const renderBody = (which) => mount(body, which === 'otp' ? otpForm() : passwordForm());
  renderBody(tab);

  const googleBtn = h('button', { class: 'btn btn-block', type: 'button', dataset: { act: 'google' }, onclick: () => run(() => startGoogle(ctx), googleBtn) }, t('auth.login.google'));
  show(
    ctx,
    wrap(
      brand(t('app.name'), t('auth.login.subtitle')),
      googleBtn,
      h('div', { class: 'cloud-divider' }, t('common.or')),
      segmented([{ value: 'password', label: t('auth.login.tabPassword') }, { value: 'otp', label: t('auth.login.tabOtp') }], tab, renderBody),
      body,
      h('p', { class: 'cloud-center muted' }, `${t('auth.login.noAccount')} `, linkBtn(t('auth.login.registerLink'), () => registerScreen(ctx), 'register-link')),
    ),
  );
}

/** The 6-digit e-mail code screen shared by sign-up confirmation, code sign-in and password reset. */
function verifyScreen(ctx, { email, type, info = '' }) {
  const code = input('code', { class: 'input cloud-code', inputmode: 'numeric', autocomplete: 'one-time-code', required: true, maxlength: 14, placeholder: '······' });
  const btn = primary(t('auth.otp.verify'), 'verify-submit');
  const resend = plain('', 'resend');
  let left = RESEND_SECONDS;
  const paint = () => {
    resend.disabled = left > 0;
    resend.textContent = left > 0 ? t('auth.otp.resendWait', { s: left }) : t('auth.otp.resend');
  };
  paint();
  const timer = setInterval(() => {
    if (left > 0) {
      left -= 1;
      paint();
    }
  }, 1000);
  ctx.cleanups.push(() => clearInterval(timer));

  resend.onclick = async () => {
    const ok = await run(async () => {
      if (type === 'signup') await ctx.client.auth.resendSignupCode({ email });
      else if (type === 'recovery') await ctx.client.auth.sendPasswordReset({ email });
      else await ctx.client.auth.sendEmailOtp({ email });
      return true;
    }, resend);
    if (ok) {
      left = RESEND_SECONDS;
      paint();
      toast(t('auth.verify.resent'), 'success');
    }
  };

  show(
    ctx,
    wrap(
      brand(type === 'recovery' ? t('auth.reset.title') : t('auth.verify.title')),
      note(info || t('auth.verify.text', { email })),
      h(
        'form',
        {
          class: 'stack',
          onsubmit: async (e) => {
            e.preventDefault();
            const token = fromBnDigits(code.value).replace(/\D/g, ''); // Bengali digits are accepted
            if (token.length !== 6) return toast(t('err.otp_expired'), 'error', 5000);
            const ok = await run(async () => {
              await ctx.client.auth.verifyEmailOtp({ email, token, type });
              if (type !== 'recovery') await finishSignIn(ctx);
              return true;
            }, btn);
            if (!ok) return undefined;
            return type === 'recovery' ? newPasswordScreen(ctx) : refresh(ctx);
          },
        },
        field(t('auth.otp.codeLabel'), code),
        btn,
        resend,
      ),
      h('div', { class: 'cloud-center' }, linkBtn(t('auth.otp.changeEmail'), () => loginScreen(ctx, { email }), 'change-email')),
    ),
  );
  setTimeout(() => code.focus(), 50);
}

// ---- registration and password reset ------------------------------------------------------------------------

function registerScreen(ctx) {
  const f = {
    name: input('fullName', { required: true, autocomplete: 'name' }),
    email: input('email', { type: 'email', required: true, autocomplete: 'email', inputmode: 'email', autocapitalize: 'none', placeholder: t('auth.email.placeholder') }),
    pass: input('password', { type: 'password', required: true, minlength: 10, autocomplete: 'new-password' }),
    pass2: input('password2', { type: 'password', required: true, autocomplete: 'new-password' }),
  };
  const btn = primary(t('auth.register.submit'), 'register-submit');
  const googleBtn = h('button', { class: 'btn btn-block', type: 'button', dataset: { act: 'google' }, onclick: () => run(() => startGoogle(ctx), googleBtn) }, t('auth.login.google'));
  show(
    ctx,
    wrap(
      brand(t('auth.register.title'), t('auth.register.subtitle')),
      googleBtn,
      h('div', { class: 'cloud-divider' }, t('common.or')),
      h(
        'form',
        {
          class: 'stack',
          onsubmit: async (e) => {
            e.preventDefault();
            if (f.pass.value !== f.pass2.value) return toast(t('auth.register.mismatch'), 'error', 5000);
            const email = f.email.value.trim();
            const outcome = await run(async () => {
              const r = await ctx.client.auth.signUp({ email, password: f.pass.value, fullName: f.name.value.trim() });
              if (r.session) {
                await finishSignIn(ctx);
                return 'in';
              }
              return 'verify';
            }, btn);
            if (outcome === 'in') await refresh(ctx);
            else if (outcome === 'verify') verifyScreen(ctx, { email, type: 'signup' });
          },
        },
        field(t('auth.register.fullName'), f.name),
        field(t('common.email'), f.email),
        field(t('common.password'), f.pass, t('auth.register.passwordHint')),
        field(t('auth.register.password2'), f.pass2),
        btn,
      ),
      h('p', { class: 'cloud-center muted' }, `${t('auth.register.haveAccount')} `, linkBtn(t('auth.register.loginLink'), () => loginScreen(ctx), 'login-link')),
    ),
  );
}

function forgotScreen(ctx, { email = '' } = {}) {
  const mail = input('email', { type: 'email', required: true, autocomplete: 'email', inputmode: 'email', autocapitalize: 'none', value: email, placeholder: t('auth.email.placeholder') });
  const btn = primary(t('auth.otp.send'), 'reset-send');
  show(
    ctx,
    wrap(
      brand(t('auth.reset.title'), t('auth.reset.text')),
      h(
        'form',
        {
          class: 'stack',
          onsubmit: async (e) => {
            e.preventDefault();
            const address = mail.value.trim();
            const ok = await run(async () => {
              await ctx.client.auth.sendPasswordReset({ email: address });
              return true;
            }, btn);
            if (ok) verifyScreen(ctx, { email: address, type: 'recovery', info: t('auth.otp.sentInfo', { email: address }) });
          },
        },
        field(t('common.email'), mail),
        btn,
      ),
      h('div', { class: 'cloud-center' }, linkBtn(t('common.back'), () => loginScreen(ctx, { email }), 'back')),
    ),
  );
}

function newPasswordScreen(ctx) {
  const p1 = input('newPassword', { type: 'password', required: true, minlength: 10, autocomplete: 'new-password' });
  const p2 = input('password2', { type: 'password', required: true, autocomplete: 'new-password' });
  const btn = primary(t('auth.reset.submit'), 'newpass-submit');
  show(
    ctx,
    wrap(
      brand(t('auth.reset.title')),
      h(
        'form',
        {
          class: 'stack',
          onsubmit: async (e) => {
            e.preventDefault();
            if (p1.value !== p2.value) return toast(t('auth.register.mismatch'), 'error', 5000);
            const ok = await run(async () => {
              await ctx.client.auth.updatePassword(p1.value);
              await finishSignIn(ctx);
              return true;
            }, btn);
            if (ok) {
              toast(t('auth.reset.done'), 'success');
              await refresh(ctx);
            }
          },
        },
        field(t('auth.reset.newPassword'), p1, t('auth.register.passwordHint')),
        field(t('auth.register.password2'), p2),
        btn,
      ),
    ),
  );
}

// ---- the business application ---------------------------------------------------------------------------------------

function businessForm(init = {}) {
  const i = {
    name: input('bizName', { required: true, value: init.name || '', autocomplete: 'organization' }),
    ownerName: input('ownerName', { required: true, value: init.ownerName || '', autocomplete: 'name' }),
    phone: input('phone', { type: 'tel', required: true, inputmode: 'tel', value: init.phone || '', placeholder: t('biz.phoneHint'), autocomplete: 'tel' }),
    email: input('bizEmail', { type: 'email', value: init.email || '', autocomplete: 'email', autocapitalize: 'none' }),
    address: input('address', { value: init.address || '', autocomplete: 'street-address' }),
    district: input('district', { value: init.district || '' }),
    tradeLicense: input('license', { value: init.tradeLicense || '' }),
  };
  const optional = ` (${t('common.optional')})`;
  const values = () => Object.fromEntries(Object.entries(i).map(([k, el]) => [k, el.value]));
  return {
    nodes: [
      field(t('biz.name'), i.name),
      field(t('biz.owner'), i.ownerName),
      field(t('biz.phone'), i.phone, t('biz.phoneHint')),
      field(t('biz.email') + optional, i.email),
      field(t('biz.address'), i.address),
      field(t('biz.district'), i.district),
      field(t('biz.license') + optional, i.tradeLicense),
    ],
    values,
    problem() {
      const v = values();
      if (v.name.trim().length < 2) return t('err.invalid_name');
      if (v.ownerName.trim().length < 2) return t('err.invalid_owner_name');
      if (!actions.isBdMobile(v.phone)) return t('err.invalid_phone');
      return '';
    },
  };
}

function applyScreen(ctx, g) {
  const f = businessForm({ ownerName: g.user?.fullName || '' });
  const btn = primary(t('biz.apply.submit'), 'apply-submit');
  show(
    ctx,
    wrap(
      brand(t('biz.apply.title'), t('biz.apply.subtitle')),
      h(
        'form',
        {
          class: 'stack',
          onsubmit: async (e) => {
            e.preventDefault();
            const bad = f.problem();
            if (bad) return toast(bad, 'error', 5000);
            const ok = await run(async () => {
              await actions.registerBusiness(ctx.client, f.values());
              return true;
            }, btn);
            if (!ok) return undefined;
            toast(t('biz.apply.done'), 'success');
            return refresh(ctx);
          },
        },
        ...f.nodes,
        btn,
      ),
      signOutLink(ctx),
    ),
  );
}

function pendingScreen(ctx, g) {
  show(
    ctx,
    wrap(
      brand(t('gate.pending.title')),
      h('div', { class: 'cloud-center' }, badge(t('gate.status.pending'), 'warn')),
      note(t('gate.pending.text', { name: g.business.name }), 'warn'),
      plain(t('common.refresh'), 'refresh', () => refresh(ctx)),
      signOutLink(ctx),
    ),
  );
}

async function rejectedScreen(ctx, g) {
  show(ctx, loadingScreen());
  let row = {};
  try {
    row = (await ctx.client.select('businesses', { columns: 'id,name,owner_name,phone,email,address,district,trade_license', filters: { id: `eq.${g.business.business_id}` } }))[0] || {};
  } catch (e) {
    if (!(e instanceof CloudError)) console.error(e); // the form simply opens with what we know
  }
  const f = businessForm({ name: row.name ?? g.business.name, ownerName: row.owner_name, phone: row.phone, email: row.email || '', address: row.address, district: row.district, tradeLicense: row.trade_license });
  const btn = primary(t('gate.rejected.resubmit'), 'resubmit');
  show(
    ctx,
    wrap(
      brand(t('gate.rejected.title')),
      h('div', { class: 'cloud-center' }, badge(t('gate.status.rejected'), 'danger')),
      note(t('gate.rejected.text', { name: g.business.name }), 'danger'),
      g.business.status_reason ? note(`${t('gate.rejected.reason')}: ${g.business.status_reason}`) : null,
      h('p', { class: 'muted' }, t('gate.rejected.fix')),
      h(
        'form',
        {
          class: 'stack',
          onsubmit: async (e) => {
            e.preventDefault();
            const bad = f.problem();
            if (bad) return toast(bad, 'error', 5000);
            const ok = await run(async () => {
              await actions.updateApplication(ctx.client, g.business.business_id, f.values());
              await actions.resubmitBusiness(ctx.client, g.business.business_id);
              return true;
            }, btn);
            if (!ok) return undefined;
            toast(t('gate.rejected.done'), 'success');
            return refresh(ctx);
          },
        },
        ...f.nodes,
        btn,
      ),
      signOutLink(ctx),
    ),
  );
}

/** A plain explanation screen: suspended, disabled, revoked, offline-blocked … */
function infoScreen(ctx, { state, title, text, reason = '', extra = '', kind = 'danger', action }) {
  show(
    ctx,
    wrap(
      brand(title),
      note(text, kind),
      reason ? note(`${t('common.reason')}: ${reason}`) : null,
      extra ? h('p', { class: 'muted cloud-center' }, extra) : null,
      action ? plain(action[1], action[0], () => refresh(ctx)) : null,
      state === 'session_revoked' ? null : signOutLink(ctx),
    ),
  );
}

// ---- two-step security (TOTP) --------------------------------------------------------------------------------------

async function mfaEnrollScreen(ctx) {
  show(ctx, wrap(brand(t('mfa.enroll.title')), h('p', { class: 'muted cloud-center' }, t('common.loading'))));
  let e;
  try {
    e = await ctx.client.auth.mfa.enroll();
  } catch (err) {
    toast(errorText(err), 'error', 6000);
    return show(ctx, wrap(brand(t('mfa.enroll.title')), plain(t('common.retry'), 'retry', () => mfaEnrollScreen(ctx)), signOutLink(ctx)));
  }
  const code = input('code', { class: 'input cloud-code', inputmode: 'numeric', autocomplete: 'one-time-code', required: true, maxlength: 10, placeholder: '······' });
  const btn = primary(t('mfa.enroll.submit'), 'mfa-submit');
  return show(
    ctx,
    wrap(
      brand(t('mfa.enroll.title'), t('mfa.enroll.text')),
      e.qrCode ? h('img', { class: 'cloud-qr', src: e.qrCode, alt: 'QR' }) : null,
      h('div', { class: 'muted cloud-center' }, t('mfa.secret')),
      h('div', { class: 'cloud-secret', dataset: { secret: '1' } }, e.secret),
      h(
        'form',
        {
          class: 'stack',
          onsubmit: async (ev) => {
            ev.preventDefault();
            const ok = await run(async () => {
              await ctx.client.auth.mfa.verify({ factorId: e.factorId, code: fromBnDigits(code.value) });
              return true;
            }, btn);
            if (ok) await refresh(ctx);
          },
        },
        field(t('mfa.codeLabel'), code),
        btn,
      ),
      signOutLink(ctx),
    ),
  );
}

async function mfaChallengeScreen(ctx) {
  let factor;
  try {
    factor = (await ctx.client.auth.mfa.factors()).find((f) => f.type === 'totp' && f.status === 'verified');
  } catch (err) {
    toast(errorText(err), 'error', 6000);
  }
  if (!factor) return mfaEnrollScreen(ctx);
  const code = input('code', { class: 'input cloud-code', inputmode: 'numeric', autocomplete: 'one-time-code', required: true, maxlength: 10, placeholder: '······' });
  const btn = primary(t('mfa.challenge.submit'), 'mfa-submit');
  return show(
    ctx,
    wrap(
      brand(t('mfa.challenge.title'), t('mfa.challenge.text')),
      h(
        'form',
        {
          class: 'stack',
          onsubmit: async (ev) => {
            ev.preventDefault();
            const ok = await run(async () => {
              await ctx.client.auth.mfa.verify({ factorId: factor.id, code: fromBnDigits(code.value) });
              return true;
            }, btn);
            if (ok) await refresh(ctx);
          },
        },
        field(t('mfa.codeLabel'), code),
        btn,
      ),
      signOutLink(ctx),
    ),
  );
}

// ---- after the gate: quick-unlock PIN and the status pill -----------------------------------------------------------------

/** Cloud mode needs a quick-unlock PIN on this device (the screen lock asks for it). Resolves once it is set. */
export function requirePin() {
  return new Promise((resolve) => {
    const pin = input('pin', { type: 'password', inputmode: 'numeric', maxlength: 6, required: true, autocomplete: 'new-password' });
    const pin2 = input('pin2', { type: 'password', inputmode: 'numeric', maxlength: 6, required: true, autocomplete: 'new-password' });
    const btn = primary(t('pin.submit'), 'pin-submit');
    const modal = openModal({
      title: t('pin.title'),
      dismissable: false,
      content: h(
        'form',
        {
          class: 'stack',
          onsubmit: async (e) => {
            e.preventDefault();
            const a = fromBnDigits(pin.value);
            if (!/^\d{4,6}$/.test(a)) return toast(t('pin.invalid'), 'error', 5000);
            if (a !== fromBnDigits(pin2.value)) return toast(t('pin.mismatch'), 'error', 5000);
            btn.disabled = true;
            try {
              await auth.setOwnPin(a);
              toast(t('pin.done'), 'success');
              modal.close();
              resolve();
            } catch (err) {
              console.error(err);
              toast(err?.message || t('err.unknown'), 'error', 5000);
            } finally {
              btn.disabled = false;
            }
          },
        },
        h('p', { class: 'muted' }, t('pin.text')),
        field(t('pin.label'), pin),
        field(t('pin.label2'), pin2),
        btn,
      ),
    });
  });
}

/** A small pill when the data is read-only (subscription ended) or the answer comes from the last offline check. */
export function showStatusBanner(gate) {
  document.getElementById('cloud-banner')?.remove();
  const message = gate.readOnly ? t('gate.readonly') : gate.offline ? t('gate.offline.grace') : '';
  if (message) document.body.append(h('div', { id: 'cloud-banner', class: 'cloud-banner', role: 'status' }, message));
}

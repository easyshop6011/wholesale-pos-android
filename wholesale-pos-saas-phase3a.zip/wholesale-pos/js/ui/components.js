/**
 * components.js — reusable UI building blocks: toast, modal, confirm, form
 * fields, badges, empty states and file helpers.
 */
import { h, icon, mount, $ } from './dom.js';
import { ValidationError } from '../core/utils.js';

// ---- Toasts -----------------------------------------------------------------

/**
 * Show a short message. type: 'info' | 'success' | 'error'
 */
export function toast(message, type = 'info', ms = 3500) {
  const root = $('#toast-root');
  if (!root) return;
  const el = h('div', { class: `toast ${type}`, role: 'status' }, message);
  root.append(el);
  setTimeout(() => el.classList.add('out'), ms);
  setTimeout(() => el.remove(), ms + 400);
}

/** Show an error from a service: validation errors verbatim, others generically. */
export function showError(err) {
  if (!(err instanceof ValidationError)) console.error(err);
  toast(err?.message || 'Something went wrong', 'error', 5000);
}

/**
 * Run an async action, showing errors as toasts. Disables `btn` while running.
 * @returns {Promise<any|undefined>}
 */
export async function guard(fn, btn) {
  if (btn) btn.disabled = true;
  try {
    return await fn();
  } catch (e) {
    showError(e);
    return undefined;
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ---- Modal --------------------------------------------------------------------

/**
 * Open a modal dialog.
 * @param {{title:string, content:Node|Node[], actions?:Node[], size?:'sm'|'md'|'lg', dismissable?:boolean, onClose?:Function}} o
 * @returns {{close:Function, el:HTMLElement}}
 */
export function openModal({ title, content, actions = [], size = 'md', dismissable = true, onClose }) {
  const root = $('#modal-root');
  const prevFocus = document.activeElement;
  const close = () => {
    document.removeEventListener('keydown', onKey);
    overlay.remove();
    prevFocus?.focus?.();
    onClose?.();
  };
  const onKey = (e) => {
    if (e.key === 'Escape' && dismissable && root.lastElementChild === overlay) close();
  };
  const dialog = h(
    'div',
    { class: `modal modal-${size}`, role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
    h('div', { class: 'modal-head' }, h('h3', null, title), dismissable && h('button', { class: 'icon-btn', 'aria-label': 'Close', onclick: close }, icon('x'))),
    h('div', { class: 'modal-body' }, content),
    actions.length ? h('div', { class: 'modal-actions' }, actions) : null,
  );
  const overlay = h('div', { class: 'overlay', onmousedown: (e) => e.target === overlay && dismissable && close() }, dialog);
  root.append(overlay);
  document.addEventListener('keydown', onKey);
  setTimeout(() => dialog.querySelector('[autofocus],input:not([type=hidden]),select,textarea')?.focus(), 30);
  return { close, el: dialog };
}

/** Promise-based confirm dialog. Resolves true/false. */
export function confirmDialog({ title = 'Are you sure?', message, confirmText = 'Confirm', cancelText = 'Cancel', danger = false }) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => {
      if (!done) {
        done = true;
        resolve(v);
      }
    };
    const m = openModal({
      title,
      size: 'sm',
      content: h('p', { class: 'pre-wrap' }, message),
      onClose: () => finish(false),
      actions: [
        h('button', { class: 'btn', onclick: () => m.close() }, cancelText),
        h(
          'button',
          {
            class: `btn ${danger ? 'btn-danger' : 'btn-primary'}`,
            onclick: () => {
              finish(true);
              m.close();
            },
          },
          confirmText,
        ),
      ],
    });
  });
}

/**
 * Dialog with a single text/number input. Resolves the entered string or null.
 */
export function promptDialog({ title, label, value = '', type = 'text', placeholder = '', confirmText = 'OK', cancelText = 'Cancel' }) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => {
      if (!done) {
        done = true;
        resolve(v);
      }
    };
    const input = h('input', { type, value, placeholder, class: 'input', autofocus: true, inputmode: type === 'number' ? 'decimal' : undefined });
    const ok = () => {
      finish(input.value);
      m.close();
    };
    input.addEventListener('keydown', (e) => e.key === 'Enter' && ok());
    const m = openModal({
      title,
      size: 'sm',
      content: field(label, input),
      onClose: () => finish(null),
      actions: [h('button', { class: 'btn', onclick: () => m.close() }, cancelText), h('button', { class: 'btn btn-primary', onclick: ok }, confirmText)],
    });
  });
}

// ---- Forms --------------------------------------------------------------------

/** Label + control (+ optional hint) wrapper. */
export function field(label, control, hint) {
  return h('label', { class: 'field' }, h('span', { class: 'field-label' }, label), control, hint ? h('span', { class: 'field-hint' }, hint) : null);
}

/** <select> from [{value,label}] or plain strings. */
export function select(options, value, props = {}) {
  return h(
    'select',
    { class: 'input', value, ...props },
    options.map((o) => (typeof o === 'string' ? h('option', { value: o }, o) : h('option', { value: o.value }, o.label))),
  );
}

/** Pill-style toggle between options; calls onChange(value). */
export function segmented(options, value, onChange) {
  const wrap = h('div', { class: 'segmented', role: 'tablist' });
  const render = (cur) => {
    wrap.replaceChildren(
      ...options.map((o) =>
        h(
          'button',
          {
            class: o.value === cur ? 'active' : '',
            type: 'button',
            role: 'tab',
            'aria-selected': o.value === cur,
            onclick: () => {
              render(o.value);
              onChange(o.value);
            },
          },
          o.label,
        ),
      ),
    );
  };
  render(value);
  return wrap;
}

// ---- Misc ---------------------------------------------------------------------

export const badge = (text, kind = 'neutral') => h('span', { class: `badge badge-${kind}` }, text);

export const emptyState = (title, hint, action) => h('div', { class: 'empty' }, h('div', { class: 'empty-title' }, title), hint ? h('div', { class: 'muted' }, hint) : null, action || null);

export const pageHeader = (title, ...actions) => h('div', { class: 'page-head' }, h('h2', null, title), h('div', { class: 'page-actions' }, actions));

/** Search box with an icon. */
export function searchBox(placeholder, onInput, value = '') {
  const input = h('input', { type: 'search', class: 'input', placeholder, value, autocomplete: 'off', 'aria-label': placeholder });
  let t;
  input.addEventListener('input', () => {
    clearTimeout(t);
    t = setTimeout(() => onInput(input.value), 150);
  });
  return Object.assign(h('div', { class: 'searchbox' }, icon('search', 18), input), { input });
}

/** Blob -> base64 string (no data: prefix). */
function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1] || '');
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

/**
 * Save/share a file. In a browser it triggers a download; inside the Android
 * app (where blob downloads do not work) it writes the file to the app cache and
 * opens the Android share sheet so it can be saved to Files, Drive, WhatsApp…
 */
export async function downloadFile(filename, content, mime = 'text/plain') {
  const blob = content instanceof Blob ? content : new Blob([content], { type: `${mime};charset=utf-8` });
  const cap = globalThis.Capacitor;
  if (cap?.isNativePlatform?.() && cap.Plugins?.Filesystem && cap.Plugins?.Share) {
    const { uri } = await cap.Plugins.Filesystem.writeFile({ path: filename, data: await blobToBase64(blob), directory: 'CACHE' });
    await cap.Plugins.Share.share({ title: filename, url: uri, dialogTitle: 'Save or share file' });
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = h('a', { href: url, download: filename });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/** CSV download with a UTF-8 BOM so Excel reads Bengali/Unicode correctly. */
export function downloadCSV(filename, csvText) {
  return downloadFile(filename, `﻿${csvText}`, 'text/csv');
}

/** Prompt the user for a file and resolve its text (or null if cancelled). */
export function pickFile(accept) {
  return new Promise((resolve) => {
    const input = h('input', { type: 'file', accept, style: { display: 'none' } });
    input.addEventListener('change', async () => resolve(input.files[0] ? await input.files[0].text() : null));
    input.addEventListener('cancel', () => resolve(null));
    document.body.append(input);
    input.click();
    setTimeout(() => input.remove(), 60000);
  });
}

/** Placeholder shown while a view loads (stat tiles + two cards). */
export function skeleton() {
  return h('div', { class: 'view-inner' }, h('div', { class: 'sk sk-line w40' }), h('div', { class: 'sk-stats' }, [1, 2, 3, 4].map(() => h('div', { class: 'sk' }))), h('div', { class: 'card' }, h('div', { class: 'sk sk-line w60' }), h('div', { class: 'sk sk-box' })));
}

/** Call `fn` at most once per `ms` after the last call (collapses bursts of data:changed). */
export function debounce(fn, ms = 250) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}

/**
 * Filter bar used by the list screens.
 *   const fb = filterBar([
 *     { key: 'search', type: 'search', placeholder: 'Search…' },
 *     { key: 'status', type: 'select', label: 'Status', options: [{value:'',label:'Any'}, …] },
 *     { key: 'from', type: 'date', label: 'From', more: true },
 *     { key: 'min', type: 'number', label: 'Min total', more: true },
 *   ], { search: '' }, (values) => reload());
 * Fields marked `more` live in the collapsible "More filters" panel. Active
 * filters show as removable chips. `fb.values` is always the current state.
 */
export function filterBar(fields, initial = {}, onChange = () => {}) {
  const values = Object.fromEntries(fields.map((f) => [f.key, initial[f.key] ?? f.default ?? '']));
  const defaults = Object.fromEntries(fields.map((f) => [f.key, f.default ?? '']));
  const controls = {};
  const chips = h('div', { class: 'active-filters' });
  const morePanel = h('div', { class: 'filter-more' });
  const bar = h('div', { class: 'filters' });
  const moreBtn = h('button', { class: 'btn btn-sm', type: 'button', onclick: () => morePanel.classList.toggle('open') });
  let timer;
  const fire = (delay = 0) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      paintChips();
      onChange({ ...values });
    }, delay);
  };
  const labelOf = (f, v) => (f.type === 'select' ? f.options.find((o) => String(o.value) === String(v))?.label ?? v : f.type === 'date' ? v : v);

  for (const f of fields) {
    let el;
    if (f.type === 'search') {
      const sb = searchBox(f.placeholder || 'Search…', (v) => { values[f.key] = v; fire(0); }, values[f.key]);
      controls[f.key] = sb.input;
      el = sb;
    } else if (f.type === 'select') {
      el = h('select', { class: 'input', 'aria-label': f.label, title: f.label, onchange: (e) => { values[f.key] = e.target.value; fire(); } }, f.options.map((o) => h('option', { value: o.value }, o.label)));
      el.value = values[f.key];
      controls[f.key] = el;
    } else {
      el = h('input', { class: 'input', type: f.type, 'aria-label': f.label, placeholder: f.placeholder || '', inputmode: f.type === 'number' ? 'decimal' : undefined, value: values[f.key], oninput: (e) => { values[f.key] = e.target.value; fire(f.type === 'number' ? 300 : 0); } });
      controls[f.key] = el;
    }
    if (f.more) morePanel.append(h('label', null, f.label, el));
    else bar.append(el);
  }
  const hasMore = fields.some((f) => f.more);
  if (hasMore) bar.append(moreBtn);

  function activeKeys() {
    return fields.filter((f) => f.type !== 'search' && String(values[f.key]) !== String(defaults[f.key]));
  }
  function paintChips() {
    const act = activeKeys();
    const moreActive = act.filter((f) => f.more).length;
    mount(moreBtn, icon('settings', 16), moreActive ? `More filters (${moreActive})` : 'More filters');
    // (replaceChildren turns a `null` argument into the TEXT "null" — leave the missing "Clear all" button out instead)
    chips.replaceChildren(
      ...act.map((f) => h('button', { class: 'fchip', type: 'button', title: 'Remove filter', onclick: () => set(f.key, defaults[f.key]) }, `${f.label}: ${labelOf(f, values[f.key])}`, icon('x', 14))),
      ...(act.length > 1 || (act.length && values.search) ? [h('button', { class: 'btn btn-sm', type: 'button', onclick: () => reset() }, 'Clear all')] : []),
    );
    chips.classList.toggle('hidden', !chips.childNodes.length);
  }
  /** Set one filter programmatically. */
  function set(key, v, silent = false) {
    values[key] = v;
    const c = controls[key];
    if (c) c.value = v;
    if (!silent) fire();
    else paintChips();
  }
  function reset() {
    for (const f of fields) if (f.type !== 'search') values[f.key] = defaults[f.key], controls[f.key] && (controls[f.key].value = defaults[f.key]);
    fire();
  }
  paintChips();
  return { el: h('div', null, bar, morePanel, chips), values, set, reset };
}

/** Prev / Next pager. `onPage(newOffset)`. Hidden when everything fits on one page. */
export function pager({ total, offset, limit, onPage }) {
  if (total <= limit) return h('div');
  const page = Math.floor(offset / limit) + 1;
  const pages = Math.ceil(total / limit);
  return h(
    'div',
    { class: 'pager' },
    h('button', { class: 'btn btn-sm', disabled: offset <= 0, onclick: () => onPage(Math.max(0, offset - limit)) }, '← Prev'),
    h('span', null, `Page ${page} of ${pages}`),
    h('button', { class: 'btn btn-sm', disabled: offset + limit >= total, onclick: () => onPage(offset + limit) }, 'Next →'),
  );
}

/**
 * customer-dialogs.js — the add/edit customer and "receive payment" dialogs, shared by
 * the customer list, the customer profile and the New Sale screen.
 */
import { h } from './dom.js';
import { openModal, toast, guard, field, select } from './components.js';
import { saveCustomer, receivePayment } from '../services/customers.js';
import { PAYMENT_METHODS } from '../services/payment-methods.js';
import { money } from '../core/format.js';
import { uuid } from '../core/utils.js';

/** Add / edit dialog. Calls `onSaved(customer)` after saving. */
export function editCustomer(existing, onSaved) {
  const f = {
    name: h('input', { class: 'input', value: existing?.name || '', required: true, autofocus: true }),
    phone: h('input', { class: 'input', type: 'tel', inputmode: 'tel', value: existing?.phone || '' }),
    address: h('input', { class: 'input', value: existing?.address || '' }),
    notes: h('textarea', { class: 'input', rows: 2 }, existing?.notes || ''),
  };
  const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Save customer');
  const m = openModal({
    title: existing ? 'Edit customer' : 'Add customer',
    size: 'sm',
    content: h(
      'form',
      {
        class: 'stack',
        onsubmit: (e) => {
          e.preventDefault();
          guard(async () => {
            const c = await saveCustomer({ id: existing?.id, name: f.name.value, phone: f.phone.value, address: f.address.value, notes: f.notes.value });
            m.close();
            toast('Customer saved', 'success');
            onSaved?.(c);
          }, save);
        },
      },
      field('Name', f.name),
      field('Phone', f.phone),
      field('Address', f.address),
      field('Notes', f.notes),
      h('div', { class: 'modal-actions inline' }, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), save),
    ),
  });
}

/**
 * "Receive payment" dialog (reduces the customer's due). One `requestId` per dialog, so
 * a double tap on the button can never record the payment twice.
 */
export function paymentDialog(customer, due, onSaved) {
  const requestId = uuid();
  const amount = h('input', { class: 'input', inputmode: 'decimal', value: String(due), autofocus: true });
  const method = select(PAYMENT_METHODS.map((x) => ({ value: x.id, label: x.label })), 'cash');
  const note = h('input', { class: 'input', placeholder: 'e.g. receipt no., cheque no.' });
  const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Record payment');
  const m = openModal({
    title: `Receive payment — ${customer.name}`,
    size: 'sm',
    content: h(
      'form',
      {
        class: 'stack',
        onsubmit: (e) => {
          e.preventDefault();
          guard(async () => {
            await receivePayment({ customerId: customer.id, amount: amount.value, note: note.value, method: method.value, requestId });
            m.close();
            toast('Payment recorded', 'success');
            onSaved?.();
          }, save);
        },
      },
      h('div', { class: 'hint-box' }, `Outstanding due: ${money(due)}`),
      field('Amount received', amount),
      field('Paid by', method),
      field('Note', note),
      h('div', { class: 'modal-actions inline' }, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), save),
    ),
  });
}

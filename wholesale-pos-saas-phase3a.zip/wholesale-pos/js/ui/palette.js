/**
 * palette.js — the global search palette (Ctrl/⌘+K or the top-bar button).
 * One box searches products, customers and invoices; ↑/↓ + Enter or tap to open.
 */
import { h, icon } from './dom.js';
import { globalSearch } from '../services/globalsearch.js';
import { auth } from '../services/auth.js';
import { money, fmtDate, qty } from '../core/format.js';

let open = false;

/** Items shown as results: {group, title, sub, right, href} */
function flatten(res) {
  const items = [];
  for (const p of res.products) items.push({ group: 'Products', title: p.name, sub: p.sku || '', right: `${qty(p.stock)} ${p.unit || ''}`, href: `#/products?q=${encodeURIComponent(p.name)}`, search: ['products', p.name] });
  for (const c of res.customers) items.push({ group: 'Customers', title: c.name, sub: c.phone || '', right: '', href: `#/customers/${c.id}` });
  for (const i of res.invoices) items.push({ group: 'Invoices', title: i.invoiceNo, sub: `${i.customerName || ''} · ${fmtDate(i.date)}`, right: money(i.total), href: `#/invoices?q=${encodeURIComponent(i.invoiceNo)}` });
  return items;
}

export function openPalette(navigate) {
  if (open) return;
  open = true;
  const root = document.getElementById('modal-root');
  const input = h('input', { type: 'search', placeholder: 'Search products, customers, invoices…', autocomplete: 'off', 'aria-label': 'Search everything' });
  const results = h('div', { class: 'palette-res' }, h('div', { class: 'palette-hint' }, 'Type a name, phone number, SKU or invoice number.'));
  const box = h('div', { class: 'palette', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Search' }, h('div', { class: 'palette-in' }, icon('search', 20), input, h('kbd', null, 'Esc')), results);
  const overlay = h('div', { class: 'overlay palette-ov', onmousedown: (e) => e.target === overlay && close() }, box);
  let items = [];
  let sel = 0;
  let seq = 0;
  let timer;

  const close = () => {
    open = false;
    document.removeEventListener('keydown', onKey, true);
    overlay.remove();
  };
  const go = (it) => {
    close();
    navigate(it.href.replace(/^#\//, ''));
  };
  const paintSel = () => results.querySelectorAll('.palette-item').forEach((el, i) => {
    el.classList.toggle('sel', i === sel);
    if (i === sel) el.scrollIntoView({ block: 'nearest' });
  });
  const paint = () => {
    if (!items.length) return results.replaceChildren(h('div', { class: 'palette-hint' }, input.value.trim() ? 'No matches.' : 'Type a name, phone number, SKU or invoice number.'));
    const kids = [];
    let g = '';
    items.forEach((it, i) => {
      if (it.group !== g) kids.push(h('div', { class: 'palette-group' }, (g = it.group)));
      kids.push(h('button', { class: 'palette-item', type: 'button', onclick: () => go(it), onmousemove: () => { sel = i; paintSel(); } }, h('div', { class: 'grow' }, h('div', { class: 'strong truncate' }, it.title), it.sub ? h('div', { class: 'muted small truncate' }, it.sub) : null), it.right ? h('div', { class: 'strong small' }, it.right) : null));
    });
    results.replaceChildren(...kids);
    paintSel();
  };
  const onKey = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(items.length - 1, sel + 1); paintSel(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); paintSel(); }
    else if (e.key === 'Enter' && items[sel]) { e.preventDefault(); go(items[sel]); }
  };
  input.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const my = ++seq;
      const res = await globalSearch(input.value, { can: (p) => auth.can(p) });
      if (my !== seq) return; // a newer keystroke superseded this one
      items = flatten(res);
      sel = 0;
      paint();
    }, 120);
  });
  document.addEventListener('keydown', onKey, true);
  root.append(overlay);
  input.focus();
}

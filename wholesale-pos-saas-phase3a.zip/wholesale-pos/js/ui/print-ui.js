/**
 * print-ui.js — UI glue for printing: print an invoice with friendly errors and
 * show an on-screen receipt preview (the exact image that gets printed).
 */
import { h } from './dom.js';
import { openModal, toast, showError } from './components.js';
import { getInvoice } from '../services/sales.js';
import { printInvoice, PrinterError, currentTransport } from '../printing/printer.js';
import { buildReceiptModel } from '../printing/receipt.js';
import { renderReceiptCanvas } from '../printing/receipt-canvas.js';
import { settings } from '../services/settings.js';

/**
 * Print a saved invoice (by id or already-loaded object with items).
 * Never throws — shows a toast instead, so a printer problem can't lose a sale.
 * @returns {Promise<boolean>} true if the job was sent
 */
export async function printInvoiceUi(invoiceOrId) {
  try {
    const inv = typeof invoiceOrId === 'string' ? await getInvoice(invoiceOrId) : invoiceOrId;
    if (!inv) throw new PrinterError('Invoice not found.');
    await printInvoice(inv, inv.items);
    toast(currentTransport().id === 'browser' ? 'Print dialog opened' : 'Sent to printer', 'success');
    return true;
  } catch (e) {
    if (e instanceof PrinterError) toast(e.message, 'error', 6000);
    else showError(e);
    return false;
  }
}

/** Open a modal showing the receipt exactly as it will print, with a Print button. */
export async function previewInvoice(invoiceOrId) {
  const inv = typeof invoiceOrId === 'string' ? await getInvoice(invoiceOrId) : invoiceOrId;
  if (!inv) return;
  const model = buildReceiptModel(inv, inv.items, settings.all());
  const canvas = await renderReceiptCanvas(model, { width: settings.get('paperWidthDots') });
  canvas.className = 'receipt-canvas';
  const m = openModal({
    title: `Receipt ${inv.invoiceNo}`,
    size: 'sm',
    content: h('div', { class: 'receipt-preview' }, canvas),
    actions: [h('button', { class: 'btn', onclick: () => m.close() }, 'Close'), h('button', { class: 'btn btn-primary', onclick: () => printInvoiceUi(inv) }, 'Print')],
  });
}

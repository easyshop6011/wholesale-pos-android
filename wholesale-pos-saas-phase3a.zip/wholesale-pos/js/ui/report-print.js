/**
 * report-print.js — "print this list" for customer statements and the stock history.
 *
 * Builds a clean A4 sheet (business name, title, filters, summary, table) and prints
 * it with the browser's print dialog; every other part of the page is hidden by the
 * `body.print-report` rules in css/app.css. (Receipts for the thermal printer are a
 * different path — see printing/. Inside the Android app the system print dialog may
 * not be available: use "Export CSV" there.)
 */
import { h } from './dom.js';
import { settings } from '../services/settings.js';
import { fmtDateTime } from '../core/format.js';

/**
 * @param {{title:string, meta?:[string,string][], summary?:[string,string][], columns:{label:string, num?:boolean}[], rows:any[][], note?:string}} o
 * @returns {HTMLElement}
 */
export function reportSheet({ title, meta = [], summary = [], columns, rows, note = '' }) {
  return h(
    'div',
    { class: 'print-sheet' },
    h('div', { class: 'ps-head' }, h('div', { class: 'ps-biz' }, settings.get('businessName')), h('div', { class: 'ps-sub' }, [settings.get('address'), settings.get('phone')].filter(Boolean).join(' · '))),
    h('h1', null, title),
    meta.length ? h('dl', { class: 'ps-meta' }, meta.flatMap(([k, v]) => [h('dt', null, k), h('dd', null, v)])) : null,
    summary.length ? h('div', { class: 'ps-summary' }, summary.map(([k, v]) => h('div', null, h('span', null, k), h('b', null, v)))) : null,
    h(
      'table',
      { class: 'ps-table' },
      h('thead', null, h('tr', null, columns.map((c) => h('th', { class: c.num ? 'num' : '' }, c.label)))),
      h('tbody', null, rows.map((r) => h('tr', null, r.map((v, i) => h('td', { class: columns[i]?.num ? 'num' : '' }, v ?? ''))))),
    ),
    note ? h('p', { class: 'ps-note' }, note) : null,
    h('div', { class: 'ps-foot' }, `Printed ${fmtDateTime(new Date().toISOString())} (Asia/Dhaka)`),
  );
}

/** Show `sheet` alone on the page and open the print dialog; restores the page afterwards. */
export function printSheet(sheet) {
  document.body.append(sheet);
  document.body.classList.add('print-report');
  let finished = false;
  const done = () => {
    if (finished) return;
    finished = true;
    document.body.classList.remove('print-report');
    sheet.remove();
    window.removeEventListener('afterprint', done);
  };
  window.addEventListener('afterprint', done);
  try {
    window.print();
  } finally {
    // Some mobile webviews never fire `afterprint`; tidy up anyway.
    setTimeout(done, 120000);
  }
  return done;
}

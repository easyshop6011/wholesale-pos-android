/**
 * return-dialog.js — take goods back from an invoice.
 *
 * Shows every line with what was sold / already returned / can still come back, asks for
 * the quantities and a reason, and calls services/returns.js. The service puts the goods
 * back into stock (with a stock-history row), reduces what the customer owes first and
 * refunds only the rest. ONE requestId per dialog, so pressing the button twice returns
 * the goods once.
 */
import { h } from './dom.js';
import { openModal, toast, guard, field, select } from './components.js';
import { returnableLines, returnSale } from '../services/returns.js';
import { PAYMENT_METHODS } from '../services/payment-methods.js';
import { money, qty } from '../core/format.js';
import { uuid } from '../core/utils.js';

/**
 * @param {string} invoiceId
 * @param {() => void} [onDone]  called after a successful return
 */
export async function openReturnDialog(invoiceId, onDone) {
  const data = await returnableLines(invoiceId);
  if (!data) return toast('Invoice not found', 'error');
  const { invoice, lines } = data;
  if (lines.every((l) => l.remaining <= 0)) return toast('Everything on this invoice has already been returned.', 'info');
  const requestId = uuid();
  const inputs = new Map();
  const reason = h('input', { class: 'input', placeholder: 'e.g. damaged on delivery, wrong item', 'data-field': 'reason' });
  const method = select(PAYMENT_METHODS.map((x) => ({ value: x.id, label: x.label })), 'cash', { 'data-field': 'refund-method' });
  const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Take goods back');

  const rows = lines.map((l) => {
    const input = h('input', { class: 'input num-input', inputmode: 'decimal', placeholder: '0', disabled: l.remaining <= 0, 'aria-label': `Return quantity of ${l.name}`, 'data-item': l.id });
    inputs.set(l.id, input);
    return h('li', { class: 'return-line' }, h('div', { class: 'grow' }, h('div', { class: 'strong' }, l.name), h('div', { class: 'muted small' }, `sold ${qty(l.qty)} ${l.unit || ''} at ${money(l.unitPrice)}${l.returned ? ` · already returned ${qty(l.returned)}` : ''} · can return ${qty(l.remaining)}`)), input);
  });

  const m = openModal({
    title: `Take goods back — ${invoice.invoiceNo}`,
    size: 'md',
    content: h(
      'form',
      {
        class: 'stack',
        onsubmit: (e) => {
          e.preventDefault();
          guard(async () => {
            const items = [...inputs].map(([itemId, el]) => ({ itemId, qty: el.value })).filter((x) => String(x.qty).trim() !== '');
            const r = await returnSale({ invoiceId, items, reason: reason.value, refundMethod: method.value, requestId });
            m.close();
            toast(`${r.returnNo}: value ${money(r.amount)} — ${r.creditApplied > 0 ? `reduced the due by ${money(r.creditApplied)}` : ''}${r.creditApplied > 0 && r.refund > 0 ? ', ' : ''}${r.refund > 0 ? `refund ${money(r.refund)}` : ''}`.replace(/ — $/, ''), 'success', 6000);
            onDone?.(r);
          }, save);
        },
      },
      h('div', { class: 'hint-box' }, 'The goods go back into stock. What the customer still owes is reduced first; only the rest is refunded.'),
      h('ul', { class: 'list' }, rows),
      field('Reason', reason),
      field('Refund paid by (if any money goes back)', method),
      h('div', { class: 'modal-actions inline' }, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), save),
    ),
  });
}

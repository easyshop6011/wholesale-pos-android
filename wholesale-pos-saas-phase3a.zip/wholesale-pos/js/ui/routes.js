/**
 * routes.js — the route registry. To add a feature/page:
 *   1. create js/ui/views/<name>.js exporting `default async function render(root, ctx)`
 *      (optionally returning a cleanup function),
 *   2. add one entry below. Navigation, permissions and lazy loading come for free.
 *
 * `perm` is checked with auth.can(); `mobile: true` puts it in the bottom bar
 * (others go under "More").
 */
export const ROUTES = [
  { path: 'dashboard', label: 'Dashboard', icon: 'home', perm: 'dashboard', mobile: true, load: () => import('./views/dashboard.js') },
  { path: 'pos', label: 'New Sale', icon: 'cart', perm: 'pos', mobile: true, load: () => import('./views/pos.js') },
  { path: 'invoices', label: 'Invoices', icon: 'file', perm: 'invoices', mobile: true, load: () => import('./views/invoices.js') },
  { path: 'customers', label: 'Customers', icon: 'users', perm: 'customers', mobile: true, load: () => import('./views/customers.js') },
  { path: 'products', label: 'Products', icon: 'package', perm: 'products.view', load: () => import('./views/products.js') },
  { path: 'inventory', label: 'Inventory', icon: 'layers', perm: 'inventory.view', load: () => import('./views/inventory.js') },
  { path: 'stock-history', label: 'Stock History', icon: 'file', perm: 'inventory.view', load: () => import('./views/stock-history.js') },
  { path: 'reports', label: 'Reports', icon: 'chart', perm: 'reports', load: () => import('./views/reports.js') },
  { path: 'settings', label: 'Settings', icon: 'settings', perm: 'printer', load: () => import('./views/settings.js') },
];

export const DEFAULT_ROUTE = 'dashboard';

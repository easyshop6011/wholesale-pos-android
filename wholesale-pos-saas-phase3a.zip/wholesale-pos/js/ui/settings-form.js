/**
 * settings-form.js — shared building blocks of the Settings tabs.
 */
import { h } from './dom.js';
import { toast, guard, field, select } from './components.js';
import { settings } from '../services/settings.js';

// ---------------------------------------------------------------------------
// Small form builder: [{key,label,type,options,hint}] -> inputs + Save button.
// ---------------------------------------------------------------------------

/**
 * Build a settings form. Values are read back according to `type`:
 * text | password | number | textarea | check | select.
 * @returns {{el:HTMLElement, inputs:Record<string,HTMLElement>}}
 */
export function settingsForm(defs, { onSaved, extra } = {}) {
  const inputs = {};
  const controls = defs.map((d) => {
    const v = settings.get(d.key);
    let el;
    if (d.type === 'check') el = h('input', { type: 'checkbox', checked: !!v });
    else if (d.type === 'select') el = select(d.options, String(v));
    else if (d.type === 'textarea') el = h('textarea', { class: 'input', rows: d.rows || 2 }, v ?? '');
    else el = h('input', { class: 'input', type: d.type === 'number' ? 'text' : d.type || 'text', inputmode: d.type === 'number' ? 'decimal' : undefined, value: v ?? '', placeholder: d.placeholder || '', autocomplete: 'off' });
    inputs[d.key] = el;
    return d.type === 'check' ? h('label', { class: 'check' }, el, h('span', null, d.label, d.hint ? h('span', { class: 'field-hint' }, ` — ${d.hint}`) : null)) : field(d.label, el, d.hint);
  });
  const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Save settings');
  const el = h(
    'form',
    {
      class: 'stack',
      onsubmit: (e) => {
        e.preventDefault();
        guard(async () => {
          const patch = {};
          for (const d of defs) {
            const i = inputs[d.key];
            if (d.type === 'check') patch[d.key] = i.checked;
            else if (d.type === 'number') patch[d.key] = Number(String(i.value).replace(/,/g, '')) || 0;
            else if (d.type === 'select' && typeof settings.get(d.key) === 'number') patch[d.key] = Number(i.value);
            else if (d.type === 'select' && typeof settings.get(d.key) === 'boolean') patch[d.key] = i.value === 'true';
            else patch[d.key] = typeof i.value === 'string' && d.type !== 'textarea' ? i.value.trim() : i.value;
          }
          await settings.update(patch);
          toast('Settings saved', 'success');
          onSaved?.(patch);
        }, save);
      },
    },
    controls,
    extra || null,
    h('div', null, save),
  );
  return { el, inputs };
}

export const card = (title, ...children) => h('section', { class: 'card stack' }, title ? h('h3', null, title) : null, children);


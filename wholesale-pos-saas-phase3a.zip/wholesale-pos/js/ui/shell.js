/**
 * shell.js — the signed-in application frame (sidebar, top bar, bottom
 * navigation on phones) and the hash router that loads views into it.
 */
import { h, mount, icon } from './dom.js';
import { ROUTES, DEFAULT_ROUTE } from './routes.js';
import { auth, ROLES } from '../services/auth.js';
import { openPalette } from './palette.js';
import { settings } from '../services/settings.js';
import { bus } from '../core/bus.js';
import { getSyncStatus, syncNow, refreshStatus } from '../services/sync.js';
import { toast, showError, emptyState, skeleton } from './components.js';
import { fmtDate, fmtDateTime } from '../core/format.js';

let cleanup = null;
let offBus = [];

/** Parse "#/customers/abc" -> { path:'customers', params:['abc'] } */
function parseHash() {
  const raw = location.hash.replace(/^#\/?/, '') || DEFAULT_ROUTE;
  const [pathPart, qs = ''] = raw.split('?');
  const parts = pathPart.split('/').map(decodeURIComponent);
  return { path: parts[0], params: parts.slice(1), query: Object.fromEntries(new URLSearchParams(qs)) };
}

/** Navigate to a route path such as "customers/<id>". */
export function navigate(path) {
  location.hash = `#/${path}`;
}

/** Build and mount the shell into `root`; returns nothing. Call again to rebuild. */
export function mountShell(root) {
  offBus.forEach((off) => off());
  offBus = [];
  const user = auth.user();
  const allowed = ROUTES.filter((r) => auth.can(r.perm));

  const viewEl = h('main', { id: 'view', class: 'view', tabindex: '-1' });
  const syncChip = h('button', { class: 'chip', type: 'button', title: 'Sync status' });
  const moreMenu = h('div', { class: 'more-menu hidden' });

  const navLink = (r, cls = '') => h('a', { href: `#/${r.path}`, class: `nav-link ${cls}`, dataset: { path: r.path } }, icon(r.icon), h('span', null, r.label));

  const sidebar = h(
    'aside',
    { class: 'sidebar' },
    h('div', { class: 'brand' }, h('div', { class: 'brand-mark' }, 'P'), h('div', { class: 'brand-name', id: 'brand-name' }, settings.get('businessName'))),
    h('nav', { class: 'nav' }, allowed.map((r) => navLink(r))),
    h(
      'div',
      { class: 'side-user' },
      h('div', { class: 'avatar' }, (user.displayName || '?').slice(0, 1).toUpperCase()),
      h('div', { class: 'grow' }, h('div', { class: 'user-name' }, user.displayName), h('div', { class: 'muted small' }, ROLES[user.role]?.label || user.role)),
      h('button', { class: 'icon-btn', title: 'Lock screen', 'aria-label': 'Lock screen', onclick: () => auth.lock() }, icon('lock')),
      h('button', { class: 'icon-btn', title: 'Sign out', 'aria-label': 'Sign out', onclick: () => auth.logout() }, icon('logout')),
    ),
  );

  const top = h(
    'header',
    { class: 'topbar' },
    h('div', { class: 'top-title' }, h('span', { id: 'top-name' }, settings.get('businessName'))),
    h('button', { class: 'top-search', type: 'button', title: 'Search (Ctrl+K)', 'aria-label': 'Search', onclick: () => openPalette(navigate) }, icon('search', 18), h('span', { class: 't' }, 'Search'), h('kbd', { class: 't' }, 'Ctrl K')),
    syncChip,
    h('button', { class: 'icon-btn top-lock', title: 'Lock screen', 'aria-label': 'Lock screen', onclick: () => auth.lock() }, icon('lock')),
  );

  const mobileItems = allowed.filter((r) => r.mobile);
  const overflow = allowed.filter((r) => !r.mobile);
  const bottom = h(
    'nav',
    { class: 'bottom-nav' },
    mobileItems.map((r) => navLink(r, 'b')),
    overflow.length
      ? h(
          'button',
          {
            class: 'nav-link b',
            type: 'button',
            onclick: (e) => {
              e.stopPropagation();
              moreMenu.classList.toggle('hidden');
            },
          },
          icon('more'),
          h('span', null, 'More'),
        )
      : null,
  );
  moreMenu.append(
    ...overflow.map((r) => h('a', { href: `#/${r.path}`, class: 'nav-link', onclick: () => moreMenu.classList.add('hidden') }, icon(r.icon), h('span', null, r.label))),
    h('button', { class: 'nav-link', type: 'button', onclick: () => auth.logout() }, icon('logout'), h('span', null, 'Sign out')),
  );
  document.addEventListener('click', () => moreMenu.classList.add('hidden'));
  if (!window.__paletteKey) {
    window.__paletteKey = true;
    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' && document.body.dataset.screen === 'app') {
        e.preventDefault();
        openPalette(navigate);
      }
    });
  }

  mount(root, h('div', { class: 'shell' }, sidebar, h('div', { class: 'main' }, top, viewEl), bottom, moreMenu));

  // ---- sync chip ----
  const paintChip = (st = getSyncStatus()) => {
    let text;
    let kind;
    if (!st.configured) [text, kind] = ['Sync off', 'muted'];
    else if (st.running) [text, kind] = ['Syncing…', 'info'];
    else if (!navigator.onLine) [text, kind] = [st.pending ? `Offline · ${st.pending} pending` : 'Offline', 'warn'];
    else if (st.lastError) [text, kind] = [`Sync error · ${st.pending} pending`, 'danger'];
    else if (st.pending) [text, kind] = [`${st.pending} pending`, 'warn'];
    else [text, kind] = ['All synced', 'ok'];
    syncChip.className = `chip chip-${kind}`;
    mount(syncChip, icon('cloud', 16), h('span', null, text));
    syncChip.title = st.lastError || (st.lastSyncAt ? `Last sync: ${fmtDateTime(st.lastSyncAt)} (Asia/Dhaka)` : 'Sync status');
  };
  syncChip.onclick = async () => {
    const st = getSyncStatus();
    if (!st.configured) return navigate('settings');
    const r = await syncNow();
    if (r.failed) showError(new Error(getSyncStatus().lastError || 'Sync failed'));
    else toast(r.sent ? `Synced ${r.sent} record(s)` : 'Everything is up to date', 'success');
  };
  offBus.push(bus.on('sync:status', paintChip));
  window.addEventListener('online', () => paintChip());
  window.addEventListener('offline', () => paintChip());
  offBus.push(bus.on('settings:changed', () => {
    const n = settings.get('businessName');
    const a = document.getElementById('brand-name');
    const b = document.getElementById('top-name');
    if (a) a.textContent = n;
    if (b) b.textContent = n;
  }));
  refreshStatus().then(paintChip);

  // ---- router ----
  // A navigation can start while the previous one is still loading its module or fetching its data. Without a
  // token the SLOWER one would finish last and overwrite the page the user actually asked for (the URL says
  // "#/pos" while the screen still shows "Settings"). Each navigation takes a number; a superseded one stops
  // before touching the screen and disposes whatever it had already built.
  let routeSeq = 0;
  const route = async () => {
    const my = ++routeSeq;
    const { path, params, query } = parseHash();
    const def = allowed.find((r) => r.path === path) || allowed.find((r) => r.path === DEFAULT_ROUTE) || allowed[0];
    document.querySelectorAll('.nav-link[data-path]').forEach((a) => a.classList.toggle('active', a.dataset.path === def.path));
    moreMenu.classList.add('hidden');
    try {
      cleanup?.();
    } catch (e) {
      console.error(e);
    }
    cleanup = null;
    mount(viewEl, skeleton());
    try {
      const mod = await def.load();
      if (my !== routeSeq) return; // a newer navigation took over while the module was loading
      const content = h('div', { class: 'view-inner' });
      mount(viewEl, content);
      const dispose = (await mod.default(content, { params: def.path === path ? params : [], query: def.path === path ? query : {}, navigate })) || null;
      if (my !== routeSeq) {
        // superseded while it was rendering: its listeners must not leak, and its content is already off screen
        try {
          dispose?.();
        } catch (e) {
          console.error(e);
        }
        return;
      }
      cleanup = dispose;
      viewEl.scrollTop = 0;
      window.scrollTo(0, 0);
    } catch (e) {
      if (my !== routeSeq) return;
      console.error(e);
      mount(viewEl, emptyState('This page failed to load', e.message));
    }
  };
  window.onhashchange = route;
  route();
  // warm the other views in the background so navigation feels instant
  const idle = window.requestIdleCallback || ((f) => setTimeout(f, 1500));
  idle(() => allowed.forEach((r) => r.load().catch(() => {})));
}

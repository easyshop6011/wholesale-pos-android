/**
 * stock-ui.js — pieces shared by the Stock History page, the product profile and the
 * Inventory screen: the movement table, type badges and the three stock dialogs
 * (receive a delivery · correct a count · write off damaged goods).
 *
 * Every dialog creates ONE requestId when it opens, so tapping "Save" twice (or
 * submitting again after a slow save) can never move the stock twice.
 */
import { h } from './dom.js';
import { openModal, toast, guard, field, segmented, badge } from './components.js';
import { dataTable } from './table.js';
import { receiveStock, adjustStock, writeOffStock, movementsToCSV, MOVEMENT_TYPES } from '../services/inventory.js';
import { auth } from '../services/auth.js';
import { qty, money, fmtDateTime } from '../core/format.js';
import { uuid } from '../core/utils.js';
import { reportSheet } from './report-print.js';

const KIND = { created: 'neutral', initial: 'ok', receive: 'ok', sale: 'info', void: 'neutral', return: 'info', adjustment: 'warn', damage: 'danger' };

/** Coloured label for a movement type. */
export const typeBadge = (type) => badge(MOVEMENT_TYPES[type]?.label || type, KIND[type] || 'neutral');

/** Options for a "type" filter. */
export const TYPE_OPTIONS = [{ value: '', label: 'All changes' }, ...Object.entries(MOVEMENT_TYPES).map(([value, d]) => ({ value, label: d.label }))];

const signed = (n) => (n > 0 ? '+' : '') + qty(n);

/**
 * The stock-history table.
 * @param {object[]} rows  newest first
 * @param {{cost?:boolean, product?:boolean, empty?:string}} [o]  `product:false` hides the product column (product profile)
 */
export function movementTable(rows, { cost = false, product = true, empty = 'No stock changes recorded.' } = {}) {
  const cols = [
    { label: 'Date & time', value: (r) => r.createdAt, render: (r) => h('span', { class: 'nowrap', title: r.createdAt }, fmtDateTime(r.createdAt, { seconds: true })) },
    ...(product ? [{ label: 'Product', value: (r) => r.productName, render: (r) => h('div', null, h('a', { href: `#/products/${r.productId}`, class: 'strong' }, r.productName), r.productCode ? h('div', { class: 'muted small' }, r.productCode) : null) }] : []),
    { label: 'Action', value: (r) => r.type, render: (r) => typeBadge(r.type) },
    { label: 'Before', num: true, value: (r) => r.previousStock, render: (r) => (r.previousStock === undefined ? '—' : qty(r.previousStock)) },
    { label: 'Change', num: true, value: (r) => r.qty, render: (r) => h('span', { class: `strong ${r.qty < 0 ? 'neg' : r.qty > 0 ? 'ok-text' : ''}` }, r.type === 'created' ? '—' : signed(r.qty)) },
    { label: 'After', num: true, value: (r) => r.balance, render: (r) => h('b', null, qty(r.balance)) },
    { label: 'Reason / note', value: (r) => r.reason, render: (r) => h('span', null, r.reason || '—') },
    { label: 'Reference', value: (r) => r.refNo, render: (r) => r.refNo || '—' },
    { label: 'User', value: (r) => r.userName, render: (r) => r.userName || '—' },
    ...(cost ? [{ label: 'Cost / supplier / batch', value: (r) => r.unitCost, render: (r) => (r.unitCost != null || r.supplier || r.batchNo ? h('span', { class: 'small' }, [r.unitCost != null ? money(r.unitCost) : '', r.supplier, r.batchNo ? `batch ${r.batchNo}` : ''].filter(Boolean).join(' · ')) : '—') }] : []),
  ];
  return dataTable(cols, rows, { empty, rowClass: () => 'move-row', stack: true });
}

/** Rows for a printed stock-history sheet. */
export function movementSheet(rows, { title = 'Stock history', meta = [], cost = false } = {}) {
  const columns = [{ label: 'Date & time' }, { label: 'Product' }, { label: 'Action' }, { label: 'Before', num: true }, { label: 'Change', num: true }, { label: 'After', num: true }, { label: 'Reason' }, { label: 'Ref' }, { label: 'User' }, ...(cost ? [{ label: 'Cost / supplier / batch' }] : [])];
  return reportSheet({
    title,
    meta,
    columns,
    rows: rows.map((r) => [fmtDateTime(r.createdAt, { seconds: true }), r.productName, MOVEMENT_TYPES[r.type]?.label || r.type, r.previousStock ?? '', r.type === 'created' ? '' : signed(r.qty), qty(r.balance), r.reason || '', r.refNo || '', r.userName || '', ...(cost ? [[r.unitCost != null ? money(r.unitCost) : '', r.supplier, r.batchNo].filter(Boolean).join(' · ')] : [])]),
    note: 'Times are Asia/Dhaka. Rows are never edited or deleted; a correction is a new row.',
  });
}

export { movementsToCSV };

/** Shared dialog frame with a live "current → new balance" hint. */
function stockDialog({ title, product, extra, hintFor, submit, saveLabel }) {
  const requestId = uuid();
  const q = h('input', { class: 'input', inputmode: 'decimal', autofocus: true, placeholder: '0', 'data-field': 'qty' });
  const hint = h('div', { class: 'field-hint', 'data-field': 'hint' });
  const paint = () => {
    hint.textContent = hintFor(Number(String(q.value).replace(/,/g, '')) || 0);
  };
  q.addEventListener('input', paint);
  const save = h('button', { class: 'btn btn-primary', type: 'submit' }, saveLabel);
  const done = { fn: null };
  const m = openModal({
    title,
    size: 'sm',
    content: h(
      'form',
      {
        class: 'stack',
        onsubmit: (e) => {
          e.preventDefault();
          guard(async () => {
            const r = await submit({ qty: q.value, requestId });
            m.close();
            toast(r?.unchanged ? 'Stock already matches — nothing changed' : 'Stock updated', 'success');
            done.fn?.();
          }, save);
        },
      },
      field(`Quantity (${product.unit})`, q, hint),
      ...extra.nodes,
      h('div', { class: 'modal-actions inline' }, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), save),
    ),
  });
  paint();
  return { onDone: (fn) => { done.fn = fn; }, q };
}

/** Delivery: stock goes up; cost, supplier and batch are kept on the history row. */
export function receiveDialog(p, onDone) {
  const canCost = auth.can('reports.profit');
  const f = {
    cost: h('input', { class: 'input', inputmode: 'decimal', placeholder: p.costPrice ? String(p.costPrice) : '0.00', 'data-field': 'cost' }),
    supplier: h('input', { class: 'input', placeholder: 'Optional', 'data-field': 'supplier' }),
    batch: h('input', { class: 'input', placeholder: 'Optional · batch / lot no.', 'data-field': 'batch' }),
    note: h('input', { class: 'input', placeholder: 'e.g. purchase invoice no.', 'data-field': 'note' }),
    update: h('input', { type: 'checkbox' }),
  };
  const d = stockDialog({
    title: `Receive stock — ${p.name}`,
    product: p,
    saveLabel: 'Add to stock',
    hintFor: (n) => `Current ${qty(p.stock)} ${p.unit} → new balance ${qty(p.stock + n)} ${p.unit}`,
    submit: ({ qty: q, requestId }) => receiveStock({ productId: p.id, qty: q, unitCost: f.cost.value, supplier: f.supplier.value, batchNo: f.batch.value, note: f.note.value, updateCostPrice: f.update.checked, requestId }),
    extra: {
      nodes: [
        h('div', { class: 'grid-2' }, canCost ? field('Purchase cost / unit', f.cost) : null, field('Supplier', f.supplier)),
        field('Batch / lot', f.batch),
        field('Note', f.note),
        canCost ? h('label', { class: 'check' }, f.update, h('span', null, 'Also make this the product’s cost price')) : null,
      ].filter(Boolean),
    },
  });
  d.onDone(onDone);
}

/** Count correction: add, remove or set the exact counted quantity (writes a NEW history row). */
export function adjustDialog(p, onDone) {
  let mode = 'add';
  const reason = h('input', { class: 'input', placeholder: 'e.g. stock count, found extra', 'data-field': 'reason' });
  const seg = segmented([{ value: 'add', label: 'Add' }, { value: 'remove', label: 'Remove' }, { value: 'set', label: 'Set exact' }], mode, (v) => { mode = v; d.q.dispatchEvent(new Event('input')); });
  const d = stockDialog({
    title: `Correct stock — ${p.name}`,
    product: p,
    saveLabel: 'Save correction',
    hintFor: (n) => `Current ${qty(p.stock)} ${p.unit} → new balance ${qty(mode === 'add' ? p.stock + n : mode === 'remove' ? p.stock - n : n)} ${p.unit}`,
    submit: ({ qty: q, requestId }) => adjustStock({ productId: p.id, mode, qty: q, reason: reason.value, requestId }),
    extra: { nodes: [field('Reason', reason)] },
  });
  d.q.closest('form').prepend(seg);
  d.onDone(onDone);
}

/** Damaged / expired / lost goods: stock goes down. */
export function writeOffDialog(p, onDone) {
  const reason = h('input', { class: 'input', placeholder: 'e.g. water damage, expired', 'data-field': 'reason' });
  const d = stockDialog({
    title: `Damaged / lost — ${p.name}`,
    product: p,
    saveLabel: 'Write off',
    hintFor: (n) => `Current ${qty(p.stock)} ${p.unit} → new balance ${qty(p.stock - n)} ${p.unit}`,
    submit: ({ qty: q, requestId }) => writeOffStock({ productId: p.id, qty: q, reason: reason.value, requestId }),
    extra: { nodes: [field('What happened?', reason)] },
  });
  d.onDone(onDone);
}

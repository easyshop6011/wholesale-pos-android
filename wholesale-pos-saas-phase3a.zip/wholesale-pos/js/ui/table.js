/**
 * table.js — a tiny declarative table + CSV export used by reports and ledgers.
 *
 *   const cols = [
 *     { label: 'Product', value: (r) => r.name },
 *     { label: 'Revenue', num: true, value: (r) => r.revenue, render: (r) => money(r.revenue) },
 *   ];
 *   dataTable(cols, rows, { footer: ['Total', money(sum)] });
 *   downloadCSV('x.csv', tableToCSV(cols, rows));
 *
 * `value` is the raw cell value (used for CSV); `render` is the optional on-screen
 * formatting (may return a Node). `num: true` right-aligns the column.
 */
import { h } from './dom.js';
import { toCSV } from '../core/utils.js';
import { emptyState } from './components.js';

/**
 * @param {{label:string, num?:boolean, value:(row:any)=>any, render?:(row:any)=>any}[]} cols
 * @param {any[]} rows
 * @param {{footer?:any[], onRow?:(row:any)=>void, rowClass?:(row:any)=>string, empty?:string, stack?:boolean}} [opts]
 *   `stack: true` — on a phone every row becomes a small card ("Label  value" lines) instead of a sideways-scrolling row
 */
export function dataTable(cols, rows, { footer, onRow, rowClass, empty = 'Nothing to show.', stack = false } = {}) {
  if (!rows.length) return emptyState(empty);
  const cell = (c, r) => (c.render ? c.render(r) : c.value(r));
  return h(
    'div',
    { class: 'table-wrap' },
    h(
      'table',
      { class: `table${stack ? ' stack-sm' : ''}` },
      h('thead', null, h('tr', null, cols.map((c) => h('th', { class: c.num ? 'num' : '' }, c.label)))),
      h(
        'tbody',
        null,
        rows.map((r) =>
          h(
            'tr',
            { class: `${onRow ? 'click' : ''} ${rowClass ? rowClass(r) : ''}`.trim(), onclick: onRow ? () => onRow(r) : null },
            cols.map((c) => h('td', { class: c.num ? 'num' : '', 'data-label': stack ? c.label : null }, cell(c, r))),
          ),
        ),
      ),
      footer ? h('tfoot', null, h('tr', null, cols.map((c, i) => h('td', { class: c.num ? 'num' : '' }, footer[i] ?? '')))) : null,
    ),
  );
}

/** CSV text for the same columns/rows (header row + raw values). */
export function tableToCSV(cols, rows, footer) {
  const out = [cols.map((c) => c.label), ...rows.map((r) => cols.map((c) => c.value(r)))];
  if (footer) out.push(footer.map((f) => f ?? ''));
  return toCSV(out);
}

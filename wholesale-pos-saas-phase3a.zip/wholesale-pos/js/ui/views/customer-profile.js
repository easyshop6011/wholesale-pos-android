/**
 * customer-profile.js — one customer, completely: contact + IDs, totals, current due,
 * and the full audit-style history (every sale with its product lines, every payment,
 * every return, every void with its reason) — filterable by date, exportable as CSV
 * and printable as a statement.  Route: #/customers/<id>
 *
 * All numbers come from services/customers.js `customerProfile` (recomputed from the
 * real transactions each time); nothing here adds up money itself.
 */
import { h, mount, icon } from '../dom.js';
import { confirmDialog, toast, guard, badge, emptyState, downloadCSV, skeleton } from '../components.js';
import { customerProfile, customerHistoryToCSV, deleteCustomer } from '../../services/customers.js';
import { auth } from '../../services/auth.js';
import { methodLabel } from '../../services/payment-methods.js';
import { money, qty, fmtDate, fmtDateTime } from '../../core/format.js';
import { dateParts, addDays, monthRange } from '../../core/utils.js';
import { bus } from '../../core/bus.js';
import { editCustomer, paymentDialog } from '../customer-dialogs.js';
import { showInvoiceDetail } from './invoices.js';
import { printInvoiceUi } from '../print-ui.js';
import { reportSheet, printSheet } from '../report-print.js';

const STATE_BADGE = { paid: ['Paid', 'ok'], 'settled-later': ['Settled later', 'ok'], partial: ['Partly paid', 'warn'], unpaid: ['Unpaid', 'danger'], void: ['Void', 'danger'] };

/** A labelled number tile. */
const tile = (label, value, sub, cls = '', id = '') => h('div', { class: 'stat-tile' }, h('div', { class: 'stat-label' }, label), h('div', { class: `stat-value ${cls}`, 'data-stat': id }, value), sub ? h('div', { class: 'stat-sub' }, sub) : null);

/** Product lines of one invoice (name, qty, unit, price, discount share, net). */
function itemsTable(inv) {
  return h(
    'div',
    { class: 'table-wrap' },
    h(
      'table',
      { class: 'table compact' },
      h('thead', null, h('tr', null, ['Product', 'Qty', 'Unit', 'Unit price', 'Line total', 'Discount', 'Net'].map((t, i) => h('th', { class: i > 0 && i !== 2 ? 'num' : '' }, t)))),
      h(
        'tbody',
        null,
        inv.items.map((it) =>
          h('tr', null, h('td', null, it.name), h('td', { class: 'num' }, qty(it.qty)), h('td', null, it.unit || ''), h('td', { class: 'num' }, money(it.unitPrice)), h('td', { class: 'num' }, money(it.total)), h('td', { class: 'num' }, it.discountShare ? money(it.discountShare) : '—'), h('td', { class: 'num' }, money(it.net))),
        ),
      ),
    ),
  );
}

const kv = (pairs) => h('dl', { class: 'kv' }, pairs.flatMap(([k, v]) => [h('dt', null, k), h('dd', null, v)]));
const balanceLine = (e) => h('div', { class: 'hist-balance muted small' }, 'Balance after: ', h('b', { class: e.balance > 0 ? 'neg' : e.balance < 0 ? 'ok-text' : '' }, e.balance < 0 ? `${money(-e.balance)} credit` : money(e.balance)));

function entryView(e) {
  const when = fmtDateTime(e.at, { seconds: true });
  if (e.kind === 'invoice') {
    const inv = e.invoice;
    const [label, kind] = STATE_BADGE[inv.state] || ['', 'neutral'];
    return h(
      'article',
      { class: `hist-entry kind-invoice ${inv.status === 'void' ? 'void' : ''}`, 'data-kind': 'invoice', 'data-ref': inv.invoiceNo },
      h('div', { class: 'hist-head' }, h('div', null, h('div', { class: 'strong' }, inv.invoiceNo), h('div', { class: 'muted small' }, when)), h('div', { class: 'hist-right' }, badge(label, kind), h('div', { class: 'strong num' }, money(inv.total)))),
      kv([
        ['Paid at sale', `${money(inv.paid)}${inv.paid > 0 ? ` · ${methodLabel(inv.paymentMethod)}` : ''}`],
        ['Due at sale', money(inv.due)],
        ...(inv.status !== 'void' && inv.due > 0 ? [['Paid later (oldest first)', money(inv.laterPaid)], ['Still unpaid', h('b', { class: inv.remainingDue > 0 ? 'neg' : 'ok-text' }, money(inv.remainingDue))]] : []),
        ...(inv.discount ? [['Discount', money(inv.discount)]] : []),
        ['Cashier', inv.createdByName || '—'],
      ]),
      h('details', { class: 'hist-items' }, h('summary', null, `${inv.items.length} product${inv.items.length === 1 ? '' : 's'}`), itemsTable(inv)),
      h('div', { class: 'row gap hist-actions' }, h('button', { class: 'btn btn-sm', onclick: () => showInvoiceDetail(inv.id) }, 'Open'), h('button', { class: 'btn btn-sm', onclick: () => guard(() => printInvoiceUi(inv.id)) }, icon('printer', 16), 'Print')),
      balanceLine(e),
    );
  }
  if (e.kind === 'payment') {
    const p = e.payment;
    return h('article', { class: 'hist-entry kind-payment', 'data-kind': 'payment' }, h('div', { class: 'hist-head' }, h('div', null, h('div', { class: 'strong' }, 'Payment received'), h('div', { class: 'muted small' }, when)), h('div', { class: 'hist-right' }, h('div', { class: 'strong num ok-text' }, money(p.amount)))), kv([['Paid by', methodLabel(p.method)], ['Received by', p.userName || '—'], ...(p.note ? [['Note', p.note]] : [])]), balanceLine(e));
  }
  if (e.kind === 'return') {
    const r = e.return;
    return h(
      'article',
      { class: 'hist-entry kind-return', 'data-kind': 'return', 'data-ref': r.returnNo },
      h('div', { class: 'hist-head' }, h('div', null, h('div', { class: 'strong' }, `Goods returned · ${r.returnNo}`), h('div', { class: 'muted small' }, when)), h('div', { class: 'hist-right' }, badge('Return', 'info'), h('div', { class: 'strong num' }, money(r.amount)))),
      kv([['From invoice', r.invoiceNo], ['Reason', r.reason], ['Reduced the due by', money(r.creditApplied)], ['Refunded in cash', `${money(r.refund)}${r.refund > 0 ? ` · ${methodLabel(r.refundMethod)}` : ''}`], ['By', r.createdByName || '—']]),
      h('ul', { class: 'hist-lines' }, r.items.map((it) => h('li', null, `${qty(it.qty)} ${it.unit || ''} × ${it.name} — ${money(it.amount)}`.replace(/\s+/g, ' ')))),
      balanceLine(e),
    );
  }
  const v = e.void;
  return h(
    'article',
    { class: 'hist-entry kind-void void', 'data-kind': 'void', 'data-ref': e.ref },
    h('div', { class: 'hist-head' }, h('div', null, h('div', { class: 'strong' }, `Invoice ${e.ref} voided`), h('div', { class: 'muted small' }, when)), h('div', { class: 'hist-right' }, badge('Void', 'danger'))),
    kv([['Reason', v.reason || '—'], ['Voided by', v.by || '—'], ['Removed from the due', money(e.credit)], ...(v.refundOwed > 0 ? [['Paid at sale — give back', h('b', { class: 'neg' }, money(v.refundOwed))]] : [])]),
    balanceLine(e),
  );
}

/** Plain-text rows of the history for the printed statement. */
function statementRows(entries) {
  return [...entries].reverse().map((e) => {
    const when = fmtDateTime(e.at);
    if (e.kind === 'invoice') return [when, 'Invoice', e.invoice.invoiceNo + (e.invoice.status === 'void' ? ' (void)' : ''), e.invoice.items.map((i) => `${i.name} ×${qty(i.qty)}`).join(', '), e.invoice.due ? money(e.invoice.due) : '', e.invoice.paid ? `${money(e.invoice.paid)} at sale` : '', money(e.balance)];
    if (e.kind === 'payment') return [when, 'Payment', methodLabel(e.payment.method), e.payment.note || '', '', money(e.payment.amount), money(e.balance)];
    if (e.kind === 'return') return [when, 'Return', e.return.returnNo, `${e.return.items.map((i) => `${i.name} ×${qty(i.qty)}`).join(', ')} — ${e.return.reason}`, '', money(e.return.creditApplied), money(e.balance)];
    return [when, 'Void', e.ref, e.void.reason, '', money(e.credit), money(e.balance)];
  });
}

/** Open the full profile of customer `id` in `root`. Returns the cleanup function. */
export async function renderProfile(root, id, ctx) {
  const range = { from: '', to: '' };
  let data = null;
  const head = h('div');
  const list = h('section', { class: 'card hist-list' });
  const meta = h('div', { class: 'result-meta' });

  const from = h('input', { class: 'input', type: 'date', 'aria-label': 'From date', value: '', onchange: () => apply() });
  const to = h('input', { class: 'input', type: 'date', 'aria-label': 'To date', value: '', onchange: () => apply() });
  const apply = () => {
    range.from = from.value;
    range.to = to.value;
    load();
  };
  const quick = (label, f, t) => h('button', { class: 'btn btn-sm', type: 'button', onclick: () => { from.value = f; to.value = t; apply(); } }, label);
  const today = () => dateParts().date;
  const filters = h(
    'div',
    { class: 'card filter-card' },
    h('div', { class: 'filters' }, h('label', { class: 'inline-field' }, 'From', from), h('label', { class: 'inline-field' }, 'To', to), quick('This month', monthRange(dateParts().month).from, today()), quick('Last 30 days', addDays(today(), -29), today()), quick('All time', '', '')),
  );

  mount(root, h('p', null, h('a', { href: '#/customers' }, '← All customers')), head, filters, meta, list);
  mount(head, skeleton());

  let seq = 0;
  async function load() {
    const my = ++seq;
    let d;
    try {
      d = await customerProfile(id, range);
    } catch (e) {
      if (my !== seq) return;
      return mount(root, emptyState('Customer not found', e?.message, h('a', { class: 'btn', href: '#/customers' }, 'Back')));
    }
    if (my !== seq) return;
    data = d;
    paint();
  }

  function paint() {
    const { customer: c, summary: s, period, entries } = data;
    const credit = s.currentDue < 0;
    mount(
      head,
      h(
        'div',
        { class: 'card profile-card' },
        h(
          'div',
          { class: 'card-head' },
          h(
            'div',
            null,
            h('h2', null, c.name, ' ', c.code ? badge(c.code, 'info') : null),
            h('div', { class: 'muted' }, [c.phone, c.address].filter(Boolean).join(' · ') || 'No contact details'),
            h('div', { class: 'muted small id-line' }, 'Customer ID: ', h('code', { 'data-field': 'customer-id' }, c.id), c.notes ? ` · ${c.notes}` : ''),
          ),
          h(
            'div',
            { class: 'page-actions' },
            h('button', { class: 'btn btn-sm', onclick: () => editCustomer(c, () => load()) }, icon('edit', 16), 'Edit'),
            auth.can('customers.delete') ? h('button', { class: 'btn btn-sm', onclick: async () => { if (await confirmDialog({ title: 'Delete customer?', message: `Delete "${c.name}"? Only possible if they have no transactions.`, confirmText: 'Delete', danger: true })) await guard(async () => { await deleteCustomer(id); toast('Customer deleted', 'success'); ctx.navigate('customers'); }); } }, icon('trash', 16), 'Delete') : null,
          ),
        ),
        h(
          'div',
          { class: 'stat-grid' },
          tile('Total purchases', money(s.totalPurchases), `${s.invoiceCount} invoice${s.invoiceCount === 1 ? '' : 's'}${s.voidedCount ? ` · ${s.voidedCount} voided` : ''}`, '', 'purchases'),
          tile('Total paid', money(s.totalPaid), `${money(s.paidAtSale)} at sale + ${money(s.paymentsReceived)} later`, 'ok-text', 'paid'),
          tile(credit ? 'Credit balance' : 'Current due', money(Math.abs(s.currentDue)), credit ? 'the shop owes this customer' : s.currentDue > 0 ? 'to be collected' : 'nothing owed', s.currentDue > 0 ? 'neg' : credit ? 'ok-text' : '', 'due'),
          tile('Invoices', String(s.invoiceCount), s.returnCount ? `${s.returnCount} return${s.returnCount === 1 ? '' : 's'}` : 'no returns', '', 'invoices'),
          tile('Last purchase', s.lastPurchase ? fmtDate(s.lastPurchase.date) : '—', s.lastPurchase ? `${fmtDateTime(s.lastPurchase.at, { seconds: true }).split(', ')[1]} · ${s.lastPurchase.invoiceNo}` : 'never bought', '', 'last'),
        ),
        s.returnsValue > 0 ? h('div', { class: 'hint-box' }, `Goods returned: ${money(s.returnsValue)} (reduced the due by ${money(s.creditFromReturns)}, refunded ${money(s.refunds)}). Net purchases ${money(s.netPurchases)}.`) : null,
        s.reconciles ? null : h('div', { class: 'warn-box', 'data-warning': 'reconcile' }, 'The totals above do not add up — please tell your administrator (the data may be damaged).'),
        h(
          'div',
          { class: 'row gap profile-actions' },
          h('button', { class: 'btn btn-primary', onclick: () => { try { localStorage.setItem('pos:draft', JSON.stringify({ customer: { id: c.id, name: c.name, phone: c.phone, due: Math.max(0, s.currentDue) }, items: [] })); } catch { /* ignore */ } ctx.navigate('pos'); } }, icon('cart', 18), 'New sale'),
          s.currentDue > 0 ? h('button', { class: 'btn', onclick: () => paymentDialog(c, s.currentDue, () => load()) }, icon('wallet', 18), 'Receive payment') : null,
          h('button', { class: 'btn', 'data-action': 'csv', onclick: () => guard(() => downloadCSV(`customer-${(c.code || c.id.slice(0, 8)).replace(/[^A-Za-z0-9-]/g, '')}-history.csv`, customerHistoryToCSV(data))) }, icon('download', 18), 'Export CSV'),
          h('button', { class: 'btn', 'data-action': 'print', onclick: () => printStatement() }, icon('printer', 18), 'Print statement'),
        ),
      ),
    );
    const filtered = range.from || range.to;
    mount(meta, h('span', null, `${entries.length} entr${entries.length === 1 ? 'y' : 'ies'}${filtered ? ` · ${range.from ? fmtDate(range.from) : 'start'} → ${range.to ? fmtDate(range.to) : 'today'}` : ''}`), filtered ? h('span', { class: 'muted' }, `Sales ${money(period.sales)} · Payments ${money(period.paymentsReceived)} · Balance ${money(period.openingBalance)} → ${money(period.closingBalance)}`) : null);
    mount(list, entries.length ? entries.map(entryView) : emptyState(filtered ? 'No transactions in this period.' : 'No transactions yet.', filtered ? 'Change the dates or choose "All time".' : 'Start a sale for this customer with "New sale".'));
  }

  function printStatement() {
    const { customer: c, summary: s, period, entries } = data;
    printSheet(
      reportSheet({
        title: 'Customer statement',
        meta: [['Customer', c.name], ['Customer ID', `${c.code ? `${c.code} · ` : ''}${c.id}`], ['Phone', c.phone || '—'], ['Address', c.address || '—'], ['Period', range.from || range.to ? `${range.from || 'start'} to ${range.to || 'today'}` : 'All time']],
        summary: [['Total purchases', money(s.totalPurchases)], ['Total paid', money(s.totalPaid)], [s.currentDue < 0 ? 'Credit balance' : 'Current due', money(Math.abs(s.currentDue))], ['Invoices', String(s.invoiceCount)], ...(range.from || range.to ? [['Balance at start', money(period.openingBalance)], ['Balance at end', money(period.closingBalance)]] : [])],
        columns: [{ label: 'Date & time' }, { label: 'Type' }, { label: 'Reference' }, { label: 'Details' }, { label: 'Due added', num: true }, { label: 'Paid / credit', num: true }, { label: 'Balance', num: true }],
        rows: statementRows(entries),
        note: 'Times are Asia/Dhaka. Balance = what the customer owes after that entry.',
      }),
    );
  }

  await load();
  return bus.on('data:changed', () => load());
}

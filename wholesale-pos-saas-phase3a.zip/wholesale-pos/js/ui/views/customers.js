/**
 * customers.js — the customer list (search by name / phone, filters, sorting).
 * Opening a customer shows the full profile (route #/customers/<id>, see
 * customer-profile.js): totals, due, complete transaction history, payments, returns,
 * voids, CSV export and a printable statement.
 */
import { h, mount, icon } from '../dom.js';
import { pageHeader, filterBar, pager, debounce } from '../components.js';
import { listCustomers } from '../../services/customers.js';
import { dataTable } from '../table.js';
import { money, fmtDate } from '../../core/format.js';
import { bus } from '../../core/bus.js';
import { dateParts, addDays } from '../../core/utils.js';
import { editCustomer } from '../customer-dialogs.js';
import { renderProfile } from './customer-profile.js';

export { editCustomer };

export default async function render(root, ctx) {
  if (ctx.params[0]) return renderProfile(root, ctx.params[0], ctx);
  const PAGE = 50;
  let offset = 0;
  const body = h('section', { class: 'card' });
  const meta = h('div', { class: 'result-meta' });
  const fb = filterBar(
    [
      { key: 'search', type: 'search', placeholder: 'Search name, phone, address…' },
      { key: 'due', type: 'select', label: 'Dues', options: [{ value: '', label: 'Any balance' }, { value: 'has', label: 'Owes money' }, { value: 'none', label: 'No due' }] },
      { key: 'sort', type: 'select', label: 'Sort', default: 'name', options: [{ value: 'name', label: 'Name A–Z' }, { value: 'due-desc', label: 'Highest due' }, { value: 'purchases-desc', label: 'Top buyers' }, { value: 'recent', label: 'Recent buyers' }, { value: 'oldest', label: 'Longest inactive' }] },
      { key: 'minDue', type: 'number', label: 'Due at least', more: true },
      { key: 'inactive', type: 'select', label: 'Last purchase', more: true, options: [{ value: '', label: 'Any time' }, { value: '30', label: 'Not in 30 days' }, { value: '60', label: 'Not in 60 days' }, { value: '90', label: 'Not in 90 days' }] },
    ],
    { due: ctx.query?.due || '', search: ctx.query?.q || '' },
    () => { offset = 0; paint(); },
  );
  mount(root, pageHeader('Customers', h('button', { class: 'btn btn-primary', onclick: () => editCustomer(null) }, icon('plus', 18), 'Add customer')), fb.el, meta, body);
  let seq = 0;
  async function paint() {
    const my = ++seq;
    const v = fb.values;
    const notBoughtSince = v.inactive ? addDays(dateParts().date, -Number(v.inactive)) : '';
    const all = await listCustomers({ search: v.search, due: v.due, minDue: v.minDue, notBoughtSince, sort: v.sort });
    if (my !== seq) return;
    const rows = all.slice(offset, offset + PAGE);
    const dueSum = all.reduce((a, c) => a + Math.max(0, c.due), 0);
    mount(meta, h('span', null, `${all.length} customer${all.length === 1 ? '' : 's'}`), dueSum > 0 ? h('span', { class: 'warn-text' }, `Total due ${money(dueSum)}`) : null);
    mount(
      body,
      dataTable(
        [
          { label: 'Customer', value: (r) => r.name, render: (r) => h('div', null, h('div', { class: 'strong' }, r.name), h('div', { class: 'muted small' }, r.phone || r.address || '')) },
          { label: 'Phone', value: (r) => r.phone },
          { label: 'Invoices', num: true, value: (r) => r.invoiceCount },
          { label: 'Purchases', num: true, value: (r) => r.totalPurchases, render: (r) => money(r.totalPurchases) },
          { label: 'Due', num: true, value: (r) => r.due, render: (r) => (r.due > 0 ? h('span', { class: 'neg strong' }, money(r.due)) : '—') },
          { label: 'Last purchase', value: (r) => r.lastPurchase, render: (r) => (r.lastPurchase ? fmtDate(r.lastPurchase) : '—') },
        ],
        rows,
        { onRow: (r) => ctx.navigate(`customers/${r.id}`), empty: v.search || v.due || v.minDue || v.inactive ? 'No customer matches these filters.' : 'No customers yet. Add your first customer.' },
      ),
      pager({ total: all.length, offset, limit: PAGE, onPage: (o) => { offset = o; paint(); window.scrollTo(0, 0); } }),
    );
  }
  await paint();
  return bus.on('data:changed', debounce(paint, 250));
}

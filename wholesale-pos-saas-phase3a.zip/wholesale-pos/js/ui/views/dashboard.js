/**
 * dashboard.js — headline numbers with trends, 30-day sales chart, top products,
 * low stock, recent invoices. Repaints (debounced) when data changes.
 */
import { h, mount, icon } from '../dom.js';
import { pageHeader, badge, emptyState, debounce } from '../components.js';
import { dashboard } from '../../services/reports.js';
import { money, fmtDate, fmtTime, qty } from '../../core/format.js';
import { bus } from '../../core/bus.js';
import { auth } from '../../services/auth.js';
import { lineChart, barChart, hBars, sparkline, delta } from '../charts.js';
import { segmented } from '../components.js';

/** A KPI tile: label, value, optional delta badge / sparkline / sub-text. */
function stat({ label, value, sub, iconName, tone = 'primary', href, extra, spark }) {
  const body = [
    h('div', { class: `stat-icon tone-${tone}` }, icon(iconName, 22)),
    h('div', { class: 'stat-body grow' }, h('div', { class: 'stat-label' }, label), h('div', { class: 'stat-value' }, value), h('div', { class: 'stat-top' }, extra || null, sub ? h('span', { class: 'stat-sub' }, sub) : null)),
    spark || null,
  ];
  return href ? h('a', { class: 'card stat', href }, body) : h('div', { class: 'card stat' }, body);
}

const dayLabel = (d) => new Date(`${d}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

export default async function render(root) {
  const body = h('div');
  let range = 30; // 7 or 30 days
  mount(root, pageHeader('Dashboard', h('a', { class: 'btn btn-primary', href: '#/pos' }, icon('plus', 18), 'New sale')), body);

  const paint = async () => {
    const d = await dashboard();
    const canReports = auth.can('reports');
    const days = d.last30.slice(-range);
    const topList = d.topMonth.length ? d.topMonth : d.topToday;
    const week = d.last7.reduce((a, x) => a + x.sales, 0);
    mount(
      body,
      h(
        'div',
        { class: 'stats' },
        stat({ label: "Today's sales", value: money(d.todaySales), sub: `${d.todayCount} invoice${d.todayCount === 1 ? '' : 's'}${d.todayReturns > 0 ? ` · returns ${money(d.todayReturns)}` : ''}`, iconName: 'cart', href: '#/invoices', extra: delta(d.todaySales, d.yesterdaySales, { label: 'vs yesterday' }), spark: sparkline(d.last7.map((x) => x.sales)) }),
        stat({ label: 'This month', value: money(d.monthSales), sub: `Week: ${money(week)}`, iconName: 'chart', tone: 'teal', href: canReports ? '#/reports' : undefined }),
        stat({ label: 'Total due', value: money(d.totalDue), sub: 'Owed by customers', iconName: 'wallet', tone: d.totalDue > 0 ? 'amber' : 'green', href: '#/customers?due=has' }),
        stat({ label: 'Customers', value: String(d.totalCustomers), iconName: 'users', tone: 'violet', href: '#/customers' }),
        stat({ label: 'Products', value: String(d.totalProducts), sub: d.lowStock.length ? `${d.lowStock.length} low on stock` : 'Stock levels OK', iconName: 'package', tone: 'rose', href: d.lowStock.length ? '#/inventory' : '#/products' }),
      ),
      h(
        'section',
        { class: 'card' },
        h('div', { class: 'card-head' }, h('h3', null, 'Sales'), segmented([{ value: 7, label: '7 days' }, { value: 30, label: '30 days' }], range, (v) => { range = v; paint(); })),
        range === 7
          ? barChart({ labels: days.map((x) => new Date(`${x.date}T12:00:00`).toLocaleDateString('en-US', { weekday: 'short' })), series: [{ label: 'Sales', values: days.map((x) => x.sales) }], format: money, highlightLast: true, title: 'Sales, last 7 days', tipTitle: (i) => fmtDate(days[i].date), height: 200 })
          : lineChart({ labels: days.map((x) => dayLabel(x.date)), series: [{ label: 'Sales', values: days.map((x) => x.sales) }], format: money, title: 'Sales, last 30 days', height: 220 }),
      ),
      h(
        'div',
        { class: 'grid-2 gap' },
        h('section', { class: 'card' }, h('div', { class: 'card-head' }, h('h3', null, d.topMonth.length ? 'Top products this month' : 'Top products today')), hBars(topList.map((p) => ({ label: p.name, value: p.revenue, sub: `${qty(p.qty)} sold` })), { format: money, empty: 'No sales yet.' })),
        h(
          'section',
          { class: 'card' },
          h('div', { class: 'card-head' }, h('h3', null, 'Low stock'), d.lowStock.length ? badge(`${d.lowStock.length}`, 'warn') : null),
          d.lowStock.length
            ? h('ul', { class: 'list' }, d.lowStock.slice(0, 6).map((p) => h('li', null, h('span', null, p.name), h('span', { class: p.stock <= 0 ? 'neg strong' : 'strong' }, `${qty(p.stock)} ${p.unit}`))))
            : emptyState('Nothing running low', 'All products are above their low-stock level.'),
          d.lowStock.length > 6 ? h('a', { class: 'small', href: '#/inventory' }, `See all ${d.lowStock.length} →`) : null,
        ),
      ),
      h(
        'section',
        { class: 'card' },
        h('div', { class: 'card-head' }, h('h3', null, 'Recent invoices'), h('a', { class: 'small', href: '#/invoices' }, 'View all →')),
        d.recent.length
          ? h('ul', { class: 'list' }, d.recent.map((i) => h('li', { class: i.status === 'void' ? 'void' : '' }, h('div', null, h('div', { class: 'strong' }, i.invoiceNo, i.status === 'void' ? badge('VOID', 'danger') : null), h('div', { class: 'muted small' }, `${i.customerName} · ${fmtDate(i.date)} ${fmtTime(i.time)}`)), h('div', { class: 'right' }, h('div', { class: 'strong' }, money(i.total)), i.due > 0 ? h('div', { class: 'small warn-text' }, `Due ${money(i.due)}`) : null))))
          : emptyState('No invoices yet', 'Create your first sale to see it here.', h('a', { class: 'btn btn-primary', href: '#/pos' }, 'New sale')),
      ),
    );
  };
  await paint();
  return bus.on('data:changed', debounce(paint, 300));
}

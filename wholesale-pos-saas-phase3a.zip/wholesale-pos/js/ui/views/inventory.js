/**
 * inventory.js — current stock with low-stock warnings and the stock actions
 * (receive a delivery, correct a count, write off damaged goods). Every action is
 * recorded in the stock history — see the Stock History page for the full log.
 */
import { h, mount, icon } from '../dom.js';
import { segmented, badge, emptyState, pageHeader, searchBox } from '../components.js';
import { listProducts } from '../../services/catalog.js';
import { queryMovements } from '../../services/inventory.js';
import { auth } from '../../services/auth.js';
import { qty } from '../../core/format.js';
import { bus } from '../../core/bus.js';
import { movementTable, receiveDialog, adjustDialog, writeOffDialog } from '../stock-ui.js';

export default async function render(root, ctx = {}) {
  const canAdjust = auth.can('inventory.adjust');
  let tab = 'stock';
  const filter = { search: '', low: false };
  const body = h('div');
  const lowToggle = h('input', { type: 'checkbox', onchange: () => { filter.low = lowToggle.checked; paint(); } });
  const sb = searchBox('Search products…', (v) => { filter.search = v; paint(); });
  const toolbar = h('div', { class: 'toolbar' }, sb, h('label', { class: 'check' }, lowToggle, h('span', null, 'Low stock only')));
  const banner = h('div');

  mount(
    root,
    pageHeader('Inventory', h('a', { class: 'btn', href: '#/stock-history', 'data-action': 'open-history' }, icon('layers', 18), 'Full stock history')),
    banner,
    h('div', { class: 'tabs' }, segmented([{ value: 'stock', label: 'Stock levels' }, { value: 'moves', label: 'Recent changes' }], tab, (v) => { tab = v; toolbar.classList.toggle('hidden', v !== 'stock'); paint(); })),
    toolbar,
    h('section', { class: 'card' }, body),
  );

  async function paint() {
    const all = await listProducts();
    const low = all.filter((p) => p.stock <= p.lowStockLevel);
    mount(banner, low.length ? h('div', { class: 'warn-box', style: { marginBottom: '12px' } }, `${icon('alert', 16).outerHTML ? '' : ''}⚠ ${low.length} product${low.length === 1 ? ' is' : 's are'} at or below the low-stock level.`) : null);
    if (tab === 'moves') return paintMoves();
    const rows = await listProducts({ search: filter.search, lowOnly: filter.low });
    if (!rows.length) return mount(body, emptyState('No products found'));
    mount(
      body,
      h(
        'ul',
        { class: 'list' },
        rows.map((p) =>
          h(
            'li',
            null,
            h('div', { class: 'grow' }, h('div', { class: 'strong' }, p.name), h('div', { class: 'muted small' }, `${p.categoryName} · warn at ${qty(p.lowStockLevel)} ${p.unit}`)),
            h('div', { class: 'right' }, h('div', { class: `strong ${p.stock <= 0 ? 'neg' : p.stock <= p.lowStockLevel ? 'warn-text' : ''}` }, `${qty(p.stock)} ${p.unit}`), p.stock <= 0 ? badge('Out of stock', 'danger') : p.stock <= p.lowStockLevel ? badge('Low', 'warn') : badge('OK', 'ok')),
            h('a', { class: 'btn btn-sm', href: `#/products/${p.id}`, title: `Stock history of ${p.name}` }, 'History'),
            canAdjust ? h('button', { class: 'btn btn-sm', 'data-action': 'receive', onclick: () => receiveDialog(p, () => paint()) }, 'Receive') : null,
            canAdjust ? h('button', { class: 'btn btn-sm', 'data-action': 'adjust', onclick: () => adjustDialog(p, () => paint()) }, 'Correct') : null,
            canAdjust ? h('button', { class: 'btn btn-sm', 'data-action': 'writeoff', onclick: () => writeOffDialog(p, () => paint()) }, 'Damaged') : null,
          ),
        ),
      ),
    );
  }

  async function paintMoves() {
    const { rows, total } = await queryMovements({ limit: 50 });
    mount(body, movementTable(rows, { cost: auth.can('reports.profit'), empty: 'No stock changes recorded yet.' }), total > 50 ? h('p', { class: 'muted' }, `Showing the latest 50 of ${total}. `, h('a', { href: '#/stock-history' }, 'Open the full stock history →')) : null);
  }

  await paint();
  return bus.on('data:changed', () => paint());
}

/**
 * invoices.js — invoice history: search / filter, open an invoice, re-print it,
 * and (admin) void it. Also exports `showInvoiceDetail()` so other screens
 * (customer history, dashboard) can open the same dialog.
 */
import { h, mount, icon } from '../dom.js';
import { openModal, confirmDialog, promptDialog, toast, guard, badge, emptyState, pageHeader, filterBar, pager, debounce } from '../components.js';
import { queryInvoices, getInvoice, voidInvoice } from '../../services/sales.js';
import { auth } from '../../services/auth.js';
import { dataTable } from '../table.js';
import { money, qty, fmtDate, fmtTime, fmtDateTime } from '../../core/format.js';
import { listReturns } from '../../services/returns.js';
import { methodLabel } from '../../services/payment-methods.js';
import { openReturnDialog } from '../return-dialog.js';
import { dateParts, addDays } from '../../core/utils.js';
import { printInvoiceUi, previewInvoice } from '../print-ui.js';
import { bus } from '../../core/bus.js';

/** Sync badge for an invoice row. */
export function syncBadge(inv) {
  if (inv.status === 'void') return badge('Void', 'danger');
  if (inv.syncStatus === 'synced') return badge('Synced', 'ok');
  if (inv.syncStatus === 'failed') return badge('Sync failed', 'danger');
  return badge('Pending sync', 'warn');
}

/** Open the invoice detail dialog (lines, totals, payment, returns, void details, print, return, void). */
export async function showInvoiceDetail(id) {
  const inv = await getInvoice(id);
  if (!inv) return toast('Invoice not found', 'error');
  const returns = auth.can('invoices') || auth.can('customers') ? await listReturns({ invoiceId: id }).catch(() => []) : [];
  const canVoid = auth.can('invoices.void') && inv.status !== 'void' && !returns.length;
  const canReturn = auth.can('invoices.return') && inv.status !== 'void';
  const m = openModal({
    title: `Invoice ${inv.invoiceNo}`,
    size: 'md',
    content: h(
      'div',
      { class: 'stack' },
      h(
        'dl',
        { class: 'kv' },
        h('dt', null, 'Date & time'), h('dd', { 'data-field': 'invoice-time' }, fmtDateTime(inv.createdAt, { seconds: true }) || `${fmtDate(inv.date)} ${fmtTime(inv.time)}`),
        h('dt', null, 'Customer'), h('dd', null, inv.customerName + (inv.customerPhone ? ` · ${inv.customerPhone}` : '')),
        h('dt', null, 'Cashier'), h('dd', null, inv.createdByName || '—'),
        h('dt', null, 'Status'), h('dd', null, syncBadge(inv)),
      ),
      inv.status === 'void'
        ? h('div', { class: 'warn-box', 'data-box': 'void' }, `Voided ${fmtDateTime(inv.voidedAt, { seconds: true })}${inv.voidedBy ? ` by ${inv.voidedBy}` : ''}: ${inv.voidReason || 'no reason recorded'}. Stock was restored.${(inv.voidRefund ?? inv.paid) > 0 ? ` The customer paid ${money(inv.voidRefund ?? inv.paid)} at the counter — give it back.` : ''}`)
        : null,
      dataTable(
        [
          { label: 'Product', value: (r) => r.name },
          { label: 'Qty', num: true, value: (r) => r.qty, render: (r) => `${qty(r.qty)} ${r.unit || ''}` },
          { label: 'Price', num: true, value: (r) => r.unitPrice, render: (r) => money(r.unitPrice) },
          { label: 'Total', num: true, value: (r) => r.total, render: (r) => money(r.total) },
        ],
        inv.items,
      ),
      h(
        'dl',
        { class: 'kv' },
        h('dt', null, 'Subtotal'), h('dd', null, money(inv.subtotal)),
        h('dt', null, 'Discount'), h('dd', null, money(inv.discount)),
        h('dt', null, 'Grand total'), h('dd', { class: 'big' }, money(inv.total)),
        h('dt', null, 'Paid'), h('dd', null, `${money(inv.paid)}${inv.paid > 0 && inv.paymentMethod ? ` · ${methodLabel(inv.paymentMethod)}` : ''}`),
        h('dt', null, 'Due'), h('dd', { class: inv.due > 0 ? 'neg' : '' }, money(inv.due)),
      ),
      returns.length
        ? h('div', { 'data-box': 'returns' }, h('div', { class: 'strong' }, 'Goods returned'), h('ul', { class: 'list' }, returns.map((r) => h('li', null, h('div', { class: 'grow' }, h('div', { class: 'strong' }, `${r.returnNo} · ${money(r.amount)}`), h('div', { class: 'muted small' }, `${fmtDateTime(r.createdAt)} · ${r.items.map((i) => `${qty(i.qty)} ${i.name}`).join(', ')} · ${r.reason}`))))))
        : null,
      inv.notes ? h('p', { class: 'muted' }, `Note: ${inv.notes}`) : null,
    ),
    actions: [
      canVoid
        ? h(
            'button',
            {
              class: 'btn btn-danger',
              'data-action': 'void',
              onclick: async () => {
                // the reason is required: ask again (keeping what was typed) until it is long enough or the user cancels
                let reason = '';
                for (;;) {
                  reason = await promptDialog({ title: 'Void invoice', label: 'Reason (required)', value: reason, confirmText: 'Continue' });
                  if (reason === null) return;
                  if (reason.trim().length >= 3) break;
                  toast('Please enter the reason for voiding (at least 3 characters).', 'error');
                }
                if (!(await confirmDialog({ title: 'Void this invoice?', message: `Stock will be restored and the invoice removed from sales and customer dues. The record stays, marked Void, with your reason.${inv.paid > 0 ? ` The customer paid ${money(inv.paid)} at the counter — remember to give it back.` : ''} This cannot be undone.`, confirmText: 'Void', danger: true }))) return;
                await guard(async () => {
                  await voidInvoice(inv.id, reason);
                  toast('Invoice voided', 'success');
                  m.close();
                });
              },
            },
            'Void',
          )
        : null,
      canReturn ? h('button', { class: 'btn', 'data-action': 'return', onclick: () => openReturnDialog(inv.id, () => m.close()) }, 'Take goods back') : null,
      h('button', { class: 'btn', onclick: () => previewInvoice(inv) }, icon('eye', 18), 'Preview'),
      h('button', { class: 'btn btn-primary', onclick: () => printInvoiceUi(inv) }, icon('printer', 18), 'Print'),
    ].filter(Boolean),
  });
}

export default async function render(root, ctx = {}) {
  const today = dateParts().date;
  const rangeOf = {
    today: { from: today, to: today },
    week: { from: addDays(today, -6), to: today },
    month: { from: `${today.slice(0, 7)}-01`, to: today },
    all: {},
  };
  const PAGE = 50;
  let offset = 0;
  const users = await auth.listUserNames().catch(() => []);
  const fb = filterBar(
    [
      { key: 'search', type: 'search', placeholder: 'Search invoice no., customer, phone…' },
      { key: 'range', type: 'select', label: 'Period', default: 'today', options: [{ value: 'today', label: 'Today' }, { value: 'week', label: 'Last 7 days' }, { value: 'month', label: 'This month' }, { value: 'all', label: 'All time' }, { value: 'custom', label: 'Custom dates' }] },
      { key: 'payment', type: 'select', label: 'Payment', options: [{ value: '', label: 'Any payment' }, { value: 'paid', label: 'Paid' }, { value: 'due', label: 'Has due' }, { value: 'unpaid', label: 'Unpaid' }, { value: 'partial', label: 'Partly paid' }] },
      { key: 'sort', type: 'select', label: 'Sort', default: 'newest', options: [{ value: 'newest', label: 'Newest first' }, { value: 'oldest', label: 'Oldest first' }, { value: 'total-desc', label: 'Highest total' }, { value: 'total-asc', label: 'Lowest total' }, { value: 'due-desc', label: 'Highest due' }] },
      { key: 'from', type: 'date', label: 'From', more: true },
      { key: 'to', type: 'date', label: 'To', more: true },
      { key: 'min', type: 'number', label: 'Min total', more: true },
      { key: 'max', type: 'number', label: 'Max total', more: true },
      { key: 'status', type: 'select', label: 'Status', more: true, options: [{ value: '', label: 'Any' }, { value: 'active', label: 'Active' }, { value: 'void', label: 'Voided' }] },
      { key: 'sync', type: 'select', label: 'Sync', more: true, options: [{ value: '', label: 'Any' }, { value: 'pending', label: 'Pending' }, { value: 'synced', label: 'Synced' }, { value: 'failed', label: 'Failed' }] },
      ...(users.length ? [{ key: 'userId', type: 'select', label: 'Cashier', more: true, options: [{ value: '', label: 'Anyone' }, ...users.map((u) => ({ value: u.id, label: u.displayName }))] }] : []),
    ],
    { search: ctx.query?.q || '', range: ctx.query?.q ? 'all' : 'today' },
    () => {
      offset = 0;
      paint();
    },
  );
  const meta = h('div', { class: 'result-meta' });
  const body = h('section', { class: 'card' });
  mount(root, pageHeader('Invoices', h('a', { class: 'btn btn-primary', href: '#/pos' }, icon('plus', 18), 'New sale')), fb.el, meta, body);

  let seq = 0;
  async function paint() {
    const my = ++seq;
    const v = fb.values;
    const range = v.range === 'custom' ? { from: v.from || undefined, to: v.to || undefined } : { ...rangeOf[v.range] };
    if (v.range !== 'custom') { if (v.from) range.from = v.from; if (v.to) range.to = v.to; }
    const r = await queryInvoices({ ...range, search: v.search, payment: v.payment, sort: v.sort, min: v.min, max: v.max, status: v.status, sync: v.sync, userId: v.userId, limit: PAGE, offset });
    if (my !== seq) return;
    mount(meta, h('span', null, `${r.total} invoice${r.total === 1 ? '' : 's'} · ${money(r.sumTotal)}`), r.sumDue > 0 ? h('span', { class: 'warn-text' }, `Due ${money(r.sumDue)}`) : null);
    mount(
      body,
      dataTable(
        [
          { label: 'Invoice', value: (x) => x.invoiceNo, render: (x) => h('span', { class: 'strong' }, x.invoiceNo) },
          { label: 'Date', value: (x) => `${x.date} ${fmtTime(x.time)}`, render: (x) => `${fmtDate(x.date)} ${fmtTime(x.time)}` },
          { label: 'Customer', value: (x) => x.customerName },
          { label: 'Total', num: true, value: (x) => x.total, render: (x) => money(x.total) },
          { label: 'Due', num: true, value: (x) => x.due, render: (x) => (x.due > 0 ? h('span', { class: 'neg' }, money(x.due)) : '—') },
          { label: 'Sync', value: (x) => x.syncStatus, render: (x) => syncBadge(x) },
        ],
        r.rows,
        { onRow: (x) => showInvoiceDetail(x.id), rowClass: (x) => (x.status === 'void' ? 'void' : ''), empty: 'No invoices match these filters.' },
      ),
      pager({ total: r.total, offset, limit: PAGE, onPage: (o) => { offset = o; paint(); window.scrollTo(0, 0); } }),
    );
  }
  await paint();
  return bus.on('data:changed', debounce(paint, 250));
}

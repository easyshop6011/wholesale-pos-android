/**
 * pos.js — the New Sale screen.
 *
 * Flow: pick customer → add products from the list → type quantity and unit
 * price for each line (prices are typed per customer) → discount / paid →
 * Save & Print. The cart is auto-saved to localStorage so a reload or crash
 * never loses a half-built invoice.
 */
import { h, mount, icon } from '../dom.js';
import { openModal, toast, showError, guard, field, searchBox, badge, emptyState } from '../components.js';
import { listProducts, listCategories } from '../../services/catalog.js';
import { listCustomers, saveCustomer } from '../../services/customers.js';
import { createInvoice, lastPricesFor } from '../../services/sales.js';
import { settings } from '../../services/settings.js';
import { auth } from '../../services/auth.js';
import { money, qty as fmtQty } from '../../core/format.js';
import { toNum, round2, uuid } from '../../core/utils.js';
import { lineTotal } from '../../core/money.js';
import { PAYMENT_METHODS } from '../../services/payment-methods.js';
import { printInvoiceUi, previewInvoice } from '../print-ui.js';

const DRAFT_KEY = 'pos:draft';

/** Load / save the in-progress cart. */
const draft = {
  load() {
    try {
      return JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null');
    } catch {
      return null;
    }
  },
  save(state) {
    try {
      localStorage.setItem(DRAFT_KEY, JSON.stringify(state));
    } catch {
      /* ignore */
    }
  },
  clear() {
    try {
      localStorage.removeItem(DRAFT_KEY);
    } catch {
      /* ignore */
    }
  },
};

export default async function render(root, ctx) {
  const saved = draft.load();
  /** The whole screen state. */
  const state = {
    customer: saved?.customer || null, // {id,name,phone,due}
    items: saved?.items || [], // {key,productId,name,unit,stock,qty,unitPrice}
    discount: saved?.discount || '',
    discountMode: saved?.discountMode || 'amount', // 'amount' | 'percent'
    paid: saved?.paid || '',
    paidTouched: saved?.paidTouched || false,
    notes: saved?.notes || '',
    method: saved?.method || 'cash', // how the paid amount is received
    // One id per sale. Saving the same sale again (double tap, retry after a crash, two tabs) returns the invoice that
    // already exists instead of creating a second one — it is kept in the saved draft so it survives a reload.
    requestId: saved?.requestId || uuid(),
  };
  let lastPrices = new Map();
  const refs = {};

  const persist = () => draft.save(state);

  // ---------- calculations ----------
  const subtotal = () => round2(state.items.reduce((a, i) => a + lineTotal(toNum(i.qty), toNum(i.unitPrice)), 0));
  const discountAmount = () => {
    const d = toNum(state.discount);
    const v = state.discountMode === 'percent' ? (subtotal() * d) / 100 : d;
    return round2(Math.min(Math.max(v, 0), subtotal()));
  };
  const grand = () => round2(subtotal() - discountAmount());
  const paidAmount = () => (state.paidTouched ? round2(toNum(state.paid)) : grand());
  const dueAmount = () => round2(grand() - paidAmount());

  /** Refresh only the numbers (keeps input focus intact while typing). */
  function updateTotals() {
    for (const it of state.items) {
      const el = refs.lineTotals?.get(it.key);
      if (el) el.textContent = money(lineTotal(toNum(it.qty), toNum(it.unitPrice)));
    }
    refs.subtotal.textContent = money(subtotal());
    refs.grand.textContent = money(grand());
    if (!state.paidTouched) refs.paid.value = grand() ? String(grand()) : '';
    refs.due.textContent = money(dueAmount());
    refs.due.parentElement.classList.toggle('has-due', dueAmount() > 0);
    refs.count.textContent = `${state.items.length} item${state.items.length === 1 ? '' : 's'}`;
    refs.discHint.textContent = state.discountMode === 'percent' && toNum(state.discount) ? `= ${money(discountAmount())}` : '';
    refs.save.disabled = refs.saveOnly.disabled = !state.items.length;
    persist();
  }

  // ---------- customer ----------
  const customerCard = h('div', { class: 'card customer-card' });
  function paintCustomer() {
    const c = state.customer;
    mount(
      customerCard,
      h('div', { class: 'card-head' }, h('h3', null, 'Customer')),
      h(
        'div',
        { class: 'customer-row' },
        h('div', { class: 'avatar' }, c ? c.name.slice(0, 1).toUpperCase() : icon('user', 18)),
        h('div', { class: 'grow' }, h('div', { class: 'strong' }, c ? c.name : 'Walk-in customer'), h('div', { class: 'muted small' }, c ? c.phone || 'No phone' : 'Cash sale · no customer record')),
        c && c.due > 0 ? badge(`Owes ${money(c.due)}`, 'warn') : null,
        h('button', { class: 'btn btn-sm', onclick: pickCustomer }, c ? 'Change' : 'Select customer'),
        c ? h('button', { class: 'icon-btn', 'aria-label': 'Remove customer', onclick: () => setCustomer(null) }, icon('x', 18)) : null,
      ),
    );
  }
  async function setCustomer(c) {
    state.customer = c ? { id: c.id, name: c.name, phone: c.phone, due: c.due || 0 } : null;
    lastPrices = c ? await lastPricesFor(c.id) : new Map();
    paintCustomer();
    paintItems();
    updateTotals();
  }

  /** Searchable customer picker with inline "new customer". */
  async function pickCustomer() {
    let all = await listCustomers();
    const list = h('div', { class: 'pick-list' });
    const paint = (q = '') => {
      const s = q.trim().toLowerCase();
      const rows = all.filter((c) => !s || c.nameLower.includes(s) || c.phone.includes(s.replace(/\D/g, '') || '§')).slice(0, 60);
      mount(
        list,
        rows.map((c) =>
          h('button', { class: 'pick-row', type: 'button', onclick: () => { m.close(); setCustomer(c); } }, h('div', null, h('div', { class: 'strong' }, c.name), h('div', { class: 'muted small' }, c.phone || 'No phone')), c.due > 0 ? badge(`Due ${money(c.due)}`, 'warn') : null),
        ),
        rows.length ? null : h('div', { class: 'muted pad' }, 'No match.'),
        h('button', { class: 'pick-row add', type: 'button', onclick: () => newCustomer(q) }, icon('plus', 18), h('span', null, q.trim() ? `Add “${q.trim()}” as new customer` : 'Add new customer')),
      );
    };
    const sb = searchBox('Search name or phone…', paint);
    const m = openModal({ title: 'Select customer', content: h('div', { class: 'stack' }, sb, list), size: 'md' });
    paint();
    setTimeout(() => sb.input.focus(), 40);

    function newCustomer(prefill) {
      const looksPhone = /^[+\d][\d\s-]{5,}$/.test(prefill.trim());
      const name = h('input', { class: 'input', value: looksPhone ? '' : prefill.trim(), required: true, autofocus: true });
      const phone = h('input', { class: 'input', type: 'tel', inputmode: 'tel', value: looksPhone ? prefill.trim() : '' });
      const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Save & select');
      const nm = openModal({
        title: 'New customer',
        size: 'sm',
        content: h(
          'form',
          {
            class: 'stack',
            id: 'new-cust-form',
            onsubmit: (e) => {
              e.preventDefault();
              guard(async () => {
                const c = await saveCustomer({ name: name.value, phone: phone.value });
                nm.close();
                m.close();
                await setCustomer({ ...c, due: 0 });
              }, save);
            },
          },
          field('Name', name),
          field('Phone', phone),
          h('div', { class: 'modal-actions inline' }, h('button', { class: 'btn', type: 'button', onclick: () => nm.close() }, 'Cancel'), save),
        ),
      });
    }
  }

  // ---------- product picker ----------
  async function pickProduct() {
    const [products, cats] = await Promise.all([listProducts(), listCategories()]);
    let cat = null;
    let query = '';
    let added = 0;
    const list = h('div', { class: 'pick-list' });
    const chips = h('div', { class: 'chips' });
    const paintChips = () =>
      mount(chips, [{ id: null, name: 'All' }, ...cats].map((c) => h('button', { class: `chip-btn ${c.id === cat ? 'active' : ''}`, type: 'button', onclick: () => { cat = c.id; paintChips(); paint(); } }, c.name)));
    const addProduct = (p) => {
      const existing = state.items.find((i) => i.productId === p.id);
      if (existing) {
        m.close();
        setTimeout(() => refs.itemsBox.querySelector(`[data-key="${existing.key}"] .qty-in`)?.focus(), 50);
        return toast(`${p.name} is already in the invoice`, 'info');
      }
      state.items.push({ key: uuid(), productId: p.id, name: p.name, unit: p.unit, stock: p.stock, qty: '', unitPrice: '' });
      added += 1;
      paintItems(true);
      updateTotals();
      m.close();
    };
    const paint = () => {
      const q = query.trim().toLowerCase();
      const rows = products.filter((p) => (!cat || p.categoryId === cat) && (!q || `${p.nameLower} ${(p.sku || '').toLowerCase()}`.includes(q)));
      mount(
        list,
        rows.map((p) =>
          h(
            'button',
            { class: 'pick-row', type: 'button', onclick: () => addProduct(p) },
            h('div', null, h('div', { class: 'strong' }, p.name), h('div', { class: 'muted small' }, `${p.categoryName}${p.sku ? ` · ${p.sku}` : ''}`)),
            h('div', { class: 'right' }, h('div', { class: p.stock <= 0 ? 'neg strong' : p.stock <= p.lowStockLevel ? 'warn-text strong' : 'strong' }, `${fmtQty(p.stock)} ${p.unit}`), h('div', { class: 'muted small' }, 'in stock')),
          ),
        ),
        rows.length ? null : emptyState('No products found', products.length ? 'Try another search.' : 'Add products first (Products page).'),
      );
    };
    const sb = searchBox('Search product name or code…', (v) => { query = v; paint(); });
    // Barcode scanners type the code then press Enter: if exactly one match, add it.
    sb.input.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const q = sb.input.value.trim().toLowerCase();
      const exact = products.filter((p) => (p.sku || '').toLowerCase() === q);
      const only = exact.length === 1 ? exact : products.filter((p) => p.nameLower.includes(q));
      if (only.length === 1) addProduct(only[0]);
    });
    const m = openModal({ title: 'Add product', content: h('div', { class: 'stack' }, sb, cats.length ? chips : null, list), size: 'md' });
    paintChips();
    paint();
    setTimeout(() => sb.input.focus(), 40);
  }

  // ---------- line items ----------
  const itemsBox = h('div', { class: 'items' });
  refs.itemsBox = itemsBox;
  function paintItems(focusLast = false) {
    refs.lineTotals = new Map();
    if (!state.items.length) {
      mount(itemsBox, emptyState('No products yet', 'Tap “Add product” to start this invoice.'));
      return;
    }
    mount(
      itemsBox,
      state.items.map((it, idx) => {
        const total = h('div', { class: 'line-total' }, money(lineTotal(toNum(it.qty), toNum(it.unitPrice))));
        refs.lineTotals.set(it.key, total);
        const last = lastPrices.get(it.productId);
        const qtyIn = h('input', { class: 'input qty-in', type: 'text', inputmode: 'decimal', placeholder: 'Qty', value: it.qty, 'aria-label': `Quantity for ${it.name}`, autocomplete: 'off' });
        const priceIn = h('input', { class: 'input price-in', type: 'text', inputmode: 'decimal', placeholder: 'Unit price', value: it.unitPrice, 'aria-label': `Unit price for ${it.name}`, autocomplete: 'off' });
        qtyIn.addEventListener('input', () => { it.qty = qtyIn.value; updateTotals(); stockWarn(); });
        priceIn.addEventListener('input', () => { it.unitPrice = priceIn.value; updateTotals(); });
        qtyIn.addEventListener('keydown', (e) => e.key === 'Enter' && (e.preventDefault(), priceIn.focus()));
        priceIn.addEventListener('keydown', (e) => e.key === 'Enter' && (e.preventDefault(), pickProduct()));
        const warn = h('div', { class: 'small warn-text' });
        const stockWarn = () => {
          warn.textContent = toNum(it.qty) > it.stock && !settings.get('allowNegativeStock') ? `Only ${fmtQty(it.stock)} ${it.unit} in stock` : '';
        };
        stockWarn();
        return h(
          'div',
          { class: 'line', dataset: { key: it.key } },
          h(
            'div',
            { class: 'line-head' },
            h('div', { class: 'grow' }, h('div', { class: 'strong' }, `${idx + 1}. ${it.name}`), h('div', { class: 'muted small' }, `Stock: ${fmtQty(it.stock)} ${it.unit}`)),
            h('button', { class: 'icon-btn', 'aria-label': `Remove ${it.name}`, onclick: () => { state.items = state.items.filter((x) => x.key !== it.key); paintItems(); updateTotals(); } }, icon('trash', 18)),
          ),
          h('div', { class: 'line-inputs' }, h('label', { class: 'mini' }, h('span', null, `Qty (${it.unit})`), qtyIn), h('label', { class: 'mini' }, h('span', null, 'Unit price'), priceIn), h('div', { class: 'mini right' }, h('span', null, 'Total'), total)),
          last != null && String(last) !== String(it.unitPrice) ? h('button', { class: 'chip-btn small-chip', type: 'button', onclick: () => { it.unitPrice = String(last); priceIn.value = it.unitPrice; updateTotals(); } }, `Last price for this customer: ${money(last)} — tap to use`) : null,
          warn,
        );
      }),
    );
    if (focusLast) setTimeout(() => itemsBox.querySelector('.line:last-child .qty-in')?.focus(), 60);
  }

  // ---------- totals / payment ----------
  const discIn = h('input', { class: 'input', type: 'text', inputmode: 'decimal', placeholder: '0', value: state.discount, 'aria-label': 'Discount' });
  discIn.addEventListener('input', () => { state.discount = discIn.value; updateTotals(); });
  const modeBtn = h('button', { class: 'btn btn-sm', type: 'button', title: 'Switch between amount and percent' }, state.discountMode === 'percent' ? '%' : settings.get('currency'));
  modeBtn.onclick = () => {
    state.discountMode = state.discountMode === 'percent' ? 'amount' : 'percent';
    modeBtn.textContent = state.discountMode === 'percent' ? '%' : settings.get('currency');
    updateTotals();
  };
  const paidIn = h('input', { class: 'input', type: 'text', inputmode: 'decimal', placeholder: '0', value: state.paidTouched ? state.paid : '', 'aria-label': 'Paid amount' });
  paidIn.addEventListener('input', () => { state.paid = paidIn.value; state.paidTouched = true; updateTotals(); });
  const notesIn = h('input', { class: 'input', placeholder: 'Note (optional)', value: state.notes, 'aria-label': 'Note' });
  notesIn.addEventListener('input', () => { state.notes = notesIn.value; persist(); });
  refs.paid = paidIn;
  refs.method = h('select', { class: 'input', 'aria-label': 'Paid by', 'data-field': 'pay-method', onchange: (e) => { state.method = e.target.value; persist(); } }, PAYMENT_METHODS.map((m) => h('option', { value: m.id }, m.label)));
  refs.method.value = state.method;
  refs.subtotal = h('span', null, '');
  refs.grand = h('span', null, '');
  refs.due = h('span', null, '');
  refs.discHint = h('span', { class: 'muted small' }, '');
  refs.count = h('span', { class: 'muted small' }, '');

  /** Validate, save, then optionally print. */
  async function save(print) {
    const btn = print ? refs.save : refs.saveOnly;
    const inv = await guard(
      () =>
        createInvoice(
          { customerId: state.customer?.id || null, items: state.items.map((i) => ({ productId: i.productId, qty: i.qty, unitPrice: i.unitPrice })), discount: discountAmount(), paid: paidAmount(), paymentMethod: state.method, notes: state.notes, requestId: state.requestId },
          auth.user(),
        ),
      btn,
    );
    if (!inv) return;
    if (inv.duplicate) toast('This sale was already saved — nothing was added twice.', 'info');
    draft.clear();
    const printNow = print || settings.get('autoPrint');
    if (printNow) await printInvoiceUi(inv);
    showDone(inv);
  }

  function showDone(inv) {
    const m = openModal({
      title: 'Invoice saved',
      size: 'sm',
      dismissable: false,
      content: h(
        'div',
        { class: 'done' },
        h('div', { class: 'done-check' }, icon('check', 36)),
        h('div', { class: 'strong big' }, inv.invoiceNo),
        h('div', { class: 'muted' }, `${inv.customerName} · ${money(inv.total)}`),
        inv.due > 0 ? h('div', { class: 'warn-text strong' }, `Due ${money(inv.due)}`) : h('div', { class: 'ok-text strong' }, 'Paid in full'),
      ),
      actions: [
        h('button', { class: 'btn', onclick: () => previewInvoice(inv) }, icon('eye', 18), 'Preview'),
        h('button', { class: 'btn', onclick: () => printInvoiceUi(inv) }, icon('printer', 18), 'Print'),
        h('button', { class: 'btn btn-primary', onclick: () => { m.close(); ctx.navigate('pos'); resetAll(); } }, 'New sale'),
      ],
    });
  }

  function resetAll() {
    Object.assign(state, { customer: null, items: [], discount: '', discountMode: 'amount', paid: '', paidTouched: false, notes: '', method: 'cash', requestId: uuid() });
    if (refs.method) refs.method.value = 'cash';
    lastPrices = new Map();
    discIn.value = paidIn.value = notesIn.value = '';
    modeBtn.textContent = settings.get('currency');
    paintCustomer();
    paintItems();
    updateTotals();
    draft.clear();
  }

  refs.save = h('button', { class: 'btn btn-primary btn-lg grow', onclick: () => save(true) }, icon('printer', 20), 'Save & Print');
  refs.saveOnly = h('button', { class: 'btn btn-lg', onclick: () => save(false) }, 'Save');

  const summary = h(
    'section',
    { class: 'card summary' },
    h('div', { class: 'sum-row' }, h('span', null, 'Subtotal ', refs.count), refs.subtotal),
    h('div', { class: 'sum-row input-row' }, h('span', null, 'Discount ', refs.discHint), h('div', { class: 'inline-input' }, discIn, modeBtn)),
    h('div', { class: 'sum-row grand' }, h('span', null, 'Grand total'), refs.grand),
    h('div', { class: 'sum-row input-row' }, h('span', null, 'Paid'), h('div', { class: 'inline-input' }, paidIn, h('button', { class: 'btn btn-sm', type: 'button', onclick: () => { state.paidTouched = false; paidIn.value = ''; updateTotals(); } }, 'Full'), h('button', { class: 'btn btn-sm', type: 'button', onclick: () => { state.paidTouched = true; state.paid = '0'; paidIn.value = '0'; updateTotals(); } }, 'None'))),
    h('div', { class: 'sum-row input-row' }, h('span', null, 'Paid by'), refs.method),
    h('div', { class: 'sum-row due' }, h('span', null, 'Due'), refs.due),
    notesIn,
    h('div', { class: 'row gap' }, refs.saveOnly, refs.save),
    h('button', { class: 'btn btn-link', type: 'button', onclick: () => { if (!state.items.length || confirm('Clear this invoice?')) resetAll(); } }, 'Clear invoice'),
  );

  mount(
    root,
    h('div', { class: 'page-head' }, h('h2', null, 'New sale')),
    h(
      'div',
      { class: 'pos-layout' },
      h('div', { class: 'pos-main' }, customerCard, h('section', { class: 'card' }, h('div', { class: 'card-head' }, h('h3', null, 'Products'), h('button', { class: 'btn btn-primary btn-sm', onclick: pickProduct }, icon('plus', 16), 'Add product')), itemsBox)),
      h('div', { class: 'pos-side' }, summary),
    ),
  );

  if (state.customer) lastPrices = await lastPricesFor(state.customer.id);
  paintCustomer();
  paintItems();
  updateTotals();
}

/**
 * product-profile.js — one product with its COMPLETE stock history.
 * Route: #/products/<id>
 *
 * Shows what the product is (name, codes, unit, price, cost for those allowed to see it),
 * the stock on hand, quick actions (receive · correct · damaged) and every stock change
 * ever recorded for it, newest first. A note says honestly when part of the stock
 * pre-dates the history (it is never invented).
 */
import { h, mount, icon } from '../dom.js';
import { badge, emptyState, downloadCSV, guard, pageHeader, skeleton } from '../components.js';
import { productHistory, movementsToCSV } from '../../services/inventory.js';
import { auth } from '../../services/auth.js';
import { money, qty, fmtDateTime } from '../../core/format.js';
import { bus } from '../../core/bus.js';
import { movementTable, movementSheet, receiveDialog, adjustDialog, writeOffDialog } from '../stock-ui.js';
import { printSheet } from '../report-print.js';

const tile = (label, value, sub, cls = '') => h('div', { class: 'stat-tile' }, h('div', { class: 'stat-label' }, label), h('div', { class: `stat-value ${cls}` }, value), sub ? h('div', { class: 'stat-sub' }, sub) : null);

export async function renderProductProfile(root, id) {
  const head = h('div');
  const body = h('section', { class: 'card' });
  mount(root, h('p', null, h('a', { href: '#/products' }, '← All products')), head, body);
  mount(head, skeleton());

  let seq = 0;
  async function load() {
    const my = ++seq;
    let d;
    try {
      d = await productHistory(id);
    } catch (e) {
      if (my !== seq) return;
      return mount(root, emptyState('Product not found', e?.message, h('a', { class: 'btn', href: '#/products' }, 'Back')));
    }
    if (my !== seq) return;
    paint(d);
  }

  function paint({ product: p, movements, check }) {
    const canAdjust = auth.can('inventory.adjust');
    const canCost = auth.can('reports.profit');
    const low = p.stock <= p.lowStockLevel;
    const stockCls = p.stock <= 0 ? 'neg' : low ? 'warn-text' : '';
    mount(
      head,
      h(
        'div',
        { class: 'card profile-card' },
        h(
          'div',
          { class: 'card-head' },
          h('div', null, h('h2', null, p.name, ' ', p.code ? badge(p.code, 'info') : null, p.active ? null : badge('Archived', 'neutral')), h('div', { class: 'muted' }, [p.sku ? `SKU ${p.sku}` : '', `per ${p.unit}`].filter(Boolean).join(' · ')), h('div', { class: 'muted small id-line' }, 'Product ID: ', h('code', { 'data-field': 'product-id' }, p.id))),
          h(
            'div',
            { class: 'page-actions' },
            h('button', { class: 'btn btn-sm', 'data-action': 'csv', onclick: () => guard(() => downloadCSV(`stock-history-${(p.code || p.id.slice(0, 8)).replace(/[^A-Za-z0-9-]/g, '')}.csv`, movementsToCSV(movements, { cost: canCost }))) }, icon('download', 16), 'CSV'),
            h('button', { class: 'btn btn-sm', 'data-action': 'print', onclick: () => printSheet(movementSheet(movements, { title: `Stock history — ${p.name}`, cost: canCost, meta: [['Product', p.name], ['Product ID', `${p.code ? `${p.code} · ` : ''}${p.id}`], ['Stock now', `${qty(p.stock)} ${p.unit}`]] })) }, icon('printer', 16), 'Print'),
          ),
        ),
        h('div', { class: 'stat-grid' }, tile('In stock', `${qty(p.stock)} ${p.unit}`, low ? (p.stock <= 0 ? 'out of stock' : `low (warn at ${qty(p.lowStockLevel)})`) : `warn at ${qty(p.lowStockLevel)}`, stockCls), tile('Default price', money(p.defaultPrice), `per ${p.unit}`), canCost ? tile('Cost price', money(p.costPrice), `stock value ${money(p.costPrice * p.stock)}`) : null, tile('History records', String(check.count), check.firstRecordedAt ? `since ${fmtDateTime(check.firstRecordedAt)}` : 'none yet')),
        canAdjust
          ? h('div', { class: 'row gap profile-actions' }, h('button', { class: 'btn btn-primary', 'data-action': 'receive', onclick: () => receiveDialog(p, load) }, icon('plus', 18), 'Receive stock'), h('button', { class: 'btn', 'data-action': 'correct', onclick: () => adjustDialog(p, load) }, 'Correct count'), h('button', { class: 'btn', 'data-action': 'damage', onclick: () => writeOffDialog(p, load) }, 'Damaged / lost'))
          : null,
        check.ok ? null : h('div', { class: 'warn-box', 'data-warning': 'ledger' }, `⚠ This product's history does not add up: ${check.problems.slice(0, 2).join('; ')}.`),
        check.ok && check.untracked > 0 ? h('div', { class: 'hint-box', 'data-notice': 'untracked' }, `${qty(check.untracked)} ${p.unit} of the current stock already existed before stock history was recorded for this product. History starts at the first recorded change; earlier movements are unknown and are not invented.`) : null,
      ),
    );
    mount(body, movementTable(movements, { cost: canCost, product: false, empty: 'No stock history recorded for this product yet.' }));
  }

  await load();
  return bus.on('data:changed', () => load());
}

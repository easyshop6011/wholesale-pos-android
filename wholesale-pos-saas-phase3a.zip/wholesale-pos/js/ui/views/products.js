/**
 * products.js — product list with search / category filter, add / edit / delete,
 * and the category manager. Employees can browse; only admins can change data
 * (permission "products.edit" is granted by the admin wildcard).
 */
import { h, mount, icon } from '../dom.js';
import { openModal, confirmDialog, promptDialog, toast, guard, field, select, badge, emptyState, pageHeader, filterBar, pager, debounce } from '../components.js';
import { listProducts, listCategories, saveProduct, deleteProduct, saveCategory, deleteCategory } from '../../services/catalog.js';
import { auth } from '../../services/auth.js';
import { money, qty } from '../../core/format.js';
import { bus } from '../../core/bus.js';
import { uuid } from '../../core/utils.js';
import { renderProductProfile } from './product-profile.js';

export default async function render(root, ctx = {}) {
  if (ctx.params?.[0]) return renderProductProfile(root, ctx.params[0]);
  const canEdit = auth.can('products.edit');
  const PAGE = 60;
  let offset = 0;
  const listBox = h('div');
  const meta = h('div', { class: 'result-meta' });
  const catOptions = (cats) => [{ value: '', label: 'All categories' }, ...cats.map((c) => ({ value: c.id, label: c.name }))];
  let cats = await listCategories();
  let fb = buildFilters();

  function buildFilters(prev = {}) {
    const f = filterBar(
      [
        { key: 'search', type: 'search', placeholder: 'Search name, SKU, category…' },
        { key: 'categoryId', type: 'select', label: 'Category', options: catOptions(cats) },
        { key: 'stock', type: 'select', label: 'Stock', options: [{ value: '', label: 'Any stock' }, { value: 'attention', label: 'Needs attention' }, { value: 'low', label: 'Low' }, { value: 'out', label: 'Out of stock' }, { value: 'ok', label: 'In stock' }] },
        { key: 'sort', type: 'select', label: 'Sort', default: 'name', options: [{ value: 'name', label: 'Name A–Z' }, { value: 'stock-asc', label: 'Lowest stock' }, { value: 'stock-desc', label: 'Highest stock' }, { value: 'price-asc', label: 'Price: low → high' }, { value: 'price-desc', label: 'Price: high → low' }, { value: 'newest', label: 'Newest' }] },
        { key: 'minPrice', type: 'number', label: 'Min price', more: true },
        { key: 'maxPrice', type: 'number', label: 'Max price', more: true },
      ],
      { search: prev.search ?? ctx.query?.q ?? '', categoryId: prev.categoryId ?? '', stock: prev.stock ?? '', sort: prev.sort ?? 'name', minPrice: prev.minPrice ?? '', maxPrice: prev.maxPrice ?? '' },
      () => { offset = 0; paint(); },
    );
    return f;
  }
  const filterHost = h('div', null, fb.el);

  mount(
    root,
    pageHeader('Products', canEdit ? h('button', { class: 'btn', onclick: manageCategories }, icon('tag', 18), 'Categories') : null, canEdit ? h('button', { class: 'btn btn-primary', onclick: () => editProduct() }, icon('plus', 18), 'Add product') : null),
    filterHost,
    meta,
    h('section', { class: 'card' }, listBox),
  );

  /** Reload category filter options (keeps the other filters). */
  async function loadCats() {
    cats = await listCategories();
    const keep = { ...fb.values };
    if (!cats.some((c) => c.id === keep.categoryId)) keep.categoryId = '';
    fb = buildFilters(keep);
    filterHost.replaceChildren(fb.el);
    return cats;
  }

  let seq = 0;
  async function paint() {
    const my = ++seq;
    const v = fb.values;
    const all = await listProducts({ search: v.search, categoryId: v.categoryId || null, stock: v.stock, sort: v.sort, minPrice: v.minPrice, maxPrice: v.maxPrice });
    if (my !== seq) return;
    const rows = all.slice(offset, offset + PAGE);
    mount(meta, h('span', null, `${all.length} product${all.length === 1 ? '' : 's'}`));
    if (!all.length) {
      mount(listBox, emptyState('No products found', v.search || v.categoryId || v.stock || v.minPrice || v.maxPrice ? 'Try different filters.' : 'Add your first product to start selling.', canEdit ? h('button', { class: 'btn btn-primary', onclick: () => editProduct() }, 'Add product') : null));
      return;
    }
    mount(
      listBox,
      h(
        'ul',
        { class: 'list' },
        rows.map((p) =>
          h(
            'li',
            { class: 'click', onclick: (e) => { if (!e.target.closest('button')) ctx.navigate?.(`products/${p.id}`); } },
            h('div', { class: 'grow' }, h('a', { class: 'strong', href: `#/products/${p.id}` }, p.name), h('div', { class: 'muted small' }, `${p.code ? `${p.code} · ` : ''}${p.categoryName}${p.sku ? ` · ${p.sku}` : ''} · default ${money(p.defaultPrice)} / ${p.unit}`)),
            h('div', { class: 'right' }, h('div', { class: p.stock <= 0 ? 'neg strong' : p.stock <= p.lowStockLevel ? 'warn-text strong' : 'strong' }, `${qty(p.stock)} ${p.unit}`), p.stock <= 0 ? badge('Out', 'danger') : p.stock <= p.lowStockLevel ? badge('Low', 'warn') : null),
            canEdit
              ? h('div', { class: 'row' }, h('button', { class: 'icon-btn', title: 'Stock history', 'aria-label': `Stock history of ${p.name}`, onclick: () => ctx.navigate?.(`products/${p.id}`) }, icon('layers', 18)), h('button', { class: 'icon-btn', title: 'Edit', 'aria-label': `Edit ${p.name}`, onclick: () => editProduct(p) }, icon('edit', 18)), h('button', { class: 'icon-btn', title: 'Delete', 'aria-label': `Delete ${p.name}`, onclick: () => remove(p) }, icon('trash', 18)))
              : null,
          ),
        ),
      ),
      pager({ total: all.length, offset, limit: PAGE, onPage: (o) => { offset = o; paint(); window.scrollTo(0, 0); } }),
    );
  }

  /** Add / edit dialog. */
  async function editProduct(p = null) {
    const cats = await listCategories();
    const requestId = uuid(); // one per dialog: a double tap on Save cannot create the product twice
    const f = {
      name: h('input', { class: 'input', value: p?.name || '', required: true, autofocus: true }),
      sku: h('input', { class: 'input', value: p?.sku || '', placeholder: 'Optional · barcode / code' }),
      category: select([{ value: '', label: 'Uncategorized' }, ...cats.map((c) => ({ value: c.id, label: c.name }))], p?.categoryId || ''),
      unit: h('input', { class: 'input', value: p?.unit || 'pcs', list: 'unit-list' }),
      cost: h('input', { class: 'input', inputmode: 'decimal', value: p ? p.costPrice : '', placeholder: '0.00' }),
      price: h('input', { class: 'input', inputmode: 'decimal', value: p ? p.defaultPrice : '', placeholder: '0.00' }),
      stock: h('input', { class: 'input', inputmode: 'decimal', value: '', placeholder: '0' }),
      low: h('input', { class: 'input', inputmode: 'decimal', value: p ? p.lowStockLevel : '', placeholder: 'Default' }),
    };
    const units = h('datalist', { id: 'unit-list' }, ['pcs', 'kg', 'g', 'ltr', 'bag', 'box', 'ctn', 'dozen', 'pack', 'tin', 'btl'].map((u) => h('option', { value: u })));
    const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Save');
    const m = openModal({
      title: p ? 'Edit product' : 'Add product',
      content: h(
        'form',
        {
          class: 'stack',
          onsubmit: (e) => {
            e.preventDefault();
            guard(async () => {
              await saveProduct({ id: p?.id, requestId, name: f.name.value, sku: f.sku.value, categoryId: f.category.value || null, unit: f.unit.value, costPrice: f.cost.value, defaultPrice: f.price.value, stock: f.stock.value, lowStockLevel: f.low.value }, auth.user());
              m.close();
              toast(p ? 'Product updated' : 'Product added', 'success');
            }, save);
          },
        },
        field('Product name', f.name),
        h('div', { class: 'grid-2' }, field('Category', f.category), field('Unit', f.unit)),
        units,
        h('div', { class: 'grid-2' }, field('Cost price', f.cost, 'Used for profit in reports'), field('Default price', f.price, 'Only a suggestion — type the real price on each invoice')),
        h('div', { class: 'grid-2' }, p ? field('Current stock', h('input', { class: 'input', value: `${qty(p.stock)} ${p.unit}`, disabled: true }), 'Change it from Inventory (receive / correct) — every change is recorded in the stock history') : field('Opening stock', f.stock), field('Low-stock warning at', f.low, 'Leave empty to use the default')),
        field('Code / SKU', f.sku),
        h('div', { class: 'modal-actions inline' }, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), save),
      ),
    });
  }

  async function remove(p) {
    if (!(await confirmDialog({ title: 'Delete product', message: `Delete “${p.name}”?\nIts stock history and past invoices are always kept, so the product is archived (hidden from selling) instead of being erased.`, confirmText: 'Delete', danger: true }))) return;
    const r = await guard(() => deleteProduct(p.id));
    if (r) toast(r.archived ? 'Product archived — its history is kept' : 'Product deleted', 'success');
  }

  /** Category manager. */
  async function manageCategories() {
    const body = h('div', { class: 'stack' });
    const m = openModal({ title: 'Categories', size: 'sm', content: body, actions: [h('button', { class: 'btn btn-primary', onclick: () => m.close() }, 'Done')] });
    const draw = async () => {
      const cats = await listCategories();
      mount(
        body,
        h('button', { class: 'btn btn-primary btn-sm', onclick: async () => { const n = await promptDialog({ title: 'New category', label: 'Name' }); if (n && (await guard(() => saveCategory({ name: n })))) draw(); } }, icon('plus', 16), 'Add category'),
        cats.length
          ? h(
              'ul',
              { class: 'list' },
              cats.map((c) =>
                h(
                  'li',
                  null,
                  h('span', null, c.name),
                  h(
                    'div',
                    { class: 'row' },
                    h('button', { class: 'icon-btn', 'aria-label': `Rename ${c.name}`, onclick: async () => { const n = await promptDialog({ title: 'Rename category', label: 'Name', value: c.name }); if (n && (await guard(() => saveCategory({ id: c.id, name: n })))) draw(); } }, icon('edit', 18)),
                    h('button', { class: 'icon-btn', 'aria-label': `Delete ${c.name}`, onclick: async () => { if (await confirmDialog({ message: `Delete category “${c.name}”? Its products become Uncategorized.`, danger: true, confirmText: 'Delete' })) { await guard(() => deleteCategory(c.id)); draw(); } } }, icon('trash', 18)),
                  ),
                ),
              ),
            )
          : emptyState('No categories yet'),
      );
    };
    draw();
  }

  await paint();
  const off = bus.on('data:changed', debounce(async ({ store } = {}) => {
    if (store === 'categories' || store === '*') await loadCats();
    paint();
  }, 250));
  return off;
}

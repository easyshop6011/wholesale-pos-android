/**
 * reports.js — the Reports screen.
 *
 * Tabs: Overview (KPIs + comparison with the previous period + trend), Sales,
 * Products, Customers (top buyers + due ageing), Profit, Staff, Busy hours,
 * Inventory (+ re-order suggestions) and the Daily sheet. Every tab can export
 * CSV (UTF-8 with BOM so Excel shows Bengali correctly) and print.
 * Cost/profit figures need the `reports.profit` permission.
 */
import { h, mount, icon } from '../dom.js';
import { pageHeader, downloadCSV, emptyState, select, field } from '../components.js';
import {
  dailyReport, inventoryReport, salesTrend, monthlyTrend, productSalesReport, topCustomers, categoryShare, profitReport,
  salesByUser, paymentMix, hourlySales, periodSummary, dueAging, AGE_BUCKETS, reorderSuggestions,
} from '../../services/reports.js';
import { dataTable, tableToCSV } from '../table.js';
import { money, qty, fmtDate, fmtMonth, fmtTime } from '../../core/format.js';
import { dateParts, addDays } from '../../core/utils.js';
import { showInvoiceDetail } from './invoices.js';
import { auth } from '../../services/auth.js';
import { lineChart, barChart, hBars, donut, delta, legend } from '../charts.js';

const PRESETS = [
  { value: 'today', label: 'Today' },
  { value: '7', label: 'Last 7 days' },
  { value: '30', label: 'Last 30 days' },
  { value: '90', label: 'Last 90 days' },
  { value: 'month', label: 'This month' },
  { value: 'lastmonth', label: 'Last month' },
  { value: 'year', label: 'This year' },
  { value: 'custom', label: 'Custom…' },
];

/** Date range for a preset. */
export function rangeFor(preset, today = dateParts().date, custom = {}) {
  const first = (d) => `${d.slice(0, 7)}-01`;
  switch (preset) {
    case 'today': return { from: today, to: today };
    case '7': return { from: addDays(today, -6), to: today };
    case '90': return { from: addDays(today, -89), to: today };
    case 'month': return { from: first(today), to: today };
    case 'lastmonth': { const end = addDays(first(today), -1); return { from: first(end), to: end }; }
    case 'year': return { from: `${today.slice(0, 4)}-01-01`, to: today };
    case 'custom': return { from: custom.from || addDays(today, -29), to: custom.to || today };
    default: return { from: addDays(today, -29), to: today };
  }
}

/** The period of the same length that ends the day before `from`. */
export function previousRange({ from, to }) {
  const days = Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000) + 1;
  return { from: addDays(from, -days), to: addDays(from, -1) };
}

const label = (key) => ({ day: 'Daily', week: 'Weekly', month: 'Monthly' })[key] || key;

const kpi = (l, v, extra, tone = '') => h('div', { class: 'kpi' }, h('div', { class: 'kpi-l' }, l), h('div', { class: `kpi-v ${tone}` }, v), extra || null);
const card = (title, ...kids) => h('section', { class: 'card' }, title ? h('div', { class: 'card-head' }, h('h3', null, title)) : null, ...kids);
const tableCard = (cols, rows, opts) => h('section', { class: 'card' }, dataTable(cols, rows, opts));

/** Short x-axis label for a bucket. */
function bucketLabel(b, gran) {
  if (gran === 'month') return new Date(`${b.key}-01T12:00:00`).toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
  return new Date(`${b.key}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}
/** Pick day/week/month buckets so a chart never has hundreds of points. */
const granFor = ({ from, to }) => {
  const days = (Date.parse(to) - Date.parse(from)) / 86400000 + 1;
  return days <= 45 ? 'day' : days <= 200 ? 'week' : 'month';
};

export default async function render(root) {
  const now = dateParts();
  const canProfit = auth.can('reports.profit');
  const TABS = [
    { value: 'overview', label: 'Overview' },
    { value: 'sales', label: 'Sales' },
    { value: 'products', label: 'Products' },
    { value: 'customers', label: 'Customers' },
    ...(canProfit ? [{ value: 'profit', label: 'Profit' }] : []),
    { value: 'staff', label: 'Staff' },
    { value: 'hours', label: 'Busy hours' },
    { value: 'inventory', label: 'Inventory' },
    { value: 'daily', label: 'Daily sheet' },
  ];
  const s = { tab: 'overview', preset: '30', custom: {}, date: now.date, gran: 'auto' };
  const controls = h('div', { class: 'range-bar' });
  const body = h('div');
  const tabsEl = h('div', { class: 'rtabs', role: 'tablist' });
  let csv = null;
  let seq = 0;

  const exportBtn = h('button', { class: 'btn', onclick: () => csv && downloadCSV(csv.name, csv.text) }, icon('download', 18), 'Export CSV');
  const printBtn = h('button', { class: 'btn', onclick: () => window.print() }, icon('printer', 18), 'Print');
  mount(root, pageHeader('Reports', exportBtn, printBtn), tabsEl, controls, body);

  const paintTabs = () => mount(tabsEl, TABS.map((t) => h('button', { type: 'button', role: 'tab', class: t.value === s.tab ? 'active' : '', 'aria-selected': t.value === s.tab, onclick: () => { s.tab = t.value; paintTabs(); paint(); } }, t.label)));

  const dateInput = (get, set) => h('input', { class: 'input', type: 'date', value: get(), onchange: (e) => { if (e.target.value) { set(e.target.value); paint(); } } });
  function paintControls() {
    if (s.tab === 'daily') return mount(controls, field('Date', dateInput(() => s.date, (v) => (s.date = v))));
    if (s.tab === 'inventory') return mount(controls);
    const sel = select(PRESETS, s.preset, { onchange: (e) => { s.preset = e.target.value; paintControls(); paint(); } });
    mount(controls, sel, s.preset === 'custom' ? [dateInput(() => rangeFor('custom', now.date, s.custom).from, (v) => (s.custom.from = v)), '→', dateInput(() => rangeFor('custom', now.date, s.custom).to, (v) => (s.custom.to = v))] : h('span', { class: 'muted small' }, (() => { const r = rangeFor(s.preset, now.date, s.custom); return r.from === r.to ? fmtDate(r.from) : `${fmtDate(r.from)} – ${fmtDate(r.to)}`; })()));
  }

  async function paint() {
    const my = ++seq;
    paintControls();
    csv = null;
    mount(body, h('div', { class: 'sk-stats' }, [1, 2, 3, 4].map(() => h('div', { class: 'sk' }))), h('div', { class: 'card' }, h('div', { class: 'sk sk-box' })));
    try {
      const r = rangeFor(s.preset, now.date, s.custom);
      const view = await ({ overview, sales, products, customers, profit, staff, hours, inventory, daily }[s.tab])(r);
      if (my === seq) mount(body, view);
    } catch (e) {
      console.error(e);
      if (my === seq) mount(body, emptyState('Report failed', e.message));
    }
  }

  // ---- Overview -------------------------------------------------------------
  async function overview(r) {
    const prev = previousRange(r);
    const gran = granFor(r);
    const [cur, before, trend, mix, cats, topP] = await Promise.all([periodSummary(r), periodSummary(prev), salesTrend({ ...r, granularity: gran }), paymentMix(r), categoryShare(r), productSalesReport(r)]);
    const b = trend.buckets;
    csv = { name: `overview-${r.from}_to_${r.to}.csv`, text: tableToCSV([{ label: 'Period', value: (x) => x.key }, { label: 'Invoices', value: (x) => x.invoices }, { label: 'Sales', value: (x) => x.sales }, { label: 'Paid at sale', value: (x) => x.paid }, { label: 'Due created', value: (x) => x.due }, { label: 'Dues collected', value: (x) => x.paymentsReceived }], b) };
    return h('div', null,
      h('div', { class: 'kpis' },
        kpi('Sales', money(cur.sales), delta(cur.sales, before.sales)),
        kpi('Invoices', String(cur.invoices), delta(cur.invoices, before.invoices)),
        kpi('Average invoice', money(cur.avgInvoice), delta(cur.avgInvoice, before.avgInvoice)),
        kpi('Cash collected', money(cur.cashCollected), delta(cur.cashCollected, before.cashCollected), 'ok-text'),
        kpi('Due created', money(cur.dueCreated), delta(cur.dueCreated, before.dueCreated, { inverse: true }), cur.dueCreated > 0 ? 'warn-text' : ''),
        canProfit ? kpi('Gross profit', money(cur.profit), delta(cur.profit, before.profit), 'ok-text') : null,
      ),
      h('p', { class: 'muted small' }, `Compared with ${fmtDate(prev.from)} – ${fmtDate(prev.to)}.`),
      card(`Sales (${label(gran).toLowerCase()})`,
        lineChart({ labels: b.map((x) => bucketLabel(x, gran)), series: [{ label: 'Sales', values: b.map((x) => x.sales) }, { label: 'Cash collected', values: b.map((x) => x.cashCollected), color: 'var(--c2)' }], format: money, title: 'Sales and cash collected', tipTitle: (i) => (gran === 'month' ? fmtMonth(b[i].key) : fmtDate(b[i].key)) }),
        legend([{ label: 'Sales' }, { label: 'Cash collected', color: 'var(--c2)' }])),
      h('div', { class: 'grid-2 gap' },
        card('Top products', hBars(topP.rows.slice(0, 6).map((p) => ({ label: p.name, value: p.revenue, sub: `${qty(p.qty)} ${p.unit || ''}` })), { format: money })),
        card('Sales by category', donut(cats.rows.map((c) => ({ label: c.category || 'Uncategorized', value: c.revenue })), { format: money, centre: money(cats.total), centreSub: 'total' }))),
      card('Where the money went', donut([{ label: 'Paid at sale', value: mix.paidAtSale }, { label: 'Old dues collected', value: mix.duesCollected }, { label: 'Credit given (due)', value: mix.dueCreated }], { format: money })),
    );
  }

  // ---- Sales ----------------------------------------------------------------
  async function sales(r) {
    const gran = s.gran === 'auto' ? granFor(r) : s.gran;
    const t = await salesTrend({ ...r, granularity: gran });
    const b = t.buckets;
    const cols = [
      { label: gran === 'month' ? 'Month' : gran === 'week' ? 'Week of' : 'Date', value: (x) => x.key, render: (x) => (gran === 'month' ? fmtMonth(x.key) : fmtDate(x.key)) },
      { label: 'Invoices', num: true, value: (x) => x.invoices },
      { label: 'Sales', num: true, value: (x) => x.sales, render: (x) => money(x.sales) },
      { label: 'Discount', num: true, value: (x) => x.discount, render: (x) => money(x.discount) },
      { label: 'Paid at sale', num: true, value: (x) => x.paid, render: (x) => money(x.paid) },
      { label: 'Due created', num: true, value: (x) => x.due, render: (x) => money(x.due) },
      { label: 'Dues collected', num: true, value: (x) => x.paymentsReceived, render: (x) => money(x.paymentsReceived) },
    ];
    const tt = t.totals;
    csv = { name: `sales-${gran}-${r.from}_to_${r.to}.csv`, text: tableToCSV(cols, b, ['Total', tt.invoices, tt.sales, tt.discount, tt.paid, tt.due, tt.paymentsReceived]) };
    const gsel = select([{ value: 'auto', label: 'Auto grouping' }, { value: 'day', label: 'By day' }, { value: 'week', label: 'By week' }, { value: 'month', label: 'By month' }], s.gran, { onchange: (e) => { s.gran = e.target.value; paint(); } });
    const year = s.preset === 'year' || s.preset === 'custom' ? null : await monthlyTrend(12);
    return h('div', null,
      h('div', { class: 'range-bar' }, gsel),
      h('div', { class: 'kpis' }, kpi('Sales', money(tt.sales)), kpi('Invoices', String(tt.invoices)), kpi('Discounts', money(tt.discount)), kpi('Dues collected', money(tt.paymentsReceived), null, 'ok-text')),
      card(`${label(gran)} sales`, barChart({ labels: b.map((x) => bucketLabel(x, gran)), series: [{ label: 'Sales', values: b.map((x) => x.sales) }], format: money, title: 'Sales', tipTitle: (i) => (gran === 'month' ? fmtMonth(b[i].key) : fmtDate(b[i].key)) })),
      year ? card('Last 12 months', lineChart({ labels: year.buckets.map((x) => bucketLabel(x, 'month')), series: [{ label: 'Sales', values: year.buckets.map((x) => x.sales) }], format: money, title: 'Monthly sales, last 12 months', height: 180, tipTitle: (i) => fmtMonth(year.buckets[i].key) })) : null,
      tableCard(cols, b, { footer: ['Total', tt.invoices, money(tt.sales), money(tt.discount), money(tt.paid), money(tt.due), money(tt.paymentsReceived)], empty: 'No sales in this period.' }));
  }

  // ---- Products -------------------------------------------------------------
  async function products(r) {
    const [p, cats] = await Promise.all([productSalesReport(r), categoryShare(r)]);
    const cols = [
      { label: 'Product', value: (x) => x.name },
      { label: 'Qty sold', num: true, value: (x) => x.qty, render: (x) => `${qty(x.qty)} ${x.unit || ''}` },
      { label: 'Invoices', num: true, value: (x) => x.invoices },
      { label: 'Avg price', num: true, value: (x) => x.avgPrice, render: (x) => money(x.avgPrice) },
      { label: 'Revenue', num: true, value: (x) => x.revenue, render: (x) => money(x.revenue) },
      ...(canProfit ? [{ label: 'Est. profit', num: true, value: (x) => x.profit, render: (x) => money(x.profit) }] : []),
    ];
    csv = { name: `product-sales-${r.from}_to_${r.to}.csv`, text: tableToCSV(cols, p.rows) };
    return h('div', null,
      h('div', { class: 'grid-2 gap' },
        card('Top 10 by revenue', hBars(p.rows.slice(0, 10).map((x) => ({ label: x.name, value: x.revenue, sub: `${qty(x.qty)} ${x.unit || ''} · ${x.invoices} invoice${x.invoices === 1 ? '' : 's'}` })), { format: money })),
        card('By category', donut(cats.rows.map((c) => ({ label: c.category || 'Uncategorized', value: c.revenue })), { format: money }))),
      tableCard(cols, p.rows, { empty: 'No product sales in this period.' }),
      h('p', { class: 'muted small' }, 'Revenue is the sum of invoice lines (before any invoice-level discount).'));
  }

  // ---- Customers ------------------------------------------------------------
  async function customers(r) {
    const [top, age] = await Promise.all([topCustomers({ ...r, limit: 10 }), dueAging()]);
    const cols = [
      { label: 'Customer', value: (c) => c.name },
      { label: 'Phone', value: (c) => c.phone },
      ...AGE_BUCKETS.map((a) => ({ label: a.label, num: true, value: (c) => c[a.key], render: (c) => (c[a.key] > 0 ? money(c[a.key]) : '—') })),
      { label: 'Total due', num: true, value: (c) => c.total, render: (c) => h('span', { class: 'neg strong' }, money(c.total)) },
      { label: 'Oldest', num: true, value: (c) => c.oldestDays, render: (c) => `${c.oldestDays}d` },
    ];
    csv = { name: `customer-dues-ageing-${now.date}.csv`, text: tableToCSV(cols, age.rows, ['Total', '', ...AGE_BUCKETS.map((a) => age.totals[a.key]), age.totals.total, '']) };
    return h('div', null,
      card(`Top customers (${fmtDate(r.from)} – ${fmtDate(r.to)})`, hBars(top.rows.map((c) => ({ label: c.name, value: c.sales, sub: `${c.invoices} invoice${c.invoices === 1 ? '' : 's'}${c.due > 0 ? ` · due ${money(c.due)}` : ''}`, href: `#/customers/${c.customerId}` })), { format: money })),
      card('Customer dues by age',
        h('div', { class: 'kpis' }, kpi('Total outstanding', money(age.totals.total), null, age.totals.total > 0 ? 'neg' : ''), ...AGE_BUCKETS.map((a) => kpi(a.label, money(age.totals[a.key]), null, a.key === 'd90' && age.totals.d90 > 0 ? 'neg' : ''))),
        barChart({ labels: AGE_BUCKETS.map((a) => a.label.replace(' days', 'd')), series: [{ label: 'Outstanding', values: AGE_BUCKETS.map((a) => age.totals[a.key]), color: 'var(--c3)' }], format: money, title: 'Dues by age', height: 170 })),
      tableCard(cols, age.rows, { footer: ['Total', '', ...AGE_BUCKETS.map((a) => money(age.totals[a.key])), money(age.totals.total), ''], onRow: (c) => (location.hash = `#/customers/${c.id}`), empty: 'No customer owes anything. 🎉' }),
      h('p', { class: 'muted small' }, 'Payments are applied to the oldest unpaid invoices first.'));
  }

  // ---- Profit ---------------------------------------------------------------
  async function profit(r) {
    const gran = granFor(r);
    const [p, t] = await Promise.all([profitReport(r), Promise.resolve(null)]);
    void t;
    const days = p.byDay;
    const cols = [
      { label: 'Product', value: (x) => x.name },
      { label: 'Qty', num: true, value: (x) => x.qty, render: (x) => `${qty(x.qty)} ${x.unit || ''}` },
      { label: 'Revenue', num: true, value: (x) => x.revenue, render: (x) => money(x.revenue) },
      { label: 'Cost', num: true, value: (x) => x.cost, render: (x) => money(x.cost) },
      { label: 'Profit', num: true, value: (x) => x.profit, render: (x) => h('span', { class: x.profit < 0 ? 'neg strong' : 'strong' }, money(x.profit)) },
      { label: 'Margin', num: true, value: (x) => x.margin, render: (x) => `${x.margin}%` },
    ];
    csv = { name: `profit-${r.from}_to_${r.to}.csv`, text: tableToCSV(cols, p.byProduct) };
    const T = p.totals;
    void gran;
    return h('div', null,
      h('div', { class: 'kpis' }, kpi('Revenue (net)', money(T.revenue)), kpi('Cost of goods', money(T.cost)), kpi('Gross profit', money(T.profit), null, 'ok-text'), kpi('Margin', `${T.margin}%`), kpi('Discounts given', money(T.discount), h('div', { class: 'small muted' }, `${T.discountPct}% of gross`))),
      T.missingCostLines ? h('div', { class: 'warn-box' }, `${T.missingCostLines} sold line(s) have no cost price — profit is overstated for them. Set cost prices on products.`) : null,
      card('Profit by day', barChart({ labels: days.map((x) => fmtDate(x.date).slice(0, 6)), series: [{ label: 'Profit', values: days.map((x) => Math.max(0, x.profit)), color: 'var(--c5)' }], format: money, title: 'Profit by day', tipTitle: (i) => fmtDate(days[i].date), height: 190 })),
      card('Most profitable products', hBars(p.byProduct.slice(0, 8).map((x) => ({ label: x.name, value: Math.max(0, x.profit), sub: `margin ${x.margin}%` })), { format: money, color: 'var(--c5)' })),
      tableCard(cols, p.byProduct, { empty: 'No sales in this period.' }));
  }

  // ---- Staff ----------------------------------------------------------------
  async function staff(r) {
    const u = await salesByUser(r);
    const cols = [
      { label: 'Cashier', value: (x) => x.name },
      { label: 'Invoices', num: true, value: (x) => x.invoices },
      { label: 'Sales', num: true, value: (x) => x.sales, render: (x) => money(x.sales) },
      { label: 'Avg invoice', num: true, value: (x) => x.avgInvoice, render: (x) => money(x.avgInvoice) },
      { label: 'Discount', num: true, value: (x) => x.discount, render: (x) => money(x.discount) },
      { label: 'Due created', num: true, value: (x) => x.due, render: (x) => money(x.due) },
      { label: 'Voided', num: true, value: (x) => x.voided },
    ];
    csv = { name: `sales-by-staff-${r.from}_to_${r.to}.csv`, text: tableToCSV(cols, u.rows) };
    return h('div', null, card('Sales by cashier', hBars(u.rows.map((x) => ({ label: x.name, value: x.sales, sub: `${x.invoices} invoices${x.voided ? ` · ${x.voided} voided` : ''}` })), { format: money })), tableCard(cols, u.rows, { empty: 'No sales in this period.' }));
  }

  // ---- Busy hours -----------------------------------------------------------
  async function hours(r) {
    const hs = await hourlySales(r);
    const max = Math.max(...hs.hours.map((x) => x.sales), 1);
    const best = [...hs.hours].sort((a, b) => b.sales - a.sales)[0];
    csv = { name: `hourly-${r.from}_to_${r.to}.csv`, text: tableToCSV([{ label: 'Hour', value: (x) => x.hour }, { label: 'Invoices', value: (x) => x.invoices }, { label: 'Sales', value: (x) => x.sales }], hs.hours) };
    const hh = (n) => `${n % 12 || 12}${n < 12 ? 'a' : 'p'}`;
    return h('div', null,
      card('Sales by hour of day',
        best.sales > 0 ? h('p', { class: 'muted' }, `Busiest hour: ${hh(best.hour)} (${money(best.sales)} over ${best.invoices} invoice${best.invoices === 1 ? '' : 's'}).`) : null,
        barChart({ labels: hs.hours.map((x) => hh(x.hour)), series: [{ label: 'Sales', values: hs.hours.map((x) => x.sales) }], format: money, title: 'Sales by hour', height: 200, tipTitle: (i) => `${hh(i)} – ${hh((i + 1) % 24)}` }),
        h('div', { class: 'heat', style: { marginTop: '14px' } }, hs.hours.map((x) => h('div', { style: { '--v': (x.sales / max).toFixed(2) }, title: `${hh(x.hour)}: ${money(x.sales)}` }))),
        h('div', { class: 'heat-axis' }, hs.hours.map((x) => h('span', null, x.hour % 6 === 0 ? hh(x.hour) : '')))));
  }

  // ---- Inventory ------------------------------------------------------------
  async function inventory() {
    const [r, sug] = await Promise.all([inventoryReport(), reorderSuggestions()]);
    const cols = [
      { label: 'Product', value: (p) => p.name },
      { label: 'Category', value: (p) => p.category },
      { label: 'Stock', num: true, value: (p) => p.stock, render: (p) => `${qty(p.stock)} ${p.unit}` },
      { label: 'Low level', num: true, value: (p) => p.lowStockLevel, render: (p) => qty(p.lowStockLevel) },
      { label: 'Cost value', num: true, value: (p) => p.costValue, render: (p) => money(p.costValue) },
      { label: 'Retail value', num: true, value: (p) => p.retailValue, render: (p) => money(p.retailValue) },
      { label: 'Status', value: (p) => p.status, render: (p) => h('span', { class: p.status === 'OK' ? 'ok-text' : p.status === 'Low' ? 'warn-text' : 'neg' }, p.status) },
    ];
    const scols = [
      { label: 'Product', value: (x) => x.name },
      { label: 'In stock', num: true, value: (x) => x.stock, render: (x) => `${qty(x.stock)} ${x.unit}` },
      { label: `Sold (${sug.days}d)`, num: true, value: (x) => x.soldQty, render: (x) => qty(x.soldQty) },
      { label: 'Per day', num: true, value: (x) => x.perDay },
      { label: 'Lasts', num: true, value: (x) => x.daysLeft ?? '', render: (x) => (x.daysLeft === null ? '—' : `${x.daysLeft}d`) },
      { label: `Buy (${sug.coverDays}d cover)`, num: true, value: (x) => x.suggest, render: (x) => h('b', null, `${qty(x.suggest)} ${x.unit}`) },
      { label: 'Status', value: (x) => x.status, render: (x) => h('span', { class: x.status === 'Running out' ? 'warn-text' : 'neg' }, x.status) },
    ];
    csv = { name: `inventory-${now.date}.csv`, text: tableToCSV(cols, r.rows, ['Total', '', '', '', r.totals.costValue, r.totals.retailValue, '']) };
    return h('div', null,
      h('div', { class: 'kpis' }, kpi('Stock value (cost)', money(r.totals.costValue)), kpi('Stock value (retail)', money(r.totals.retailValue)), kpi('Items', String(r.totals.items)), kpi('Low / out of stock', String(r.totals.low), null, r.totals.low ? 'warn-text' : '')),
      card('Re-order suggestions', h('p', { class: 'muted small' }, `Based on what sold in the last ${sug.days} days.`), dataTable(scols, sug.rows, { empty: 'Nothing needs re-ordering right now.' })),
      tableCard(cols, r.rows, { footer: ['Total', '', '', '', money(r.totals.costValue), money(r.totals.retailValue), ''], empty: 'No products yet.' }));
  }

  // ---- Daily sheet ----------------------------------------------------------
  async function daily() {
    const r = await dailyReport(s.date);
    const sm = r.summary;
    const cols = [
      { label: 'Invoice', value: (i) => i.invoiceNo },
      { label: 'Time', value: (i) => fmtTime(i.time) },
      { label: 'Customer', value: (i) => i.customerName },
      { label: 'Total', num: true, value: (i) => (i.status === 'void' ? 0 : i.total), render: (i) => money(i.total) },
      { label: 'Paid', num: true, value: (i) => i.paid, render: (i) => money(i.paid) },
      { label: 'Due', num: true, value: (i) => i.due, render: (i) => money(i.due) },
      { label: 'Status', value: (i) => i.status },
    ];
    csv = { name: `daily-sales-${s.date}.csv`, text: tableToCSV(cols, r.invoices) };
    return h('div', null, h('div', { class: 'kpis' }, kpi('Net sales', money(sm.netSales)), kpi('Invoices', String(sm.invoices)), kpi('Discounts', money(sm.discount)), kpi('Cash collected', money(sm.cashCollected), null, 'ok-text'), kpi('Due created', money(sm.dueCreated), null, 'neg'), sm.returnsValue > 0 ? kpi('Goods returned', money(sm.returnsValue), null, 'neg') : null, sm.returnsValue > 0 ? kpi('Net after returns', money(sm.netAfterReturns)) : null), tableCard(cols, r.invoices, { onRow: (i) => showInvoiceDetail(i.id), rowClass: (i) => (i.status === 'void' ? 'void' : ''), empty: `No sales on ${fmtDate(s.date)}.` }));
  }

  paintTabs();
  await paint();
}

/**
 * settings-backup.js — Settings → Backup: automatic backups (local snapshots,
 * Google Drive, device copy), snapshot list with restore/download/delete, plus
 * the manual export/import and the Drive backup list.
 */
import { h, mount, icon } from '../dom.js';
import { confirmDialog, toast, guard, badge, downloadFile, pickFile, openModal, promptDialog, field } from '../components.js';
import { settings } from '../../services/settings.js';
import { createBackupFile, importDatabase, backupToDrive, listDriveBackups, restoreFromDrive, serializeBackup, backupFileName, setSessionBackupPassphrase, hasSessionBackupPassphrase } from '../../services/backup.js';
import { encryptionAvailable, MIN_PASSPHRASE } from '../../services/backup-crypto.js';
import { listSnapshots, getSnapshot, deleteSnapshot, restoreSnapshot, takeSnapshot, getBackupStatus } from '../../services/autobackup.js';
import { bus } from '../../core/bus.js';
import { fmtDate, fmtDateTime } from '../../core/format.js';
import { settingsForm, card } from '../settings-form.js';

/** Exact time in Asia/Dhaka. */
const when = (iso) => (iso ? fmtDateTime(iso) : 'never');
const kb = (n) => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);
const REASONS = { auto: ['Automatic', 'info'], manual: ['Manual', 'neutral'], 'before-restore': ['Before restore', 'warn'] };

/**
 * Ask whether to protect a backup file with a passphrase. Resolves `{ passphrase }`
 * ('' = no encryption) or null when cancelled. The passphrase is typed twice, is only
 * used for this one file and is never saved anywhere — losing it means the file cannot
 * be opened by anyone.
 */
export function askNewPassphrase({ title = 'Protect this backup?', confirmText = 'Continue' } = {}) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    const can = encryptionAvailable();
    const use = h('input', { type: 'checkbox', checked: can, disabled: !can, 'data-field': 'encrypt' });
    const pass = h('input', { class: 'input', type: 'password', autocomplete: 'new-password', placeholder: `At least ${MIN_PASSPHRASE} characters`, 'data-field': 'passphrase' });
    const again = h('input', { class: 'input', type: 'password', autocomplete: 'new-password', placeholder: 'Type it again', 'data-field': 'passphrase2' });
    const err = h('div', { class: 'neg small', 'data-field': 'pass-error' });
    for (const el of [pass, again, use]) el.addEventListener('input', () => { err.textContent = ''; });
    const ok = () => {
      err.textContent = ''; // a message from an earlier attempt must not linger once the input is fixed
      if (use.checked) {
        if ([...pass.value].length < MIN_PASSPHRASE) return (err.textContent = `The passphrase must be at least ${MIN_PASSPHRASE} characters.`);
        if (pass.value !== again.value) return (err.textContent = 'The two passphrases are not the same.');
      }
      finish({ passphrase: use.checked ? pass.value : '' });
      m.close();
    };
    const m = openModal({
      title,
      size: 'sm',
      onClose: () => finish(null),
      content: h('div', { class: 'stack' },
        h('p', { class: 'muted small' }, 'A backup contains every customer, invoice and user (as password hashes). Encrypting it means only someone who knows the passphrase can read it — even if the file is lost or shared by mistake.'),
        h('label', { class: 'check' }, use, h('span', null, 'Encrypt with a passphrase (recommended)')),
        can ? null : h('div', { class: 'warn-box' }, 'Encryption needs a secure connection (HTTPS) or the Android app.'),
        field('Passphrase', pass), field('Repeat passphrase', again),
        h('div', { class: 'warn-text small' }, 'The passphrase is NOT stored anywhere. If you forget it the backup cannot be opened — write it down somewhere safe.'),
        err),
      actions: [h('button', { class: 'btn', onclick: () => m.close() }, 'Cancel'), h('button', { class: 'btn btn-primary', 'data-action': 'confirm-passphrase', onclick: ok }, confirmText)],
    });
  });
}

/** Run `fn(passphrase)`; if the file turns out to be encrypted (or the passphrase was wrong) ask for it and try again. */
async function withPassphrase(fn) {
  let pass = '';
  for (;;) {
    try {
      return await fn(pass);
    } catch (e) {
      if (e?.code !== 'passphrase-required' && !/Wrong passphrase/.test(e?.message || '')) throw e;
      const p = await promptDialog({ title: 'Encrypted backup', label: e?.code === 'passphrase-required' ? 'Backup passphrase' : 'Wrong passphrase — try again', type: 'password', confirmText: 'Open backup' });
      if (!p) return undefined;
      pass = p;
    }
  }
}

export function backupTab(offs) {
  const statusBox = h('div', { class: 'stack' });
  const snapBox = h('div');
  const driveBox = h('div', { class: 'stack' });

  const paintStatus = async () => {
    const st = await getBackupStatus();
    mount(
      statusBox,
      h(
        'dl',
        { class: 'kv' },
        h('dt', null, 'Automatic backup'), h('dd', null, st.enabled ? badge('On', 'ok') : badge('Off', 'warn')),
        h('dt', null, 'Last automatic backup'), h('dd', null, when(st.lastAutoBackupAt)),
        h('dt', null, 'Next due'), h('dd', null, st.enabled && st.nextDueAt ? when(st.nextDueAt) : '—'),
        h('dt', null, 'Saved snapshots'), h('dd', null, String(st.count)),
        h('dt', null, 'Last Google Drive backup'), h('dd', null, when(st.lastDriveBackupAt)),
        h('dt', null, 'Problems'), h('dd', { class: st.lastError || st.driveError ? 'neg' : '' }, st.lastError || st.driveError || '—'),
      ),
    );
  };
  const paintSnaps = async () => {
    const snaps = await listSnapshots();
    mount(
      snapBox,
      snaps.length
        ? h(
            'div',
            null,
            snaps.map((s) =>
              h(
                'div',
                { class: 'snap-row' },
                h('div', { class: 'grow' }, h('div', { class: 'strong' }, when(s.createdAt), ' ', badge(...(REASONS[s.reason] || [s.reason, 'neutral']))), h('div', { class: 'muted small' }, `${s.counts?.invoices ?? 0} invoices · ${s.counts?.products ?? 0} products · ${s.counts?.customers ?? 0} customers · ${kb(s.bytes)}`)),
                h('div', { class: 'row gap' },
                  h('button', { class: 'btn btn-sm', onclick: () => guard(async () => { const full = await getSnapshot(s.id); const ask = await askNewPassphrase({ title: 'Save snapshot', confirmText: 'Save file' }); if (!ask) return; const text = ask.passphrase ? await serializeBackup(JSON.parse(full.json), ask.passphrase) : full.json; await downloadFile(`snapshot-${s.createdAt.slice(0, 16).replace(/[:T]/g, '-')}${ask.passphrase ? '.enc' : ''}.json`, text, 'application/json'); }) }, icon('download', 16), 'Save'),
                  h('button', { class: 'btn btn-sm', onclick: async () => { if (await confirmDialog({ title: 'Restore this snapshot?', message: `Replace ALL data on this device with the snapshot from ${when(s.createdAt)}? A safety copy of the current data is saved first, so you can undo this.`, confirmText: 'Restore', danger: true })) guard(async () => { await restoreSnapshot(s.id); toast('Restored', 'success'); setTimeout(() => location.reload(), 800); }); } }, 'Restore'),
                  h('button', { class: 'icon-btn', title: 'Delete snapshot', 'aria-label': 'Delete snapshot', onclick: () => guard(async () => { await deleteSnapshot(s.id); }) }, icon('trash', 18))),
              ),
            ),
          )
        : h('div', { class: 'muted small' }, 'No snapshots yet. The first one is taken a few seconds after the app starts (when automatic backup is on).'),
    );
  };
  const refresh = () => { paintStatus(); paintSnaps(); };
  offs.push(bus.on('backup:status', refresh));
  refresh();

  const auto = settingsForm(
    [
      { key: 'autoBackupEnabled', label: 'Back up automatically', type: 'check' },
      { key: 'autoBackupEveryHours', label: 'How often', type: 'select', options: [{ value: '6', label: 'Every 6 hours' }, { value: '12', label: 'Every 12 hours' }, { value: '24', label: 'Daily' }, { value: '48', label: 'Every 2 days' }, { value: '168', label: 'Weekly' }] },
      { key: 'autoBackupAfterSales', label: 'Also after this many new invoices (0 = off)', type: 'number' },
      { key: 'autoBackupKeep', label: 'Snapshots to keep', type: 'select', options: [{ value: '5', label: '5' }, { value: '10', label: '10' }, { value: '20', label: '20' }, { value: '30', label: '30' }] },
      { key: 'autoBackupToDrive', label: 'Also upload to Google Drive (needs Sync set up + internet)', type: 'check' },
      { key: 'autoBackupEncrypt', label: 'Encrypt the Google Drive copy (the passphrase is asked once after the app starts and is never stored)', type: 'check' },
      { key: 'autoBackupToDevice', label: 'Also save a file in the phone’s Documents folder (Android app)', type: 'check' },
    ],
    { onSaved: refresh },
  );
  const nowBtn = h('button', { class: 'btn btn-primary', type: 'button' }, icon('download', 18), 'Take a snapshot now');
  nowBtn.onclick = () => guard(async () => { await takeSnapshot('manual'); toast('Snapshot saved', 'success'); }, nowBtn);

  const exportBtn = h('button', { class: 'btn', type: 'button', 'data-action': 'export' }, icon('download', 18), 'Export database file');
  exportBtn.onclick = () => guard(async () => {
    const ask = await askNewPassphrase({ title: 'Export database file', confirmText: 'Export' });
    if (!ask) return;
    const f = await createBackupFile({ passphrase: ask.passphrase });
    await downloadFile(f.fileName, f.text, 'application/json');
    toast(f.encrypted ? 'Encrypted backup file created' : 'Backup file created (not encrypted — keep it private)', 'success');
    refresh();
  }, exportBtn);
  const importBtn = h('button', { class: 'btn', type: 'button', 'data-action': 'import' }, icon('upload', 18), 'Import database file');
  importBtn.onclick = async () => {
    const text = await pickFile('.json,application/json');
    if (!text) return;
    if (!(await confirmDialog({ title: 'Replace all data?', message: 'Importing REPLACES everything on this device (products, customers, invoices, users, settings) with the backup file. The file is checked completely first and a safety snapshot of the current data is saved; if anything is wrong, nothing is changed.', confirmText: 'Replace data', danger: true }))) return;
    await guard(async () => {
      const r = await withPassphrase((pass) => importDatabase(text, { passphrase: pass }));
      if (!r) return;
      toast(`Imported ${r.stores.invoices || 0} invoices, ${r.stores.products || 0} products${r.warnings.length ? ` (${r.warnings.length} notice${r.warnings.length === 1 ? '' : 's'})` : ''}`, 'success');
      setTimeout(() => location.reload(), 800);
    }, importBtn);
  };

  const passBtn = h('button', { class: 'btn', type: 'button', 'data-action': 'session-passphrase' }, icon('lock', 18), hasSessionBackupPassphrase() ? 'Backup passphrase set for this session' : 'Enter backup passphrase for this session');
  passBtn.onclick = async () => {
    const p = await promptDialog({ title: 'Backup passphrase', label: `Used only until the app is closed or you sign out (min ${MIN_PASSPHRASE} characters)`, type: 'password', confirmText: 'Use' });
    if (!p) return;
    if ([...p].length < MIN_PASSPHRASE) return toast(`The passphrase must be at least ${MIN_PASSPHRASE} characters.`, 'error');
    setSessionBackupPassphrase(p);
    passBtn.lastChild.textContent = 'Backup passphrase set for this session';
    toast('Automatic Drive backups will be encrypted with it this session', 'success');
  };

  const driveBtn = h('button', { class: 'btn btn-primary', type: 'button' }, icon('cloud', 18), 'Back up to Google Drive now');
  const loadDrive = async () => {
    mount(driveBox, h('div', { class: 'muted small' }, 'Loading Drive backups…'));
    try {
      const files = await listDriveBackups();
      mount(driveBox, files.length
        ? h('ul', { class: 'list' }, files.slice(0, 10).map((f) => h('li', null, h('div', { class: 'grow' }, h('div', { class: 'strong' }, f.name), h('div', { class: 'muted small' }, `${fmtDate(f.created.slice(0, 10))} · ${kb(f.size)}`)), h('button', { class: 'btn btn-sm', onclick: async () => { if (await confirmDialog({ title: 'Restore this backup?', message: `Replace ALL data on this device with ${f.name}?`, confirmText: 'Restore', danger: true })) guard(async () => { const r = await withPassphrase((pass) => restoreFromDrive(f.id, { passphrase: pass })); if (!r) return; toast('Restored', 'success'); setTimeout(() => location.reload(), 800); }); } }, 'Restore'))))
        : h('div', { class: 'muted small' }, 'No backups in Google Drive yet.'));
    } catch (e) {
      mount(driveBox, h('div', { class: 'muted small' }, e.message));
    }
  };
  driveBtn.onclick = () => guard(async () => { const ask = await askNewPassphrase({ title: 'Back up to Google Drive', confirmText: 'Back up' }); if (!ask) return; const f = await backupToDrive({ passphrase: ask.passphrase }); toast(`Saved ${f.name} to Google Drive${ask.passphrase ? ' (encrypted)' : ''}`, 'success'); loadDrive(); refresh(); }, driveBtn);
  loadDrive();

  const last = settings.get('lastBackupAt');
  return h(
    'div',
    { class: 'stack' },
    card('Automatic backup', h('p', { class: 'muted small' }, 'Snapshots are kept in a separate store on this device, so importing, restoring or clearing data never deletes them. Backup files contain password hashes — keep them private or encrypt them (the sync token is never included).'), statusBox, auto.el, h('div', { class: 'row gap', style: { flexWrap: 'wrap' } }, nowBtn, passBtn)),
    card('Saved snapshots', snapBox),
    card('Backup file', h('p', { class: 'muted small' }, `Last manual export: ${last ? when(last) : 'never'}.`), h('div', { class: 'row gap', style: { flexWrap: 'wrap' } }, exportBtn, importBtn), h('p', { class: 'muted small' }, 'Files can be encrypted with a passphrase (AES-256). The Google Sheets token is never written into a backup file.')),
    card('Google Drive', h('p', { class: 'muted small' }, 'Uses the same Google Apps Script as Sheets sync. Backups go to the “POS Backups” folder in the script owner’s Drive. Requires internet.'), driveBtn, driveBox),
  );
}

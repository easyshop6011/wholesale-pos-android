/**
 * settings-sync.js — Settings → Sync: connection form + a "sync health" panel
 * (state, counts, queue, recent runs, verify / retry / re-send catalog).
 */
import { h, mount, icon } from '../dom.js';
import { toast, guard, badge, confirmDialog } from '../components.js';
import { getSyncStatus, syncNow, testConnection, retryFailed, refreshStatus, getQueue, getSyncLog, verifyUploaded, resetCatalogSync, clearSyncLog } from '../../services/sync.js';
import { bus } from '../../core/bus.js';
import { fmtDate, fmtDateTime } from '../../core/format.js';
import { settingsForm, card } from '../settings-form.js';

const stamp = (iso) => (iso ? fmtDateTime(iso, { seconds: true }) : 'Never');

/** Overall health: [css tone, headline]. */
function health(st) {
  if (!st.configured) return ['', 'Not set up', 'Enter the Web App URL and token below to start uploading to Google Sheets.'];
  if (st.running) return ['info', 'Syncing…', 'Uploading now.'];
  if (st.failed) return ['danger', `${st.failed} record(s) need attention`, 'The server rejected them. Fix the cause and press “Retry failed”.'];
  if (!navigator.onLine) return ['warn', 'Offline', st.pending ? `${st.pending} record(s) will upload when the internet returns.` : 'Everything so far is uploaded.'];
  if (st.lastError) return ['danger', 'Last sync failed', st.lastError];
  if (st.pending) return ['warn', `${st.pending} waiting to upload`, st.nextRetryAt ? `Next automatic retry ${stamp(st.nextRetryAt)}.` : 'Will upload shortly.'];
  return ['ok', 'All synced', `Last sync ${stamp(st.lastSyncAt)}.`];
}

export function syncTab(offs) {
  const hero = h('div');
  const queueBox = h('div');
  const logBox = h('div');

  const paintStatus = () => {
    const st = getSyncStatus();
    const [tone, title, sub] = health(st);
    mount(
      hero,
      h('div', { class: 'sync-hero' }, h('span', { class: `sync-dot ${tone}` }), h('div', { class: 'grow' }, h('div', { class: 'strong big' }, title), h('div', { class: 'muted small' }, sub))),
      h('div', { class: 'sync-counts' },
        h('div', null, h('b', null, String(st.pendingInvoices)), 'invoices waiting'),
        h('div', null, h('b', null, String(st.pendingPayments)), 'payments waiting'),
        h('div', null, h('b', null, String(st.pendingReturns ?? 0)), 'returns waiting'),
        h('div', null, h('b', { class: st.failed ? 'neg' : '' }, String(st.failed)), 'need attention'),
        h('div', null, h('b', null, String(st.catalogPending ?? 0)), 'products/customers changed')),
      st.notice ? h('div', { class: 'warn-box', 'data-box': 'sync-notice' }, st.notice) : null,
      st.lastSyncAt ? h('div', { class: 'muted small', 'data-field': 'last-sync' }, `Last successful sync: ${stamp(st.lastSyncAt)} (Asia/Dhaka)`) : h('div', { class: 'muted small', 'data-field': 'last-sync' }, 'Never synced yet.'),
      st.consecutiveFailures ? h('div', { class: 'muted small' }, `${st.consecutiveFailures} failed attempt(s) in a row — retries slow down automatically (batch size ${st.batchSize}).`) : null,
    );
  };
  const paintQueue = async () => {
    const q = await getQueue(30);
    mount(queueBox, q.length ? q.map((r) => h('div', { class: 'queue-row' }, h('div', { class: 'grow' }, h('div', null, r.label), r.error ? h('div', { class: 'err-text' }, r.error) : null), h('div', { class: 'right' }, badge(r.status === 'failed' ? 'Failed' : 'Waiting', r.status === 'failed' ? 'danger' : 'warn'), r.attempts ? h('div', { class: 'muted small' }, `${r.attempts} attempt(s)`) : null))) : h('div', { class: 'muted small' }, 'Nothing is waiting. 🎉'));
  };
  const paintLog = async () => {
    const rows = await getSyncLog(15);
    mount(logBox, rows.length ? rows.map((r) => h('div', { class: 'queue-row' }, h('div', { class: 'grow' }, h('div', null, r.kind === 'verify' ? `Checked ${r.checked} uploaded invoices, ${r.missing} missing` : `Sent ${r.sent}, already there ${r.duplicates}${r.catalog ? `, catalog ${r.catalog}` : ''}${r.rejected ? `, rejected ${r.rejected}` : ''}`), r.error ? h('div', { class: 'err-text' }, r.error) : null), h('div', { class: 'right muted small' }, badge(r.ok ? 'OK' : 'Failed', r.ok ? 'ok' : 'danger'), h('div', null, stamp(r.createdAt), r.ms ? ` · ${(r.ms / 1000).toFixed(1)}s` : '')))) : h('div', { class: 'muted small' }, 'No sync runs yet.'));
  };
  const refresh = () => { paintStatus(); paintQueue(); paintLog(); };
  offs.push(bus.on('sync:status', refresh));
  refreshStatus();
  refresh();

  const testBtn = h('button', { class: 'btn', type: 'button' }, 'Test connection');
  const nowBtn = h('button', { class: 'btn btn-primary', type: 'button' }, icon('refresh', 18), 'Sync now');
  const retryBtn = h('button', { class: 'btn', type: 'button' }, 'Retry failed');
  const verifyBtn = h('button', { class: 'btn', type: 'button', title: 'Asks Google Sheets which uploaded invoices it really has; re-uploads any that were deleted from the sheet.' }, 'Verify uploads');
  const resendBtn = h('button', { class: 'btn', type: 'button', title: 'Re-send every product and customer on the next sync.' }, 'Re-send catalog');
  const clearBtn = h('button', { class: 'btn btn-sm', type: 'button' }, 'Clear log');
  const f = settingsForm(
    [
      { key: 'syncEnabled', label: 'Sync automatically when internet is available', type: 'check' },
      { key: 'syncCatalog', label: 'Also send products and customers (stock and dues) to the sheet', type: 'check' },
      { key: 'syncUrl', label: 'Google Apps Script Web App URL', placeholder: 'https://script.google.com/macros/s/…/exec' },
      { key: 'syncToken', label: 'Secret token', type: 'password', hint: 'Must equal the POS_TOKEN script property' },
    ],
    { onSaved: () => refreshStatus() },
  );
  testBtn.onclick = () => guard(async () => { await testConnection({ url: f.inputs.syncUrl.value.trim(), token: f.inputs.syncToken.value.trim() }); toast('Connection OK ✔', 'success'); refresh(); }, testBtn);
  nowBtn.onclick = () => guard(async () => {
    const r = await syncNow();
    if (r.failed) throw new Error(getSyncStatus().lastError || 'Sync failed');
    toast(r.sent || r.duplicates ? `Synced ${r.sent} new, ${r.duplicates} already uploaded` : 'Everything is up to date', 'success');
  }, nowBtn);
  retryBtn.onclick = () => guard(async () => { await retryFailed(); toast('Retrying…', 'success'); }, retryBtn);
  verifyBtn.onclick = () => guard(async () => {
    const r = await verifyUploaded();
    toast(r.unsupported ? 'Update the Apps Script to the latest Code.gs to use this check.' : r.missing ? `${r.missing} invoice(s) were missing from the sheet and are being re-uploaded.` : `All ${r.checked} uploaded invoices are in the sheet ✔`, r.missing || r.unsupported ? 'info' : 'success', 5000);
  }, verifyBtn);
  resendBtn.onclick = async () => { if (await confirmDialog({ title: 'Re-send catalog?', message: 'Every product and customer will be sent again on the next sync (existing rows are updated, not duplicated).', confirmText: 'Re-send' })) guard(async () => { await resetCatalogSync(); await syncNow(); toast('Catalog queued', 'success'); }); };
  clearBtn.onclick = () => guard(async () => { await clearSyncLog(); paintLog(); });

  return h(
    'div',
    { class: 'stack' },
    card('Sync health', hero, h('div', { class: 'row gap', style: { flexWrap: 'wrap' } }, nowBtn, retryBtn, verifyBtn, resendBtn)),
    card('Google Sheets connection', h('p', { class: 'muted small' }, 'Every invoice is stored on this device first. When internet is available it is uploaded to your Google Sheet exactly once (each invoice has a unique ID). Setup guide: docs/SYNC.md.'), f.el, h('div', null, testBtn)),
    card('Waiting to upload', queueBox),
    card('Recent sync runs', logBox, h('div', null, clearBtn)),
  );
}

/**
 * settings-users.js — Settings → Users (roles + per-user permissions) and
 * Settings → Activity (who did what).
 */
import { h, mount, icon } from '../dom.js';
import { openModal, toast, guard, field, select, badge, filterBar, promptDialog } from '../components.js';
import { auth, ROLES, PERMISSION_LIST, effectivePermissions } from '../../services/auth.js';
import { listAudit } from '../../services/audit.js';
import { card } from '../settings-form.js';
import { fmtDate, fmtDateTime } from '../../core/format.js';

const ROLE_OPTIONS = Object.entries(ROLES).map(([value, r]) => ({ value, label: r.label }));
const roleBadge = (u) => badge(ROLES[u.role]?.label || u.role, u.role === 'admin' ? 'info' : u.role === 'manager' ? 'ok' : 'neutral');

/** Add / edit a user, including a custom permission list. */
function userDialog(existing, done) {
  const f = {
    username: h('input', { class: 'input', value: existing?.username || '', disabled: !!existing, autocapitalize: 'none' }),
    displayName: h('input', { class: 'input', value: existing?.displayName || '' }),
    role: select(ROLE_OPTIONS, existing?.role || 'employee'),
    password: h('input', { class: 'input', type: 'password', autocomplete: 'new-password', placeholder: existing ? 'Leave blank to keep' : 'Min 6 characters' }),
    pin: h('input', { class: 'input', type: 'password', inputmode: 'numeric', maxlength: 6, placeholder: existing ? 'Leave blank to keep' : '4–6 digits' }),
  };
  const custom = h('input', { type: 'checkbox', checked: Array.isArray(existing?.permissions) });
  const checks = new Map();
  const permBox = h('div');
  const customRow = h('label', { class: 'check' }, custom, h('span', null, 'Customise what this user can do'));

  const roleDefaults = () => ROLES[f.role.value]?.permissions || [];
  const paintPerms = () => {
    const isAdmin = f.role.value === 'admin';
    customRow.classList.toggle('hidden', isAdmin);
    if (isAdmin) return mount(permBox, h('p', { class: 'muted small' }, 'Administrators can do everything.'));
    if (!custom.checked) return mount(permBox, h('p', { class: 'muted small' }, `Uses the ${ROLES[f.role.value].label} defaults: ${roleDefaults().length} permissions.`));
    const base = Array.isArray(existing?.permissions) && existing.role === f.role.value ? existing.permissions : roleDefaults();
    checks.clear();
    const groups = [...new Set(PERMISSION_LIST.map((p) => p.group))];
    mount(permBox, groups.map((g) => h('div', null, h('div', { class: 'perm-group' }, g), h('div', { class: 'perm-grid' }, PERMISSION_LIST.filter((p) => p.group === g).map((p) => {
      const cb = h('input', { type: 'checkbox', checked: base.includes(p.key) });
      checks.set(p.key, cb);
      return h('label', { class: 'check' }, cb, h('span', null, p.label));
    })))));
  };
  f.role.addEventListener('change', () => { custom.checked = false; paintPerms(); });
  custom.addEventListener('change', paintPerms);
  paintPerms();

  const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Save');
  const m = openModal({
    title: existing ? `Edit ${existing.username}` : 'Add user',
    size: 'md',
    content: h(
      'form',
      {
        class: 'stack',
        onsubmit: (e) => {
          e.preventDefault();
          guard(async () => {
            const permissions = f.role.value !== 'admin' && custom.checked ? [...checks].filter(([, cb]) => cb.checked).map(([k]) => k) : null;
            if (existing) {
              // Changing a password / PIN asks for YOUR password first (the service requires it as well).
              let confirmation = '';
              if (f.password.value || f.pin.value) {
                confirmation = await promptDialog({ title: 'Confirm it is you', label: 'Your own password', type: 'password', confirmText: 'Confirm' });
                if (confirmation === null) return;
              }
              await auth.updateUser(existing.id, { displayName: f.displayName.value, role: f.role.value, permissions });
              if (confirmation) await auth.setCredentials(existing.id, { password: f.password.value, pin: f.pin.value, currentPassword: confirmation });
            } else {
              await auth.createUser({ username: f.username.value.trim(), displayName: f.displayName.value, role: f.role.value, password: f.password.value, pin: f.pin.value, permissions });
            }
            m.close();
            toast('User saved', 'success');
            done();
          }, save);
        },
      },
      field('Username', f.username),
      field('Display name', f.displayName),
      field('Role', f.role, 'Cashier: sell and manage customers. Manager: also void invoices, edit products, adjust stock, see reports. Administrator: everything.'),
      customRow,
      permBox,
      field('Password', f.password),
      field('PIN', f.pin),
      h('div', { class: 'modal-actions inline' }, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), save),
    ),
  });
}

export function usersTab() {
  const box = h('div');
  const paint = async () => {
    const users = await auth.listUsers();
    mount(
      box,
      users.map((u) =>
        h(
          'div',
          { class: `user-card ${u.active ? '' : 'void'}` },
          h('div', { class: 'avatar' }, (u.displayName || '?').slice(0, 1).toUpperCase()),
          h('div', { class: 'grow' }, h('div', { class: 'strong' }, u.displayName, ' ', roleBadge(u), Array.isArray(u.permissions) && u.role !== 'admin' ? [' ', badge('Custom', 'warn')] : null, u.active ? null : [' ', badge('Disabled', 'danger')]), h('div', { class: 'muted small' }, `@${u.username} · ${u.role === 'admin' ? 'all permissions' : `${effectivePermissions(u).length} permissions`}${u.lastLoginAt ? ` · last sign-in ${fmtDate(u.lastLoginAt.slice(0, 10))}` : ''}`)),
          h('button', { class: 'btn btn-sm', onclick: () => userDialog(u, paint) }, 'Edit'),
          u.id !== auth.user().id ? h('button', { class: 'btn btn-sm', onclick: () => guard(async () => { await auth.updateUser(u.id, { active: !u.active }); paint(); }) }, u.active ? 'Disable' : 'Enable') : null,
        ),
      ),
    );
  };
  paint();
  return card('Users', h('p', { class: 'muted small' }, 'Several people can share one device: each signs in with their own password, and the lock screen lets anyone switch user with their PIN. Every sale records who made it.'), box, h('div', null, h('button', { class: 'btn btn-primary', onclick: () => userDialog(null, paint) }, icon('plus', 18), 'Add user')));
}

const ACTION_OPTIONS = [['', 'All activity'], ['auth', 'Sign-ins'], ['invoice', 'Invoices'], ['stock', 'Stock'], ['product', 'Products'], ['customer', 'Customers'], ['payment', 'Payments'], ['user', 'Users'], ['settings', 'Settings'], ['backup', 'Backup'], ['security', 'Denied attempts']].map(([value, label]) => ({ value, label }));

export function activityTab(offs) {
  const list = h('div');
  const meta = h('div', { class: 'result-meta' });
  const wrap = h('div', { class: 'stack' });
  const init = async () => {
    const users = await auth.listUserNames();
    const fb = filterBar(
      [
        { key: 'search', type: 'search', placeholder: 'Search activity…' },
        { key: 'action', type: 'select', label: 'Type', options: ACTION_OPTIONS },
        { key: 'userId', type: 'select', label: 'User', options: [{ value: '', label: 'Everyone' }, ...users.map((u) => ({ value: u.id, label: u.displayName }))] },
        { key: 'from', type: 'date', label: 'From', more: true },
        { key: 'to', type: 'date', label: 'To', more: true },
      ],
      {},
      () => paint(),
    );
    const paint = async () => {
      const v = fb.values;
      const rows = await listAudit({ search: v.search, action: v.action, userId: v.userId, from: v.from || undefined, to: v.to || undefined, limit: 200 });
      mount(meta, h('span', null, `${rows.length}${rows.length === 200 ? '+' : ''} entries`));
      mount(list, rows.length ? rows.map((r) => h('div', { class: 'log-row' }, h('div', { class: 'muted small nowrap' }, fmtDateTime(r.createdAt, { seconds: true })), h('div', null, h('span', { class: 'strong' }, r.userName || 'System'), ' ', badge(r.action, 'neutral'), r.target ? ` ${r.target}` : '', r.detail ? h('div', { class: 'muted small' }, r.detail) : null))) : h('div', { class: 'muted small pad' }, 'No activity matches these filters.'));
    };
    mount(wrap, fb.el, meta, list);
    await paint();
    offs.push(...[]);
  };
  init();
  return card('Activity log', h('p', { class: 'muted small' }, 'Sign-ins, voided invoices, stock changes and user changes. The newest 5,000 entries are kept.'), wrap);
}


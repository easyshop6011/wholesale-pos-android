/**
 * settings.js — all configuration screens.
 *
 *   Printer      (everyone)  connect printer, paper size, test print
 *   My account   (everyone)  change own password / PIN
 *   Business     (admin)     name, logo, address, phone, footer, currency
 *   Invoices     (admin)     numbering, stock rules, auto-lock
 *   Sync         (admin)     Google Sheets URL + token, status, retry
 *   Backup       (admin)     export / import / Google Drive
 *   Users        (admin)     employees and admins
 *
 * Tabs the current user may not open are not shown (see auth.can('settings')).
 */
import { h, mount, icon } from '../dom.js';
import { openModal, toast, guard, field, select, segmented, badge, pageHeader } from '../components.js';
import { settings } from '../../services/settings.js';
import { auth } from '../../services/auth.js';
import { TRANSPORTS, currentTransport, connectPrinter, printTest, sampleInvoice } from '../../printing/printer.js';
import { ValidationError } from '../../core/utils.js';
import { previewInvoice } from '../print-ui.js';
import { settingsForm, card } from '../settings-form.js';
import { backupTab } from './settings-backup.js';
import { usersTab, activityTab } from './settings-users.js';
import { syncTab } from './settings-sync.js';

// ---------------------------------------------------------------------------
// Business
// ---------------------------------------------------------------------------

/** Downscale a chosen logo to ≤384×160 px on a white background (PNG data URL). */
async function processLogo(file) {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, 384 / bmp.width, 160 / bmp.height);
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(bmp.width * scale));
  c.height = Math.max(1, Math.round(bmp.height * scale));
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL('image/png');
}

function businessTab() {
  const logoBox = h('div', { class: 'stack' });
  const paintLogo = () => {
    const logo = settings.get('logo');
    mount(
      logoBox,
      logo ? h('img', { class: 'logo-preview', src: logo, alt: 'Company logo' }) : h('div', { class: 'muted small' }, 'No logo yet. A simple black-and-white logo prints best.'),
      h(
        'div',
        { class: 'row gap' },
        h('button', { class: 'btn btn-sm', type: 'button', onclick: chooseLogo }, icon('upload', 16), logo ? 'Change logo' : 'Upload logo'),
        logo ? h('button', { class: 'btn btn-sm', type: 'button', onclick: () => guard(async () => { await settings.update({ logo: '' }); paintLogo(); }) }, 'Remove') : null,
      ),
    );
  };
  const chooseLogo = () => {
    const input = h('input', { type: 'file', accept: 'image/*', style: { display: 'none' } });
    input.addEventListener('change', () => input.files[0] && guard(async () => { await settings.update({ logo: await processLogo(input.files[0]) }); paintLogo(); toast('Logo saved', 'success'); }));
    document.body.append(input);
    input.click();
    setTimeout(() => input.remove(), 60000);
  };
  paintLogo();
  const f = settingsForm([
    { key: 'businessName', label: 'Business name' },
    { key: 'address', label: 'Address', type: 'textarea' },
    { key: 'phone', label: 'Phone number' },
    { key: 'email', label: 'Email (optional)' },
    { key: 'taxId', label: 'Tax / BIN number (optional)' },
    { key: 'footer', label: 'Receipt footer message', type: 'textarea' },
    { key: 'currency', label: 'Currency symbol', hint: 'e.g. ৳  $  Rs' },
  ]);
  return h('div', { class: 'stack' }, card('Company logo', logoBox), card('Company information', f.el));
}

// ---------------------------------------------------------------------------
// Invoicing & security preferences
// ---------------------------------------------------------------------------

function generalTab() {
  const f = settingsForm([
    { key: 'invoicePrefix', label: 'Invoice number prefix', hint: 'Numbers look like INV-261027-0001' },
    { key: 'deviceCode', label: 'Device code', hint: 'Use a different letter on every device (A, B…) so invoice numbers never clash' },
    { key: 'lowStockDefault', label: 'Default low-stock level', type: 'number' },
    { key: 'allowNegativeStock', label: 'Allow selling more than the stock on hand', type: 'check' },
    { key: 'showPreviousDue', label: 'Show the customer’s previous due on receipts', type: 'check' },
    { key: 'autoLockMinutes', label: 'Auto-lock after (minutes idle, 0 = never)', type: 'number' },
  ]);
  return card('Invoices & security', f.el);
}

// ---------------------------------------------------------------------------
// Printer
// ---------------------------------------------------------------------------

/** Modal that lists paired Bluetooth / USB printers (Android app transport). */
async function chooseNativePrinter(t, onDone) {
  const list = h('div', { class: 'pick-list' }, h('div', { class: 'pad muted' }, 'Looking for printers…'));
  const m = openModal({ title: 'Choose printer', size: 'sm', content: h('div', { class: 'stack' }, h('div', { class: 'hint-box' }, 'Bluetooth printers must be paired first in Android Settings → Bluetooth. USB printers: connect with an OTG cable.'), list), actions: [h('button', { class: 'btn', onclick: () => m.close() }, 'Close')] });
  try {
    const devs = await t.listDevices();
    mount(
      list,
      devs.length
        ? devs.map((d) =>
            h('button', { class: 'pick-row', type: 'button', onclick: () => { t.select(d); localStorage.setItem('pos:transportChosen', '1'); m.close(); toast(`Printer set to ${d.name}`, 'success'); onDone(); } }, h('div', null, h('div', { class: 'strong' }, d.name), h('div', { class: 'muted small mono' }, d.address)), badge(d.type === 'usb' ? 'USB' : 'Bluetooth', 'info')),
          )
        : h('div', { class: 'pad muted' }, 'No paired Bluetooth or USB printers found.'),
    );
  } catch (e) {
    mount(list, h('div', { class: 'pad neg' }, e.message || String(e)));
  }
}

function printerTab() {
  const status = h('div', { class: 'muted small' });
  const paintStatus = () => {
    const t = currentTransport();
    mount(status, t.supported() ? `Current printer: ${t.name() || 'not chosen yet'}` : '⚠ This printer type is not available on this device/browser.');
  };
  const transportSel = select(
    TRANSPORTS.filter((t) => t.supported() || t.id === settings.get('printTransport')).map((t) => ({ value: t.id, label: t.label + (t.supported() ? '' : ' (unavailable)') })),
    settings.get('printTransport'),
    {
      onchange: () => {
        try { localStorage.setItem('pos:transportChosen', '1'); } catch { /* ignore */ }
        guard(async () => { await settings.update({ printTransport: transportSel.value }); paintStatus(); });
      },
    },
  );
  const connectBtn = h('button', { class: 'btn', type: 'button' }, icon('printer', 18), 'Choose / pair printer');
  connectBtn.onclick = async () => {
    const t = currentTransport();
    if (t.id === 'native') return chooseNativePrinter(t, paintStatus);
    if (t.id === 'browser') return toast('The system print dialog needs no pairing.');
    await guard(async () => {
      const name = await connectPrinter();
      toast(`Connected: ${name || 'printer'}`, 'success');
      paintStatus();
    }, connectBtn);
  };
  const testBtn = h('button', { class: 'btn btn-primary', type: 'button' }, 'Print test receipt');
  testBtn.onclick = () => guard(async () => { await printTest(); toast('Test receipt sent', 'success'); }, testBtn).catch?.(() => {});
  const previewBtn = h('button', { class: 'btn', type: 'button', onclick: () => { const s = sampleInvoice(); previewInvoice({ ...s.invoice, items: s.items }); } }, icon('eye', 18), 'Preview receipt');
  paintStatus();

  const f = settingsForm(
    [
      { key: 'printMode', label: 'Print mode', type: 'select', options: [{ value: 'raster', label: 'Graphic — logo + any language (Bengali etc.)' }, { value: 'text', label: 'Text — fastest, English only, no logo' }] },
      { key: 'paperWidthDots', label: 'Paper width', type: 'select', options: [{ value: '576', label: '80 mm (576 dots)' }, { value: '512', label: '80 mm — narrow models (512 dots)' }, { value: '384', label: '58 mm (384 dots)' }] },
      { key: 'textColumns', label: 'Text-mode columns', type: 'select', options: [{ value: '48', label: '48 (80 mm, font A)' }, { value: '42', label: '42' }, { value: '32', label: '32 (58 mm)' }] },
      { key: 'printDensity', label: 'Print darkness (graphic mode, 100–220)', type: 'number', hint: 'Raise if the print looks faint' },
      { key: 'copies', label: 'Copies', type: 'number' },
      { key: 'feedLines', label: 'Blank lines before cutting', type: 'number' },
      { key: 'autoPrint', label: 'Print automatically after saving an invoice', type: 'check' },
      { key: 'cutPaper', label: 'Cut paper after printing', type: 'check' },
      { key: 'openDrawer', label: 'Open cash drawer after printing', type: 'check' },
      { key: 'bleChunkSize', label: 'Bluetooth chunk size (bytes)', type: 'number', hint: 'Lower (e.g. 20–60) if a BLE printer prints garbage' },
      { key: 'bleDelayMs', label: 'Bluetooth delay between chunks (ms)', type: 'number' },
    ],
    {},
  );
  // numeric selects must be stored as numbers — settingsForm handles that via the existing value's type.
  return h('div', { class: 'stack' }, card('Printer connection', field('Printer type', transportSel), status, h('div', { class: 'row gap', style: { flexWrap: 'wrap' } }, connectBtn, testBtn, previewBtn), h('div', { class: 'hint-box' }, 'Android app: pick “Bluetooth / USB — Android app” for direct printing. Chrome: Bluetooth (BLE) / USB. Any device: “System print dialog”. See docs/PRINTING.md.')), card('Receipt options', f.el));
}

// ---------------------------------------------------------------------------
// My account
// ---------------------------------------------------------------------------

function accountTab() {
  const me = auth.user();
  const cur = h('input', { class: 'input', type: 'password', autocomplete: 'current-password' });
  const pw = h('input', { class: 'input', type: 'password', autocomplete: 'new-password', placeholder: 'New password (blank = keep)' });
  const pin = h('input', { class: 'input', type: 'password', inputmode: 'numeric', maxlength: 6, placeholder: 'New PIN (blank = keep)' });
  const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Update');
  return card(
    `My account — ${me.displayName}`,
    h(
      'form',
      {
        class: 'stack',
        onsubmit: (e) => {
          e.preventDefault();
          guard(async () => {
            if (!(await auth.verifyPassword(cur.value))) throw new ValidationError('Current password is incorrect.');
            if (!pw.value && !pin.value) throw new ValidationError('Enter a new password or PIN.');
            await auth.setCredentials(me.id, { password: pw.value, pin: pin.value, currentPassword: cur.value });
            cur.value = pw.value = pin.value = '';
            toast('Credentials updated', 'success');
          }, save);
        },
      },
      field('Current password', cur),
      field('New password', pw),
      field('New PIN', pin),
      h('div', { class: 'row gap' }, save, h('button', { class: 'btn', type: 'button', onclick: () => auth.lock() }, icon('lock', 18), 'Lock now')),
    ),
  );
}

// ---------------------------------------------------------------------------

/** Theme and density — applied instantly and remembered on this device. */
function appearanceTab() {
  const pick = (key, options) => {
    const box = h('div', { class: 'theme-pick' });
    const paint = () => mount(box, options.map((o) => h('button', { type: 'button', class: `theme-card ${settings.get(key) === o.value ? 'active' : ''}`, onclick: async () => { await settings.update({ [key]: o.value }); paint(); } }, o.label)));
    paint();
    return box;
  };
  const group = (label, control, hint) => h('div', { class: 'field', role: 'group', 'aria-label': label }, h('span', { class: 'field-label' }, label), control, hint ? h('span', { class: 'field-hint' }, hint) : null);
  return card(
    'Appearance',
    group('Theme', pick('theme', [{ value: 'auto', label: '🌓 Match device' }, { value: 'light', label: '☀️ Light' }, { value: 'dark', label: '🌙 Dark' }])),
    group('Density', pick('density', [{ value: 'comfortable', label: 'Comfortable' }, { value: 'compact', label: 'Compact' }]), 'Compact fits more rows on screen — handy on small phones and busy lists.'),
  );
}

export default async function render(root, ctx) {
  const admin = auth.can('settings');
  const offs = [];
  const tabs = [
    ...(admin ? [{ value: 'business', label: 'Business' }] : []),
    { value: 'printer', label: 'Printer' },
    ...(admin ? [{ value: 'general', label: 'Invoices' }, { value: 'sync', label: 'Sync' }, { value: 'backup', label: 'Backup' }, { value: 'users', label: 'Users' }] : []),
    ...(auth.can('audit') ? [{ value: 'activity', label: 'Activity' }] : []),
    { value: 'appearance', label: 'Appearance' },
    { value: 'account', label: 'My account' },
  ];
  let tab = ctx.params[0] && tabs.some((t) => t.value === ctx.params[0]) ? ctx.params[0] : tabs[0].value;
  const body = h('div');
  const paint = () => {
    offs.splice(0).forEach((o) => o());
    const map = { business: businessTab, printer: printerTab, general: generalTab, sync: () => syncTab(offs), backup: () => backupTab(offs), users: usersTab, activity: () => activityTab(offs), appearance: appearanceTab, account: accountTab };
    mount(body, map[tab]());
  };
  mount(root, pageHeader('Settings'), h('div', { class: 'tabs' }, segmented(tabs, tab, (v) => { tab = v; paint(); })), body);
  paint();
  return () => offs.forEach((o) => o());
}

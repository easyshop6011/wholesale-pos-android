/**
 * stock-history.js — EVERY stock change of EVERY product, newest first:
 * new product, opening stock, deliveries, sales, voids, returns, corrections, damage.
 * Filter by date, product, kind of change and user; export CSV; print.
 * Route: #/stock-history   (also reached from a product: #/stock-history?product=<id>)
 */
import { h, mount, icon } from '../dom.js';
import { toast, guard, badge, pageHeader, filterBar, pager, downloadCSV, debounce } from '../components.js';
import { queryMovements, verifyStockLedger, movementsToCSV } from '../../services/inventory.js';
import { listProducts } from '../../services/catalog.js';
import { auth } from '../../services/auth.js';
import { qty, fmtDate } from '../../core/format.js';
import { dateParts, addDays } from '../../core/utils.js';
import { bus } from '../../core/bus.js';
import { movementTable, movementSheet, TYPE_OPTIONS } from '../stock-ui.js';
import { printSheet } from '../report-print.js';

export default async function render(root, ctx = {}) {
  const PAGE = 100;
  let offset = 0;
  const canCost = auth.can('reports.profit');
  const [products, users] = await Promise.all([listProducts({ includeInactive: true }), auth.listUserNames()]);
  const today = dateParts().date;
  const fb = filterBar(
    [
      { key: 'search', type: 'search', placeholder: 'Search product, reason, reference, user…' },
      { key: 'from', type: 'date', label: 'From' },
      { key: 'to', type: 'date', label: 'To' },
      { key: 'productId', type: 'select', label: 'Product', options: [{ value: '', label: 'All products' }, ...products.map((p) => ({ value: p.id, label: p.active ? p.name : `${p.name} (archived)` }))] },
      { key: 'type', type: 'select', label: 'Change', options: TYPE_OPTIONS },
      { key: 'userId', type: 'select', label: 'User', more: true, options: [{ value: '', label: 'All users' }, ...users.map((u) => ({ value: u.id, label: u.displayName }))] },
    ],
    { productId: ctx.query?.product || '', search: ctx.query?.q || '' },
    () => { offset = 0; paint(); },
  );
  const quick = (label, from, to) => h('button', { class: 'btn btn-sm', type: 'button', onclick: () => { fb.set('from', from, true); fb.set('to', to); } }, label);
  const meta = h('div', { class: 'result-meta' });
  const body = h('section', { class: 'card' });
  const banner = h('div');
  let current = { rows: [], total: 0 };

  const exportAll = async () => (await queryMovements({ ...filters(), limit: 100000, offset: 0 })).rows;
  const filters = () => {
    const v = fb.values;
    return { from: v.from || undefined, to: v.to || undefined, productId: v.productId || undefined, type: v.type, userId: v.userId, search: v.search };
  };

  mount(
    root,
    pageHeader(
      'Stock History',
      h('button', { class: 'btn', 'data-action': 'csv', onclick: () => guard(async () => downloadCSV(`stock-history-${today}.csv`, movementsToCSV(await exportAll(), { cost: canCost }))) }, icon('download', 18), 'Export CSV'),
      h('button', { class: 'btn', 'data-action': 'print', onclick: () => guard(async () => { const f = filters(); printSheet(movementSheet(await exportAll(), { cost: canCost, meta: [['Period', f.from || f.to ? `${f.from || 'start'} to ${f.to || 'today'}` : 'All time'], ['Product', f.productId ? products.find((p) => p.id === f.productId)?.name || '' : 'All'], ['Change', f.type || 'All'], ['Records', String(current.total)]] })); }) }, icon('printer', 18), 'Print'),
    ),
    banner,
    fb.el,
    h('div', { class: 'row gap quick-row' }, quick('Today', today, today), quick('Last 7 days', addDays(today, -6), today), quick('Last 30 days', addDays(today, -29), today), quick('All time', '', '')),
    meta,
    body,
  );

  let seq = 0;
  async function paint() {
    const my = ++seq;
    const r = await queryMovements({ ...filters(), limit: PAGE, offset });
    if (my !== seq) return;
    current = r;
    mount(meta, h('span', null, `${r.total} record${r.total === 1 ? '' : 's'}`), r.total ? h('span', { class: 'muted' }, `In ${qty(r.unitsIn)} · Out ${qty(r.unitsOut)}`) : null);
    mount(body, movementTable(r.rows, { cost: canCost, empty: fb.values.search || fb.values.from || fb.values.to || fb.values.productId || fb.values.type || fb.values.userId ? 'No stock changes match these filters.' : 'No stock changes recorded yet. Adding a product, receiving stock, selling, voiding or returning creates history automatically.' }), pager({ total: r.total, offset, limit: PAGE, onPage: (o) => { offset = o; paint(); window.scrollTo(0, 0); } }));
  }

  /** Honest statement about how complete the history is. */
  async function paintBanner() {
    const v = await verifyStockLedger();
    mount(
      banner,
      v.problems.length
        ? h('div', { class: 'warn-box', 'data-warning': 'ledger', style: { marginBottom: '12px' } }, `⚠ The recorded history of ${v.problems.length} product(s) does not add up to the stock on hand (${v.problems.slice(0, 3).map((p) => p.name).join(', ')}${v.problems.length > 3 ? '…' : ''}). Open the product to see details.`)
        : v.untracked.length
          ? h('div', { class: 'hint-box', 'data-notice': 'untracked', style: { marginBottom: '12px' } }, `${v.untracked.length} product(s) already held stock before stock history was introduced (${v.untracked.slice(0, 3).map((p) => `${p.name}: ${qty(p.untracked)}`).join(', ')}${v.untracked.length > 3 ? '…' : ''}). That earlier stock is not invented — history starts from the first recorded change.`)
          : null,
    );
  }

  await Promise.all([paint(), paintBanner()]);
  return bus.on('data:changed', debounce(() => { paint(); paintBanner(); }, 300));
}

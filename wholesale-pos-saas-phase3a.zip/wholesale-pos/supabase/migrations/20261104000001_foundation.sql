-- =====================================================================================
-- Wholesale POS Cloud — migration 0001: foundation
--   extensions, the private schema, secure-by-default privileges, shared helper functions.
--
-- IMPORTANT: this file has been statically checked (tools/check-sql.mjs) but NOT executed
-- by its author (no PostgreSQL was available). Run `supabase db reset` on a throw-away
-- project first — see docs/CLOUD-SETUP.md.
-- =====================================================================================

create extension if not exists pgcrypto with schema extensions;

-- `private` holds internal functions. It is NOT exposed through the API (api.schemas in
-- supabase/config.toml lists only `public`), and API roles get no access to it.
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

-- Secure by default: tables / sequences created later in `public` are NOT opened to the API roles
-- automatically. Every grant is written out explicitly in migration 0004.
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;
alter default privileges in schema public revoke execute on functions from anon, authenticated;

-- ---- generic trigger functions ---------------------------------------------------------

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end
$$;

-- Used on append-only tables: not even the service role can edit or delete a row.
create or replace function public.prevent_mutation()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  raise exception 'table % is append-only: % is not allowed', tg_table_name, tg_op
    using errcode = '42501';
end
$$;

-- Business time is Asia/Dhaka. The client sends one instant (occurred_at); the calendar
-- day / clock time / month are DERIVED here so they can never disagree with it.
create or replace function public.derive_dhaka_dtm()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  v timestamp;
begin
  v := new.occurred_at at time zone 'Asia/Dhaka';
  new.biz_date := v::date;
  new.biz_time := v::time;
  new.biz_month := to_char(v, 'YYYY-MM');
  return new;
end
$$;

create or replace function public.derive_dhaka_date()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.biz_date := (new.occurred_at at time zone 'Asia/Dhaka')::date;
  return new;
end
$$;

-- ---- Bangladeshi mobile numbers ---------------------------------------------------------
-- "+880 1712-345678", "০১৭১২৩৪৫৬৭৮", "8801712345678" -> "01712345678"
create or replace function public.normalize_phone(p text)
returns text
language sql
immutable
set search_path = ''
as $$
  select case
    when s.d ~ '^8801[0-9]{9}$' then substr(s.d, 3)
    else s.d
  end
  from (
    select regexp_replace(translate(coalesce(p, ''), '০১২৩৪৫৬৭৮৯', '0123456789'), '[^0-9]', '', 'g') as d
  ) s
$$;

-- ---- permission catalogue (MUST match js/services/permissions.js — a unit test checks it) --

create or replace function public.all_permission_keys()
returns text[]
language sql
immutable
set search_path = ''
as $$
  select array[
    'dashboard', 'pos', 'invoices', 'invoices.void', 'invoices.return',
    'customers', 'customers.delete', 'products.view', 'products.edit',
    'inventory.view', 'inventory.adjust', 'reports', 'reports.profit',
    'audit', 'printer', 'settings'
  ]::text[]
$$;

-- Default permissions of the non-owner roles. owner / admin always have everything.
create or replace function public.role_default_permissions(p_role text)
returns text[]
language sql
immutable
set search_path = ''
as $$
  select case p_role
    when 'manager' then array[
      'dashboard', 'pos', 'invoices', 'invoices.void', 'invoices.return', 'customers',
      'products.view', 'products.edit', 'inventory.view', 'inventory.adjust',
      'reports', 'reports.profit', 'audit', 'printer'
    ]::text[]
    when 'cashier' then array[
      'dashboard', 'pos', 'invoices', 'customers', 'products.view', 'inventory.view', 'printer'
    ]::text[]
    else array[]::text[]
  end
$$;

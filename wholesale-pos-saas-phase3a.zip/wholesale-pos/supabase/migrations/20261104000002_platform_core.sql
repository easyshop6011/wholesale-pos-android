-- =====================================================================================
-- Wholesale POS Cloud — migration 0002: platform core
--   profiles · platform_admins · plans · subscriptions · subscription_events ·
--   platform_settings · businesses · business_approvals · business_members ·
--   business_invitations · business_settings · user_devices · user_security_events ·
--   audit_logs · access_logs
--
-- Row Level Security and grants are in migration 0004 (every table here gets RLS).
-- =====================================================================================

-- ---- profiles (one row per auth user) ---------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  full_name text not null default '',
  phone text,
  avatar_url text,
  locale text not null default 'bn' check (locale in ('bn', 'en')),
  timezone text not null default 'Asia/Dhaka',
  is_active boolean not null default true,
  last_seen_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint profiles_phone_format check (phone is null or phone ~ '^01[3-9][0-9]{8}$')
);

create or replace function public.profiles_before_write()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.phone := nullif(public.normalize_phone(new.phone), '');
  new.full_name := btrim(coalesce(new.full_name, ''));
  return new;
end
$$;

create trigger profiles_before_write
  before insert or update on public.profiles
  for each row execute function public.profiles_before_write();

-- Every new auth user gets a profile. Only the NAME is taken from the sign-up metadata —
-- never a role or any permission (sign-up metadata is controlled by the caller).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    lower(new.email),
    coalesce(
      nullif(btrim(new.raw_user_meta_data ->> 'full_name'), ''),
      nullif(btrim(new.raw_user_meta_data ->> 'name'), ''),
      ''
    )
  )
  on conflict (id) do nothing;
  return new;
end
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.handle_user_email_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.profiles set email = lower(new.email) where id = new.id;
  return new;
end
$$;

create trigger on_auth_user_email_changed
  after update of email on auth.users
  for each row
  when (old.email is distinct from new.email)
  execute function public.handle_user_email_change();

-- ---- platform administrators (Super Admin) ----------------------------------------------
-- Rows are created ONLY from the SQL editor via private.grant_super_admin() (migration 0005).
-- The table has RLS enabled, no policies and no grants: the API can neither read nor write it.
create table public.platform_admins (
  user_id uuid primary key references auth.users (id) on delete cascade,
  note text not null default '',
  created_at timestamptz not null default now()
);

-- ---- plans, subscriptions ---------------------------------------------------------------
create table public.plans (
  code text primary key check (code ~ '^[a-z][a-z0-9_]{1,30}$'),
  name text not null,
  name_bn text not null,
  description_bn text not null default '',
  max_businesses integer not null check (max_businesses >= 1),
  max_employees_per_business integer not null check (max_employees_per_business >= 0),
  features jsonb not null default '{}'::jsonb,
  price_bdt numeric(10, 2) check (price_bdt is null or price_bdt >= 0),
  billing_period text not null default 'monthly' check (billing_period in ('monthly', 'yearly', 'lifetime')),
  purchasable boolean not null default false,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- One row per business OWNER; the plan covers all businesses of that owner.
-- A row whose current_period_end has passed behaves as "expired" (read-only) even if the
-- status text still says 'active' — no cron job is needed for the cut-off.
create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references public.profiles (id) on delete restrict,
  plan_code text not null references public.plans (code),
  status text not null default 'active' check (status in ('trialing', 'active', 'past_due', 'expired', 'cancelled')),
  started_at timestamptz not null default now(),
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  provider text not null default 'manual' check (provider in ('manual', 'bkash', 'nagad', 'rocket', 'card', 'other')),
  provider_ref text not null default '',
  note text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.subscription_events (
  id uuid primary key default gen_random_uuid(),
  subscription_id uuid references public.subscriptions (id) on delete restrict,
  owner_id uuid not null references public.profiles (id) on delete restrict,
  event_type text not null check (event_type in ('created', 'plan_changed', 'renewed', 'expired', 'cancelled', 'admin_override', 'payment_recorded')),
  from_plan text,
  to_plan text,
  from_status text,
  to_status text,
  actor_id uuid,
  note text not null default '',
  created_at timestamptz not null default now()
);
create index subscription_events_owner_idx on public.subscription_events (owner_id, created_at desc);

create table public.platform_settings (
  key text primary key check (key ~ '^[a-z][a-z0-9_.]{1,63}$'),
  value jsonb not null,
  description text not null default '',
  is_public boolean not null default false,
  updated_by uuid,
  updated_at timestamptz not null default now()
);

-- What the plan allows. Used by the triggers / functions that enforce limits ON THE SERVER.
create or replace function public.owner_plan_limits(p_owner uuid)
returns table (plan_code text, max_businesses integer, max_employees integer)
language sql
stable
security definer
set search_path = ''
as $$
  select p.code, p.max_businesses, p.max_employees_per_business
  from public.plans p
  where p.code = coalesce((select s.plan_code from public.subscriptions s where s.owner_id = p_owner), 'free')
  limit 1
$$;

-- ---- businesses (tenants) ---------------------------------------------------------------
create table public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles (id) on delete restrict,
  name text not null check (char_length(btrim(name)) between 2 and 120),
  owner_name text not null check (char_length(btrim(owner_name)) between 2 and 120),
  phone text not null check (phone ~ '^01[3-9][0-9]{8}$'),
  email text check (email is null or email ~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'),
  address text not null default '',
  district text not null default '',
  trade_license text not null default '',
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'suspended')),
  status_reason text not null default '',
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles (id) on delete set null,
  suspended_at timestamptz,
  currency text not null default 'BDT',
  timezone text not null default 'Asia/Dhaka',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);
create unique index businesses_owner_name_uq on public.businesses (owner_id, lower(btrim(name))) where deleted_at is null;
create index businesses_owner_idx on public.businesses (owner_id);
create index businesses_status_idx on public.businesses (status) where deleted_at is null;

-- The history of the approval workflow (submitted / approved / rejected / suspended …). Append-only.
create table public.business_approvals (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete restrict,
  decision text not null check (decision in ('submitted', 'resubmitted', 'approved', 'rejected', 'suspended', 'reinstated')),
  reason text not null default '',
  decided_by uuid,
  created_at timestamptz not null default now()
);
create index business_approvals_business_idx on public.business_approvals (business_id, created_at desc);

-- ---- membership: owner / admin / manager / cashier (+ custom permission list) ------------
create table public.business_members (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete restrict,
  user_id uuid not null references public.profiles (id) on delete restrict,
  role text not null check (role in ('owner', 'admin', 'manager', 'cashier')),
  -- NULL = the role's default permissions; a list = "Custom Role" (managers / cashiers only)
  permissions text[] check (permissions is null or permissions <@ public.all_permission_keys()),
  display_name text not null default '',
  status text not null default 'active' check (status in ('active', 'disabled')),
  invited_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, user_id),
  constraint members_admin_has_all check (role not in ('owner', 'admin') or permissions is null)
);
create unique index business_members_one_owner_uq on public.business_members (business_id) where role = 'owner';
create index business_members_user_idx on public.business_members (user_id) where status = 'active';

-- Plan limit on employees, enforced by the database itself (the UI hiding a button is not enough).
create or replace function public.enforce_employee_limit()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_owner uuid;
  v_max integer;
  v_count integer;
begin
  if new.role = 'owner' or new.status <> 'active' then
    return new;
  end if;
  select b.owner_id into v_owner from public.businesses b where b.id = new.business_id;
  perform pg_advisory_xact_lock(hashtext('members:' || new.business_id::text));
  select l.max_employees into v_max from public.owner_plan_limits(v_owner) l;
  select count(*) into v_count
  from public.business_members m
  where m.business_id = new.business_id and m.role <> 'owner' and m.status = 'active' and m.id <> new.id;
  if v_max is null or v_count >= v_max then
    raise exception 'plan_limit:employees' using errcode = 'P0001', detail = format('limit=%s', coalesce(v_max, 0));
  end if;
  return new;
end
$$;

create trigger business_members_limit
  before insert or update of role, status on public.business_members
  for each row execute function public.enforce_employee_limit();

-- Staff invitations. The token itself is NEVER stored — only its SHA-256 hash.
create table public.business_invitations (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete cascade,
  email text not null check (email = lower(email) and email ~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'),
  role text not null check (role in ('admin', 'manager', 'cashier')),
  permissions text[] check (permissions is null or permissions <@ public.all_permission_keys()),
  token_hash text not null unique,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'revoked', 'expired')),
  expires_at timestamptz not null default (now() + interval '7 days'),
  invited_by uuid not null references public.profiles (id) on delete cascade,
  accepted_by uuid references public.profiles (id) on delete set null,
  accepted_at timestamptz,
  created_at timestamptz not null default now()
);
create index business_invitations_business_idx on public.business_invitations (business_id, status);

-- Business-wide settings (name, address, footer, invoice prefix …). Device settings such as
-- the printer stay on the device, and secrets (sync tokens …) are refused by the CHECKs below.
create table public.business_settings (
  business_id uuid not null references public.businesses (id) on delete restrict,
  key text not null check (key ~ '^[A-Za-z][A-Za-z0-9_.:-]{0,63}$' and key !~* '(token|secret|password|apikey|api_key|private)'),
  value jsonb not null check (octet_length(value::text) <= 200000),
  updated_by uuid,
  updated_at timestamptz not null default now(),
  primary key (business_id, key)
);

-- ---- devices & security events -----------------------------------------------------------
create table public.user_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  device_id text not null check (char_length(device_id) between 8 and 80),
  session_id uuid,
  label text not null default '',
  platform text not null default 'web' check (platform in ('web', 'android', 'ios', 'other')),
  user_agent text not null default '',
  first_seen_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz,
  revoked_reason text,
  unique (user_id, device_id)
);
create index user_devices_session_idx on public.user_devices (user_id, session_id);

-- Sessions that were signed out remotely. A revoked session stays dead even if the same device signs in
-- again (that creates a NEW session id). RLS on, no policy, no grant: only server functions touch it.
create table public.revoked_sessions (
  session_id uuid primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  revoked_at timestamptz not null default now()
);
create index revoked_sessions_user_idx on public.revoked_sessions (user_id);

create table public.user_security_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  event_type text not null check (event_type in (
    'login', 'new_device_login', 'many_devices', 'login_failed', 'otp_requested', 'password_changed',
    'password_reset', 'mfa_enrolled', 'mfa_removed', 'device_revoked', 'logout_all',
    'customer_claim_failed', 'customer_claimed'
  )),
  severity text not null default 'info' check (severity in ('info', 'notice', 'warning')),
  device_id text,
  ip text,
  user_agent text not null default '',
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index user_security_events_user_idx on public.user_security_events (user_id, created_at desc);

-- ---- audit & access logs (append-only) ---------------------------------------------------
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references public.businesses (id) on delete restrict,
  actor_id uuid,
  actor_name text not null default '',
  action text not null check (char_length(action) between 3 and 80),
  target_type text not null default '',
  target_id text not null default '',
  details jsonb not null default '{}'::jsonb,
  source text not null default 'server' check (source in ('server', 'client')),
  created_at timestamptz not null default now()
);
create index audit_logs_business_idx on public.audit_logs (business_id, created_at desc);
create index audit_logs_actor_idx on public.audit_logs (actor_id, created_at desc);

create table public.access_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  business_id uuid references public.businesses (id) on delete restrict,
  kind text not null check (kind in ('admin_action', 'blocked_business', 'blocked_subscription', 'blocked_session')),
  resource text not null default '',
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index access_logs_created_idx on public.access_logs (created_at desc);
create index access_logs_user_idx on public.access_logs (user_id, created_at desc);
create index access_logs_business_idx on public.access_logs (business_id, created_at desc) where business_id is not null;

-- ---- triggers: updated_at, append-only ---------------------------------------------------
do $$
declare
  t text;
begin
  foreach t in array array['profiles', 'plans', 'subscriptions', 'platform_settings', 'businesses', 'business_members', 'business_settings'] loop
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', t);
  end loop;
  -- no UPDATE and no DELETE, ever
  foreach t in array array['subscription_events', 'business_approvals', 'audit_logs', 'access_logs'] loop
    execute format('create trigger append_only before update or delete on public.%I for each row execute function public.prevent_mutation()', t);
  end loop;
  -- no UPDATE (rows may disappear only together with the user they belong to)
  execute 'create trigger append_only before update on public.user_security_events for each row execute function public.prevent_mutation()';
end
$$;

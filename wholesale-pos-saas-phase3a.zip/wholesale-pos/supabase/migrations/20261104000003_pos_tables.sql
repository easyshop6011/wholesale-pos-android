-- =====================================================================================
-- Wholesale POS Cloud — migration 0003: business-owned POS tables
--
-- TENANT ISOLATION AT THE DATA LAYER: every table carries business_id, and every reference
-- between two business-owned tables is a COMPOSITE foreign key (business_id, x_id) →
-- parent(business_id, id). A row of business A can therefore never point at a row of
-- business B — not even through a buggy function or a service-role script.
--
-- Money is numeric(14,2), quantities numeric(14,3) (same precision as js/core/money.js).
-- Business time (Asia/Dhaka) columns biz_date / biz_time / biz_month are derived from the
-- instant occurred_at by triggers; the app never computes them on the server side.
-- Row Level Security and grants: migration 0004.
-- =====================================================================================

-- ---- catalogue --------------------------------------------------------------------------
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete restrict,
  name text not null check (char_length(btrim(name)) between 1 and 80),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (business_id, id)
);
create unique index categories_business_name_uq on public.categories (business_id, lower(btrim(name))) where deleted_at is null;

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete restrict,
  code text,
  name text not null check (char_length(btrim(name)) between 1 and 120),
  phone text check (phone is null or char_length(phone) between 3 and 24),
  address text not null default '',
  notes text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (business_id, id)
);
create unique index suppliers_business_code_uq on public.suppliers (business_id, code) where code is not null and code <> '';

create table public.products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete restrict,
  code text,
  name text not null check (char_length(btrim(name)) between 1 and 160),
  sku text,
  category_id uuid,
  unit text not null default 'pc' check (char_length(unit) between 1 and 20),
  cost_price numeric(14, 2) not null default 0 check (cost_price >= 0),
  default_price numeric(14, 2) not null default 0 check (default_price >= 0),
  -- Stock is changed ONLY by server functions through stock_movements (never directly by a client).
  stock numeric(14, 3) not null default 0,
  low_stock_level numeric(14, 3) not null default 0 check (low_stock_level >= 0),
  active boolean not null default true,
  last_move_at timestamptz,
  request_id text check (request_id is null or char_length(request_id) between 8 and 80),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (business_id, id),
  foreign key (business_id, category_id) references public.categories (business_id, id)
);
create unique index products_business_code_uq on public.products (business_id, code) where code is not null and code <> '';
create unique index products_business_request_uq on public.products (business_id, request_id) where request_id is not null;
create index products_business_name_idx on public.products (business_id, lower(name));
create index products_business_category_idx on public.products (business_id, category_id);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete restrict,
  code text,
  name text not null check (char_length(btrim(name)) between 1 and 120),
  phone text check (phone is null or char_length(phone) between 3 and 24),
  -- digits only, +88 removed: used to MATCH a verified phone number when a customer claims an account
  phone_norm text generated always as (nullif(public.normalize_phone(phone), '')) stored,
  email text check (email is null or (email = lower(email) and email ~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$')),
  address text not null default '',
  notes text not null default '',
  request_id text check (request_id is null or char_length(request_id) between 8 and 80),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (business_id, id)
);
create unique index customers_business_phone_uq on public.customers (business_id, phone) where phone is not null and phone <> '' and deleted_at is null;
create unique index customers_business_code_uq on public.customers (business_id, code) where code is not null and code <> '';
create unique index customers_business_request_uq on public.customers (business_id, request_id) where request_id is not null;
create index customers_business_name_idx on public.customers (business_id, lower(name));
create index customers_phone_norm_idx on public.customers (phone_norm) where phone_norm is not null;
create index customers_email_idx on public.customers (email) where email is not null;

-- Which login belongs to which customer record. One customer record ↔ at most one verified
-- login; one login may be linked to customers of SEVERAL shops. Rows are created only by the
-- verified-claim functions (Phase 4) — never by a client directly.
create table public.customer_accounts (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  customer_id uuid not null,
  user_id uuid not null references public.profiles (id) on delete cascade,
  status text not null default 'verified' check (status in ('verified', 'revoked')),
  verified_via text not null check (verified_via in ('email', 'phone', 'invite_code')),
  created_at timestamptz not null default now(),
  verified_at timestamptz not null default now(),
  revoked_at timestamptz,
  foreign key (business_id, customer_id) references public.customers (business_id, id) on delete restrict,
  unique (customer_id, user_id)
);
create unique index customer_accounts_one_login_per_customer_uq on public.customer_accounts (customer_id) where status = 'verified';
create index customer_accounts_user_idx on public.customer_accounts (user_id) where status = 'verified';
create index customer_accounts_business_idx on public.customer_accounts (business_id, customer_id);

-- One-time claim codes handed to a customer by the shop. Only the HASH of the code is stored.
create table public.customer_invitations (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  customer_id uuid not null,
  code_hash text not null unique,
  status text not null default 'pending' check (status in ('pending', 'used', 'revoked', 'expired')),
  expires_at timestamptz not null default (now() + interval '7 days'),
  created_by uuid references public.profiles (id) on delete set null,
  used_by uuid references public.profiles (id) on delete set null,
  used_at timestamptz,
  created_at timestamptz not null default now(),
  foreign key (business_id, customer_id) references public.customers (business_id, id) on delete restrict
);
create index customer_invitations_business_idx on public.customer_invitations (business_id, customer_id, status);

-- ---- sales ------------------------------------------------------------------------------
create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete restrict,
  invoice_no text not null check (char_length(invoice_no) between 3 and 64),
  request_id text check (request_id is null or char_length(request_id) between 8 and 80),
  customer_id uuid,
  customer_name text not null default '',
  customer_phone text not null default '',
  occurred_at timestamptz not null check (occurred_at > timestamptz '2020-01-01 00:00:00+00'),
  biz_date date not null,
  biz_time time not null,
  biz_month text not null,
  subtotal numeric(14, 2) not null check (subtotal >= 0),
  discount numeric(14, 2) not null default 0 check (discount >= 0),
  total numeric(14, 2) not null check (total >= 0),
  paid numeric(14, 2) not null default 0 check (paid >= 0),
  due numeric(14, 2) not null check (due >= 0),
  previous_due numeric(14, 2) not null default 0,
  payment_method text not null default '' check (payment_method in ('', 'cash', 'bkash', 'nagad', 'rocket', 'bank', 'card', 'cheque', 'other')),
  status text not null default 'active' check (status in ('active', 'void')),
  void_reason text not null default '',
  voided_at timestamptz,
  voided_by uuid,
  voided_by_name text not null default '',
  void_refund numeric(14, 2),
  notes text not null default '',
  rev integer not null default 1 check (rev >= 1),
  device_code text not null default '',
  created_by uuid references public.profiles (id) on delete set null,
  created_by_name text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint invoices_total_ok check (total = round(subtotal - discount, 2)),
  constraint invoices_due_ok check (due = round(total - paid, 2)),
  constraint invoices_discount_ok check (discount <= subtotal),
  constraint invoices_paid_ok check (paid <= total),
  constraint invoices_credit_needs_customer check (due = 0 or customer_id is not null),
  unique (business_id, id),
  unique (business_id, invoice_no), -- the same number may exist in ANOTHER business
  foreign key (business_id, customer_id) references public.customers (business_id, id)
);
create unique index invoices_business_request_uq on public.invoices (business_id, request_id) where request_id is not null;
create index invoices_business_date_idx on public.invoices (business_id, biz_date desc);
create index invoices_business_customer_idx on public.invoices (business_id, customer_id);
create index invoices_business_month_idx on public.invoices (business_id, biz_month);

-- Once saved, the money fields of an invoice never change; the only later change is a void.
create or replace function public.invoices_guard_update()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.business_id is distinct from old.business_id
     or new.invoice_no is distinct from old.invoice_no
     or new.customer_id is distinct from old.customer_id
     or new.occurred_at is distinct from old.occurred_at
     or new.subtotal is distinct from old.subtotal
     or new.discount is distinct from old.discount
     or new.total is distinct from old.total
     or new.paid is distinct from old.paid
     or new.due is distinct from old.due
     or new.created_by is distinct from old.created_by then
    raise exception 'invoice money / identity fields are immutable' using errcode = '42501';
  end if;
  if old.status = 'void' and new.status <> 'void' then
    raise exception 'a voided invoice cannot be reactivated' using errcode = '42501';
  end if;
  if new.rev < old.rev then
    raise exception 'invoice revision cannot go backwards' using errcode = '42501';
  end if;
  return new;
end
$$;

create trigger invoices_guard_update
  before update on public.invoices
  for each row execute function public.invoices_guard_update();

create table public.invoice_items (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  invoice_id uuid not null,
  line integer not null check (line >= 1),
  product_id uuid not null,
  name text not null,
  unit text not null default '',
  qty numeric(14, 3) not null check (qty > 0),
  unit_price numeric(14, 2) not null check (unit_price >= 0),
  cost_price numeric(14, 2) not null default 0 check (cost_price >= 0),
  total numeric(14, 2) not null check (total = round(qty * unit_price, 2)),
  unique (business_id, id),
  unique (invoice_id, line),
  foreign key (business_id, invoice_id) references public.invoices (business_id, id) on delete cascade,
  foreign key (business_id, product_id) references public.products (business_id, id)
);
create index invoice_items_business_invoice_idx on public.invoice_items (business_id, invoice_id);
create index invoice_items_business_product_idx on public.invoice_items (business_id, product_id);

-- Money received from a customer against their due.
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  request_id text check (request_id is null or char_length(request_id) between 8 and 80),
  customer_id uuid not null,
  customer_name text not null default '',
  customer_phone text not null default '',
  amount numeric(14, 2) not null check (amount > 0),
  method text not null default 'cash' check (method in ('cash', 'bkash', 'nagad', 'rocket', 'bank', 'card', 'cheque', 'other')),
  note text not null default '',
  occurred_at timestamptz not null check (occurred_at > timestamptz '2020-01-01 00:00:00+00'),
  biz_date date not null,
  biz_time time not null,
  biz_month text not null,
  created_by uuid references public.profiles (id) on delete set null,
  created_by_name text not null default '',
  created_at timestamptz not null default now(),
  unique (business_id, id),
  foreign key (business_id, customer_id) references public.customers (business_id, id)
);
create unique index payments_business_request_uq on public.payments (business_id, request_id) where request_id is not null;
create index payments_business_customer_idx on public.payments (business_id, customer_id, occurred_at desc);
create index payments_business_date_idx on public.payments (business_id, biz_date desc);

create table public.sales_returns (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  return_no text not null check (char_length(return_no) between 3 and 64),
  request_id text check (request_id is null or char_length(request_id) between 8 and 80),
  invoice_id uuid not null,
  invoice_no text not null,
  customer_id uuid,
  customer_name text not null default '',
  amount numeric(14, 2) not null check (amount >= 0),
  credit_applied numeric(14, 2) not null check (credit_applied >= 0),
  refund numeric(14, 2) not null check (refund >= 0),
  refund_method text not null default '' check (refund_method in ('', 'cash', 'bkash', 'nagad', 'rocket', 'bank', 'card', 'cheque', 'other')),
  reason text not null check (char_length(btrim(reason)) >= 3),
  occurred_at timestamptz not null check (occurred_at > timestamptz '2020-01-01 00:00:00+00'),
  biz_date date not null,
  biz_time time not null,
  biz_month text not null,
  created_by uuid references public.profiles (id) on delete set null,
  created_by_name text not null default '',
  created_at timestamptz not null default now(),
  constraint sales_returns_split_ok check (amount = round(credit_applied + refund, 2)),
  unique (business_id, id),
  unique (business_id, return_no),
  foreign key (business_id, invoice_id) references public.invoices (business_id, id),
  foreign key (business_id, customer_id) references public.customers (business_id, id)
);
create unique index sales_returns_business_request_uq on public.sales_returns (business_id, request_id) where request_id is not null;
create index sales_returns_business_invoice_idx on public.sales_returns (business_id, invoice_id);
create index sales_returns_business_customer_idx on public.sales_returns (business_id, customer_id);

create table public.sales_return_items (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  return_id uuid not null,
  invoice_item_id uuid not null,
  product_id uuid not null,
  name text not null,
  unit text not null default '',
  qty numeric(14, 3) not null check (qty > 0),
  unit_price numeric(14, 2) not null check (unit_price >= 0),
  amount numeric(14, 2) not null check (amount >= 0),
  foreign key (business_id, return_id) references public.sales_returns (business_id, id) on delete cascade,
  foreign key (business_id, invoice_item_id) references public.invoice_items (business_id, id),
  foreign key (business_id, product_id) references public.products (business_id, id)
);
create index sales_return_items_business_return_idx on public.sales_return_items (business_id, return_id);

-- ---- inventory --------------------------------------------------------------------------
-- Append-only ledger: every change of products.stock writes exactly one row here.
create table public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  product_id uuid not null,
  product_name text not null,
  product_code text,
  type text not null check (type in ('created', 'initial', 'receive', 'sale', 'void', 'return', 'adjustment', 'damage')),
  qty numeric(14, 3) not null,
  previous_stock numeric(14, 3) not null,
  balance numeric(14, 3) not null,
  reason text not null default '',
  ref_id uuid,
  ref_no text not null default '',
  user_id uuid references public.profiles (id) on delete set null,
  user_name text not null default '',
  unit_cost numeric(14, 2) check (unit_cost is null or unit_cost >= 0),
  supplier text not null default '',
  batch_no text not null default '',
  op_key text check (op_key is null or char_length(op_key) between 3 and 160),
  occurred_at timestamptz not null check (occurred_at > timestamptz '2020-01-01 00:00:00+00'),
  biz_date date not null,
  created_at timestamptz not null default now(),
  constraint stock_movements_chain_ok check (balance = previous_stock + qty),
  constraint stock_movements_sign_ok check (
    type in ('created', 'adjustment')
    or (type in ('initial', 'receive', 'void', 'return') and qty > 0)
    or (type in ('sale', 'damage') and qty < 0)
  ),
  unique (business_id, id),
  foreign key (business_id, product_id) references public.products (business_id, id)
);
create unique index stock_movements_business_opkey_uq on public.stock_movements (business_id, op_key) where op_key is not null;
create index stock_movements_business_product_idx on public.stock_movements (business_id, product_id, occurred_at desc);
create index stock_movements_business_date_idx on public.stock_movements (business_id, biz_date desc);

-- ---- purchases & suppliers ---------------------------------------------------------------
create table public.purchases (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  purchase_no text not null check (char_length(purchase_no) between 3 and 64),
  request_id text check (request_id is null or char_length(request_id) between 8 and 80),
  supplier_id uuid,
  supplier_name text not null default '',
  occurred_at timestamptz not null check (occurred_at > timestamptz '2020-01-01 00:00:00+00'),
  biz_date date not null,
  biz_time time not null,
  biz_month text not null,
  subtotal numeric(14, 2) not null check (subtotal >= 0),
  discount numeric(14, 2) not null default 0 check (discount >= 0),
  total numeric(14, 2) not null check (total >= 0),
  paid numeric(14, 2) not null default 0 check (paid >= 0),
  due numeric(14, 2) not null check (due >= 0),
  payment_method text not null default '' check (payment_method in ('', 'cash', 'bkash', 'nagad', 'rocket', 'bank', 'card', 'cheque', 'other')),
  notes text not null default '',
  status text not null default 'received' check (status in ('received', 'void')),
  void_reason text not null default '',
  rev integer not null default 1 check (rev >= 1),
  device_code text not null default '',
  created_by uuid references public.profiles (id) on delete set null,
  created_by_name text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint purchases_total_ok check (total = round(subtotal - discount, 2)),
  constraint purchases_due_ok check (due = round(total - paid, 2)),
  constraint purchases_discount_ok check (discount <= subtotal),
  constraint purchases_paid_ok check (paid <= total),
  constraint purchases_credit_needs_supplier check (due = 0 or supplier_id is not null),
  unique (business_id, id),
  unique (business_id, purchase_no),
  foreign key (business_id, supplier_id) references public.suppliers (business_id, id)
);
create unique index purchases_business_request_uq on public.purchases (business_id, request_id) where request_id is not null;
create index purchases_business_date_idx on public.purchases (business_id, biz_date desc);
create index purchases_business_supplier_idx on public.purchases (business_id, supplier_id);

create table public.purchase_items (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  purchase_id uuid not null,
  line integer not null check (line >= 1),
  product_id uuid not null,
  name text not null,
  unit text not null default '',
  qty numeric(14, 3) not null check (qty > 0),
  unit_cost numeric(14, 2) not null check (unit_cost >= 0),
  total numeric(14, 2) not null check (total = round(qty * unit_cost, 2)),
  batch_no text not null default '',
  unique (purchase_id, line),
  foreign key (business_id, purchase_id) references public.purchases (business_id, id) on delete cascade,
  foreign key (business_id, product_id) references public.products (business_id, id)
);
create index purchase_items_business_purchase_idx on public.purchase_items (business_id, purchase_id);
create index purchase_items_business_product_idx on public.purchase_items (business_id, product_id);

-- Money paid to a supplier against what the shop owes (the mirror image of payments).
create table public.supplier_payments (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  request_id text check (request_id is null or char_length(request_id) between 8 and 80),
  supplier_id uuid not null,
  supplier_name text not null default '',
  amount numeric(14, 2) not null check (amount > 0),
  method text not null default 'cash' check (method in ('cash', 'bkash', 'nagad', 'rocket', 'bank', 'card', 'cheque', 'other')),
  note text not null default '',
  occurred_at timestamptz not null check (occurred_at > timestamptz '2020-01-01 00:00:00+00'),
  biz_date date not null,
  biz_time time not null,
  biz_month text not null,
  created_by uuid references public.profiles (id) on delete set null,
  created_by_name text not null default '',
  created_at timestamptz not null default now(),
  unique (business_id, id),
  foreign key (business_id, supplier_id) references public.suppliers (business_id, id)
);
create unique index supplier_payments_business_request_uq on public.supplier_payments (business_id, request_id) where request_id is not null;
create index supplier_payments_business_supplier_idx on public.supplier_payments (business_id, supplier_id, occurred_at desc);

-- ---- triggers ---------------------------------------------------------------------------
do $$
declare
  t text;
begin
  foreach t in array array['categories', 'suppliers', 'products', 'customers', 'invoices', 'purchases'] loop
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', t);
  end loop;

  foreach t in array array['invoices', 'payments', 'sales_returns', 'purchases', 'supplier_payments'] loop
    execute format('create trigger derive_dhaka_dtm before insert on public.%I for each row execute function public.derive_dhaka_dtm()', t);
  end loop;

  execute 'create trigger derive_dhaka_date before insert on public.stock_movements for each row execute function public.derive_dhaka_date()';

  -- the money trail is append-only: corrections are NEW rows, never edits
  foreach t in array array['payments', 'sales_returns', 'sales_return_items', 'stock_movements', 'supplier_payments'] loop
    execute format('create trigger append_only before update or delete on public.%I for each row execute function public.prevent_mutation()', t);
  end loop;

  -- invoice lines never change after the sale
  foreach t in array array['invoice_items', 'purchase_items'] loop
    execute format('create trigger no_update before update on public.%I for each row execute function public.prevent_mutation()', t);
  end loop;
end
$$;

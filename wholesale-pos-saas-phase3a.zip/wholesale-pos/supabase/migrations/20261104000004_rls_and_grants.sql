-- =====================================================================================
-- Wholesale POS Cloud — migration 0004: Row Level Security, helper functions, grants
--
-- THE MODEL
--   * Every table has RLS enabled. A table without a policy is closed (default deny).
--   * Staff access is decided by public.my_business_ids(): the businesses where the caller is an
--     ACTIVE member, the business is APPROVED (pending / rejected / suspended = no cloud data),
--     the account and the session are not disabled / revoked, and — for writes — the owner's
--     subscription has not run out. Permissions (the same keys as js/services/permissions.js)
--     are checked inside the same function.
--   * Money-bearing tables (invoices, payments, returns, stock, purchases …) have SELECT policies
--     only: clients can never INSERT / UPDATE / DELETE them. They are written by server
--     functions that run one transaction (Phase 5), which also keeps stock correct.
--   * Master data (categories, products, customers, suppliers, settings) can be written by
--     permitted staff, but never deleted (soft delete only) and `products.stock` is not writable.
--   * Purchase cost (`cost_price`, `unit_cost`) is hidden from the API: it is readable only through
--     public.get_product_costs() for people holding `reports.profit` or `products.edit`.
--   * Customers (portal users) have NO policy on any table here. They read their own data only
--     through dedicated server functions that return safe columns (Phase 4).
--   * The Super Admin has no policy on POS tables: the platform sees counts and totals only.
-- =====================================================================================

-- ---- helper functions -------------------------------------------------------------------

create or replace function public.current_session_id()
returns uuid
language sql
stable
set search_path = ''
as $$
  select case
    when (auth.jwt() ->> 'session_id') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      then (auth.jwt() ->> 'session_id')::uuid
  end
$$;

create or replace function public.auth_email_verified()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce((select u.email_confirmed_at is not null from auth.users u where u.id = (select auth.uid())), false)
$$;

-- A session the user signed out remotely ("sign out that device") stops working immediately, even though
-- the short-lived access token itself is still valid until it expires.
create or replace function public.session_is_revoked()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.revoked_sessions r
    where r.session_id = public.current_session_id()
      and r.user_id = (select auth.uid())
  )
$$;

create or replace function public.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce((select p.is_active from public.profiles p where p.id = (select auth.uid())), false)
         and not public.session_is_revoked()
$$;

create or replace function public.is_platform_admin_any_aal()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (select 1 from public.platform_admins a where a.user_id = (select auth.uid()))
         and public.is_active_user()
$$;

-- Super Admin powers need MFA (aal2) unless platform_settings says otherwise.
create or replace function public.is_platform_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.is_platform_admin_any_aal()
         and (
           coalesce(((select ps.value from public.platform_settings ps where ps.key = 'security.super_admin_require_mfa') #>> '{}')::boolean, true) = false
           or coalesce((select auth.jwt() ->> 'aal'), '') = 'aal2'
         )
$$;

create or replace function public.subscription_is_writable(p_owner uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(
    (select s.status in ('trialing', 'active') and (s.current_period_end is null or s.current_period_end > now())
     from public.subscriptions s
     where s.owner_id = p_owner),
    true -- no row yet = the free plan, which never expires
  )
$$;

-- The businesses the caller may use: ACTIVE member of an APPROVED business.
--   p_perms : the member needs ANY of these permission keys (NULL = any member)
--   p_write : also require the owner's subscription to be in good standing (expired = read-only)
create or replace function public.my_business_ids(p_perms text[] default null, p_write boolean default false)
returns setof uuid
language sql
stable
security definer
set search_path = ''
as $$
  select m.business_id
  from public.business_members m
  join public.businesses b on b.id = m.business_id
  where m.user_id = (select auth.uid())
    and m.status = 'active'
    and b.status = 'approved'
    and b.deleted_at is null
    and public.is_active_user()
    and (not p_write or public.subscription_is_writable(b.owner_id))
    and (
      p_perms is null
      or m.role in ('owner', 'admin')
      or (coalesce(m.permissions, public.role_default_permissions(m.role)) && p_perms)
    )
$$;

-- owner / admin of an approved business (staff management, invitations)
create or replace function public.my_admin_business_ids()
returns setof uuid
language sql
stable
security definer
set search_path = ''
as $$
  select m.business_id
  from public.business_members m
  join public.businesses b on b.id = m.business_id
  where m.user_id = (select auth.uid())
    and m.status = 'active'
    and m.role in ('owner', 'admin')
    and b.status = 'approved'
    and b.deleted_at is null
    and public.is_active_user()
$$;

-- businesses the caller owns, whatever their approval state (an owner may see a pending / rejected application)
create or replace function public.my_owned_business_ids()
returns setof uuid
language sql
stable
security definer
set search_path = ''
as $$
  select b.id from public.businesses b where b.owner_id = (select auth.uid()) and b.deleted_at is null
$$;

create or replace function public.can_read_business(p_business uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select p_business in (select public.my_business_ids())
$$;

create or replace function public.can_write_business(p_business uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select p_business in (select public.my_business_ids(null, true))
$$;

create or replace function public.has_permission(p_business uuid, p_perm text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select p_business in (select public.my_business_ids(array[p_perm]))
$$;

create or replace function public.can_view_profile(p_user uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select p_user = (select auth.uid())
      or exists (
        select 1
        from public.business_members me
        join public.business_members them on them.business_id = me.business_id
        where me.user_id = (select auth.uid())
          and me.status = 'active'
          and me.role in ('owner', 'admin')
          and them.user_id = p_user
      )
$$;

-- stamp who changed a business setting
create or replace function public.business_settings_stamp()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_by := (select auth.uid());
  return new;
end
$$;

create trigger business_settings_stamp
  before insert or update on public.business_settings
  for each row execute function public.business_settings_stamp();

-- ---- enable RLS everywhere --------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.platform_admins enable row level security;
alter table public.plans enable row level security;
alter table public.subscriptions enable row level security;
alter table public.subscription_events enable row level security;
alter table public.platform_settings enable row level security;
alter table public.businesses enable row level security;
alter table public.business_approvals enable row level security;
alter table public.business_members enable row level security;
alter table public.business_invitations enable row level security;
alter table public.business_settings enable row level security;
alter table public.user_devices enable row level security;
alter table public.revoked_sessions enable row level security;
alter table public.user_security_events enable row level security;
alter table public.audit_logs enable row level security;
alter table public.access_logs enable row level security;
alter table public.categories enable row level security;
alter table public.suppliers enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.customer_accounts enable row level security;
alter table public.customer_invitations enable row level security;
alter table public.invoices enable row level security;
alter table public.invoice_items enable row level security;
alter table public.payments enable row level security;
alter table public.sales_returns enable row level security;
alter table public.sales_return_items enable row level security;
alter table public.stock_movements enable row level security;
alter table public.purchases enable row level security;
alter table public.purchase_items enable row level security;
alter table public.supplier_payments enable row level security;

-- platform_admins and revoked_sessions: RLS on, deliberately NO policy and NO grant.

-- ---- policies: accounts & platform -------------------------------------------------------
create policy profiles_select on public.profiles for select to authenticated
  using (id = (select auth.uid()) or public.can_view_profile(id) or (select public.is_platform_admin()));
create policy profiles_update_own on public.profiles for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

create policy plans_select on public.plans for select to authenticated
  using (is_active or (select public.is_platform_admin()));
create policy plans_insert_admin on public.plans for insert to authenticated
  with check ((select public.is_platform_admin()));
create policy plans_update_admin on public.plans for update to authenticated
  using ((select public.is_platform_admin()))
  with check ((select public.is_platform_admin()));

create policy subscriptions_select on public.subscriptions for select to authenticated
  using (owner_id = (select auth.uid()) or (select public.is_platform_admin()));
create policy subscription_events_select on public.subscription_events for select to authenticated
  using (owner_id = (select auth.uid()) or (select public.is_platform_admin()));

create policy platform_settings_select on public.platform_settings for select to authenticated
  using (is_public or (select public.is_platform_admin()));
create policy platform_settings_insert_admin on public.platform_settings for insert to authenticated
  with check ((select public.is_platform_admin()));
create policy platform_settings_update_admin on public.platform_settings for update to authenticated
  using ((select public.is_platform_admin()))
  with check ((select public.is_platform_admin()));

create policy businesses_select on public.businesses for select to authenticated
  using (
    owner_id = (select auth.uid())
    or id in (select public.my_business_ids())
    or (select public.is_platform_admin())
  );
-- The owner may correct the application details (column grants below allow only those columns).
-- status / owner_id can only be changed by the workflow functions in migration 0005.
create policy businesses_update_owner on public.businesses for update to authenticated
  using (owner_id = (select auth.uid()) and status <> 'suspended' and deleted_at is null)
  with check (owner_id = (select auth.uid()) and status <> 'suspended' and deleted_at is null);

create policy business_approvals_select on public.business_approvals for select to authenticated
  using (business_id in (select public.my_owned_business_ids()) or (select public.is_platform_admin()));

create policy business_members_select on public.business_members for select to authenticated
  using (user_id = (select auth.uid()) or business_id in (select public.my_business_ids()));

create policy business_invitations_select on public.business_invitations for select to authenticated
  using (business_id in (select public.my_admin_business_ids()));

create policy business_settings_select on public.business_settings for select to authenticated
  using (business_id in (select public.my_business_ids()));
create policy business_settings_insert on public.business_settings for insert to authenticated
  with check (business_id in (select public.my_business_ids(array['settings'], true)));
create policy business_settings_update on public.business_settings for update to authenticated
  using (business_id in (select public.my_business_ids(array['settings'], true)))
  with check (business_id in (select public.my_business_ids(array['settings'], true)));

create policy user_devices_select on public.user_devices for select to authenticated
  using (user_id = (select auth.uid()));
create policy user_security_events_select on public.user_security_events for select to authenticated
  using (user_id = (select auth.uid()));

create policy audit_logs_select on public.audit_logs for select to authenticated
  using (
    (business_id is not null and business_id in (select public.my_business_ids(array['audit'])))
    or (select public.is_platform_admin())
  );
create policy access_logs_select on public.access_logs for select to authenticated
  using ((select public.is_platform_admin()));

-- ---- policies: master data (writable by permitted staff, never deletable) ----------------
create policy categories_select on public.categories for select to authenticated
  using (business_id in (select public.my_business_ids(array['products.view', 'pos', 'products.edit', 'inventory.view'])));
create policy categories_insert on public.categories for insert to authenticated
  with check (business_id in (select public.my_business_ids(array['products.edit'], true)));
create policy categories_update on public.categories for update to authenticated
  using (business_id in (select public.my_business_ids(array['products.edit'], true)))
  with check (business_id in (select public.my_business_ids(array['products.edit'], true)));

create policy suppliers_select on public.suppliers for select to authenticated
  using (business_id in (select public.my_business_ids(array['inventory.view'])));
create policy suppliers_insert on public.suppliers for insert to authenticated
  with check (business_id in (select public.my_business_ids(array['inventory.adjust'], true)));
create policy suppliers_update on public.suppliers for update to authenticated
  using (business_id in (select public.my_business_ids(array['inventory.adjust'], true)))
  with check (business_id in (select public.my_business_ids(array['inventory.adjust'], true)));

create policy products_select on public.products for select to authenticated
  using (business_id in (select public.my_business_ids(array['products.view', 'pos', 'products.edit', 'inventory.view'])));
create policy products_insert on public.products for insert to authenticated
  with check (business_id in (select public.my_business_ids(array['products.edit'], true)));
create policy products_update on public.products for update to authenticated
  using (business_id in (select public.my_business_ids(array['products.edit'], true)))
  with check (business_id in (select public.my_business_ids(array['products.edit'], true)));

create policy customers_select on public.customers for select to authenticated
  using (business_id in (select public.my_business_ids(array['customers', 'pos', 'invoices'])));
create policy customers_insert on public.customers for insert to authenticated
  with check (business_id in (select public.my_business_ids(array['customers', 'pos'], true)));
-- soft delete (deleted_at) additionally needs `customers.delete`
create policy customers_update on public.customers for update to authenticated
  using (business_id in (select public.my_business_ids(array['customers'], true)))
  with check (
    business_id in (select public.my_business_ids(array['customers'], true))
    and (deleted_at is null or business_id in (select public.my_business_ids(array['customers.delete'], true)))
  );

create policy customer_accounts_select on public.customer_accounts for select to authenticated
  using (business_id in (select public.my_business_ids(array['customers'])));
create policy customer_invitations_select on public.customer_invitations for select to authenticated
  using (business_id in (select public.my_business_ids(array['customers'])));

-- ---- policies: money tables (read only for clients) --------------------------------------
create policy invoices_select on public.invoices for select to authenticated
  using (business_id in (select public.my_business_ids(array['invoices', 'pos', 'customers'])));
create policy invoice_items_select on public.invoice_items for select to authenticated
  using (business_id in (select public.my_business_ids(array['invoices', 'pos', 'customers'])));
create policy payments_select on public.payments for select to authenticated
  using (business_id in (select public.my_business_ids(array['customers', 'invoices'])));
create policy sales_returns_select on public.sales_returns for select to authenticated
  using (business_id in (select public.my_business_ids(array['invoices', 'invoices.return', 'customers'])));
create policy sales_return_items_select on public.sales_return_items for select to authenticated
  using (business_id in (select public.my_business_ids(array['invoices', 'invoices.return', 'customers'])));
create policy stock_movements_select on public.stock_movements for select to authenticated
  using (business_id in (select public.my_business_ids(array['inventory.view'])));
create policy purchases_select on public.purchases for select to authenticated
  using (business_id in (select public.my_business_ids(array['inventory.view'])));
create policy purchase_items_select on public.purchase_items for select to authenticated
  using (business_id in (select public.my_business_ids(array['inventory.view'])));
create policy supplier_payments_select on public.supplier_payments for select to authenticated
  using (business_id in (select public.my_business_ids(array['inventory.view'])));

-- ---- grants: start from nothing, then open exactly what is needed -------------------------
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;

grant select on
  public.plans, public.subscriptions, public.subscription_events, public.platform_settings,
  public.businesses, public.business_approvals, public.business_members, public.business_invitations,
  public.business_settings, public.user_devices, public.user_security_events, public.audit_logs,
  public.access_logs, public.categories, public.suppliers, public.customers, public.customer_accounts,
  public.customer_invitations, public.invoices, public.payments, public.sales_returns,
  public.sales_return_items, public.purchases, public.purchase_items, public.supplier_payments,
  public.profiles
  to authenticated;

grant update (full_name, phone, avatar_url, locale, timezone) on public.profiles to authenticated;
grant insert, update on public.plans to authenticated;
grant insert, update on public.platform_settings to authenticated;
grant update (name, owner_name, phone, email, address, district, trade_license) on public.businesses to authenticated;
grant insert (business_id, key, value), update (value) on public.business_settings to authenticated;

grant insert (id, business_id, name), update (name, deleted_at) on public.categories to authenticated;
grant insert (id, business_id, code, name, phone, address, notes, active),
      update (code, name, phone, address, notes, active, deleted_at) on public.suppliers to authenticated;
grant insert (id, business_id, code, name, phone, email, address, notes, request_id),
      update (code, name, phone, email, address, notes, deleted_at) on public.customers to authenticated;

-- products: `stock` and `last_move_at` can be neither inserted nor updated by a client.
grant insert (id, business_id, code, name, sku, category_id, unit, cost_price, default_price, low_stock_level, active, request_id),
      update (code, name, sku, category_id, unit, cost_price, default_price, low_stock_level, active, deleted_at)
  on public.products to authenticated;

-- Tables whose purchase-cost column is hidden: SELECT is granted column by column, without it.
do $$
declare
  r record;
begin
  for r in
    select c.table_name::text as tbl, string_agg(format('%I', c.column_name::text), ', ' order by c.ordinal_position) as cols
    from information_schema.columns c
    where c.table_schema = 'public'
      and c.table_name in ('products', 'invoice_items', 'stock_movements')
      and c.column_name not in ('cost_price', 'unit_cost')
    group by c.table_name
  loop
    execute format('grant select (%s) on public.%I to authenticated', r.cols, r.tbl);
  end loop;
end
$$;

-- =====================================================================================
-- Wholesale POS Cloud — migration 0005: workflow functions, reference data, execute grants
--
--   Business registration → pending → Super Admin approves / rejects → (suspend / reinstate)
--   Super Admin bootstrap (SQL editor only) · device / security events · access state
--
-- Every function: SECURITY DEFINER + `set search_path = ''` + fully qualified names, and EXECUTE is
-- revoked from everybody and re-granted only to `authenticated` at the bottom of this file.
-- Errors are short machine codes (e.g. 'plan_limit:businesses'); the app shows them in Bengali.
-- =====================================================================================

-- ---- internal helpers (schema private: not reachable through the API) ---------------------

create or replace function private.write_audit(
  p_business uuid,
  p_action text,
  p_target_type text default '',
  p_target_id text default '',
  p_details jsonb default '{}'::jsonb,
  p_source text default 'server'
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_name text;
begin
  select coalesce(nullif(m.display_name, ''), nullif(p.full_name, ''), p.email, '')
    into v_name
  from public.profiles p
  left join public.business_members m on m.user_id = p.id and m.business_id = p_business
  where p.id = v_uid;

  insert into public.audit_logs (business_id, actor_id, actor_name, action, target_type, target_id, details, source)
  values (p_business, v_uid, coalesce(v_name, ''), p_action, coalesce(p_target_type, ''), coalesce(p_target_id, ''), coalesce(p_details, '{}'::jsonb), p_source);
end
$$;

create or replace function private.log_access(
  p_kind text,
  p_business uuid,
  p_resource text,
  p_details jsonb default '{}'::jsonb
)
returns void
language sql
security definer
set search_path = ''
as $$
  insert into public.access_logs (user_id, business_id, kind, resource, details)
  values ((select auth.uid()), p_business, p_kind, p_resource, coalesce(p_details, '{}'::jsonb))
$$;

-- ---- Super Admin bootstrap ----------------------------------------------------------------
-- Run from the Supabase SQL editor (role postgres) AFTER you registered and verified your own
-- e-mail in the app:      select private.grant_super_admin('you@example.com');
-- The `private` schema is not exposed by the API, so public registration can never reach this.

create or replace function private.grant_super_admin(p_email text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid;
begin
  select u.id into v_user
  from auth.users u
  where lower(u.email) = lower(btrim(p_email)) and u.email_confirmed_at is not null;
  if v_user is null then
    raise exception 'no verified user with e-mail %. Register in the app and verify the e-mail first.', p_email
      using errcode = 'P0002';
  end if;
  insert into public.platform_admins (user_id, note)
  values (v_user, 'granted from the SQL editor')
  on conflict (user_id) do nothing;
  perform private.write_audit(null, 'platform.super_admin_granted', 'user', v_user::text, '{}'::jsonb);
  return v_user;
end
$$;

create or replace function private.revoke_super_admin(p_email text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid;
begin
  select u.id into v_user from auth.users u where lower(u.email) = lower(btrim(p_email));
  if v_user is null then
    raise exception 'unknown user %', p_email using errcode = 'P0002';
  end if;
  if (select count(*) from public.platform_admins) <= 1
     and exists (select 1 from public.platform_admins a where a.user_id = v_user) then
    raise exception 'cannot remove the last super admin' using errcode = 'P0001';
  end if;
  delete from public.platform_admins where user_id = v_user;
  perform private.write_audit(null, 'platform.super_admin_revoked', 'user', v_user::text, '{}'::jsonb);
end
$$;

-- ---- business registration ------------------------------------------------------------------

create or replace function public.register_business(
  p_name text,
  p_owner_name text,
  p_phone text,
  p_email text default null,
  p_address text default '',
  p_district text default '',
  p_trade_license text default ''
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_phone text := public.normalize_phone(p_phone);
  v_name text := btrim(coalesce(p_name, ''));
  v_owner_name text := btrim(coalesce(p_owner_name, ''));
  v_email text := nullif(lower(btrim(coalesce(p_email, ''))), '');
  v_max integer;
  v_owned integer;
  v_recent integer;
  v_id uuid;
begin
  if v_uid is null then
    raise exception 'auth_required' using errcode = '28000';
  end if;
  if not public.is_active_user() then
    raise exception 'account_disabled' using errcode = '42501';
  end if;
  if not public.auth_email_verified() then
    raise exception 'email_not_verified' using errcode = '42501';
  end if;
  if char_length(v_name) < 2 or char_length(v_name) > 120 then
    raise exception 'invalid_name' using errcode = '22023';
  end if;
  if char_length(v_owner_name) < 2 or char_length(v_owner_name) > 120 then
    raise exception 'invalid_owner_name' using errcode = '22023';
  end if;
  if v_phone !~ '^01[3-9][0-9]{8}$' then
    raise exception 'invalid_phone' using errcode = '22023';
  end if;
  if v_email is not null and v_email !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' then
    raise exception 'invalid_email' using errcode = '22023';
  end if;

  perform pg_advisory_xact_lock(hashtext('register:' || v_uid::text));

  if coalesce(((select ps.value from public.platform_settings ps where ps.key = 'registration.open') #>> '{}')::boolean, true) = false then
    raise exception 'registration_closed' using errcode = '42501';
  end if;

  -- at most 5 applications per day per person
  select count(*) into v_recent
  from public.business_approvals a
  join public.businesses b on b.id = a.business_id
  where b.owner_id = v_uid
    and a.decision in ('submitted', 'resubmitted')
    and a.created_at > now() - interval '1 day';
  if v_recent >= 5 then
    raise exception 'rate_limited' using errcode = 'P0001';
  end if;

  -- everybody who registers a business starts on the free plan
  insert into public.subscriptions (owner_id, plan_code, status)
  values (v_uid, 'free', 'active')
  on conflict (owner_id) do nothing;
  if found then
    insert into public.subscription_events (subscription_id, owner_id, event_type, to_plan, to_status, actor_id, note)
    select s.id, v_uid, 'created', 'free', 'active', v_uid, 'first business registration'
    from public.subscriptions s
    where s.owner_id = v_uid;
  end if;

  -- plan limit (server side — hiding a button in the app is not a restriction)
  select l.max_businesses into v_max from public.owner_plan_limits(v_uid) l;
  select count(*) into v_owned
  from public.businesses b
  where b.owner_id = v_uid and b.deleted_at is null and b.status <> 'rejected';
  if v_max is null or v_owned >= v_max then
    raise exception 'plan_limit:businesses' using errcode = 'P0001', detail = format('limit=%s', coalesce(v_max, 0));
  end if;

  begin
    insert into public.businesses (owner_id, name, owner_name, phone, email, address, district, trade_license)
    values (
      v_uid, v_name, v_owner_name, v_phone, v_email,
      btrim(coalesce(p_address, '')), btrim(coalesce(p_district, '')), btrim(coalesce(p_trade_license, ''))
    )
    returning id into v_id;
  exception
    when unique_violation then
      raise exception 'duplicate_business_name' using errcode = '23505';
  end;

  insert into public.business_members (business_id, user_id, role, display_name, invited_by)
  values (
    v_id, v_uid, 'owner',
    coalesce(nullif((select p.full_name from public.profiles p where p.id = v_uid), ''), v_owner_name),
    v_uid
  );
  insert into public.business_approvals (business_id, decision, decided_by)
  values (v_id, 'submitted', v_uid);
  perform private.write_audit(v_id, 'business.register', 'business', v_id::text, jsonb_build_object('name', v_name));
  return v_id;
end
$$;

-- A rejected application goes back to "pending" after the owner corrected the details.
create or replace function public.resubmit_business(p_business uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_b public.businesses;
  v_recent integer;
begin
  if v_uid is null then
    raise exception 'auth_required' using errcode = '28000';
  end if;
  if not public.is_active_user() then
    raise exception 'account_disabled' using errcode = '42501';
  end if;
  select * into v_b from public.businesses b where b.id = p_business and b.owner_id = v_uid and b.deleted_at is null for update;
  if not found then
    raise exception 'business_not_found' using errcode = 'P0002';
  end if;
  if v_b.status <> 'rejected' then
    raise exception 'invalid_transition' using errcode = 'P0001', detail = v_b.status;
  end if;
  select count(*) into v_recent
  from public.business_approvals a
  where a.business_id = p_business and a.decision in ('submitted', 'resubmitted') and a.created_at > now() - interval '1 day';
  if v_recent >= 5 then
    raise exception 'rate_limited' using errcode = 'P0001';
  end if;
  update public.businesses
     set status = 'pending', status_reason = '', submitted_at = now(), reviewed_at = null, reviewed_by = null
   where id = p_business;
  insert into public.business_approvals (business_id, decision, decided_by) values (p_business, 'resubmitted', v_uid);
  perform private.write_audit(p_business, 'business.resubmit', 'business', p_business::text, '{}'::jsonb);
end
$$;

-- ---- Super Admin: approve / reject / suspend -----------------------------------------------

create or replace function public.review_business(p_business uuid, p_decision text, p_reason text default '')
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_b public.businesses;
  v_reason text := btrim(coalesce(p_reason, ''));
begin
  if not public.is_platform_admin() then
    raise exception 'not_platform_admin' using errcode = '42501';
  end if;
  select * into v_b from public.businesses b where b.id = p_business and b.deleted_at is null for update;
  if not found then
    raise exception 'business_not_found' using errcode = 'P0002';
  end if;
  if v_b.status <> 'pending' then
    raise exception 'invalid_transition' using errcode = 'P0001', detail = v_b.status;
  end if;

  if p_decision = 'approve' then
    update public.businesses
       set status = 'approved', status_reason = '', reviewed_at = now(), reviewed_by = v_uid
     where id = p_business;
    insert into public.business_approvals (business_id, decision, reason, decided_by)
    values (p_business, 'approved', v_reason, v_uid);
  elsif p_decision = 'reject' then
    if char_length(v_reason) < 5 then
      raise exception 'reason_required' using errcode = '22023';
    end if;
    update public.businesses
       set status = 'rejected', status_reason = v_reason, reviewed_at = now(), reviewed_by = v_uid
     where id = p_business;
    insert into public.business_approvals (business_id, decision, reason, decided_by)
    values (p_business, 'rejected', v_reason, v_uid);
  else
    raise exception 'invalid_decision' using errcode = '22023';
  end if;

  perform private.write_audit(p_business, 'business.' || p_decision, 'business', p_business::text, jsonb_build_object('reason', v_reason));
  perform private.log_access('admin_action', p_business, 'review_business', jsonb_build_object('decision', p_decision));
end
$$;

-- Suspend (cloud access closes at once for every member) or reinstate.
create or replace function public.set_business_suspension(p_business uuid, p_suspend boolean, p_reason text default '')
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_b public.businesses;
  v_reason text := btrim(coalesce(p_reason, ''));
begin
  if not public.is_platform_admin() then
    raise exception 'not_platform_admin' using errcode = '42501';
  end if;
  select * into v_b from public.businesses b where b.id = p_business and b.deleted_at is null for update;
  if not found then
    raise exception 'business_not_found' using errcode = 'P0002';
  end if;

  if p_suspend then
    if v_b.status <> 'approved' then
      raise exception 'invalid_transition' using errcode = 'P0001', detail = v_b.status;
    end if;
    if char_length(v_reason) < 5 then
      raise exception 'reason_required' using errcode = '22023';
    end if;
    update public.businesses
       set status = 'suspended', status_reason = v_reason, suspended_at = now()
     where id = p_business;
    insert into public.business_approvals (business_id, decision, reason, decided_by)
    values (p_business, 'suspended', v_reason, v_uid);
  else
    if v_b.status <> 'suspended' then
      raise exception 'invalid_transition' using errcode = 'P0001', detail = v_b.status;
    end if;
    update public.businesses
       set status = 'approved', status_reason = '', suspended_at = null
     where id = p_business;
    insert into public.business_approvals (business_id, decision, reason, decided_by)
    values (p_business, 'reinstated', v_reason, v_uid);
  end if;

  perform private.write_audit(
    p_business,
    case when p_suspend then 'business.suspend' else 'business.reinstate' end,
    'business', p_business::text, jsonb_build_object('reason', v_reason)
  );
  perform private.log_access('admin_action', p_business, 'set_business_suspension', jsonb_build_object('suspend', p_suspend));
end
$$;

-- ---- what may I do right now? (the app calls this after every sign-in) -----------------------
-- One answer for the whole screen flow: pending / rejected / suspended / expired are explained
-- here instead of the app guessing from failed queries. Blocked states are written to access_logs.

create or replace function public.my_access_state()
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_result jsonb;
begin
  if v_uid is null then
    raise exception 'auth_required' using errcode = '28000';
  end if;

  select jsonb_build_object(
    'user_id', v_uid,
    'active', coalesce((select p.is_active from public.profiles p where p.id = v_uid), false),
    'email_verified', public.auth_email_verified(),
    'session_revoked', public.session_is_revoked(),
    'super_admin_candidate', exists (select 1 from public.platform_admins a where a.user_id = v_uid),
    'super_admin', public.is_platform_admin(),
    'businesses', coalesce((
      select jsonb_agg(
        jsonb_build_object(
          'business_id', b.id,
          'name', b.name,
          'status', b.status,
          'status_reason', b.status_reason,
          'role', m.role,
          'member_status', m.status,
          'permissions', case
            when m.role in ('owner', 'admin') then to_jsonb(public.all_permission_keys())
            else to_jsonb(coalesce(m.permissions, public.role_default_permissions(m.role)))
          end,
          'can_read', (b.status = 'approved' and m.status = 'active'),
          'can_write', (b.status = 'approved' and m.status = 'active' and public.subscription_is_writable(b.owner_id)),
          'plan', coalesce(s.plan_code, 'free'),
          'subscription_status', coalesce(s.status, 'active'),
          'period_end', s.current_period_end
        )
        order by b.created_at
      )
      from public.business_members m
      join public.businesses b on b.id = m.business_id and b.deleted_at is null
      left join public.subscriptions s on s.owner_id = b.owner_id
      where m.user_id = v_uid
    ), '[]'::jsonb),
    'customer_links', (select count(*) from public.customer_accounts ca where ca.user_id = v_uid and ca.status = 'verified')
  ) into v_result;

  -- remember (at most once an hour) that a suspended / expired business was opened
  insert into public.access_logs (user_id, business_id, kind, resource, details)
  select v_uid, b.id,
         case when b.status = 'suspended' then 'blocked_business' else 'blocked_subscription' end,
         'my_access_state',
         jsonb_build_object('status', b.status)
  from public.business_members m
  join public.businesses b on b.id = m.business_id and b.deleted_at is null
  where m.user_id = v_uid
    and m.status = 'active'
    and (b.status = 'suspended' or (b.status = 'approved' and not public.subscription_is_writable(b.owner_id)))
    and not exists (
      select 1
      from public.access_logs l
      where l.user_id = v_uid
        and l.business_id = b.id
        and l.created_at > now() - interval '1 hour'
        and l.kind = case when b.status = 'suspended' then 'blocked_business' else 'blocked_subscription' end
    );

  if public.session_is_revoked() then
    insert into public.access_logs (user_id, kind, resource)
    select v_uid, 'blocked_session', 'my_access_state'
    where not exists (
      select 1 from public.access_logs l
      where l.user_id = v_uid and l.kind = 'blocked_session' and l.created_at > now() - interval '1 hour'
    );
  end if;

  return v_result;
end
$$;

-- ---- devices & security events -----------------------------------------------------------------

-- Called by the app after every successful sign-in. A first-seen device while other devices exist is
-- reported as 'new_device_login'; four or more different devices within a day as 'many_devices'.
create or replace function public.record_login(
  p_device_id text,
  p_label text default '',
  p_platform text default 'web',
  p_user_agent text default ''
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_sid uuid := public.current_session_id();
  v_platform text := case when p_platform in ('web', 'android', 'ios', 'other') then p_platform else 'other' end;
  v_ip text := left(split_part(coalesce(nullif(current_setting('request.headers', true), '')::json ->> 'x-forwarded-for', ''), ',', 1), 64);
  v_known boolean;
  v_others integer;
  v_recent integer;
  v_new boolean;
begin
  if v_uid is null then
    raise exception 'auth_required' using errcode = '28000';
  end if;
  if not public.is_active_user() then
    raise exception 'account_disabled' using errcode = '42501';
  end if;
  if p_device_id is null or char_length(p_device_id) not between 8 and 80 then
    raise exception 'invalid_device' using errcode = '22023';
  end if;

  select exists (select 1 from public.user_devices d where d.user_id = v_uid and d.device_id = p_device_id) into v_known;
  select count(*) into v_others
  from public.user_devices d
  where d.user_id = v_uid and d.device_id <> p_device_id and d.revoked_at is null;

  insert into public.user_devices as d (user_id, device_id, session_id, label, platform, user_agent)
  values (v_uid, p_device_id, v_sid, left(coalesce(p_label, ''), 80), v_platform, left(coalesce(p_user_agent, ''), 300))
  on conflict (user_id, device_id) do update
    set session_id = excluded.session_id,
        last_seen_at = now(),
        revoked_at = null,
        revoked_reason = null,
        label = case when excluded.label <> '' then excluded.label else d.label end,
        user_agent = excluded.user_agent;

  v_new := not v_known;
  update public.profiles set last_seen_at = now() where id = v_uid;

  insert into public.user_security_events (user_id, event_type, severity, device_id, ip, user_agent, details)
  values (
    v_uid,
    case when v_new and v_others > 0 then 'new_device_login' else 'login' end,
    case when v_new and v_others > 0 then 'notice' else 'info' end,
    p_device_id,
    nullif(v_ip, ''),
    left(coalesce(p_user_agent, ''), 300),
    jsonb_build_object('platform', v_platform, 'label', left(coalesce(p_label, ''), 80))
  );

  select count(distinct e.device_id) into v_recent
  from public.user_security_events e
  where e.user_id = v_uid
    and e.created_at > now() - interval '1 day'
    and e.event_type in ('login', 'new_device_login');
  if v_recent >= 4 then
    insert into public.user_security_events (user_id, event_type, severity, device_id, details)
    values (v_uid, 'many_devices', 'warning', p_device_id, jsonb_build_object('devices_24h', v_recent));
  end if;

  return jsonb_build_object('new_device', v_new, 'other_devices', v_others, 'suspicious', v_recent >= 4);
end
$$;

-- "Sign out that device": its CURRENT session stops working immediately (see session_is_revoked()).
-- (To end every session of the account use the Auth API's global sign-out.)
create or replace function public.revoke_device(p_device uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_device_id text;
  v_session uuid;
begin
  if v_uid is null then
    raise exception 'auth_required' using errcode = '28000';
  end if;
  update public.user_devices
     set revoked_at = now(), revoked_reason = 'revoked by the user'
   where id = p_device and user_id = v_uid and revoked_at is null
  returning device_id, session_id into v_device_id, v_session;
  if not found then
    raise exception 'device_not_found' using errcode = 'P0002';
  end if;
  if v_session is not null then
    insert into public.revoked_sessions (session_id, user_id)
    values (v_session, v_uid)
    on conflict (session_id) do nothing;
  end if;
  insert into public.user_security_events (user_id, event_type, severity, device_id)
  values (v_uid, 'device_revoked', 'notice', v_device_id);
end
$$;

-- Events the app itself knows about (the sign-in service has no database access). The user is always
-- the caller; only these harmless event types are accepted.
create or replace function public.log_security_event(p_type text, p_details jsonb default '{}'::jsonb)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
begin
  if v_uid is null then
    raise exception 'auth_required' using errcode = '28000';
  end if;
  if p_type not in ('otp_requested', 'password_changed', 'password_reset', 'mfa_enrolled', 'mfa_removed', 'logout_all') then
    raise exception 'invalid_event' using errcode = '22023';
  end if;
  insert into public.user_security_events (user_id, event_type, severity, details)
  values (
    v_uid,
    p_type,
    case when p_type in ('mfa_removed', 'password_reset') then 'notice' else 'info' end,
    case when octet_length(coalesce(p_details, '{}'::jsonb)::text) <= 2000 then coalesce(p_details, '{}'::jsonb) else '{}'::jsonb end
  );
end
$$;

-- ---- purchase cost (hidden from the API columns) ------------------------------------------------
create or replace function public.get_product_costs(p_business uuid)
returns table (product_id uuid, cost_price numeric)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if p_business not in (select public.my_business_ids(array['reports.profit', 'products.edit'])) then
    raise exception 'permission_denied' using errcode = '42501';
  end if;
  return query
    select p.id, p.cost_price
    from public.products p
    where p.business_id = p_business and p.deleted_at is null;
end
$$;

-- ---- reference data (idempotent) -------------------------------------------------------------------
insert into public.plans (code, name, name_bn, description_bn, max_businesses, max_employees_per_business, features, price_bdt, billing_period, purchasable, sort_order)
values
  ('free', 'Free', 'ফ্রি',
   'একটি ব্যবসা, সীমিত কর্মচারী, মৌলিক POS, পণ্য ও কাস্টমার ব্যবস্থাপনা, বিক্রয়, বাকি হিসাব, মৌলিক প্রতিবেদন ও কাস্টমার পোর্টাল।',
   1, 3,
   '{"customer_portal": true, "advanced_reports": false, "cloud_backup": false, "advanced_inventory": false, "integrations": false, "priority_support": false}'::jsonb,
   0, 'monthly', true, 1),
  ('premium', 'Premium', 'প্রিমিয়াম',
   'একাধিক ব্যবসা, বেশি কর্মচারী, উন্নত প্রতিবেদন, ক্লাউড ব্যাকআপ, উন্নত মজুত ব্যবস্থাপনা, অতিরিক্ত ইন্টিগ্রেশন ও অগ্রাধিকার সহায়তা। (শীঘ্রই আসছে)',
   5, 25,
   '{"customer_portal": true, "advanced_reports": true, "cloud_backup": true, "advanced_inventory": true, "integrations": true, "priority_support": true}'::jsonb,
   null, 'monthly', false, 2)
on conflict (code) do nothing;

insert into public.platform_settings (key, value, description, is_public)
values
  ('security.super_admin_require_mfa', 'true'::jsonb, 'Super Admin functions require MFA (aal2). Set to false only while recovering a lost authenticator.', false),
  ('registration.open', 'true'::jsonb, 'When false, new business applications are refused.', true)
on conflict (key) do nothing;

-- ---- EXECUTE privileges: close everything, then open exactly what the app calls ------------------
revoke execute on all functions in schema public from public, anon, authenticated;
revoke execute on all functions in schema private from public, anon, authenticated;

grant execute on function
  public.current_session_id(),
  public.auth_email_verified(),
  public.session_is_revoked(),
  public.is_active_user(),
  public.is_platform_admin_any_aal(),
  public.is_platform_admin(),
  public.subscription_is_writable(uuid),
  public.my_business_ids(text[], boolean),
  public.my_admin_business_ids(),
  public.my_owned_business_ids(),
  public.can_read_business(uuid),
  public.can_write_business(uuid),
  public.has_permission(uuid, text),
  public.can_view_profile(uuid),
  public.normalize_phone(text),
  public.all_permission_keys(),
  public.role_default_permissions(text),
  public.register_business(text, text, text, text, text, text, text),
  public.resubmit_business(uuid),
  public.review_business(uuid, text, text),
  public.set_business_suspension(uuid, boolean, text),
  public.my_access_state(),
  public.record_login(text, text, text, text),
  public.revoke_device(uuid),
  public.log_security_event(text, jsonb),
  public.get_product_costs(uuid)
to authenticated;

-- =====================================================================================
-- pgTAP tests — Wholesale POS Cloud (Phase 2)
-- Run with:   supabase test db        (needs `supabase start`, i.e. Docker)
--
-- STATUS: written by the author WITHOUT access to a PostgreSQL server — it has never been executed.
-- Treat the first run as part of acceptance: if an assertion fails, the failure message tells which
-- rule is not met; if the script itself errors, send the exact error text so it can be fixed.
--
-- Who is who:
--   A  (a000…0a) owner of business A        B  (b000…0b) owner of business B
--   S  (c000…0c) cashier of business A      C  (d000…0d) customer of business A
--   SA (e000…0e) super admin                X  (f000…0f) outsider with no business
-- =====================================================================================
begin;

create extension if not exists pgtap with schema extensions;
select * from no_plan();

-- ---- helpers (live only inside this transaction) -----------------------------------------------
create schema tests;
grant usage on schema tests to authenticated;
create table tests.ids (k text primary key, v uuid not null);
grant all on tests.ids to authenticated;

create function tests.id(p_key text) returns uuid
language sql stable
as $$ select i.v from tests.ids i where i.k = p_key $$;
grant execute on function tests.id(text) to authenticated;

create function tests.create_user(p_id uuid, p_email text, p_verified boolean default true) returns void
language sql
as $$
  insert into auth.users (instance_id, id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values ('00000000-0000-0000-0000-000000000000', p_id, 'authenticated', 'authenticated', p_email,
          case when p_verified then now() end,
          '{"provider":"email","providers":["email"]}'::jsonb, '{}'::jsonb, now(), now())
$$;

-- act as a signed-in API user (what PostgREST does with a valid JWT)
create function tests.act_as(p_id uuid, p_aal text default 'aal1', p_session uuid default null) returns void
language plpgsql
as $$
begin
  perform set_config('request.jwt.claims',
    json_build_object('sub', p_id, 'role', 'authenticated', 'aal', p_aal, 'session_id', p_session)::text, true);
  set local role authenticated;
end
$$;

-- ---- fixtures ----------------------------------------------------------------------------------------
select tests.create_user('a0000000-0000-0000-0000-00000000000a', 'owner.a@example.test');
select tests.create_user('b0000000-0000-0000-0000-00000000000b', 'owner.b@example.test');
select tests.create_user('c0000000-0000-0000-0000-00000000000c', 'cashier.s@example.test');
select tests.create_user('d0000000-0000-0000-0000-00000000000d', 'customer.c@example.test');
select tests.create_user('e0000000-0000-0000-0000-00000000000e', 'super.admin@example.test');
select tests.create_user('f0000000-0000-0000-0000-00000000000f', 'outsider.x@example.test');
select tests.create_user('90000000-0000-0000-0000-000000000009', 'unverified@example.test', false);
select tests.create_user('91000000-0000-0000-0000-000000000001', 'staff1@example.test');
select tests.create_user('91000000-0000-0000-0000-000000000002', 'staff2@example.test');
select tests.create_user('91000000-0000-0000-0000-000000000003', 'staff3@example.test');

-- the Super Admin is bootstrapped from the SQL editor only
select private.grant_super_admin('super.admin@example.test');

-- =====================================================================================================
-- 1. structure: what the API roles can reach at all
-- =====================================================================================================
select ok(not has_schema_privilege('authenticated', 'private', 'usage'), 'the private schema is closed to the API roles');
select ok(not has_schema_privilege('anon', 'private', 'usage'), 'the private schema is closed to anonymous users');
select ok(not has_table_privilege('authenticated', 'public.platform_admins', 'select'), 'platform_admins cannot be read through the API');
select ok(not has_table_privilege('authenticated', 'public.revoked_sessions', 'select'), 'revoked_sessions cannot be read through the API');
select ok(not has_table_privilege('anon', 'public.products', 'select'), 'anonymous users cannot read products');
select ok(not has_table_privilege('authenticated', 'public.invoices', 'insert'), 'clients cannot insert invoices directly');
select ok(not has_table_privilege('authenticated', 'public.payments', 'insert'), 'clients cannot insert payments directly');
select ok(not has_table_privilege('authenticated', 'public.stock_movements', 'insert'), 'clients cannot insert stock movements directly');
select ok(not has_column_privilege('authenticated', 'public.products', 'cost_price', 'select'), 'purchase cost is hidden from the API');
select ok(not has_column_privilege('authenticated', 'public.products', 'stock', 'update'), 'clients cannot update stock');
select ok(not has_column_privilege('authenticated', 'public.products', 'stock', 'insert'), 'clients cannot set stock at insert');
select ok(not has_function_privilege('anon', 'public.register_business(text, text, text, text, text, text, text)', 'execute'), 'anonymous users cannot call register_business');
select ok(not has_function_privilege('anon', 'public.review_business(uuid, text, text)', 'execute'), 'anonymous users cannot call review_business');
select is(
  (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace
    where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity)::int,
  0, 'every table in the public schema has row level security enabled');
select is((select count(*) from public.platform_admins)::int, 1, 'the bootstrap created exactly one super admin');
select is((select count(*) from public.plans where code in ('free', 'premium'))::int, 2, 'the free and premium plans exist');

-- =====================================================================================================
-- 2. registration → pending → approve / reject → resubmit
-- =====================================================================================================
select tests.act_as('a0000000-0000-0000-0000-00000000000a');
insert into tests.ids select 'biz_a', public.register_business('A Traders', 'Mr A', '+880 1712-345678', 'a@shop.test', 'Dhaka', 'Dhaka', '');

select is((select status from public.businesses where id = tests.id('biz_a')), 'pending', 'a new application starts as pending');
select is((select phone from public.businesses where id = tests.id('biz_a')), '01712345678', 'the phone number is normalised');
select is((select count(*) from public.business_members where business_id = tests.id('biz_a') and role = 'owner')::int, 1, 'the applicant is recorded as the owner');
select is((select plan_code from public.subscriptions where owner_id = 'a0000000-0000-0000-0000-00000000000a'), 'free', 'a free subscription is created automatically');
select throws_ok($q$ select public.register_business('A Second Shop', 'Mr A', '01712345678') $q$, 'P0001', 'plan_limit:businesses', 'the free plan allows one business');

select tests.act_as('b0000000-0000-0000-0000-00000000000b');
insert into tests.ids select 'biz_b', public.register_business('B Stores', 'Mr B', '01812345678');
select is((select count(*) from public.businesses where id = tests.id('biz_a'))::int, 0, 'B cannot see the application of A');
select is((select count(*) from public.businesses)::int, 1, 'B sees exactly its own business');

select tests.act_as('90000000-0000-0000-0000-000000000009');
select throws_ok($q$ select public.register_business('X Shop', 'Mr X', '01712345679') $q$, '42501', 'email_not_verified', 'an unverified e-mail cannot register a business');
select tests.act_as('f0000000-0000-0000-0000-00000000000f');
select throws_ok($q$ select public.register_business('Bad Phone Shop', 'Mr F', '12345') $q$, '22023', 'invalid_phone', 'an invalid phone number is refused');

select tests.act_as('a0000000-0000-0000-0000-00000000000a');
select throws_ok(format($q$ select public.review_business(%L, 'approve') $q$, tests.id('biz_a')), '42501', 'not_platform_admin', 'a business owner cannot approve their own application');
select throws_ok($q$ select public.get_product_costs('a0000000-0000-0000-0000-00000000000a') $q$, '42501', 'permission_denied', 'purchase cost needs a membership (and a permission)');

select tests.act_as('e0000000-0000-0000-0000-00000000000e', 'aal1');
select throws_ok(format($q$ select public.review_business(%L, 'approve') $q$, tests.id('biz_a')), '42501', 'not_platform_admin', 'a super admin without MFA (aal1) has no admin power');
select tests.act_as('e0000000-0000-0000-0000-00000000000e', 'aal2');
select lives_ok(format($q$ select public.review_business(%L, 'approve') $q$, tests.id('biz_a')), 'a super admin with MFA approves a business');
select is((select status from public.businesses where id = tests.id('biz_a')), 'approved', 'the business is approved');
select throws_ok(format($q$ select public.review_business(%L, 'approve') $q$, tests.id('biz_a')), 'P0001', 'invalid_transition', 'an approved business cannot be approved again');

select throws_ok(format($q$ select public.review_business(%L, 'reject', '') $q$, tests.id('biz_b')), '22023', 'reason_required', 'a rejection needs a reason');
select lives_ok(format($q$ select public.review_business(%L, 'reject', 'documents are unreadable') $q$, tests.id('biz_b')), 'a super admin rejects with a reason');

select tests.act_as('b0000000-0000-0000-0000-00000000000b');
select is((select status_reason from public.businesses where id = tests.id('biz_b')), 'documents are unreadable', 'the owner sees the rejection reason');
select throws_ok(format($q$ update public.businesses set status = 'approved' where id = %L $q$, tests.id('biz_b')), '42501', null, 'an owner cannot approve themselves through UPDATE');
select lives_ok(format($q$ update public.businesses set address = 'Chattogram' where id = %L $q$, tests.id('biz_b')), 'an owner may correct the application details');
select lives_ok(format($q$ select public.resubmit_business(%L) $q$, tests.id('biz_b')), 'a rejected application can be resubmitted');
select is((select status from public.businesses where id = tests.id('biz_b')), 'pending', 'the resubmitted application is pending again');

select tests.act_as('e0000000-0000-0000-0000-00000000000e', 'aal2');
select lives_ok(format($q$ select public.review_business(%L, 'approve') $q$, tests.id('biz_b')), 'business B is approved');

-- ---- fixtures that only the database owner can create -----------------------------------------------
reset role;
insert into public.business_members (business_id, user_id, role, display_name)
values (tests.id('biz_a'), 'c0000000-0000-0000-0000-00000000000c', 'cashier', 'Cashier S');
insert into public.products (id, business_id, name, cost_price, default_price, stock) values
  ('10000000-0000-0000-0000-000000000001', tests.id('biz_a'), 'Rice A', 50, 60, 100),
  ('20000000-0000-0000-0000-000000000002', tests.id('biz_b'), 'Rice B', 55, 65, 80);
insert into public.customers (id, business_id, name, phone, email) values
  ('11000000-0000-0000-0000-000000000001', tests.id('biz_a'), 'Customer of A', '01911111111', 'customer.c@example.test'),
  ('22000000-0000-0000-0000-000000000002', tests.id('biz_b'), 'Customer of B', '01922222222', null);
insert into public.invoices (id, business_id, invoice_no, customer_id, customer_name, occurred_at, subtotal, discount, total, paid, due, payment_method)
values ('31000000-0000-0000-0000-000000000001', tests.id('biz_a'), 'INV-1', '11000000-0000-0000-0000-000000000001', 'Customer of A',
        '2026-11-04 20:30:00+00', 1000, 0, 1000, 400, 600, 'cash');
insert into public.invoice_items (business_id, invoice_id, line, product_id, name, qty, unit_price, cost_price, total)
values (tests.id('biz_a'), '31000000-0000-0000-0000-000000000001', 1, '10000000-0000-0000-0000-000000000001', 'Rice A', 10, 100, 50, 1000);
insert into public.customer_accounts (business_id, customer_id, user_id, verified_via)
values (tests.id('biz_a'), '11000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-00000000000d', 'email');

-- =====================================================================================================
-- 3. tenant isolation between businesses
-- =====================================================================================================
select tests.act_as('a0000000-0000-0000-0000-00000000000a');
select is((select count(*) from public.products)::int, 1, 'A sees exactly its own product');
select is((select count(*) from public.products where id = '20000000-0000-0000-0000-000000000002')::int, 0, 'A cannot see the product of B, even by its id');
select is((select count(*) from public.customers where business_id = tests.id('biz_b'))::int, 0, 'A cannot see the customers of B');
select is((select count(*) from public.profiles where id = 'b0000000-0000-0000-0000-00000000000b')::int, 0, 'A cannot read the profile of the owner of another business');
select throws_ok(format($q$ insert into public.products (business_id, name) values (%L, 'sneaky') $q$, tests.id('biz_b')), '42501', null, 'A cannot insert a product into business B');
with u as (update public.products set name = 'hacked' where id = '20000000-0000-0000-0000-000000000002' returning 1)
select is((select count(*) from u)::int, 0, 'A cannot update a product of B');
select throws_ok(format($q$ update public.products set business_id = %L where id = '10000000-0000-0000-0000-000000000001' $q$, tests.id('biz_b')), '42501', null, 'A cannot move its own product into business B');
select throws_ok($q$ select cost_price from public.products $q$, '42501', null, 'purchase cost cannot be read through the API');
select throws_ok($q$ update public.products set stock = 999 where id = '10000000-0000-0000-0000-000000000001' $q$, '42501', null, 'stock cannot be written by a client');
select throws_ok(format($q$ insert into public.products (business_id, name, stock) values (%L, 'with stock', 100) $q$, tests.id('biz_a')), '42501', null, 'stock cannot be set at insert either');
select lives_ok(format($q$ insert into public.products (business_id, name, cost_price, default_price) values (%L, 'New item', 10, 12) $q$, tests.id('biz_a')), 'the owner can create a product');
select ok((select count(*) from public.get_product_costs(tests.id('biz_a'))) >= 1, 'the owner reads purchase cost through the permission-checked function');
select throws_ok(format($q$ select * from public.get_product_costs(%L) $q$, tests.id('biz_b')), '42501', 'permission_denied', 'the owner of A cannot read purchase cost of B');

-- money tables are read-only for clients
select throws_ok(format($q$ insert into public.payments (business_id, customer_id, amount, occurred_at) values (%L, '11000000-0000-0000-0000-000000000001', 100, now()) $q$, tests.id('biz_a')), '42501', null, 'a client cannot insert a payment directly');
select throws_ok($q$ delete from public.invoices $q$, '42501', null, 'a client cannot delete invoices');
select throws_ok($q$ update public.invoices set status = 'void' $q$, '42501', null, 'a client cannot edit invoices');
select throws_ok(format($q$ insert into public.business_members (business_id, user_id, role) values (%L, 'f0000000-0000-0000-0000-00000000000f', 'admin') $q$, tests.id('biz_a')), '42501', null, 'nobody can add themselves (or others) to a business through the table API');

-- the cashier
select tests.act_as('c0000000-0000-0000-0000-00000000000c');
select throws_ok(format($q$ select * from public.get_product_costs(%L) $q$, tests.id('biz_a')), '42501', 'permission_denied', 'a cashier cannot read purchase cost');
select ok((select count(*) from public.products) >= 1, 'a cashier sees the products of the own business');
select is((select count(*) from public.products where business_id = tests.id('biz_b'))::int, 0, 'a cashier cannot see another business');
select ok((select count(*) from public.invoices) >= 1, 'a cashier sees the invoices of the own business');
select throws_ok(format($q$ insert into public.products (business_id, name) values (%L, 'cashier item') $q$, tests.id('biz_a')), '42501', null, 'a cashier cannot create products (no products.edit)');
select lives_ok(format($q$ insert into public.customers (business_id, name, phone) values (%L, 'Walk-in regular', '01933333333') $q$, tests.id('biz_a')), 'a cashier can create customers');
select throws_ok($q$ update public.customers set deleted_at = now() where id = '11000000-0000-0000-0000-000000000001' $q$, '42501', null, 'a cashier cannot delete a customer (no customers.delete)');
select is((select count(*) from public.audit_logs)::int, 0, 'a cashier cannot read the audit log (no audit permission)');
select is((select count(*) from public.business_invitations)::int, 0, 'a cashier cannot see staff invitations');

-- outsider and super admin
select tests.act_as('f0000000-0000-0000-0000-00000000000f');
select is((select count(*) from public.businesses)::int, 0, 'an outsider sees no business');
select is((select count(*) from public.products)::int, 0, 'an outsider sees no product');

select tests.act_as('e0000000-0000-0000-0000-00000000000e', 'aal2');
select is((select count(*) from public.products)::int, 0, 'the super admin has no access to business data (platform view only)');
select is((select count(*) from public.invoices)::int, 0, 'the super admin cannot read invoices either');
select ok((select count(*) from public.businesses) >= 2, 'the super admin sees every business');
select ok((select count(*) from public.access_logs) >= 1, 'the super admin can read the access log');

-- =====================================================================================================
-- 4. customer isolation: a customer login has no policy on any business table
-- =====================================================================================================
select tests.act_as('d0000000-0000-0000-0000-00000000000d');
select is((select count(*) from public.invoices)::int, 0, 'a customer cannot read invoices through the base table');
select is((select count(*) from public.invoice_items)::int, 0, 'a customer cannot read invoice lines (cost price stays private)');
select is((select count(*) from public.customers)::int, 0, 'a customer cannot read the customer table');
select is((select count(*) from public.products)::int, 0, 'a customer cannot read products');
select is((select count(*) from public.payments)::int, 0, 'a customer cannot read payments through the base table');
select is((select count(*) from public.customer_accounts)::int, 0, 'a customer cannot list the link table');
select throws_ok(format($q$ select * from public.get_product_costs(%L) $q$, tests.id('biz_a')), '42501', 'permission_denied', 'a customer cannot read purchase cost');
select throws_ok(format($q$ insert into public.customer_accounts (business_id, customer_id, user_id, verified_via) values (%L, '22000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-00000000000d', 'email') $q$, tests.id('biz_b')), '42501', null, 'a customer cannot link themselves to a customer record');

-- =====================================================================================================
-- 5. data integrity (as the database owner)
-- =====================================================================================================
reset role;
select lives_ok(format($q$ insert into public.invoices (business_id, invoice_no, occurred_at, subtotal, total, paid, due) values (%L, 'INV-1', now(), 50, 50, 50, 0) $q$, tests.id('biz_b')), 'the same invoice number may exist in another business');
select throws_ok(format($q$ insert into public.invoices (business_id, invoice_no, occurred_at, subtotal, total, paid, due) values (%L, 'INV-1', now(), 50, 50, 50, 0) $q$, tests.id('biz_a')), '23505', null, 'the same invoice number cannot repeat inside one business');
select throws_ok(format($q$ insert into public.invoices (business_id, invoice_no, occurred_at, subtotal, total, paid, due) values (%L, 'INV-2', now(), 50, 49, 49, 0) $q$, tests.id('biz_a')), '23514', null, 'an invoice whose total differs from subtotal − discount is refused');
select throws_ok(format($q$ insert into public.invoices (business_id, invoice_no, customer_id, occurred_at, subtotal, total, paid, due) values (%L, 'INV-3', '22000000-0000-0000-0000-000000000002', now(), 50, 50, 0, 50) $q$, tests.id('biz_a')), '23503', null, 'an invoice of business A cannot point at a customer of business B');
select throws_ok(format($q$ insert into public.invoices (business_id, invoice_no, occurred_at, subtotal, total, paid, due) values (%L, 'INV-4', now(), 50, 50, 0, 50) $q$, tests.id('biz_a')), '23514', null, 'a sale on credit needs a customer');
select is((select biz_date from public.invoices where id = '31000000-0000-0000-0000-000000000001')::text, '2026-11-05', 'the Asia/Dhaka calendar day is derived from the instant');
select is((select biz_month from public.invoices where id = '31000000-0000-0000-0000-000000000001'), '2026-11', 'the Asia/Dhaka month is derived too');
select throws_ok($q$ update public.invoices set total = 1 where id = '31000000-0000-0000-0000-000000000001' $q$, '42501', null, 'the money fields of an invoice are immutable');
select lives_ok($q$ update public.invoices set status = 'void', void_reason = 'test' where id = '31000000-0000-0000-0000-000000000001' $q$, 'an invoice can be voided');
select throws_ok($q$ update public.invoices set status = 'active' where id = '31000000-0000-0000-0000-000000000001' $q$, '42501', null, 'a voided invoice cannot be reactivated');
select throws_ok($q$ update public.invoice_items set qty = 1 $q$, '42501', null, 'invoice lines are immutable');

insert into public.stock_movements (business_id, product_id, product_name, type, qty, previous_stock, balance, occurred_at)
values (tests.id('biz_a'), '10000000-0000-0000-0000-000000000001', 'Rice A', 'initial', 100, 0, 100, now());
select throws_ok($q$ update public.stock_movements set qty = 1 $q$, '42501', null, 'the stock ledger is append-only (update)');
select throws_ok($q$ delete from public.stock_movements $q$, '42501', null, 'the stock ledger is append-only (delete)');
select throws_ok(format($q$ insert into public.stock_movements (business_id, product_id, product_name, type, qty, previous_stock, balance, occurred_at) values (%L, '10000000-0000-0000-0000-000000000001', 'Rice A', 'sale', 5, 100, 105, now()) $q$, tests.id('biz_a')), '23514', null, 'a sale must reduce stock');
select throws_ok(format($q$ insert into public.stock_movements (business_id, product_id, product_name, type, qty, previous_stock, balance, occurred_at) values (%L, '10000000-0000-0000-0000-000000000001', 'Rice A', 'receive', 5, 100, 999, now()) $q$, tests.id('biz_a')), '23514', null, 'the stock chain (previous + change = balance) is enforced');
select throws_ok(format($q$ insert into public.stock_movements (business_id, product_id, product_name, type, qty, previous_stock, balance, occurred_at) values (%L, '20000000-0000-0000-0000-000000000002', 'Rice B', 'receive', 5, 80, 85, now()) $q$, tests.id('biz_a')), '23503', null, 'a stock movement of business A cannot reference a product of business B');
select throws_ok($q$ update public.audit_logs set action = 'x' $q$, '42501', null, 'the audit log is append-only');
select ok((select count(*) from public.audit_logs where action = 'business.register') >= 2, 'registration is written to the audit log');
select ok((select count(*) from public.audit_logs where action = 'business.approve') >= 2, 'approval is written to the audit log');
select ok((select count(*) from public.business_approvals where business_id = tests.id('biz_b')) >= 4, 'the approval history keeps every step (submitted, rejected, resubmitted, approved)');

-- plan limit on employees (the free plan: 3). S is #1.
select lives_ok(format($q$ insert into public.business_members (business_id, user_id, role) values (%L, '91000000-0000-0000-0000-000000000001', 'cashier') $q$, tests.id('biz_a')), 'the second employee fits the free plan');
select lives_ok(format($q$ insert into public.business_members (business_id, user_id, role) values (%L, '91000000-0000-0000-0000-000000000002', 'manager') $q$, tests.id('biz_a')), 'the third employee fits the free plan');
select throws_ok(format($q$ insert into public.business_members (business_id, user_id, role) values (%L, '91000000-0000-0000-0000-000000000003', 'cashier') $q$, tests.id('biz_a')), 'P0001', 'plan_limit:employees', 'the free plan allows at most three employees');
-- (status 'disabled' so that the employee-limit trigger, which runs first, does not hide the CHECK being tested)
select throws_ok(format($q$ insert into public.business_members (business_id, user_id, role, permissions, status) values (%L, '91000000-0000-0000-0000-000000000003', 'admin', array['pos'], 'disabled') $q$, tests.id('biz_a')), '23514', null, 'an administrator cannot carry a restricted permission list');
select throws_ok(format($q$ insert into public.business_members (business_id, user_id, role, permissions, status) values (%L, '91000000-0000-0000-0000-000000000003', 'cashier', array['not.a.permission'], 'disabled') $q$, tests.id('biz_a')), '23514', null, 'an unknown permission key is refused');

-- =====================================================================================================
-- 6. suspension and subscription expiry
-- =====================================================================================================
select tests.act_as('e0000000-0000-0000-0000-00000000000e', 'aal2');
select throws_ok(format($q$ select public.set_business_suspension(%L, true, 'x') $q$, tests.id('biz_a')), '22023', 'reason_required', 'a suspension needs a reason');
select lives_ok(format($q$ select public.set_business_suspension(%L, true, 'unpaid dues dispute') $q$, tests.id('biz_a')), 'a super admin suspends a business');

select tests.act_as('a0000000-0000-0000-0000-00000000000a');
select is((select count(*) from public.products)::int, 0, 'a suspended business has no cloud data (owner)');
select is((select count(*) from public.invoices)::int, 0, 'a suspended business has no invoices in the cloud (owner)');
select throws_ok(format($q$ insert into public.products (business_id, name) values (%L, 'after suspension') $q$, tests.id('biz_a')), '42501', null, 'a suspended business cannot write');
select is((select status from public.businesses where id = tests.id('biz_a')), 'suspended', 'the owner can still read the business row (to show the reason)');
select is((public.my_access_state() -> 'businesses' -> 0 ->> 'status'), 'suspended', 'my_access_state explains the suspension');
select is((public.my_access_state() -> 'businesses' -> 0 ->> 'can_read'), 'false', 'my_access_state: reading is closed');

select tests.act_as('c0000000-0000-0000-0000-00000000000c');
select is((select count(*) from public.products)::int, 0, 'employees of a suspended business have no cloud data either');

reset role;
select ok(exists (select 1 from public.access_logs where kind = 'blocked_business' and user_id = 'a0000000-0000-0000-0000-00000000000a'), 'the blocked access was written to the access log');

select tests.act_as('e0000000-0000-0000-0000-00000000000e', 'aal2');
select lives_ok(format($q$ select public.set_business_suspension(%L, false) $q$, tests.id('biz_a')), 'a super admin reinstates the business');
select tests.act_as('a0000000-0000-0000-0000-00000000000a');
select ok((select count(*) from public.products) >= 1, 'after reinstatement the data is available again');

-- an expired subscription: data stays, but read-only
reset role;
update public.subscriptions set current_period_end = now() - interval '1 day' where owner_id = 'a0000000-0000-0000-0000-00000000000a';
select tests.act_as('a0000000-0000-0000-0000-00000000000a');
select ok((select count(*) from public.products) >= 1, 'an expired subscription keeps read access');
select throws_ok(format($q$ insert into public.products (business_id, name) values (%L, 'after expiry') $q$, tests.id('biz_a')), '42501', null, 'an expired subscription is read-only');
select is((public.my_access_state() -> 'businesses' -> 0 ->> 'can_write'), 'false', 'my_access_state: writing is closed after expiry');
reset role;
update public.subscriptions set current_period_end = null where owner_id = 'a0000000-0000-0000-0000-00000000000a';
select tests.act_as('a0000000-0000-0000-0000-00000000000a');
select lives_ok(format($q$ insert into public.products (business_id, name) values (%L, 'after renewal') $q$, tests.id('biz_a')), 'renewal restores write access');

-- =====================================================================================================
-- 7. devices, sessions and security events
-- =====================================================================================================
select tests.act_as('a0000000-0000-0000-0000-00000000000a', 'aal1', '11111111-1111-1111-1111-111111111111');
select lives_ok($q$ select public.record_login('device-aaaa-0001', 'Phone', 'android', 'ua-1') $q$, 'a login is recorded');
select is((select count(*) from public.user_devices)::int, 1, 'the device is listed');
select ok((select count(*) from public.products) >= 1, 'the session works before it is revoked');
select lives_ok($q$ select public.revoke_device((select id from public.user_devices where device_id = 'device-aaaa-0001')) $q$, 'a device can be signed out remotely');
select is((select count(*) from public.products)::int, 0, 'a revoked session stops working immediately');

select tests.act_as('a0000000-0000-0000-0000-00000000000a', 'aal1', '22222222-2222-2222-2222-222222222222');
select lives_ok($q$ select public.record_login('device-aaaa-0001', 'Phone', 'android', 'ua-1') $q$, 'the same device can sign in again');
select ok((select count(*) from public.products) >= 1, 'a NEW session on that device works');
select tests.act_as('a0000000-0000-0000-0000-00000000000a', 'aal1', '11111111-1111-1111-1111-111111111111');
select is((select count(*) from public.products)::int, 0, 'the OLD session stays revoked');

select tests.act_as('a0000000-0000-0000-0000-00000000000a', 'aal1', '22222222-2222-2222-2222-222222222222');
select lives_ok($q$ select public.record_login('device-aaaa-0002', 'Tablet', 'web', 'ua-2') $q$, 'a second device logs in');
select is((select count(*) from public.user_security_events where event_type = 'new_device_login')::int, 1, 'a login from a new device is flagged');
select throws_ok($q$ select public.log_security_event('login') $q$, '22023', 'invalid_event', 'a client cannot forge arbitrary security events');
select lives_ok($q$ select public.log_security_event('password_changed') $q$, 'a client can report a password change');
select is((select count(*) from public.user_security_events where user_id <> 'a0000000-0000-0000-0000-00000000000a')::int, 0, 'a user sees only their own security events');

-- =====================================================================================================
-- 8. platform tables
-- =====================================================================================================
select ok((select count(*) from public.plans) >= 2, 'every signed-in user can read the plans');
with u as (update public.platform_settings set value = 'false'::jsonb where key = 'registration.open' returning 1)
select is((select count(*) from u)::int, 0, 'a normal user cannot change platform settings');
select throws_ok($q$ update public.profiles set is_active = false where id = 'a0000000-0000-0000-0000-00000000000a' $q$, '42501', null, 'a user cannot change protected profile columns');
select lives_ok($q$ update public.profiles set full_name = 'Mr A Updated' where id = 'a0000000-0000-0000-0000-00000000000a' $q$, 'a user can update their own name');
select throws_ok($q$ select * from public.platform_admins $q$, '42501', null, 'platform_admins is unreachable for a normal user');
select throws_ok($q$ insert into public.subscriptions (owner_id, plan_code) values ('a0000000-0000-0000-0000-00000000000a', 'premium') $q$, '42501', null, 'a user cannot give themselves a paid plan');

reset role;
select * from finish();
rollback;

/**
 * env.js — gives every test a pristine app: empty IndexedDB, empty
 * localStorage, default settings, signed-out auth state.
 */
import { openDB, _resetForTests, DB_NAME } from '../../js/core/db.js';
import { settings } from '../../js/services/settings.js';
import { auth, _setHashIterationsForTests } from '../../js/services/auth.js';
import { TRANSPORTS } from '../../js/printing/printer.js';
import { clearCache } from '../../js/core/cache.js';
import { _resetSyncForTests } from '../../js/services/sync.js';
import { _resetSnapshotsForTests } from '../../js/services/autobackup.js';

// Tests sign in many times: use a cheap PBKDF2 work factor (the app itself always uses the real one).
_setHashIterationsForTests(1000);

export const TEST_ADMIN = { username: 'admin', displayName: 'Test Admin', password: 'password1', pin: '1234' };

/**
 * @param {{bare?:boolean}} [opts]  bare: leave the app with no users and nobody signed in
 */
export async function resetEnvironment(opts = {}) {
  try {
    (await openDB()).close();
  } catch {
    /* first run */
  }
  _resetForTests();
  await new Promise((res, rej) => {
    const req = indexedDB.deleteDatabase(DB_NAME);
    req.onsuccess = res;
    req.onerror = () => rej(req.error);
    // "blocked" only means the previous test's last (fire-and-forget) activity-log write is still finishing;
    // the delete proceeds as soon as it does. Give up only if it never happens.
    req.onblocked = () => setTimeout(() => rej(new Error('deleteDatabase blocked for 5 s')), 5000);
  });
  localStorage.clear();
  clearCache();
  _resetSyncForTests();
  await _resetSnapshotsForTests();
  auth.logout();
  while (TRANSPORTS.some((t) => t.id === 'fake')) TRANSPORTS.splice(TRANSPORTS.findIndex((t) => t.id === 'fake'), 1);
  await settings.load();
  if (!opts.bare) await auth.setupAdmin(TEST_ADMIN); // signed in as an administrator
}

/**
 * harness.js — a ~40-line test runner that works inside a real browser, so the
 * integration tests exercise the REAL IndexedDB / WebCrypto / canvas the app
 * uses (no mocks of the storage layer). Driven by tests/run-browser.mjs.
 */
export const tests = [];
/**
 * Register a test. `opts.bare: true` starts with NO users and nobody signed in (for the setup /
 * sign-in / permission tests); every other test starts signed in as an administrator because the
 * services now enforce permissions themselves.
 */
export const test = (name, fn, opts = {}) => tests.push({ name, fn, opts });

export function assert(cond, msg = 'assertion failed') {
  if (!cond) throw new Error(msg);
}
export function eq(actual, expected, msg = '') {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a !== e) throw new Error(`${msg} expected ${e} but got ${a}`);
}
/** Assert that `fn` (sync or async) rejects/throws with a message matching `re`. */
export async function rejects(fn, re, msg = '') {
  try {
    await fn();
  } catch (err) {
    if (re && !re.test(err.message)) throw new Error(`${msg} wrong error: "${err.message}" (wanted ${re})`);
    return err;
  }
  throw new Error(`${msg} expected an error matching ${re} but nothing was thrown`);
}

/** Run every registered test sequentially; `beforeEach` gives each a clean slate. */
export async function runAll(beforeEach) {
  const results = [];
  for (const t of tests) {
    const started = performance.now();
    try {
      await beforeEach(t.opts);
      await t.fn();
      results.push({ name: t.name, ok: true, ms: Math.round(performance.now() - started) });
    } catch (err) {
      results.push({ name: t.name, ok: false, error: String(err.stack || err.message || err) });
    }
  }
  return results;
}

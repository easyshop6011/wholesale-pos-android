/** Shared helpers for the browser test suites. */
export { saveProduct, saveCategory } from '../../js/services/catalog.js';
export { saveCustomer as saveCustomerLike } from '../../js/services/customers.js';

import { auth } from '../../js/services/auth.js';
import { TEST_ADMIN } from './env.js';

/** Run `fn` while `username` is signed in, then sign the test administrator back in. */
export async function asUser(username, password, fn) {
  auth.logout();
  await auth.login(username, password);
  try {
    return await fn();
  } finally {
    auth.logout();
    await auth.login(TEST_ADMIN.username, TEST_ADMIN.password);
  }
}

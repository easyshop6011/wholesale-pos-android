/**
 * legacy-db.js — builds a REAL version-2 IndexedDB (the schema of the previous release,
 * copied verbatim) filled with rows shaped exactly as that release wrote them, so the
 * migration test can open it with the current code and prove nothing is lost.
 */
import { DB_NAME } from '../../js/core/db.js';

const V2_SCHEMA = {
  users: { keyPath: 'id', indexes: [{ name: 'usernameLower', keyPath: 'usernameLower', unique: true }] },
  settings: { keyPath: 'key', indexes: [] },
  meta: { keyPath: 'key', indexes: [] }, // counters such as invoice sequence numbers
  categories: { keyPath: 'id', indexes: [{ name: 'nameLower', keyPath: 'nameLower', unique: true }] },
  products: {
    keyPath: 'id',
    indexes: [
      { name: 'nameLower', keyPath: 'nameLower' },
      { name: 'categoryId', keyPath: 'categoryId' },
      { name: 'sku', keyPath: 'sku' },
    ],
  },
  customers: {
    keyPath: 'id',
    indexes: [
      { name: 'phone', keyPath: 'phone' },
      { name: 'nameLower', keyPath: 'nameLower' },
    ],
  },
  invoices: {
    keyPath: 'id', // globally unique UUID — the dedupe key for Google Sheets
    indexes: [
      { name: 'invoiceNo', keyPath: 'invoiceNo', unique: true },
      { name: 'date', keyPath: 'date' },
      { name: 'month', keyPath: 'month' },
      { name: 'customerId', keyPath: 'customerId' },
      { name: 'syncStatus', keyPath: 'syncStatus' },
    ],
  },
  invoiceItems: {
    keyPath: 'id',
    indexes: [
      { name: 'invoiceId', keyPath: 'invoiceId' },
      { name: 'productId', keyPath: 'productId' },
    ],
  },
  payments: {
    keyPath: 'id',
    indexes: [
      { name: 'customerId', keyPath: 'customerId' },
      { name: 'date', keyPath: 'date' },
      { name: 'syncStatus', keyPath: 'syncStatus' },
    ],
  },
  // v2 -----------------------------------------------------------------
  auditLog: {
    keyPath: 'id', // who did what (sign-ins, voids, stock changes, user admin …)
    indexes: [
      { name: 'createdAt', keyPath: 'createdAt' },
      { name: 'userId', keyPath: 'userId' },
      { name: 'action', keyPath: 'action' },
    ],
  },
  syncLog: {
    keyPath: 'id', // one row per sync / reconcile run (newest 200 are kept)
    indexes: [{ name: 'createdAt', keyPath: 'createdAt' }],
  },
  stockMovements: {
    keyPath: 'id',
    indexes: [
      { name: 'productId', keyPath: 'productId' },
      { name: 'createdAt', keyPath: 'createdAt' },
    ],
  },
};


/** Delete the database and recreate it as version 2 holding `rows` ({store: [rows]}). */
export async function createV2Database(rows) {
  await new Promise((res, rej) => {
    const r = indexedDB.deleteDatabase(DB_NAME);
    r.onsuccess = res;
    r.onerror = () => rej(r.error);
    r.onblocked = () => setTimeout(() => rej(new Error('deleteDatabase blocked for 5 s')), 5000);
  });
  const db = await new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 2);
    req.onupgradeneeded = () => {
      for (const [name, def] of Object.entries(V2_SCHEMA)) {
        const store = req.result.createObjectStore(name, { keyPath: def.keyPath });
        for (const ix of def.indexes) store.createIndex(ix.name, ix.keyPath, { unique: !!ix.unique });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  await new Promise((resolve, reject) => {
    const tx = db.transaction(Object.keys(rows), 'readwrite');
    for (const [name, list] of Object.entries(rows)) for (const r of list) tx.objectStore(name).put(r);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

export const V2_STORE_NAMES = Object.keys(V2_SCHEMA);

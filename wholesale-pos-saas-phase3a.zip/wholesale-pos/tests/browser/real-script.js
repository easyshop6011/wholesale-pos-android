/**
 * real-script.js — the REAL Code.gs, running in the browser test page against the shared
 * in-memory Google fake, exposed as a `fetch` the client sync code can call. So the sync
 * tests exercise the real client (js/services/sync.js) AND the real server rules together.
 */
import { loadScript } from '../shared/fake-google.js';

let codePromise = null;
const code = () => (codePromise ||= fetch('/integrations/google-apps-script/Code.gs').then((r) => r.text()));

/**
 * @param {{token?:string}} [o]
 * @returns {Promise<{fetch:Function, call:Function, sheet:Function, calls:string[], hooks:{beforeRespond?:Function}, fail:{times:number, status?:number, message?:string}}>}
 */
export async function realScript({ token = 'secret' } = {}) {
  const s = loadScript(await code(), { token });
  const state = { calls: [], hooks: {}, fail: { times: 0, status: 200, message: '' }, ...s };
  state.fetch = async (_url, init) => {
    const body = JSON.parse(init.body);
    state.calls.push(body.action);
    if (state.fail.times > 0 && body.action !== 'ping') {
      state.fail.times -= 1;
      if (state.fail.message) return { ok: true, status: 200, text: async () => JSON.stringify({ ok: false, error: state.fail.message }) };
      throw new TypeError('Failed to fetch');
    }
    const text = s.api.doPost({ postData: { contents: init.body } }).getContent();
    // a hook can act "while the request is in flight" (e.g. the cashier voids the invoice that is being uploaded)
    if (state.hooks.beforeRespond) await state.hooks.beforeRespond(body);
    return { ok: true, status: 200, text: async () => text };
  };
  return state;
}

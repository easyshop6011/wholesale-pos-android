/**
 * suite-core.js — v3 features: search & filters, roles / permissions / user
 * switching / audit log, automatic backup.
 */
import { test, assert, eq, rejects } from './harness.js';
import { settings } from '../../js/services/settings.js';
import { saveProduct, saveCategory, asUser } from './helpers.js';
import { saveCustomer, receivePayment, listCustomers } from '../../js/services/customers.js';
import { listProducts } from '../../js/services/catalog.js';
import { createInvoice, voidInvoice, queryInvoices, paymentState } from '../../js/services/sales.js';
import { adjustStock } from '../../js/services/inventory.js';
import { globalSearch } from '../../js/services/globalsearch.js';
import { auth, ROLES, PERMISSION_LIST } from '../../js/services/auth.js';
import { listAudit, trimAudit, logAction } from '../../js/services/audit.js';
import { takeSnapshot, listSnapshots, getSnapshot, restoreSnapshot, deleteSnapshot, runAutoBackup, getBackupStatus } from '../../js/services/autobackup.js';
import { exportDatabase, importDatabase } from '../../js/services/backup.js';
import { dbAll } from '../../js/core/db.js';
import { dateParts, addDays } from '../../js/core/utils.js';

const user = { id: 'u1', displayName: 'Tester' };
const today = () => dateParts().date;

// ============================================================================
// Search & filters
// ============================================================================

test('product search: several words, accents, SKU, category, relevance order', async () => {
  const grains = await saveCategory({ name: 'Grains' });
  const oils = await saveCategory({ name: 'Oils' });
  await saveProduct({ name: 'Basmati Rice 25kg', sku: 'RC-025', categoryId: grains.id, unit: 'bag', defaultPrice: 2450, stock: 5, lowStockLevel: 10 });
  await saveProduct({ name: 'Miniket Rice 50kg', sku: 'RC-050', categoryId: grains.id, unit: 'bag', defaultPrice: 3100, stock: 0, lowStockLevel: 10 });
  await saveProduct({ name: 'Soybean Oil 5L', sku: 'OL-005', categoryId: oils.id, unit: 'btl', defaultPrice: 880, stock: 120, lowStockLevel: 20 });
  await saveProduct({ name: 'Café Mocha Mix', unit: 'pack', defaultPrice: 300, stock: 30, lowStockLevel: 5 });
  eq((await listProducts({ search: 'rice 25' })).map((p) => p.name), ['Basmati Rice 25kg'], 'all words must match, any order');
  eq((await listProducts({ search: '25 rice' })).map((p) => p.name), ['Basmati Rice 25kg']);
  eq((await listProducts({ search: 'cafe' })).map((p) => p.name), ['Café Mocha Mix'], 'accents ignored');
  eq((await listProducts({ search: 'ol-005' })).map((p) => p.name), ['Soybean Oil 5L'], 'by SKU');
  eq((await listProducts({ search: 'grains' })).length, 2, 'by category name');
  eq((await listProducts({ search: 'oil' }))[0].name, 'Soybean Oil 5L');
  // relevance: a name that STARTS with the query beats one that merely contains it
  await saveProduct({ name: 'Mustard Oil 1L', unit: 'btl', stock: 1 });
  await saveProduct({ name: 'Oil Filter', unit: 'pc', stock: 1 });
  eq((await listProducts({ search: 'oil' }))[0].name, 'Oil Filter');
});

test('product filters: stock state, price range, category, sorting', async () => {
  const g = await saveCategory({ name: 'Grains' });
  await saveProduct({ name: 'A Rice', categoryId: g.id, defaultPrice: 100, stock: 0, lowStockLevel: 5 });
  await saveProduct({ name: 'B Lentil', categoryId: g.id, defaultPrice: 200, stock: 3, lowStockLevel: 5 });
  await saveProduct({ name: 'C Oil', defaultPrice: 300, stock: 50, lowStockLevel: 5 });
  const names = async (o) => (await listProducts(o)).map((p) => p.name);
  eq(await names({ stock: 'out' }), ['A Rice']);
  eq(await names({ stock: 'low' }), ['B Lentil']);
  eq(await names({ stock: 'ok' }), ['C Oil']);
  eq(await names({ stock: 'attention' }), ['A Rice', 'B Lentil']);
  eq(await names({ lowOnly: true }), ['A Rice', 'B Lentil'], 'old lowOnly flag still works');
  eq(await names({ minPrice: 150, maxPrice: 250 }), ['B Lentil']);
  eq(await names({ sort: 'price-desc' }), ['C Oil', 'B Lentil', 'A Rice']);
  eq(await names({ sort: 'stock-asc' }), ['A Rice', 'B Lentil', 'C Oil']);
  eq(await names({ categoryId: g.id }), ['A Rice', 'B Lentil']);
});

test('customer search: phone in any format, Bengali digits, due / inactivity filters, sorting', async () => {
  const p = await saveProduct({ name: 'Rice', unit: 'bag', stock: 1000, defaultPrice: 100 });
  const a = await saveCustomer({ name: 'Rahim Traders', phone: '01711000001', address: 'Karwan Bazar' });
  const b = await saveCustomer({ name: 'Karim Store', phone: '01811000002' });
  const c = await saveCustomer({ name: 'নুর স্টোর', phone: '০১৯১১০০০০০৩' });
  eq(c.phone, '01911000003', 'Bengali digits are stored as ASCII');
  await createInvoice({ customerId: a.id, items: [{ productId: p.id, qty: 5, unitPrice: 100 }], paid: 100 }, user); // due 400
  await createInvoice({ customerId: b.id, items: [{ productId: p.id, qty: 1, unitPrice: 100 }], paid: 100 }, user);
  const names = async (o) => (await listCustomers(o)).map((x) => x.name);
  eq(await names({ search: '01711-000' }), ['Rahim Traders'], 'dashes in the query');
  eq(await names({ search: '০১৮১১' }), ['Karim Store'], 'Bengali digits in the query');
  eq(await names({ search: 'karwan' }), ['Rahim Traders'], 'address');
  eq(await names({ search: 'নুর' }), ['নুর স্টোর'], 'Bengali names');
  eq(await names({ due: 'has' }), ['Rahim Traders']);
  eq(await names({ due: 'none' }), ['Karim Store', 'নুর স্টোর'].sort((x, y) => x.localeCompare(y)));
  eq(await names({ minDue: 500 }), []);
  eq(await names({ notBoughtSince: today() }), ['নুর স্টোর'], 'never bought');
  eq((await names({ sort: 'due-desc' }))[0], 'Rahim Traders');
  eq((await names({ sort: 'purchases-desc' }))[0], 'Rahim Traders');
});

test('customer balances stay correct after changes (cache is invalidated)', async () => {
  const p = await saveProduct({ name: 'Rice', unit: 'bag', stock: 100, defaultPrice: 100 });
  const c = await saveCustomer({ name: 'Rahim' });
  eq((await listCustomers())[0].due, 0);
  const inv = await createInvoice({ customerId: c.id, items: [{ productId: p.id, qty: 2, unitPrice: 100 }], paid: 0 }, user);
  eq((await listCustomers())[0].due, 200, 'after sale');
  await receivePayment({ customerId: c.id, amount: 50 }, user);
  eq((await listCustomers())[0].due, 150, 'after payment');
  await voidInvoice(inv.id, 'wrong order', user);
  eq((await listCustomers())[0].due, -50 + 0 === -50 ? -50 : 0, 'after void the payment is an advance');
});

test('invoice query: filters, sorting, paging and totals over all matches', async () => {
  const p = await saveProduct({ name: 'Rice', unit: 'bag', stock: 1000, defaultPrice: 100 });
  const a = await saveCustomer({ name: 'Rahim', phone: '01711000001' });
  const b = await saveCustomer({ name: 'Karim', phone: '01811000002' });
  await auth.createUser({ username: 'sam', displayName: 'Sam', role: 'employee', password: 'sampass', pin: '3333' });
  const sam = (await auth.listUsers()).find((u) => u.username === 'sam');
  const sell = (cust, qty, paid) => createInvoice({ customerId: cust?.id || null, items: [{ productId: p.id, qty, unitPrice: 100 }], paid }, user);
  const i1 = await sell(a, 1, 100); // 100 paid
  const i2 = await sell(a, 5, 200); // 500 partial, due 300
  const i3 = await asUser('sam', 'sampass', () => sell(b, 10, 0)); // 1000 unpaid, sold by Sam (a real sign-in: the service records the signed-in user)
  const i4 = await sell(null, 2, 200);
  await voidInvoice(i4.id, 'oops', user);
  const q = (o) => queryInvoices({ limit: 50, ...o });
  const nos = async (o) => (await q(o)).rows.map((r) => r.invoiceNo.slice(-4));
  eq((await q({})).total, 4);
  eq((await q({})).sumTotal, 1600, 'voided invoices are not in the sum');
  eq((await q({ payment: 'paid' })).rows.length, 2, 'paid (incl. the voided one)');
  eq(await nos({ payment: 'due', sort: 'oldest' }), ['0002', '0003']);
  eq(await nos({ payment: 'unpaid' }), ['0003']);
  eq(await nos({ payment: 'partial' }), ['0002']);
  eq((await q({ payment: 'due' })).sumDue, 1300);
  eq(await nos({ userId: sam.id }), ['0003']);
  eq(await nos({ status: 'void' }), ['0004']);
  eq(await nos({ min: 400, max: 600 }), ['0002']);
  eq(await nos({ customerId: b.id }), ['0003']);
  eq(await nos({ search: 'karim' }), ['0003']);
  eq(await nos({ search: '01711' }).then((x) => x.sort()), ['0001', '0002']);
  eq((await nos({ sort: 'total-desc' }))[0], '0003');
  eq((await q({ limit: 2, offset: 0 })).rows.length, 2);
  const page2 = await q({ limit: 2, offset: 2, sort: 'oldest' });
  eq([page2.rows.length, page2.total], [2, 4]);
  eq(await nos({ from: addDays(today(), 1) }), [], 'date filter');
  eq(await nos({ sync: 'pending' }).then((x) => x.length), 3, 'voided invoices do not count as pending');
  eq([paymentState(i1), paymentState(i2), paymentState(i3)], ['paid', 'partial', 'unpaid']);
});

test('global search finds products, customers and invoices, and respects permissions', async () => {
  const p = await saveProduct({ name: 'Basmati Rice', unit: 'bag', stock: 10, defaultPrice: 100 });
  const c = await saveCustomer({ name: 'Rahim Traders', phone: '01711000001' });
  const inv = await createInvoice({ customerId: c.id, items: [{ productId: p.id, qty: 1, unitPrice: 100 }], paid: 100 }, user);
  const r = await globalSearch('rahim');
  eq([r.products.length, r.customers.length, r.invoices.length], [0, 1, 1]);
  eq((await globalSearch('basmati')).products[0].name, 'Basmati Rice');
  eq((await globalSearch(inv.invoiceNo.slice(-9))).invoices.length, 1, 'by invoice number');
  const limited = await globalSearch('rahim', { can: (k) => k === 'customers' });
  eq([limited.customers.length, limited.invoices.length], [1, 0]);
  eq(await globalSearch('  '), { products: [], customers: [], invoices: [] });
});

// ============================================================================
// Users, roles, permissions, audit log
// ============================================================================

async function team() {
  await auth.setupAdmin({ username: 'owner', displayName: 'Owner', password: 'secret1', pin: '1111' });
  await auth.createUser({ username: 'mona', displayName: 'Mona', role: 'manager', password: 'monapass', pin: '2222' });
  await auth.createUser({ username: 'sam', displayName: 'Sam', role: 'employee', password: 'sampass', pin: '3333' });
}

test('roles: manager can void/adjust/see reports but not settings; cashier cannot', async () => {
  await team();
  assert(ROLES.manager && ROLES.employee && ROLES.admin);
  auth.logout();
  await auth.login('mona', 'monapass');
  assert(auth.can('reports') && auth.can('invoices.void') && auth.can('inventory.adjust') && auth.can('products.edit') && auth.can('reports.profit') && auth.can('audit'), 'manager powers');
  assert(!auth.can('settings'), 'manager has no settings');
  auth.logout();
  await auth.login('sam', 'sampass');
  assert(auth.can('pos') && !auth.can('reports') && !auth.can('invoices.void'));
}, { bare: true });

test('custom permissions override the role; admin cannot be restricted; unknown keys are dropped', async () => {
  await team();
  const sam = (await auth.listUsers()).find((u) => u.username === 'sam');
  await auth.updateUser(sam.id, { permissions: ['dashboard', 'pos', 'invoices', 'reports', 'not-a-permission'] });
  const after = (await auth.listUsers()).find((u) => u.username === 'sam');
  eq(after.permissions, ['dashboard', 'pos', 'invoices', 'reports']);
  auth.logout();
  await auth.login('sam', 'sampass');
  assert(auth.can('reports') && !auth.can('customers'), 'custom list replaces the role defaults');
  auth.logout();
  await auth.login('owner', 'secret1');
  await auth.updateUser(sam.id, { permissions: null });
  const reset = (await auth.listUsers()).find((u) => u.username === 'sam');
  eq(reset.permissions, null, 'back to role defaults');
  const owner = (await auth.listUsers()).find((u) => u.username === 'owner');
  await auth.updateUser(owner.id, { permissions: ['pos'] });
  assert(auth.can('settings'), 'admins always keep every permission');
  assert(PERMISSION_LIST.every((p) => p.key && p.label && p.group));
}, { bare: true });

test('fast user switching with the other person\'s PIN', async () => {
  await team();
  const choices = await auth.loginChoices();
  eq(choices.map((c) => c.displayName), ['Mona', 'Owner', 'Sam']);
  assert(choices.every((c) => !('pinHash' in c) && !('passHash' in c)), 'no secrets are exposed');
  const mona = choices.find((c) => c.displayName === 'Mona');
  await rejects(() => auth.switchUser(mona.id, '9999'), /Incorrect PIN/);
  const u = await auth.switchUser(mona.id, '2222');
  eq([u.displayName, auth.user().role, auth.isLocked()], ['Mona', 'manager', false]);
  assert(!auth.can('settings'), 'permissions follow the new user');
  const log = await listAudit({ action: 'auth' });
  assert(log.some((l) => l.action === 'auth.switch' && l.userName === 'Mona'), 'switch is logged');
  assert(log.some((l) => l.action === 'auth.switch_failed'), 'failed switch is logged');
}, { bare: true });

test('disabled users cannot sign in or be switched to; last admin is protected', async () => {
  await team();
  const sam = (await auth.listUsers()).find((u) => u.username === 'sam');
  await auth.updateUser(sam.id, { active: false });
  eq((await auth.loginChoices()).some((c) => c.displayName === 'Sam'), false);
  await rejects(() => auth.switchUser(sam.id, '3333'), /Incorrect PIN/);
  auth.logout();
  await rejects(() => auth.login('sam', 'sampass'), /Invalid username or password/);
  await auth.login('owner', 'secret1');
  const owner = (await auth.listUsers()).find((u) => u.username === 'owner');
  await rejects(() => auth.updateUser(owner.id, { role: 'manager' }), /administrator/);
}, { bare: true });

test('audit log: who did what — void, stock change, product edit, user admin, logins', async () => {
  await team();
  auth.logout();
  await auth.login('owner', 'secret1');
  const p = await saveProduct({ name: 'Rice', unit: 'bag', stock: 10, defaultPrice: 100 });
  const inv = await createInvoice({ items: [{ productId: p.id, qty: 1, unitPrice: 100 }], paid: 100 }, user);
  await voidInvoice(inv.id, 'wrong item', user);
  await adjustStock({ productId: p.id, mode: 'remove', qty: 2, reason: 'damaged' }, user);
  const log = await listAudit({});
  const actions = log.map((l) => l.action);
  for (const a of ['user.create', 'auth.login', 'product.create', 'invoice.void', 'stock.adjust']) assert(actions.includes(a), `missing ${a}: ${actions}`);
  const v = log.find((l) => l.action === 'invoice.void');
  eq(v.userName, 'Owner');
  assert(v.target.startsWith('INV-') && /wrong item/.test(v.detail));
  assert(!JSON.stringify(log).includes('secret1') && !JSON.stringify(log).includes('monapass'), 'no secrets in the log');
  eq((await listAudit({ action: 'invoice' })).map((l) => l.action), ['invoice.void'], 'prefix filter');
  eq((await listAudit({ search: 'damaged' })).length, 1);
  eq((await listAudit({ from: addDays(today(), 1) })).length, 0, 'date filter');
  const mine = (await auth.listUsers()).find((u) => u.username === 'owner');
  assert((await listAudit({ userId: mine.id })).length > 0);
}, { bare: true });

test('audit log keeps only the newest entries and never throws', async () => {
  for (let i = 0; i < 12; i++) await logAction('test.entry', { target: `n${i}` });
  const total = (await listAudit({ limit: 1000 })).length; // may include a stray entry from the previous test's sign-out
  eq(await trimAudit(5), total - 5);
  const rest = await listAudit({});
  eq(rest.map((r) => r.target), ['n11', 'n10', 'n9', 'n8', 'n7']);
  await logAction('x'.repeat(10), { target: 't'.repeat(1000), detail: 'd'.repeat(1000) });
  const last = (await listAudit({ limit: 1 }))[0];
  eq([last.target.length, last.detail.length], [120, 400], 'long text is clipped');
});

// ============================================================================
// Automatic backup
// ============================================================================

test('snapshots: take, list, restore (with undo), delete — and survive a restore', async () => {
  const p = await saveProduct({ name: 'Rice', unit: 'bag', stock: 10, defaultPrice: 100 });
  const s1 = await takeSnapshot('manual');
  eq(s1.counts.products, 1);
  assert(s1.bytes > 100);
  await saveProduct({ name: 'Lentil', unit: 'kg', stock: 5 });
  eq((await listProducts()).length, 2);
  await restoreSnapshot(s1.id);
  eq((await listProducts()).map((x) => x.name), ['Rice'], 'data is back to the snapshot');
  const list = await listSnapshots();
  eq(list.map((s) => s.reason).sort(), ['before-restore', 'manual'], 'a safety snapshot was made before restoring');
  const safety = list.find((s) => s.reason === 'before-restore');
  eq((await getSnapshot(safety.id)).data.stores.products.length, 2, 'the safety snapshot holds the state before the restore');
  await restoreSnapshot(safety.id); // undo the restore
  eq((await listProducts()).length, 2, 'restore was undone');
  await deleteSnapshot(s1.id);
  assert(!(await listSnapshots()).some((s) => s.id === s1.id));
  void p;
});

test('importing a file also leaves a safety snapshot', async () => {
  await saveProduct({ name: 'Rice', unit: 'bag', stock: 1 });
  const file = await exportDatabase();
  await saveProduct({ name: 'Extra', unit: 'bag', stock: 1 });
  await importDatabase(file);
  eq((await listProducts()).length, 1);
  const safety = (await listSnapshots()).filter((s) => s.reason === 'before-restore');
  eq(safety.length, 1);
  eq(safety[0].counts.products, 2);
});

test('auto backup: runs when due, not before; keeps only the newest N; first run is immediate', async () => {
  await settings.set({ autoBackupEnabled: true, autoBackupEveryHours: 24, autoBackupKeep: 3, autoBackupToDrive: false, autoBackupAfterSales: 0 });
  await saveProduct({ name: 'Rice', unit: 'bag', stock: 1 });
  const r1 = await runAutoBackup({ online: false });
  assert(r1.snapshot, 'first backup is taken at once');
  eq(r1.snapshot.reason, 'auto');
  const r2 = await runAutoBackup({ online: false });
  eq(r2.snapshot, null, 'not due yet');
  await settings.set({ lastAutoBackupAt: new Date(Date.now() - 25 * 3600000).toISOString() });
  assert((await runAutoBackup({ online: false })).snapshot, 'due after 24 h');
  for (let i = 0; i < 4; i++) await runAutoBackup({ force: true, online: false });
  eq((await listSnapshots()).length, 3, 'old snapshots are pruned');
  eq((await getBackupStatus()).count, 3);
});

test('auto backup: also after N new invoices; disabled means never', async () => {
  const p = await saveProduct({ name: 'Rice', unit: 'bag', stock: 100, defaultPrice: 10 });
  await settings.set({ autoBackupEnabled: true, autoBackupEveryHours: 24, autoBackupAfterSales: 3, autoBackupToDrive: false });
  await runAutoBackup({ online: false });
  const sell = () => createInvoice({ items: [{ productId: p.id, qty: 1, unitPrice: 10 }], paid: 10 }, user);
  await sell();
  await sell();
  eq((await runAutoBackup({ online: false })).snapshot, null, '2 sales are not enough');
  await sell();
  assert((await runAutoBackup({ online: false })).snapshot, '3 sales trigger a backup');
  await settings.set({ autoBackupEnabled: false });
  await sell();
  await sell();
  await sell();
  eq((await runAutoBackup({ online: false })).snapshot, null, 'disabled');
  eq((await runAutoBackup({ force: true, online: false })).snapshot, null, 'even when forced, automatic backup respects the switch');
});

test('auto backup to Google Drive: only when configured and online; failures do not break it and are retried', async () => {
  await saveProduct({ name: 'Rice', unit: 'bag', stock: 1 });
  await settings.set({ autoBackupEnabled: true, autoBackupToDrive: true, syncUrl: 'https://script.google.com/macros/s/X/exec', syncToken: 'secret' });
  const uploads = [];
  let fail = true;
  const fetchImpl = async (_u, init) => {
    const b = JSON.parse(init.body);
    if (fail) throw new TypeError('Failed to fetch');
    uploads.push(b);
    return { ok: true, status: 200, text: async () => JSON.stringify({ ok: true, file: { id: 'f1', name: b.name, size: b.content.length } }) };
  };
  const offline = await runAutoBackup({ fetchImpl, online: false });
  eq([!!offline.snapshot, offline.drive, uploads.length], [true, false, 0], 'offline: local snapshot only');
  const failed = await runAutoBackup({ fetchImpl, online: true });
  eq(failed.drive, false);
  assert(/Failed to fetch/.test((await getBackupStatus()).driveError), 'error is reported');
  fail = false;
  const ok = await runAutoBackup({ fetchImpl, online: true });
  eq([ok.drive, uploads.length], [true, 1], 'retried at the next check');
  assert(uploads[0].name.startsWith('pos-backup-') && JSON.parse(uploads[0].content).format === 'wholesale-pos-backup');
  eq((await getBackupStatus()).driveError, '');
  const again = await runAutoBackup({ fetchImpl, online: true });
  eq([again.drive, uploads.length], [false, 1], 'not again until due');
  void dbAll;
});

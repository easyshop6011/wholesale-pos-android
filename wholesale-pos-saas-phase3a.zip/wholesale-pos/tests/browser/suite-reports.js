/**
 * suite-reports.js — analytics behind the charts: trends, rankings, category
 * share, profit, staff sales, cash mix, busy hours, receivables ageing and
 * reorder suggestions. Every figure is checked against numbers computed by hand.
 */
import { test, assert, eq } from './harness.js';
import { saveProduct, saveCategory, asUser } from './helpers.js';
import { auth } from '../../js/services/auth.js';
import { saveCustomer, receivePayment } from '../../js/services/customers.js';
import { createInvoice, voidInvoice } from '../../js/services/sales.js';
import { salesTrend, monthlyTrend, topCustomers, categoryShare, profitReport, salesByUser, paymentMix, hourlySales, periodSummary, dashboard, dueAging, reorderSuggestions } from '../../js/services/reports.js';
import { dateParts, addDays } from '../../js/core/utils.js';

const today = () => dateParts().date;
// Two real staff accounts: the service records WHO IS SIGNED IN as the seller, not a name passed by the caller.
const mary = { username: 'mary', password: 'marypass', displayName: 'Mary' };
const omar = { username: 'omar', password: 'omarpass', displayName: 'Omar' };

/** Rice (cost 80) in Grains, Oil (cost 700) in Oils, two customers. */
async function shop() {
  const grains = await saveCategory({ name: 'Grains' });
  const oils = await saveCategory({ name: 'Oils' });
  const rice = await saveProduct({ name: 'Rice', categoryId: grains.id, unit: 'kg', costPrice: 80, defaultPrice: 100, stock: 1000, lowStockLevel: 50 });
  const oil = await saveProduct({ name: 'Oil', categoryId: oils.id, unit: 'btl', costPrice: 700, defaultPrice: 900, stock: 100, lowStockLevel: 10 });
  const rahim = await saveCustomer({ name: 'Rahim', phone: '01711000001' });
  const karim = await saveCustomer({ name: 'Karim', phone: '01811000002' });
  for (const u of [mary, omar]) await auth.createUser({ username: u.username, displayName: u.displayName, role: 'manager', password: u.password, pin: '4321' });
  return { rice, oil, rahim, karim };
}
const sale = (customer, lines, o = {}, who = mary) => asUser(who.username, who.password, () => createInvoice({ customerId: customer?.id || null, items: lines.map(([p, qty, unitPrice]) => ({ productId: p.id, qty, unitPrice })), discount: o.discount || 0, paid: o.paid ?? 0 }));

test('salesTrend: zero-filled days, weeks and months; voided invoices excluded', async () => {
  const { rice, rahim } = await shop();
  await sale(rahim, [[rice, 10, 100]], { paid: 1000 }); // 1000
  const gone = await sale(rahim, [[rice, 5, 100]], { paid: 500 });
  await voidInvoice(gone.id, 'test void', mary);
  const from = addDays(today(), -6);
  const day = await salesTrend({ from, to: today(), granularity: 'day' });
  eq(day.buckets.length, 7);
  eq(day.buckets.map((b) => b.sales), [0, 0, 0, 0, 0, 0, 1000]);
  eq([day.totals.sales, day.totals.invoices, day.totals.cashCollected], [1000, 1, 1000]);
  const week = await salesTrend({ from: addDays(today(), -20), to: today(), granularity: 'week' });
  assert(week.buckets.length >= 3 && week.buckets.length <= 4, `weeks: ${week.buckets.length}`);
  eq(week.buckets.reduce((a, b) => a + b.sales, 0), 1000);
  assert(week.buckets.every((b) => new Date(`${b.key}T12:00:00`).getDay() === 1), 'weeks start on Monday');
  const month = await salesTrend({ from: addDays(today(), -70), to: today(), granularity: 'month' });
  eq(month.buckets.reduce((a, b) => a + b.sales, 0), 1000);
  assert(month.buckets.length >= 3);
  const m12 = await monthlyTrend(12);
  eq(m12.buckets.length, 12);
  eq(m12.buckets[11].key, dateParts().month);
  eq(m12.totals.sales, 1000);
});

test('topCustomers ranks by sales and leaves walk-in sales out', async () => {
  const { rice, rahim, karim } = await shop();
  await sale(rahim, [[rice, 10, 100]], { paid: 1000 });
  await sale(karim, [[rice, 30, 100]], { paid: 1000 }); // 3000, due 2000
  await sale(null, [[rice, 100, 100]], { paid: 10000 });
  const r = await topCustomers({ from: addDays(today(), -30), to: today() });
  eq(r.rows.map((x) => [x.name, x.sales, x.due, x.invoices]), [['Karim', 3000, 2000, 1], ['Rahim', 1000, 0, 1]]);
  eq((await topCustomers({ from: addDays(today(), -30), to: today(), limit: 1 })).rows.length, 1);
});

test('categoryShare: revenue is net of the invoice discount and adds up to net sales', async () => {
  const { rice, oil, rahim } = await shop();
  await sale(rahim, [[rice, 10, 100], [oil, 1, 900]], { discount: 190, paid: 1710 }); // subtotal 1900, net 1710
  const r = await categoryShare({ from: today(), to: today() });
  eq(r.total, 1710);
  eq(r.rows.map((x) => [x.category, x.revenue, x.share]), [['Oils', 810, 47.37], ['Grains', 900, 52.63]].sort((a, b) => b[1] - a[1]));
  eq(Math.round(r.rows.reduce((a, x) => a + x.share, 0)), 100);
});

test('profitReport: net revenue, cost from the price at sale time, margin, missing-cost warning', async () => {
  const { rice, oil, rahim } = await shop();
  const free = await saveProduct({ name: 'Gift bag', unit: 'pc', costPrice: 0, defaultPrice: 10, stock: 100 });
  await sale(rahim, [[rice, 10, 100], [oil, 1, 900]], { discount: 190, paid: 1710 }); // revenue 1710, cost 800 + 700 = 1500
  await sale(null, [[free, 4, 10]], { paid: 40 });
  const r = await profitReport({ from: today(), to: today() });
  eq([r.totals.revenue, r.totals.cost, r.totals.profit], [1750, 1500, 250]);
  eq(r.totals.margin, 14.29);
  eq([r.totals.grossSales, r.totals.discount, r.totals.missingCostLines], [1940, 190, 1]);
  eq(r.byProduct[0].name, 'Oil', 'most profitable first');
  eq(r.byProduct.map((p) => [p.name, p.revenue, p.profit]), [['Oil', 810, 110], ['Rice', 900, 100], ['Gift bag', 40, 40]]);
  eq(r.byDay.length, 1);
  // changing the cost afterwards must not rewrite history
  await saveProduct({ id: rice.id, name: 'Rice', categoryId: rice.categoryId, unit: 'kg', costPrice: 95, defaultPrice: 100 });
  eq((await profitReport({ from: today(), to: today() })).totals.cost, 1500);
});

test('salesByUser, paymentMix, hourlySales and periodSummary agree with each other', async () => {
  const { rice, rahim, karim } = await shop();
  await sale(rahim, [[rice, 10, 100]], { paid: 400 }, mary); // 1000, due 600
  await sale(karim, [[rice, 20, 100]], { paid: 2000 }, omar); // 2000
  const v = await sale(null, [[rice, 1, 100]], { paid: 100 }, omar);
  await voidInvoice(v.id, 'test void', omar);
  await receivePayment({ customerId: rahim.id, amount: 250 }, mary);
  const range = { from: today(), to: today() };
  const staff = await salesByUser(range);
  eq(staff.rows.map((r) => [r.name, r.invoices, r.sales, r.voided, r.avgInvoice]), [['Omar', 1, 2000, 1, 2000], ['Mary', 1, 1000, 0, 1000]]);
  eq(staff.totals, { invoices: 2, sales: 3000 });
  const mix = await paymentMix(range);
  eq(mix, { ...range, paidAtSale: 2400, duesCollected: 250, dueCreated: 600, refunds: 0, cashCollected: 2650, netDueChange: 350 });
  const hours = await hourlySales(range);
  eq(hours.hours.length, 24);
  eq(hours.hours.reduce((a, h) => a + h.sales, 0), 3000);
  eq(hours.hours.reduce((a, h) => a + h.invoices, 0), 2);
  const sum = await periodSummary(range);
  eq([sum.sales, sum.invoices, sum.avgInvoice, sum.cashCollected, sum.dueCreated, sum.duesCollected], [3000, 2, 1500, 2650, 600, 250]);
  eq(sum.profit, 3000 - 30 * 80);
});

test('dashboard: 30-day series, newest-first recent list, top products, due and low stock', async () => {
  const { rice, oil, rahim } = await shop();
  for (let i = 0; i < 8; i++) await sale(rahim, [[rice, 1, 100]], { paid: 100 });
  await sale(rahim, [[oil, 95, 900]], { paid: 0 }); // oil stock 100 -> 5 (low), due 85500
  const d = await dashboard();
  eq(d.last30.length, 30);
  eq(d.last7.length, 7);
  eq([d.last30[29].sales, d.last30[29].invoices, d.yesterdaySales], [800 + 85500, 9, 0]);
  eq(d.recent.length, 6);
  assert(d.recent.every((r, i) => !i || d.recent[i - 1].createdAt > r.createdAt), 'newest first');
  eq(d.recent[0].total, 85500);
  eq(d.topToday[0].name, 'Oil');
  eq([d.todaySales, d.todayCount, d.totalDue, d.totalProducts, d.totalCustomers], [86300, 9, 85500, 2, 2]);
  eq(d.lowStock.map((p) => p.name), ['Oil']);
  await sale(rahim, [[rice, 1, 100]], { paid: 100 });
  eq((await dashboard()).todayCount, 10, 'dashboard cache is dropped after a new sale');
});

test('dueAging: payments clear the OLDEST invoices first; remainders are bucketed by age', async () => {
  const { rice, rahim, karim } = await shop();
  await sale(rahim, [[rice, 10, 100]], { paid: 0 }); // 1000 (older)
  await sale(rahim, [[rice, 5, 100]], { paid: 0 }); // 500 (newer)
  await sale(karim, [[rice, 3, 100]], { paid: 0 }); // 300
  await receivePayment({ customerId: rahim.id, amount: 1200 }, mary); // clears the 1000 and 200 of the 500
  const now = await dueAging();
  eq(now.rows.map((r) => [r.name, r.total, r.d0]), [['Karim', 300, 300], ['Rahim', 300, 300]], 'equal amounts are listed by name');
  const later = await dueAging({ today: addDays(today(), 45) });
  eq(later.rows.find((r) => r.name === 'Rahim').d31, 300);
  eq(later.rows.find((r) => r.name === 'Rahim').oldestDays, 45);
  const old = await dueAging({ today: addDays(today(), 100) });
  eq([old.totals.d90, old.totals.total, old.totals.d0], [600, 600, 0]);
  const buckets = await dueAging({ today: addDays(today(), 75) });
  eq(buckets.totals.d61, 600);
  eq((await dueAging()).totals.total, (await dueAging({ today: addDays(today(), 3) })).totals.total, 'ageing never changes the amount');
});

test('reorderSuggestions: uses real sales speed; low-stock items always appear', async () => {
  const { rice, oil, rahim } = await shop();
  await saveProduct({ name: 'Dead stock', unit: 'pc', stock: 500, lowStockLevel: 5 });
  await saveProduct({ name: 'Empty shelf', unit: 'pc', stock: 0, lowStockLevel: 5 });
  await sale(rahim, [[rice, 900, 100]], { paid: 90000 }); // 900 kg in 30 days = 30/day; 100 left
  await sale(rahim, [[oil, 1, 900]], { paid: 900 });
  const r = await reorderSuggestions({ days: 30, coverDays: 14 });
  const byName = Object.fromEntries(r.rows.map((x) => [x.name, x]));
  eq(Object.keys(byName).sort(), ['Empty shelf', 'Rice'], 'oil (99 left, 0.03/day) and dead stock are fine');
  eq([byName.Rice.perDay, byName.Rice.daysLeft, byName.Rice.suggest, byName.Rice.status], [30, 3.3, 320, 'Running out'], '30/day × 14 days = 420, minus 100 in stock');
  eq([byName['Empty shelf'].status, byName['Empty shelf'].daysLeft, byName['Empty shelf'].suggest], ['Out of stock', null, 0]);
  eq(r.rows[0].name, 'Rice', 'closest to running out first');
});

/**
 * suite-sync.js — the v3 sync engine: catalog (products/customers/stock) upsert,
 * change detection, old-script fallback, exponential back-off, adaptive batch
 * size, sync log, queue view and server verification.
 */
import { test, assert, eq } from './harness.js';
import { settings } from '../../js/services/settings.js';
import { saveProduct, saveCustomerLike } from './helpers.js';
import { createInvoice, voidInvoice } from '../../js/services/sales.js';
import { receivePayment } from '../../js/services/customers.js';
import { adjustStock } from '../../js/services/inventory.js';
import { syncNow, getSyncStatus, getSyncLog, getQueue, verifyUploaded, retryFailed, testConnection, resetCatalogSync, hashOf } from '../../js/services/sync.js';
import { dbByIndex, dbAll } from '../../js/core/db.js';

const user = { id: 'u1', displayName: 'Tester' };
const mk = (o) => ({ ok: true, status: 200, text: async () => JSON.stringify(o) });

/** A faithful in-memory copy of Code.gs v3 (invoices, payments, catalog upsert, verify). */
function script({ version = 3, failNext = 0, throwAbort = 0 } = {}) {
  const s = { invoices: new Map(), payments: new Set(), products: new Map(), customers: new Map(), calls: [], failNext, throwAbort, version };
  s.fetch = async (_url, init) => {
    const body = JSON.parse(init.body);
    s.calls.push(body.action);
    if (s.throwAbort > 0 && body.action !== 'ping') {
      s.throwAbort--;
      throw Object.assign(new Error('aborted'), { name: 'AbortError' });
    }
    if (s.failNext > 0 && body.action !== 'ping') {
      s.failNext--;
      throw new TypeError('Failed to fetch');
    }
    if (body.token !== 'secret') return mk({ ok: false, error: 'Unauthorized' });
    switch (body.action) {
      case 'ping':
        return mk({ ok: true, version: s.version, capabilities: s.version >= 3 ? ['invoices', 'payments', 'backup', 'catalog', 'verify'] : undefined });
      case 'syncInvoices':
        return mk({ ok: true, results: body.invoices.map((i) => (s.invoices.has(i.id) ? (s.invoices.get(i.id).status !== i.status ? (s.invoices.set(i.id, i), { id: i.id, result: 'updated' }) : { id: i.id, result: 'duplicate' }) : (s.invoices.set(i.id, i), { id: i.id, result: 'inserted' }))) });
      case 'syncPayments':
        return mk({ ok: true, results: body.payments.map((p) => (s.payments.has(p.id) ? { id: p.id, result: 'duplicate' } : (s.payments.add(p.id), { id: p.id, result: 'inserted' }))) });
      case 'upsertProducts':
        if (s.version < 3) return mk({ ok: false, error: 'Unknown action: upsertProducts' });
        return mk({ ok: true, results: body.products.map((p) => { const had = s.products.has(p.id); s.products.set(p.id, p); return { id: p.id, result: had ? 'updated' : 'inserted' }; }) });
      case 'upsertCustomers':
        if (s.version < 3) return mk({ ok: false, error: 'Unknown action: upsertCustomers' });
        return mk({ ok: true, results: body.customers.map((c) => { const had = s.customers.has(c.id); s.customers.set(c.id, c); return { id: c.id, result: had ? 'updated' : 'inserted' }; }) });
      case 'verifyInvoices':
        if (s.version < 3) return mk({ ok: false, error: 'Unknown action: verifyInvoices' });
        return mk({ ok: true, missing: body.ids.filter((id) => !s.invoices.has(id)) });
      default:
        return mk({ ok: false, error: `Unknown action: ${body.action}` });
    }
  };
  return s;
}

async function setup() {
  await settings.set({ syncUrl: 'https://script.google.com/macros/s/X/exec', syncToken: 'secret', syncEnabled: true });
  const product = await saveProduct({ name: 'Rice 25kg', unit: 'bag', costPrice: 100, defaultPrice: 120, stock: 50, lowStockLevel: 5 });
  const customer = await saveCustomerLike({ name: 'Rahim Traders', phone: '01711000001' });
  return { product, customer };
}
const sell = (customer, product, paid = 100, qty = 1) => createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty, unitPrice: 120 }], paid }, user);

test('catalog sync: products (with stock) and customers (with due) are upserted', async () => {
  const { product, customer } = await setup();
  await sell(customer, product, 100, 2); // total 240, due 140, stock 48
  const srv = script();
  const r = await syncNow({ fetchImpl: srv.fetch });
  eq([r.failed, r.sent, r.catalog], [false, 1, 2]);
  eq([srv.products.size, srv.customers.size], [1, 1]);
  const p = [...srv.products.values()][0];
  eq([p.name, p.stock, p.category, p.status], ['Rice 25kg', 48, '', 'Active']);
  eq([...srv.customers.values()][0].due, 140);
});

test('catalog sync: only CHANGED records are sent again', async () => {
  const { product, customer } = await setup();
  const srv = script();
  await syncNow({ fetchImpl: srv.fetch });
  const before = srv.calls.length;
  await syncNow({ fetchImpl: srv.fetch });
  eq(srv.calls.length, before, 'nothing changed => no request');
  await adjustStock({ productId: product.id, mode: 'remove', qty: 5, reason: 'damaged' }, user);
  srv.calls.length = 0;
  const r = await syncNow({ fetchImpl: srv.fetch });
  eq(srv.calls, ['upsertProducts'], 'only the product changed');
  eq(r.catalog, 1);
  eq([...srv.products.values()][0].stock, 45);
  await receivePayment({ customerId: customer.id, amount: 0 + 0.01 }, user).catch(() => {}); // no due => rejected, nothing changes
  await resetCatalogSync();
  srv.calls.length = 0;
  await syncNow({ fetchImpl: srv.fetch });
  eq(srv.calls, ['upsertProducts', 'upsertCustomers'], 'reset resends everything');
});

test('catalog sync: can be switched off', async () => {
  await setup();
  await settings.set({ syncCatalog: false });
  const srv = script();
  await syncNow({ fetchImpl: srv.fetch });
  eq(srv.calls, [], 'no pending invoices, catalog off => no request');
});

test('old script without catalog actions: invoices still sync, user gets a notice', async () => {
  const { product, customer } = await setup();
  await sell(customer, product);
  const srv = script({ version: 2 });
  const r = await syncNow({ fetchImpl: srv.fetch });
  eq([r.failed, r.sent], [false, 1]);
  const st = getSyncStatus();
  eq(st.catalogSupported, false);
  assert(/older version/.test(st.notice), `notice: ${st.notice}`);
  eq(st.lastError, '');
  const calls = srv.calls.length;
  await syncNow({ fetchImpl: srv.fetch });
  eq(srv.calls.length, calls, 'unsupported actions are not retried every minute');
  await testConnection({ fetchImpl: script().fetch });
  eq(getSyncStatus().catalogSupported, true, 'a ping from an updated script re-enables it');
});

test('back-off: automatic retries wait, "Sync now" does not, success resets', async () => {
  const { product, customer } = await setup();
  await sell(customer, product);
  const srv = script({ failNext: 1 });
  const r1 = await syncNow({ fetchImpl: srv.fetch, auto: true });
  eq(r1.failed, true);
  let st = getSyncStatus();
  eq(st.consecutiveFailures, 1);
  assert(st.nextRetryAt && Date.parse(st.nextRetryAt) > Date.now() + 15000, 'next retry is in the future');
  const calls = srv.calls.length;
  const r2 = await syncNow({ fetchImpl: srv.fetch, auto: true });
  eq(r2.skipped, 'backoff');
  eq(srv.calls.length, calls, 'automatic attempt did not hit the network');
  const r3 = await syncNow({ fetchImpl: srv.fetch }); // manual
  eq([r3.failed, r3.sent], [false, 1]);
  st = getSyncStatus();
  eq([st.consecutiveFailures, st.nextRetryAt], [0, '']);
});

test('timeouts halve the batch size, successes grow it back', async () => {
  const { product, customer } = await setup();
  await sell(customer, product);
  eq(getSyncStatus().batchSize, 15);
  const srv = script({ throwAbort: 1 });
  await syncNow({ fetchImpl: srv.fetch });
  eq(getSyncStatus().batchSize, 7);
  await syncNow({ fetchImpl: srv.fetch });
  eq(getSyncStatus().batchSize, 8);
});

test('failed attempts are counted on the records and shown in the queue', async () => {
  const { product, customer } = await setup();
  await sell(customer, product);
  await syncNow({ fetchImpl: script({ failNext: 1 }).fetch });
  const q = await getQueue();
  eq(q.length, 1);
  eq([q[0].kind, q[0].status, q[0].attempts], ['invoice', 'pending', 1]);
  assert(/Failed to fetch/.test(q[0].error), q[0].error);
});

test('sync log: runs are recorded (success and failure), idle runs are not', async () => {
  const { product, customer } = await setup();
  await sell(customer, product);
  await syncNow({ fetchImpl: script({ failNext: 1 }).fetch });
  const srv = script();
  await syncNow({ fetchImpl: srv.fetch });
  await syncNow({ fetchImpl: srv.fetch }); // idle
  const log = await getSyncLog();
  eq(log.map((l) => [l.kind, l.ok]), [['sync', true], ['sync', false]], 'newest first, idle run not logged');
  eq([log[0].sent, log[0].catalog], [1, 2]);
  assert(/Failed to fetch/.test(log[1].error));
});

test('verify: invoices missing from the sheet are re-queued and uploaded again', async () => {
  const { product, customer } = await setup();
  const a = await sell(customer, product);
  const b = await sell(customer, product);
  const srv = script();
  await syncNow({ fetchImpl: srv.fetch });
  srv.invoices.delete(a.id); // someone deleted the rows by mistake
  const r = await verifyUploaded({ fetchImpl: srv.fetch });
  eq([r.checked, r.missing], [2, 1]);
  await syncNow({ fetchImpl: srv.fetch });
  eq([srv.invoices.has(a.id), srv.invoices.has(b.id), srv.invoices.size], [true, true, 2]);
  eq((await dbByIndex('invoices', 'syncStatus', 'pending')).length, 0);
  const old = await verifyUploaded({ fetchImpl: script({ version: 2 }).fetch });
  eq(old.unsupported, true);
});

test('voiding after upload re-syncs the status once (no duplicate rows)', async () => {
  const { product, customer } = await setup();
  const inv = await sell(customer, product);
  const srv = script();
  await syncNow({ fetchImpl: srv.fetch });
  await voidInvoice(inv.id, 'mistake', user);
  const r = await syncNow({ fetchImpl: srv.fetch });
  eq(r.sent, 1);
  eq(srv.invoices.size, 1);
  eq(srv.invoices.get(inv.id).status, 'Void');
});

test('retryFailed re-queues rejected records, resets the back-off and uploads them', async () => {
  const { product, customer } = await setup();
  await sell(customer, product);
  const srv = script();
  const good = srv.fetch;
  srv.fetch = async (u, i) => {
    const b = JSON.parse(i.body);
    return b.action === 'syncInvoices' ? mk({ ok: true, results: b.invoices.map((x) => ({ id: x.id, result: 'invalid' })) }) : good(u, i);
  };
  await syncNow({ fetchImpl: srv.fetch });
  eq((await dbAll('invoices'))[0].syncStatus, 'failed');
  eq(getSyncStatus().failed, 1);
  const r = await retryFailed({ fetchImpl: good }); // the "fixed" script accepts it now
  eq([r.failed, r.sent], [false, 1]);
  eq((await dbAll('invoices'))[0].syncStatus, 'synced');
  eq(getSyncStatus().failed, 0);
});

test('hashOf is stable and sensitive to every field', () => {
  eq(hashOf({ a: 1, b: 'x' }), hashOf({ a: 1, b: 'x' }));
  assert(hashOf({ a: 1, b: 'x' }) !== hashOf({ a: 1, b: 'y' }));
  assert(hashOf({ stock: 10 }) !== hashOf({ stock: 11 }));
});

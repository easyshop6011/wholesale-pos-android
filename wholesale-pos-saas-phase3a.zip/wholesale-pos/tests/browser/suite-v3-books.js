/**
 * suite-v3-books.js — customer profile & history, stock history, returns, idempotency and
 * exact money. Real IndexedDB; every figure is also computed independently in the test.
 */
import { test, assert, eq, rejects } from './harness.js';
import { saveProduct, saveCategory } from './helpers.js';
import { saveCustomer, receivePayment, customerProfile, customerHistoryToCSV, customerLedger, listCustomers, computeBalances } from '../../js/services/customers.js';
import { createInvoice, voidInvoice, getInvoice, queryInvoices } from '../../js/services/sales.js';
import { returnSale, listReturns, returnableLines } from '../../js/services/returns.js';
import { receiveStock, writeOffStock, adjustStock, queryMovements, productHistory, verifyStockLedger, listMovements, movementsToCSV } from '../../js/services/inventory.js';
import { deleteProduct, listProducts } from '../../js/services/catalog.js';
import { dailyReport, profitReport, dashboard, productSalesReport } from '../../js/services/reports.js';
import { auth } from '../../js/services/auth.js';
import { dbAll, dbGet, run } from '../../js/core/db.js';
import { dateParts, addDays, uuid } from '../../js/core/utils.js';
import { sum, toMinor } from '../../js/core/money.js';
import { dhakaDate } from '../../js/core/datetime.js';

const today = () => dateParts().date;
const line = (p, qty, unitPrice) => ({ productId: p.id, qty, unitPrice });
const sell = (customer, items, o = {}) => createInvoice({ customerId: customer?.id || null, items, discount: o.discount || 0, paid: o.paid ?? 0, paymentMethod: o.method, requestId: o.requestId, notes: o.notes }, null);

/** Rice (stock 100, ৳100) + Oil (stock 50, ৳900) and a customer. */
async function shop() {
  const rice = await saveProduct({ name: 'Rice 25kg', unit: 'bag', costPrice: 80, defaultPrice: 100, stock: 100, lowStockLevel: 10 });
  const oil = await saveProduct({ name: 'Soybean Oil', unit: 'btl', costPrice: 700, defaultPrice: 900, stock: 50, lowStockLevel: 5 });
  const rahim = await saveCustomer({ name: 'Rahim Traders', phone: '01711000001', address: 'Mirpur, Dhaka' });
  return { rice, oil, rahim };
}

// ============================================================================
// 1–3. Customer profile
// ============================================================================

test('customer profile: a new customer has a complete, empty, consistent profile', async () => {
  const c = await saveCustomer({ name: 'রহিম ট্রেডার্স', phone: '০১৭১১০০০০০১', address: 'মিরপুর, ঢাকা' });
  assert(/^[0-9a-f-]{36}$/.test(c.id), 'unique id');
  eq(c.code, 'C-0001');
  eq(c.phone, '01711000001', 'Bengali digits are stored as normal digits');
  const p = await customerProfile(c.id);
  eq(p.customer.name, 'রহিম ট্রেডার্স');
  eq(p.customer.address, 'মিরপুর, ঢাকা');
  eq({ ...p.summary, customerId: undefined }, { customerId: undefined, code: 'C-0001', totalPurchases: 0, paidAtSale: 0, paymentsReceived: 0, totalPaid: 0, refunds: 0, returnsValue: 0, creditFromReturns: 0, netPurchases: 0, netPaid: 0, currentDue: 0, invoiceCount: 0, voidedCount: 0, returnCount: 0, paymentCount: 0, lastPurchase: null, reconciles: true });
  eq(p.summary.customerId, c.id);
  eq(p.entries, []);
  eq((await saveCustomer({ name: 'Second' })).code, 'C-0002', 'codes count up');
  eq(customerHistoryToCSV(p).split('\n').length, 1, 'CSV of an empty history is just the header');
  await rejects(() => customerProfile('no-such-customer'), /Customer not found/);
  // searchable by name and by phone in any format
  eq((await listCustomers({ search: 'রহিম' })).length, 1);
  eq((await listCustomers({ search: '01711' })).length, 1);
});

test('customer profile: several sales and payments — every figure agrees with the raw records', async () => {
  const { rice, oil, rahim } = await shop();
  const i1 = await sell(rahim, [line(rice, 10, 100)], { paid: 1000, method: 'cash' }); // 1000 paid in full
  const i2 = await sell(rahim, [line(rice, 5, 100), line(oil, 2, 900)], { discount: 100, paid: 700, method: 'bkash' }); // 500+1800-100 = 2200, paid 700, due 1500
  const i3 = await sell(rahim, [line(oil, 1, 900)], { paid: 0 }); // 900 unpaid
  const p1 = await receivePayment({ customerId: rahim.id, amount: 600, method: 'nagad', note: 'first part' });
  const p2 = await receivePayment({ customerId: rahim.id, amount: 400, method: 'cash' });
  const prof = await customerProfile(rahim.id);
  const s = prof.summary;
  eq([s.totalPurchases, s.paidAtSale, s.paymentsReceived, s.totalPaid, s.currentDue], [4100, 1700, 1000, 2700, 1400]);
  eq([s.invoiceCount, s.paymentCount, s.voidedCount, s.reconciles], [3, 2, 0, true]);
  eq(s.lastPurchase.invoiceNo, i3.invoiceNo);
  assert(s.lastPurchase.at === i3.createdAt && s.lastPurchase.date === i3.date && s.lastPurchase.time === i3.time, 'last purchase has the exact date and time');
  // independent recomputation straight from the stored rows
  const invs = (await dbAll('invoices')).filter((i) => i.customerId === rahim.id);
  const pays = (await dbAll('payments')).filter((p) => p.customerId === rahim.id);
  eq(sum(invs.map((i) => i.total)), s.totalPurchases);
  eq(sum(invs.map((i) => i.paid)) + sum(pays.map((p) => p.amount)), s.totalPaid, 'each payment is counted exactly once');
  eq(computeBalances(invs, pays, []).get(rahim.id), s.currentDue);
  eq((await listCustomers())[0].due, s.currentDue, 'the customer list shows the same due');

  // history: 3 invoices + 2 payments, newest first, with the running balance
  eq(prof.entries.map((e) => e.kind), ['payment', 'payment', 'invoice', 'invoice', 'invoice']);
  eq(prof.entries.map((e) => e.balance), [1400, 1800, 2400, 1500, 0], 'running balance: 0 → +1500 → +900 → −600 → −400');
  assert(prof.entries.every((e, i, a) => !i || a[i - 1].at >= e.at), 'newest first');
  const e2 = prof.entries.find((e) => e.ref === i2.invoiceNo).invoice;
  eq(e2.items.map((i) => [i.name, i.qty, i.unit, i.unitPrice, i.total, i.discountShare, i.net]), [['Rice 25kg', 5, 'bag', 100, 500, 21.74, 478.26], ['Soybean Oil', 2, 'btl', 900, 1800, 78.26, 1721.74]]);
  eq(sum(e2.items.map((i) => i.discountShare)), 100, 'line discounts add up to the invoice discount');
  eq([e2.total, e2.paid, e2.due, e2.discount, e2.paymentMethod], [2200, 700, 1500, 100, 'bkash']);
  eq(prof.entries.filter((e) => e.kind === 'payment').map((e) => [e.payment.amount, e.payment.method, e.payment.note]).reverse(), [[600, 'nagad', 'first part'], [400, 'cash', '']]);
  // payments settle the OLDEST unpaid invoice first (display)
  eq([e2.laterPaid, e2.remainingDue, e2.state], [1000, 500, 'partial']);
  eq(prof.entries.find((e) => e.ref === i3.invoiceNo).invoice.state, 'unpaid');
  eq(prof.entries.find((e) => e.ref === i1.invoiceNo).invoice.state, 'paid');
  eq([p1.method, p2.method], ['nagad', 'cash']);
  // the ledger view (older screen) agrees
  eq((await customerLedger(rahim.id)).balance, 1400);
});

test('customer profile: partial → full payment, no overpayment, and a repeated payment request counts once', async () => {
  const { rice, rahim } = await shop();
  await sell(rahim, [line(rice, 10, 100)], { paid: 400 }); // due 600
  const rid = uuid();
  const a = await receivePayment({ customerId: rahim.id, amount: 200, requestId: rid });
  const b = await receivePayment({ customerId: rahim.id, amount: 200, requestId: rid });
  eq([a.id === b.id, b.duplicate], [true, true]);
  eq((await customerProfile(rahim.id)).summary.currentDue, 400, 'recorded once');
  await rejects(() => receivePayment({ customerId: rahim.id, amount: 400.01 }), /exceeds the outstanding due \(400\)/);
  await rejects(() => receivePayment({ customerId: rahim.id, amount: 0 }), /greater than zero/);
  await rejects(() => receivePayment({ customerId: rahim.id, amount: 'abc' }), /must be a number/);
  await receivePayment({ customerId: rahim.id, amount: 400 });
  const s = (await customerProfile(rahim.id)).summary;
  eq([s.currentDue, s.totalPaid, s.paymentCount], [0, 1000, 2]);
  await rejects(() => receivePayment({ customerId: rahim.id, amount: 1 }), /exceeds the outstanding due \(0\)/);
  eq((await dbAll('payments')).length, 2);
});

test('customer profile: a void keeps the whole audit trail (reason, who, when, refund owed) and fixes the balance', async () => {
  const { rice, rahim } = await shop();
  const keep = await sell(rahim, [line(rice, 2, 100)], { paid: 200 });
  const bad = await sell(rahim, [line(rice, 10, 100)], { paid: 300 }); // due 700
  eq((await customerProfile(rahim.id)).summary.currentDue, 700);
  const v = await voidInvoice(bad.id, 'Customer cancelled the order');
  const prof = await customerProfile(rahim.id);
  eq([prof.summary.currentDue, prof.summary.totalPurchases, prof.summary.invoiceCount, prof.summary.voidedCount], [0, 200, 1, 1]);
  eq(prof.entries.map((e) => e.kind), ['void', 'invoice', 'invoice'], 'the voided invoice is still in the history');
  const voidEntry = prof.entries[0];
  eq([voidEntry.void.reason, voidEntry.void.refundOwed, voidEntry.credit, voidEntry.ref], ['Customer cancelled the order', 300, 700, bad.invoiceNo]);
  eq(voidEntry.void.by, 'Test Admin');
  assert(voidEntry.at === v.voidedAt, 'exact void time');
  eq(prof.entries[1].invoice.status, 'void');
  eq(prof.entries[1].invoice.state, 'void');
  eq(prof.entries.map((e) => e.balance), [0, 700, 0], 'balance rises when the invoice is made and falls when it is voided');
  const raw = await getInvoice(bad.id);
  eq([raw.status, raw.voidReason, raw.voidRefund, raw.voidedBy, raw.rev], ['void', 'Customer cancelled the order', 300, 'Test Admin', 2]);
  assert(raw.voidedAt >= raw.createdAt);
  // the stock rows of the void are linked to the invoice
  const moves = await listMovements({ productId: rice.id });
  const back = moves.find((m) => m.type === 'void');
  eq([back.qty, back.refNo, back.ref], [10, bad.invoiceNo, bad.id]);
  assert(back.reason.includes('Customer cancelled the order'));
  void keep;
});

test('customer profile: date filter, opening / closing balance, period totals and a CSV that survives Bengali text', async () => {
  const { rice } = await shop();
  const c = await saveCustomer({ name: '=cmd|"/c calc"!A1 রহিম', phone: '01999000001' });
  const inv = await sell(c, [line(rice, 4, 100)], { paid: 100 }); // due 300
  await receivePayment({ customerId: c.id, amount: 100, note: 'বিকাশ' });
  const all = await customerProfile(c.id);
  eq(all.entries.length, 2);
  eq(all.period, { from: '', to: '', openingBalance: 0, closingBalance: 200, invoices: 1, sales: 400, paidAtSale: 100, paymentsReceived: 100, returns: 0, voids: 0 });
  const day = today();
  eq((await customerProfile(c.id, { from: day, to: day })).entries.length, 2);
  const none = await customerProfile(c.id, { from: addDays(day, 1), to: addDays(day, 5) });
  eq(none.entries, []);
  eq([none.period.openingBalance, none.period.closingBalance], [200, 200], 'nothing in the range: the balance carries through');
  eq(none.summary.currentDue, 200, 'the summary is always all-time');
  const before = await customerProfile(c.id, { to: addDays(day, -1) });
  eq([before.entries.length, before.period.closingBalance], [0, 0]);
  const csv = customerHistoryToCSV(all);
  const rows = csv.split('\n');
  eq(rows.length, 3);
  assert(rows[1].includes(inv.invoiceNo) && rows[1].includes('Rice 25kg'), 'invoice row');
  assert(rows[2].includes('বিকাশ'), 'Bengali note intact');
  assert(rows[1].includes("'=cmd|"), 'a customer name that starts with = is neutralised, not executable');
  assert(rows[0].startsWith('Customer ID,Customer code,Customer,Phone,Date & time (Asia/Dhaka)'));
  assert(rows[1].includes(dhakaDate(inv.createdAt)), 'Dhaka date in the CSV');
});

// ============================================================================
// 4–5. Stock history
// ============================================================================

test('stock history: a new product records "created" and "opening stock" with exact times, user and ids', async () => {
  const t0 = Date.now();
  const p = await saveProduct({ name: 'Lentils', unit: 'kg', costPrice: 90, defaultPrice: 110, stock: 40 });
  const t1 = Date.now();
  eq(p.code, 'P-0001');
  const rows = (await queryMovements({ productId: p.id })).rows; // newest first
  eq(rows.map((r) => r.type), ['initial', 'created']);
  const [init, created] = rows;
  eq([created.previousStock, created.qty, created.balance], [0, 0, 0]);
  eq([init.previousStock, init.qty, init.balance], [0, 40, 40]);
  eq([init.productId, init.productName, init.productCode, init.userName, init.unitCost], [p.id, 'Lentils', 'P-0001', 'Test Admin', 90]);
  assert(init.userId === auth.user().id, 'attributed to the signed-in user');
  for (const r of rows) {
    assert(r.createdAt >= new Date(t0).toISOString() && r.createdAt <= new Date(t1 + 5).toISOString(), 'a real timestamp from now');
    eq(r.date, dhakaDate(r.createdAt), 'Dhaka calendar day');
  }
  assert(created.createdAt < init.createdAt, 'created comes before opening stock');
  // a product with no opening stock gets just the "created" row
  const empty = await saveProduct({ name: 'Empty', stock: 0 });
  eq((await queryMovements({ productId: empty.id })).rows.map((r) => r.type), ['created']);
  eq((await verifyStockLedger()).problems, []);
});

test('stock history: receive, correct, write-off, sale, void and return each leave a correct, chained row', async () => {
  const { rice, rahim } = await shop(); // stock 100
  await receiveStock({ productId: rice.id, qty: 20, unitCost: 82.5, supplier: 'Karim Mill', batchNo: 'B-77', note: 'PO-1001' }); // 120
  await adjustStock({ productId: rice.id, mode: 'remove', qty: 2, reason: 'count: 2 bags missing' }); // 118
  await writeOffStock({ productId: rice.id, qty: 3, reason: 'rain damage' }); // 115
  const inv = await sell(rahim, [line(rice, 10, 100)], { paid: 1000 }); // 105
  await voidInvoice(inv.id, 'wrong shop'); // 115
  const inv2 = await sell(rahim, [line(rice, 6, 100)], { paid: 0 }); // 109
  const ret = await returnSale({ invoiceId: inv2.id, items: [{ itemId: (await getInvoice(inv2.id)).items[0].id, qty: 2 }], reason: 'damaged bags' }); // 111
  const { movements, check } = await productHistory(rice.id);
  eq(movements.map((m) => m.type), ['return', 'sale', 'void', 'sale', 'damage', 'adjustment', 'receive', 'initial', 'created']);
  eq(movements.map((m) => [m.previousStock, m.qty, m.balance]), [[109, 2, 111], [115, -6, 109], [105, 10, 115], [115, -10, 105], [118, -3, 115], [120, -2, 118], [100, 20, 120], [0, 100, 100], [0, 0, 0]]);
  // every row says what happened, why, who and which document
  const by = (t) => movements.find((m) => m.type === t);
  eq([by('receive').unitCost, by('receive').supplier, by('receive').batchNo, by('receive').reason], [82.5, 'Karim Mill', 'B-77', 'PO-1001']);
  eq([by('damage').reason, by('adjustment').reason], ['rain damage', 'count: 2 bags missing']);
  eq([by('return').refNo, by('return').ref], [ret.returnNo, ret.id]);
  assert(by('return').reason.includes('damaged bags') && by('return').reason.includes(inv2.invoiceNo));
  eq(by('void').refNo, inv.invoiceNo);
  assert(movements.every((m) => m.userName === 'Test Admin' && m.userId && m.createdAt && m.date), 'user + exact time on every row');
  assert(movements.every((m, i, a) => !i || a[i - 1].createdAt > m.createdAt), 'strictly increasing times, listed newest first');
  eq(check, { ok: true, problems: [], untracked: 0, firstRecordedAt: movements.at(-1).createdAt, count: 9 });
  eq((await listProducts())[0].stock, 111, 'the product shows the same stock the history ends on');
  eq((await verifyStockLedger()).problems, []);
  // all-products view: filters
  const all = await queryMovements({});
  assert(all.total >= 9);
  eq((await queryMovements({ type: 'damage' })).rows.length, 1);
  eq((await queryMovements({ search: 'rain' })).rows.map((r) => r.type), ['damage']);
  eq((await queryMovements({ search: inv.invoiceNo })).rows.map((r) => r.type).sort(), ['sale', 'void']);
  eq((await queryMovements({ userId: auth.user().id, productId: rice.id })).total, 9);
  eq((await queryMovements({ userId: 'someone-else' })).total, 0);
  eq((await queryMovements({ from: addDays(today(), 1), to: addDays(today(), 3) })).total, 0);
  eq((await queryMovements({ from: today(), to: today(), productId: rice.id })).total, 9);
  const page = await queryMovements({ productId: rice.id, limit: 4, offset: 4 });
  eq([page.rows.length, page.total], [4, 9]);
  const flow = await queryMovements({ productId: rice.id });
  eq([flow.unitsIn, flow.unitsOut], [132, 21]);
  // CSV
  const csv = movementsToCSV(flow.rows, { cost: true }).split('\n');
  eq(csv.length, 10);
  assert(csv.some((l) => l.includes('Karim Mill') && l.includes('B-77') && l.includes('82.5')));
});

test('stock history is append-only: deleting or editing a product, or correcting stock, never touches old rows', async () => {
  const { rice } = await shop();
  await adjustStock({ productId: rice.id, mode: 'add', qty: 5, reason: 'found' });
  const before = (await dbAll('stockMovements')).filter((m) => m.productId === rice.id);
  eq(before.length, 3);
  await adjustStock({ productId: rice.id, mode: 'set', qty: 90, reason: 'recount' }); // correction = a NEW row
  await saveProduct({ id: rice.id, name: 'Rice 25 kg (renamed)', unit: 'bag', costPrice: 85, defaultPrice: 105, stock: 99999 }); // stock field is ignored on edit
  eq((await listProducts())[0].stock, 90, 'editing a product cannot change its stock');
  const r = await deleteProduct(rice.id);
  eq(r.archived, true);
  const after = (await dbAll('stockMovements')).filter((m) => m.productId === rice.id);
  eq(after.length, 4);
  for (const old of before) eq(after.find((m) => m.id === old.id), old, 'old rows are byte-for-byte unchanged');
  eq((await queryMovements({ productId: rice.id })).total, 4, 'history of an archived product is still readable');
  eq((await verifyStockLedger()).problems, []);
  await adjustStock({ productId: (await saveProduct({ name: 'Other', stock: 1 })).id, mode: 'set', qty: 1 }).then((x) => eq(x.unchanged, true), () => assert(false, 'set to the same value must not fail'));
  eq((await dbAll('stockMovements')).filter((m) => m.type === 'adjustment').length, 2, 'setting the same value writes no row');
});

test('stock: several lines of one product deduct the right total once, with ONE history row', async () => {
  const { rice, rahim } = await shop();
  const inv = await sell(rahim, [line(rice, 2, 100), line(rice, 3, 95), line(rice, 0.5, 100)], { paid: 0 });
  eq((await listProducts()).find((p) => p.id === rice.id).stock, 94.5);
  const sales = (await queryMovements({ productId: rice.id, type: 'sale' })).rows;
  eq(sales.length, 1);
  eq([sales[0].qty, sales[0].previousStock, sales[0].balance, sales[0].refNo], [-5.5, 100, 94.5, inv.invoiceNo]);
  eq((await getInvoice(inv.id)).items.length, 3, 'all three lines are kept on the invoice');
  await voidInvoice(inv.id, 'mistake');
  eq((await listProducts()).find((p) => p.id === rice.id).stock, 100, 'void restores exactly what was taken');
  eq((await verifyStockLedger()).problems, []);
});

test('stock: invalid or impossible changes are refused and leave NO partial rows', async () => {
  const { rice, rahim } = await shop();
  const snapshot = async () => JSON.stringify([(await dbAll('products')).map((p) => [p.id, p.stock]), (await dbAll('stockMovements')).length, (await dbAll('invoices')).length]);
  const before = await snapshot();
  await rejects(() => adjustStock({ productId: rice.id, mode: 'remove', qty: 101 }), /Not enough stock/);
  await rejects(() => writeOffStock({ productId: rice.id, qty: 1000 }), /Not enough stock/);
  await rejects(() => receiveStock({ productId: rice.id, qty: 0 }), /greater than zero/);
  await rejects(() => receiveStock({ productId: rice.id, qty: -5 }), /cannot be negative/);
  await rejects(() => receiveStock({ productId: rice.id, qty: 'abc' }), /must be a number/);
  await rejects(() => receiveStock({ productId: rice.id, qty: 1e12 }), /too large/);
  await rejects(() => receiveStock({ productId: rice.id, qty: 5, unitCost: -1 }), /cannot be negative/);
  await rejects(() => adjustStock({ productId: rice.id, mode: 'explode', qty: 1 }), /Choose how/);
  await rejects(() => adjustStock({ productId: 'nope', mode: 'add', qty: 1 }), /Product not found/);
  await rejects(() => adjustStock({ productId: rice.id, mode: 'set', qty: -3 }), /cannot be negative/);
  // a sale that is too big fails as a WHOLE: no invoice, no stock change, no invoice number used
  await rejects(() => sell(rahim, [line(rice, 60, 100), line(rice, 60, 100)], { paid: 0 }), /Not enough stock for "Rice 25kg" — available 100/);
  await rejects(() => sell(rahim, [line(rice, 1, 100)], { paid: 500 }), /cannot exceed the invoice total/);
  await rejects(() => sell(rahim, [line(rice, 1, 100)], { discount: 500 }), /Discount must be between/);
  await rejects(() => sell(rahim, [line(rice, 1, 'abc')]), /Unit price must be a number/);
  await rejects(() => sell(rahim, [line(rice, 1, -5)]), /Unit price cannot be negative/);
  await rejects(() => sell(rahim, [line(rice, -1, 100)]), /cannot be negative/);
  await rejects(() => sell(rahim, [line(rice, 0.0001, 100)]), /greater than zero/);
  await rejects(() => sell(null, [line(rice, 1, 100)], { paid: 50 }), /Select a customer to sell on credit/);
  eq(await snapshot(), before, 'nothing changed');
  eq((await sell(rahim, [line(rice, 1, 100)], { paid: 100 })).invoiceNo.endsWith('0001'), true, 'the failed attempts did not use up invoice numbers');
});

test('stock history: products that existed before history have NO invented rows; the gap is reported honestly', async () => {
  // a product written the way an older version stored it: stock, but no history at all
  const old = { id: uuid(), name: 'Legacy Sugar', nameLower: 'legacy sugar', sku: '', categoryId: null, unit: 'kg', costPrice: 50, defaultPrice: 60, stock: 7, lowStockLevel: 2, active: true, createdAt: '2025-01-01T00:00:00.000Z', updatedAt: '2025-01-01T00:00:00.000Z' };
  await run(['products'], 'readwrite', (tx) => tx.put('products', old));
  const h0 = await productHistory(old.id);
  eq(h0.movements, [], 'no backdated rows are made up');
  eq([h0.check.ok, h0.check.untracked, h0.check.count], [true, 7, 0]);
  const v = await verifyStockLedger();
  eq(v.untracked, [{ productId: old.id, name: 'Legacy Sugar', untracked: 7 }]);
  eq(v.problems, []);
  // history starts honestly from the first real change
  await receiveStock({ productId: old.id, qty: 3, note: 'delivery' });
  const h1 = await productHistory(old.id);
  eq(h1.movements.length, 1);
  eq([h1.movements[0].previousStock, h1.movements[0].balance], [7, 10]);
  assert(h1.movements[0].createdAt > old.createdAt && h1.movements[0].createdAt >= new Date(Date.now() - 60000).toISOString(), 'dated now, not in the past');
  eq(h1.check.untracked, 7, 'the 7 units that pre-date history are still reported');
});

// ============================================================================
// Returns
// ============================================================================

test('returns: goods go back to stock, the DUE is reduced first, only the rest is refunded, all in history', async () => {
  const { rice, rahim } = await shop();
  const inv = await sell(rahim, [line(rice, 10, 100)], { paid: 400 }); // total 1000, due 600
  const [l] = (await getInvoice(inv.id)).items;
  const r1 = await returnSale({ invoiceId: inv.id, items: [{ itemId: l.id, qty: 2 }], reason: 'torn bags', refundMethod: 'cash' });
  eq([r1.amount, r1.creditApplied, r1.refund, r1.refundMethod, r1.returnNo.startsWith('RET-')], [200, 200, 0, '', true]);
  eq((await listProducts()).find((p) => p.id === rice.id).stock, 92);
  eq((await customerProfile(rahim.id)).summary.currentDue, 400, 'due reduced by the credit');
  // 9 more units than allowed → refused; the rest is refunded in cash once the due is cleared
  await rejects(() => returnSale({ invoiceId: inv.id, items: [{ itemId: l.id, qty: 9 }], reason: 'too many' }), /Only 8 bag of "Rice 25kg" can still be taken back/);
  const r2 = await returnSale({ invoiceId: inv.id, items: [{ itemId: l.id, qty: 8 }], reason: 'cancel the rest', refundMethod: 'bkash' });
  eq([r2.amount, r2.creditApplied, r2.refund, r2.refundMethod], [800, 400, 400, 'bkash']);
  const prof = await customerProfile(rahim.id);
  eq([prof.summary.currentDue, prof.summary.returnsValue, prof.summary.refunds, prof.summary.creditFromReturns], [0, 1000, 400, 600]);
  eq([prof.summary.netPurchases, prof.summary.netPaid, prof.summary.reconciles], [0, 0, true], 'bought 1000, returned 1000; paid 400 and got 400 back');
  eq(prof.entries.filter((e) => e.kind === 'return').map((e) => e.return.returnNo).length, 2);
  eq((await listProducts()).find((p) => p.id === rice.id).stock, 100, 'everything is back in stock');
  await rejects(() => returnSale({ invoiceId: inv.id, items: [{ itemId: l.id, qty: 1 }], reason: 'again' }), /Only 0/);
  eq((await returnableLines(inv.id)).lines[0].remaining, 0);
  eq((await listReturns({ invoiceId: inv.id })).length, 2);
  eq((await verifyStockLedger()).problems, []);
  // the rules around returns
  await rejects(() => voidInvoice(inv.id, 'too late'), /already has returned goods/);
  const other = await sell(rahim, [line(rice, 1, 100)], { paid: 100 });
  await voidInvoice(other.id, 'oops');
  const otherLine = (await getInvoice(other.id)).items[0];
  await rejects(() => returnSale({ invoiceId: other.id, items: [{ itemId: otherLine.id, qty: 1 }], reason: 'x y z' }), /voided invoice cannot have returns/);
  await rejects(() => returnSale({ invoiceId: inv.id, items: [], reason: 'nothing' }), /Choose at least one item/);
  await rejects(() => returnSale({ invoiceId: inv.id, items: [{ itemId: 'ghost', qty: 1 }], reason: 'ghost item' }), /not on this invoice/);
});

test('returns: the invoice discount is shared out so a full return gives back exactly what was charged; walk-in refunds in cash', async () => {
  const { rice, oil, rahim } = await shop();
  const inv = await sell(rahim, [line(rice, 3, 33.33), line(oil, 1, 99.99)], { discount: 17.77, paid: 0 });
  eq([inv.subtotal, inv.total], [199.98, 182.21]);
  const items = (await getInvoice(inv.id)).items;
  const first = await returnSale({ invoiceId: inv.id, items: [{ itemId: items[0].id, qty: 3 }], reason: 'rice back' });
  const second = await returnSale({ invoiceId: inv.id, items: [{ itemId: items[1].id, qty: 1 }], reason: 'oil back' });
  eq(toMinor(first.amount + second.amount), toMinor(inv.total), 'two part-returns add up to exactly the invoice total');
  eq((await customerProfile(rahim.id)).summary.currentDue, 0);
  const walkIn = await sell(null, [line(rice, 2, 100)], { paid: 200 });
  const w = await returnSale({ invoiceId: walkIn.id, items: [{ itemId: (await getInvoice(walkIn.id)).items[0].id, qty: 1 }], reason: 'walk-in return' });
  eq([w.amount, w.creditApplied, w.refund, w.customerId], [100, 0, 100, null]);
});

test('returns: reports show them next to sales; profit and product sales are net of returns', async () => {
  const { rice, rahim } = await shop();
  const inv = await sell(rahim, [line(rice, 10, 100)], { paid: 1000 }); // cost 80 → profit 200
  const [l] = (await getInvoice(inv.id)).items;
  await returnSale({ invoiceId: inv.id, items: [{ itemId: l.id, qty: 4 }], reason: 'quality' });
  const day = await dailyReport(today());
  eq([day.summary.netSales, day.summary.returnsValue, day.summary.netAfterReturns, day.summary.refunds, day.summary.cashCollected], [1000, 400, 600, 400, 600]);
  eq(day.returns.length, 1);
  const profit = await profitReport({ from: today(), to: today() });
  eq([profit.totals.revenue, profit.totals.cost, profit.totals.profit], [600, 480, 120]);
  const ps = await productSalesReport({ from: today(), to: today() });
  eq([ps.rows[0].qty, ps.rows[0].revenue], [6, 600]);
  eq((await dashboard()).todayReturns, 400);
});

test('submitting the same operation twice never duplicates it: sale, payment, return, delivery, product', async () => {
  const { rice, rahim } = await shop();
  // sale — sequential and truly concurrent
  const rid = uuid();
  const one = await sell(rahim, [line(rice, 5, 100)], { paid: 100, requestId: rid });
  const two = await sell(rahim, [line(rice, 5, 100)], { paid: 100, requestId: rid });
  eq([one.id === two.id, one.invoiceNo === two.invoiceNo, two.duplicate, one.duplicate], [true, true, true, undefined]);
  const rid2 = uuid();
  const both = await Promise.all([sell(rahim, [line(rice, 5, 100)], { paid: 0, requestId: rid2 }), sell(rahim, [line(rice, 5, 100)], { paid: 0, requestId: rid2 })]);
  eq(both[0].id === both[1].id, true, 'two simultaneous submits create ONE invoice');
  eq((await queryInvoices({ limit: 50 })).total, 2);
  eq((await listProducts()).find((p) => p.id === rice.id).stock, 90, 'stock was deducted once per sale, not per submit');
  eq((await queryMovements({ productId: rice.id, type: 'sale' })).total, 2);
  const next = await sell(rahim, [line(rice, 1, 100)], { paid: 100 });
  eq(next.invoiceNo.slice(-4), '0003', 'no invoice number was wasted by the duplicates');
  // delivery
  const rcv = uuid();
  await receiveStock({ productId: rice.id, qty: 10, requestId: rcv });
  const again = await receiveStock({ productId: rice.id, qty: 10, requestId: rcv });
  eq(again.duplicate, true);
  eq((await listProducts()).find((p) => p.id === rice.id).stock, 99);
  // return
  const [l] = (await getInvoice(one.id)).items;
  const rr = uuid();
  const r1 = await returnSale({ invoiceId: one.id, items: [{ itemId: l.id, qty: 1 }], reason: 'dup test', requestId: rr });
  const r2 = await returnSale({ invoiceId: one.id, items: [{ itemId: l.id, qty: 1 }], reason: 'dup test', requestId: rr });
  eq([r1.id === r2.id, r2.duplicate], [true, true]);
  eq((await listReturns({ invoiceId: one.id })).length, 1);
  eq((await listProducts()).find((p) => p.id === rice.id).stock, 100);
  // product creation
  const prq = uuid();
  const a = await saveProduct({ name: 'Once', stock: 5, requestId: prq });
  const b = await saveProduct({ name: 'Once', stock: 5, requestId: prq });
  eq(a.id === b.id, true);
  eq((await queryMovements({ productId: a.id })).total, 2);
  // void twice
  await voidInvoice(next.id, 'once');
  await rejects(() => voidInvoice(next.id, 'twice'), /already void/);
  eq((await queryMovements({ productId: rice.id, type: 'void' })).total, 1);
  eq((await verifyStockLedger()).problems, []);
});

test('money stays exact: awkward prices and quantities add up to the paisa, and totals match an independent calculation', async () => {
  const items = [];
  const rows = [[0.333, 99.99], [2.505, 1.1], [7, 19.99], [0.001, 1000], [12.75, 8.8], [3, 0.35], [1.5, 0.01]];
  for (const [i, [qty, price]] of rows.entries()) items.push([await saveProduct({ name: `Item ${i}`, unit: 'kg', stock: 1000, defaultPrice: price }), qty, price]);
  const c = await saveCustomer({ name: 'Exact' });
  const inv = await sell(c, items.map(([p, q, pr]) => line(p, q, pr)), { discount: 0.07, paid: 0.1 });
  const want = rows.reduce((a, [q, p]) => a + (BigInt(Math.round(q * 1000)) * BigInt(Math.round(p * 100)) + 500n) / 1000n, 0n); // BigInt reference, in paisa
  eq(toMinor(inv.subtotal), Number(want));
  eq(toMinor(inv.total), Number(want) - 7);
  eq(toMinor(inv.due), Number(want) - 7 - 10);
  eq((await customerProfile(c.id)).summary.currentDue, inv.due);
  // ten payments of 10 paisa each add up exactly (0.1 × 10 = 1 in floating point is 0.9999999999999999)
  const c2 = await saveCustomer({ name: 'Pennies' });
  await sell(c2, [line(items[0][0], 1, 1)], { paid: 0 });
  for (let i = 0; i < 10; i++) await receivePayment({ customerId: c2.id, amount: 0.1 });
  eq((await customerProfile(c2.id)).summary.currentDue, 0);
  await rejects(() => receivePayment({ customerId: c2.id, amount: 0.01 }), /exceeds the outstanding due \(0\)/);
});

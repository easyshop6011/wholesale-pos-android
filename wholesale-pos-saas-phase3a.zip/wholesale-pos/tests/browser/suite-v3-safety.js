/**
 * suite-v3-safety.js — security, backup & restore, database migration, Google Sheets sync
 * (client + the REAL Code.gs together), receipts / Dhaka time and restart persistence.
 */
import { test, assert, eq, rejects } from './harness.js';
import { saveProduct, asUser } from './helpers.js';
import { TEST_ADMIN } from './env.js';
import { createV2Database, V2_STORE_NAMES } from './legacy-db.js';
import { realScript } from './real-script.js';
import { settings } from '../../js/services/settings.js';
import { auth } from '../../js/services/auth.js';
import { saveCustomer, receivePayment, customerProfile, deleteCustomer, getCustomer, computeBalances } from '../../js/services/customers.js';
import { createInvoice, voidInvoice, getInvoice } from '../../js/services/sales.js';
import { returnSale } from '../../js/services/returns.js';
import { receiveStock, adjustStock, writeOffStock, queryMovements, productHistory, verifyStockLedger } from '../../js/services/inventory.js';
import { deleteProduct, listProducts } from '../../js/services/catalog.js';
import { dailyReport, profitReport, dashboard } from '../../js/services/reports.js';
import { listAudit } from '../../js/services/audit.js';
import { exportDatabase, importDatabase, createBackupFile, backupToDrive, listDriveBackups, serializeBackup } from '../../js/services/backup.js';
import { listSnapshots, getSnapshot, restoreSnapshot, deleteSnapshot } from '../../js/services/autobackup.js';
import { syncNow, getSyncStatus, getSyncLog, getQueue, retryFailed, testConnection, getDeviceId } from '../../js/services/sync.js';
import { openDB, _resetForTests, dbAll, dbGet, SCHEMA } from '../../js/core/db.js';
import { clearCache } from '../../js/core/cache.js';
import { buildReceiptModel } from '../../js/printing/receipt.js';
import { renderReceiptCanvas } from '../../js/printing/receipt-canvas.js';
import { dhakaParts, fmtDhakaTime, dhakaDate } from '../../js/core/datetime.js';
import { uuid } from '../../js/core/utils.js';

const line = (p, qty, unitPrice) => ({ productId: p.id, qty, unitPrice });
const sell = (customer, items, o = {}) => createInvoice({ customerId: customer?.id || null, items, discount: o.discount || 0, paid: o.paid ?? 0, paymentMethod: o.method, requestId: o.requestId }, null);

/** Run `fn` and return the PermissionError / ValidationError message it threw ('' if it did not throw). */
const refusal = async (fn) => {
  try {
    await fn();
    return '';
  } catch (e) {
    return e?.message || 'error';
  }
};

async function books() {
  const rice = await saveProduct({ name: 'Rice 25kg', unit: 'bag', costPrice: 80, defaultPrice: 100, stock: 100 });
  const rahim = await saveCustomer({ name: 'Rahim Traders', phone: '01711000001' });
  const inv = await sell(rahim, [line(rice, 10, 100)], { paid: 400 });
  return { rice, rahim, inv };
}

// ============================================================================
// 7. Security — the SERVICES refuse, not just the buttons
// ============================================================================

test('security: nobody signed in — every sensitive service refuses', async () => {
  const { rice, rahim, inv } = await books();
  await auth.createUser({ username: 'sam', displayName: 'Sam', role: 'employee', password: 'sampass1', pin: '3333' });
  const itemId = (await getInvoice(inv.id)).items[0].id;
  auth.logout();
  const attempts = {
    'create invoice': () => sell(rahim, [line(rice, 1, 100)], { paid: 100 }),
    'void invoice': () => voidInvoice(inv.id, 'sneaky void'),
    'return goods': () => returnSale({ invoiceId: inv.id, items: [{ itemId, qty: 1 }], reason: 'sneaky' }),
    'save product': () => saveProduct({ name: 'Ghost', stock: 1 }),
    'delete product': () => deleteProduct(rice.id),
    'adjust stock': () => adjustStock({ productId: rice.id, mode: 'add', qty: 1 }),
    'receive stock': () => receiveStock({ productId: rice.id, qty: 1 }),
    'write off stock': () => writeOffStock({ productId: rice.id, qty: 1 }),
    'receive stock with garbage input (refused before the input is even looked at)': () => receiveStock({ productId: rice.id, qty: 'abc' }),
    'adjust stock with garbage input': () => adjustStock({ productId: rice.id, mode: 'nonsense', qty: -5 }),
    'read stock history': () => queryMovements({}),
    'save customer': () => saveCustomer({ name: 'Ghost' }),
    'delete customer': () => deleteCustomer(rahim.id),
    'receive payment': () => receivePayment({ customerId: rahim.id, amount: 1 }),
    'customer profile': () => customerProfile(rahim.id),
    'daily report': () => dailyReport('2026-10-30'),
    'profit report': () => profitReport({ from: '2026-10-01', to: '2026-10-30' }),
    dashboard: () => dashboard(),
    'create user': () => auth.createUser({ username: 'evil', role: 'admin', password: 'password1', pin: '1111' }),
    'update user': () => auth.updateUser((auth.user() || {}).id || 'x', { role: 'admin' }),
    'set credentials': () => auth.setCredentials('x', { password: 'hacked123', currentPassword: 'x' }),
    'list users': () => auth.listUsers(),
    'list user names': () => auth.listUserNames(),
    'export backup': () => createBackupFile(),
    'import backup': () => importDatabase('{}'),
    'change settings': () => settings.update({ businessName: 'Hacked' }),
    'read snapshots': () => getSnapshot('x'),
    'restore snapshot': () => restoreSnapshot('x'),
    'delete snapshot': () => deleteSnapshot('x'),
    'read activity log': () => listAudit(),
    'sync queue': () => getQueue(),
    'sync log': () => getSyncLog(),
    'sync test': () => testConnection({ url: 'https://x', token: 'tttt' }),
    'retry sync': () => retryFailed(),
    'drive backup': () => backupToDrive(),
    'drive list': () => listDriveBackups(),
  };
  for (const [name, fn] of Object.entries(attempts)) assert(/sign in/i.test(await refusal(fn)), `"${name}" must refuse when nobody is signed in`);
  // the same holds on the PIN lock screen (the session exists but is locked)
  await auth.login('admin', TEST_ADMIN.password);
  auth.lock();
  for (const name of ['create invoice', 'void invoice', 'save product', 'adjust stock', 'customer profile', 'export backup', 'change settings', 'read activity log', 'list users']) assert(/sign in/i.test(await refusal(attempts[name])), `"${name}" must refuse on the lock screen`);
  eq(auth.can('pos'), false, 'a locked session has no permissions');
  await auth.unlock(TEST_ADMIN.pin);
  eq(await refusal(attempts['create invoice']), '', 'unlocked again: allowed');
  eq((await dbAll('invoices')).length, 2, 'only the one legitimate invoice was added; no refused attempt left a trace');
  // refused attempts are written to the activity log
  const denied = (await listAudit({ limit: 500 })).filter((r) => r.action === 'security.denied');
  assert(denied.length >= 20, `denied attempts are logged (${denied.length})`);
  assert(denied.some((r) => r.target === 'invoices.void'), 'the log says WHAT was attempted');
});

test('security: a cashier can sell but cannot void, return, change stock, see profit, manage users, back up or change settings', async () => {
  const { rice, rahim, inv } = await books();
  await receiveStock({ productId: rice.id, qty: 5, unitCost: 90, supplier: 'Karim Mill' });
  await auth.createUser({ username: 'sam', displayName: 'Sam', role: 'employee', password: 'sampass1', pin: '3333' });
  const itemId = (await getInvoice(inv.id)).items[0].id;
  await asUser('sam', 'sampass1', async () => {
    // allowed
    const mine = await sell(rahim, [line(rice, 1, 100)], { paid: 100 });
    eq(mine.createdByName, 'Sam', 'the sale is recorded under the signed-in user');
    await receivePayment({ customerId: rahim.id, amount: 10 });
    await customerProfile(rahim.id);
    await saveCustomer({ name: 'New walk-in regular' });
    const rows = (await queryMovements({ productId: rice.id })).rows;
    assert(rows.length > 0, 'a cashier may VIEW stock history');
    assert(rows.every((r) => r.unitCost === null), 'but not what the shop paid for the goods');
    // refused
    const must = { 'void invoice': () => voidInvoice(inv.id, 'cashier void'), 'return goods': () => returnSale({ invoiceId: inv.id, items: [{ itemId, qty: 1 }], reason: 'cashier return' }), 'edit product': () => saveProduct({ id: rice.id, name: 'Rice', unit: 'bag', defaultPrice: 1 }), 'delete product': () => deleteProduct(rice.id), 'adjust stock': () => adjustStock({ productId: rice.id, mode: 'set', qty: 1 }), 'receive stock': () => receiveStock({ productId: rice.id, qty: 1 }), 'write off': () => writeOffStock({ productId: rice.id, qty: 1 }), 'delete customer': () => deleteCustomer(rahim.id), 'profit report': () => profitReport({ from: '2026-01-01', to: '2026-12-31' }), 'list users': () => auth.listUsers(), 'create user': () => auth.createUser({ username: 'x1', password: 'password1', pin: '1111' }), 'backup': () => createBackupFile(), 'restore': () => importDatabase('{}'), 'settings': () => settings.update({ businessName: 'Mine now' }), 'activity log': () => listAudit(), 'sync queue': () => getQueue() };
    for (const [name, fn] of Object.entries(must)) assert(/not allowed|Only an administrator/.test(await refusal(fn)), `a cashier must not "${name}"`);
  });
  eq((await getInvoice(inv.id)).status, 'active');
  eq(settings.get('businessName') === 'Mine now', false);
  eq((await queryMovements({ productId: rice.id, type: 'receive' })).rows[0].unitCost, 90, 'the administrator still sees the cost');
});

test('security: a manager can void, return and adjust stock and sees cost — but not settings, backup or users', async () => {
  const { rice, inv } = await books();
  await receiveStock({ productId: rice.id, qty: 5, unitCost: 91, supplier: 'S' });
  await auth.createUser({ username: 'mona', displayName: 'Mona', role: 'manager', password: 'monapass1', pin: '4444' });
  const itemId = (await getInvoice(inv.id)).items[0].id;
  await asUser('mona', 'monapass1', async () => {
    eq((await queryMovements({ productId: rice.id, type: 'receive' })).rows[0].unitCost, 91);
    await adjustStock({ productId: rice.id, mode: 'add', qty: 1, reason: 'found' });
    await returnSale({ invoiceId: inv.id, items: [{ itemId, qty: 1 }], reason: 'manager return' });
    await profitReport({ from: '2026-01-01', to: '2026-12-31' });
    for (const [name, fn] of Object.entries({ settings: () => settings.update({ businessName: 'M' }), backup: () => createBackupFile(), users: () => auth.listUsers(), 'create user': () => auth.createUser({ username: 'x2', password: 'password1', pin: '1111' }), 'delete customer': () => deleteCustomer('x') })) assert(/not allowed|Only an administrator/.test(await refusal(fn)), `a manager must not "${name}"`);
  });
});

test('security: users cannot take over accounts, raise their rights or read secrets', async () => {
  await books();
  const sam = await auth.createUser({ username: 'sam', displayName: 'Sam', role: 'employee', password: 'sampass1', pin: '3333' });
  const adminId = (await auth.listUsers()).find((u) => u.username === 'admin').id;
  await asUser('sam', 'sampass1', async () => {
    await rejects(() => auth.setCredentials(adminId, { password: 'hacked123', currentPassword: 'sampass1' }), /Only an administrator/);
    await rejects(() => auth.setCredentials(adminId, { pin: '9999', currentPassword: 'sampass1' }), /Only an administrator/);
    await rejects(() => auth.updateUser(sam.id, { role: 'admin' }), /Only an administrator/);
    await rejects(() => auth.updateUser(sam.id, { permissions: ['settings'] }), /Only an administrator/);
    await rejects(() => auth.updateUser(adminId, { active: false }), /Only an administrator/);
    await rejects(() => auth.createUser({ username: 'evil', role: 'admin', password: 'password1', pin: '1111' }), /Only an administrator/);
    await rejects(() => auth.listUsers(), /Only an administrator/);
    const names = await auth.listUserNames();
    assert(names.every((n) => Object.keys(n).sort().join() === 'displayName,id'), 'only ids and display names are visible');
    // own credentials need the CURRENT password (a counter left unlocked cannot be hijacked)
    await rejects(() => auth.setCredentials(sam.id, { pin: '5555' }), /current password is required/);
    await rejects(() => auth.setCredentials(sam.id, { pin: '5555', currentPassword: 'wrong-one' }), /not correct/);
    await rejects(() => auth.setCredentials(sam.id, {}), /Enter a new password or PIN/);
    await rejects(() => auth.setCredentials(sam.id, { pin: '12', currentPassword: 'sampass1' }), /PIN/);
    await auth.setCredentials(sam.id, { pin: '5555', currentPassword: 'sampass1' });
  });
  // the PIN really changed, the administrator's password did not
  auth.logout();
  await rejects(() => auth.login('admin', 'hacked123'), /Invalid username or password/);
  const login = await auth.login('admin', TEST_ADMIN.password);
  eq(login.role, 'admin');
  // an administrator may reset someone else's password — after proving who they are
  await rejects(() => auth.setCredentials(sam.id, { password: 'newpass99' }), /current password is required/);
  await auth.setCredentials(sam.id, { password: 'newpass99', currentPassword: TEST_ADMIN.password });
  auth.logout();
  await rejects(() => auth.login('sam', 'sampass1'), /Invalid username or password/);
  eq((await auth.login('sam', 'newpass99')).username, 'sam');
  await auth.unlock('5555').catch(() => {}); // PIN 5555 is the new one; just proving it is accepted below
  auth.lock();
  await auth.unlock('5555');
  // no listing ever exposes hashes
  await asUser('admin', TEST_ADMIN.password, async () => {
    const dump = JSON.stringify(await auth.listUsers());
    for (const leak of ['passHash', 'pinHash', 'salt', 'pbkdf2']) assert(!dump.includes(leak), `user list leaks "${leak}"`);
    // no admin can disable themselves or leave the shop without an administrator
    await rejects(() => auth.updateUser(auth.user().id, { active: false }), /cannot disable your own account/);
    await rejects(() => auth.updateUser(auth.user().id, { role: 'manager' }), /At least one active administrator/);
  });
});

test('security: guessing the confirmation password is throttled just like signing in', async () => {
  await auth.createUser({ username: 'sam', displayName: 'Sam', role: 'employee', password: 'sampass1', pin: '3333' });
  await asUser('sam', 'sampass1', async () => {
    const id = auth.user().id;
    for (let i = 0; i < 5; i++) await rejects(() => auth.setCredentials(id, { pin: '5555', currentPassword: `guess-${i}` }), /not correct/);
    await rejects(() => auth.setCredentials(id, { pin: '5555', currentPassword: 'sampass1' }), /Too many attempts/);
    localStorage.clear(); // the cool-down is cleared here only so the rest of the suite can continue
  });
  const denied = (await listAudit({ limit: 100 })).filter((r) => r.action === 'user.credentials_denied');
  eq(denied.length, 5, 'every failed confirmation is in the activity log');
});

test('security: first-run setup can only ever create ONE administrator, even if started twice at once', async () => {
  const mkInput = (n) => ({ username: `owner${n}`, displayName: `Owner ${n}`, password: 'password1', pin: '1234' });
  const results = await Promise.allSettled([auth.setupAdmin(mkInput(1)), auth.setupAdmin(mkInput(2))]);
  eq(results.filter((r) => r.status === 'fulfilled').length, 1, 'exactly one setup wins');
  assert(/Setup already completed/.test(results.find((r) => r.status === 'rejected').reason.message));
  eq((await dbAll('users')).length, 1);
  await rejects(() => auth.setupAdmin(mkInput(3)), /Setup already completed/);
  // and nobody can use the open setup path to create more users without being an administrator
  auth.logout();
  await rejects(() => auth.createUser({ username: 'sneaky', role: 'admin', password: 'password1', pin: '1111' }), /sign in/i);
}, { bare: true });

// ============================================================================
// 6. Backup & restore
// ============================================================================

const STORES_COMPARED = ['users', 'categories', 'products', 'customers', 'invoices', 'invoiceItems', 'payments', 'stockMovements', 'salesReturns', 'meta'];
const dump = async () => Object.fromEntries(await Promise.all(STORES_COMPARED.map(async (n) => [n, JSON.stringify(await dbAll(n))])));
/** Names of the stores whose contents differ (empty = identical). Keeps failure messages short. */
const diff = (a, b) => STORES_COMPARED.filter((n) => a[n] !== b[n]);
const same = (a, b, msg) => eq(diff(a, b), [], msg || 'every store identical');

async function richBooks() {
  const { rice, rahim, inv } = await books();
  const oil = await saveProduct({ name: 'Soybean Oil', unit: 'btl', costPrice: 700, defaultPrice: 900, stock: 20 });
  const karim = await saveCustomer({ name: 'করিম স্টোর', phone: '01811000002', address: 'চট্টগ্রাম' });
  const second = await sell(karim, [line(oil, 2, 900), line(rice, 5, 100)], { discount: 50, paid: 1000, method: 'bkash' });
  await receivePayment({ customerId: rahim.id, amount: 100, method: 'nagad', note: 'part' });
  await receiveStock({ productId: oil.id, qty: 10, unitCost: 690, supplier: 'ACI', batchNo: 'B1' });
  await writeOffStock({ productId: oil.id, qty: 1, reason: 'leak' });
  await returnSale({ invoiceId: inv.id, items: [{ itemId: (await getInvoice(inv.id)).items[0].id, qty: 3 }], reason: 'torn' });
  await voidInvoice(second.id, 'wrong customer');
  await settings.set({ syncUrl: 'https://script.google.com/macros/s/DEPLOY/exec', syncToken: 'tok-SECRET-123' });
  return { rice, oil, rahim, karim, inv, second };
}

test('backup: a complete round trip restores every history exactly, never exports the sync token and keeps this device\'s own', async () => {
  const { rice } = await richBooks();
  const before = await dump();
  const profileBefore = JSON.stringify((await customerProfile((await dbAll('customers'))[0].id)).entries);
  const file = await createBackupFile();
  assert(!file.text.includes('tok-SECRET-123') && !file.text.includes('"syncToken","value":"tok'), 'the sync token is never written to a backup');
  eq(file.encrypted, false);
  assert(/^pos-backup-\d{4}-\d\d-\d\d-\d{4}\.json$/.test(file.fileName), file.fileName);
  eq(file.counts.salesReturns, 1);
  // change the shop, then restore: everything is back, including stock history and returns
  await sell(null, [line(rice, 1, 100)], { paid: 100 });
  await adjustStock({ productId: rice.id, mode: 'add', qty: 9 });
  await settings.set({ syncToken: 'tok-NEW-999' });
  assert(diff(await dump(), before).length > 0, 'the data was really changed');
  const r = await importDatabase(file.text);
  eq(r.stores.invoices, 2);
  same(await dump(), before, 'every store is exactly as it was when the backup was made');
  eq(JSON.stringify((await customerProfile((await dbAll('customers'))[0].id)).entries), profileBefore, 'customer history is identical');
  eq((await verifyStockLedger()).problems, []);
  eq(settings.get('syncToken'), 'tok-NEW-999', 'the token stays on this device: it is not part of backups');
  const snaps = await listSnapshots();
  assert(snaps.some((s) => s.reason === 'before-restore'), 'a safety copy of the replaced data was kept');
  assert((await listAudit({ limit: 50 })).some((a) => a.action === 'backup.restore'), 'the restore is in the activity log');
});

test('backup: damaged, incomplete or hostile files are refused and the live data is left untouched', async () => {
  await richBooks();
  const good = await exportDatabase();
  const text = JSON.stringify(good);
  const before = await dump();
  const snapsBefore = (await listSnapshots()).length;
  const clone = () => JSON.parse(text);
  const bad = {
    'cut off in the middle': text.slice(0, Math.floor(text.length / 2)),
    'empty file': '',
    'plain text': 'hello',
    'another app': JSON.stringify({ format: 'something-else', version: 1, stores: {} }),
    'no stores': JSON.stringify({ format: 'wholesale-pos-backup', version: 2 }),
    'future version': JSON.stringify({ ...clone(), version: 99 }),
    'missing users': (() => { const o = clone(); delete o.stores.users; return JSON.stringify(o); })(),
    'invoices not a list': (() => { const o = clone(); o.stores.invoices = { a: 1 }; return JSON.stringify(o); })(),
    'duplicate invoice number': (() => { const o = clone(); o.stores.invoices.push({ ...o.stores.invoices[0], id: 'dup-1' }); return JSON.stringify(o); })(),
    'invoice line without invoice': (() => { const o = clone(); o.stores.invoiceItems[0].invoiceId = 'ghost'; return JSON.stringify(o); })(),
    'payment for a missing customer': (() => { const o = clone(); o.stores.payments[0].customerId = 'ghost'; return JSON.stringify(o); })(),
    'wrong money': (() => { const o = clone(); o.stores.invoices[0].total += 1; return JSON.stringify(o); })(),
    'negative quantity': (() => { const o = clone(); o.stores.invoiceItems[0].qty = -1; return JSON.stringify(o); })(),
    'text where a number belongs': (() => { const o = clone(); o.stores.products[0].stock = 'lots'; return JSON.stringify(o); })(),
    'stock history for a missing product': (() => { const o = clone(); o.stores.stockMovements[0].productId = 'ghost'; return JSON.stringify(o); })(),
    'return that does not add up': (() => { const o = clone(); o.stores.salesReturns[0].refund += 5; return JSON.stringify(o); })(),
    'nobody could sign in afterwards': (() => { const o = clone(); o.stores.users.forEach((u) => (u.role = 'employee')); return JSON.stringify(o); })(),
  };
  for (const [name, content] of Object.entries(bad)) {
    const msg = await refusal(() => importDatabase(content));
    assert(/cannot be restored|not valid JSON|not a Wholesale POS backup|newer version|incomplete|damaged/.test(msg), `"${name}" must be refused (got: ${msg || 'accepted!'})`);
    same(await dump(), before, `"${name}": live data must be untouched`);
  }
  eq((await listSnapshots()).length, snapsBefore, 'a refused file does not even trigger a restore (no snapshot churn)');
  eq((await auth.listUsers()).length, 1, 'users still there');
});

test('backup: a restore that fails HALF-WAY is rolled back completely (one transaction)', async () => {
  const { rice } = await richBooks();
  const obj = await exportDatabase();
  // passes every validation rule, but the browser cannot store it: a function cannot be cloned into IndexedDB.
  // It is in the LAST store written, so every earlier store has already been cleared and refilled when it fails.
  obj.stores.salesReturns[0].poison = () => 1;
  await sell(null, [line(rice, 1, 100)], { paid: 100 }); // live data now differs from the backup
  const before = await dump();
  const snaps = (await listSnapshots()).length;
  await rejects(() => importDatabase(obj), /./);
  same(await dump(), before, 'the database is exactly as before — nothing half-applied');
  eq((await listSnapshots()).length, snaps + 1, 'the safety snapshot taken before the attempt is there');
  eq((await verifyStockLedger()).problems, []);
  await sell(null, [line(rice, 1, 100)], { paid: 100 }); // the app keeps working normally
});

test('backup: encrypted files — no plain text, no key in the file, wrong passphrase / tampering refused, right one restores', async () => {
  await richBooks();
  const before = await dump();
  const pass = 'correct horse battery staple';
  const enc = await createBackupFile({ passphrase: pass });
  eq(enc.encrypted, true);
  assert(enc.fileName.endsWith('.enc.json'));
  const env = JSON.parse(enc.text);
  eq(env.format, 'wholesale-pos-backup-encrypted');
  for (const leak of ['Rahim', 'করিম', '01711000001', 'Rice 25kg', 'passHash', 'invoices', pass, 'DEPLOY', 'tok-']) assert(!enc.text.includes(leak), `the encrypted file leaks "${leak}"`);
  assert(!/passphrase|"key"|password/i.test(Object.keys(env).concat(Object.keys(env.kdf), Object.keys(env.cipher)).join()), 'no key material field in the header');
  await sell(null, [line((await dbAll('products'))[0], 1, 100)], { paid: 100 });
  const changed = await dump();
  assert(diff(changed, before).length > 0);
  assert(/encrypted/i.test(await refusal(() => importDatabase(enc.text))), 'asks for the passphrase');
  assert(/Wrong passphrase/.test(await refusal(() => importDatabase(enc.text, { passphrase: 'not the passphrase' }))));
  const flipped = JSON.stringify({ ...env, data: env.data.slice(0, 40) + (env.data[40] === 'A' ? 'B' : 'A') + env.data.slice(41) });
  assert(/Wrong passphrase|damaged/.test(await refusal(() => importDatabase(flipped, { passphrase: pass }))));
  assert(/damaged|supported/.test(await refusal(() => importDatabase(JSON.stringify({ ...env, kdf: { ...env.kdf, iterations: 2e9 } }), { passphrase: pass }))));
  same(await dump(), changed, 'every refusal left the data untouched');
  await importDatabase(enc.text, { passphrase: pass });
  same(await dump(), before, 'the right passphrase restores everything');
  await rejects(() => createBackupFile({ passphrase: 'short' }), /at least 8/);
  // a snapshot can be exported encrypted too, through the same envelope
  assert(JSON.parse(await serializeBackup(await exportDatabase(), pass)).format === 'wholesale-pos-backup-encrypted');
});

test('backup: a backup from the previous release (version 1, no returns, old stock rows) restores and is brought up to date', async () => {
  const { rice } = await richBooks();
  const obj = JSON.parse(JSON.stringify(await exportDatabase()));
  obj.version = 1;
  delete obj.stores.salesReturns;
  // the previous release wrote just "Sale INV-…" / "Void INV-…" as the reason and had no created / return rows
  obj.stores.stockMovements = obj.stores.stockMovements.filter((m) => m.type !== 'created' && m.type !== 'return').map(({ previousStock, date, refNo, userId, productCode, opKey, unitCost, supplier, batchNo, ...old }) => ({ ...old, reason: old.reason.replace(/^(Void \S+): .*$/, '$1') }));
  obj.stores.meta = obj.stores.meta.filter((m) => !/^(seq:customer|seq:product|retseq)/.test(m.key)); // counters that did not exist yet
  for (const c of obj.stores.customers) delete c.code;
  for (const p of obj.stores.products) { delete p.code; delete p.lastMoveAt; }
  for (const i of obj.stores.invoices) { delete i.rev; delete i.requestId; delete i.paymentMethod; }
  // the old release had no returns, so drop the return and make the stock chain match what that release would have stored
  obj.stores.payments.forEach((p) => delete p.method);
  const r = await importDatabase(JSON.stringify(obj));
  assert(Array.isArray(r.warnings), 'the restore reports any notices instead of failing on old-format data');
  const rows = await dbAll('stockMovements');
  assert(rows.length > 0 && rows.every((m) => Number.isFinite(m.previousStock) && m.previousStock + m.qty === m.balance && /^\d{4}-\d\d-\d\d$/.test(m.date)), 'old rows gained previousStock and a Dhaka date, derived from what they already held');
  assert(rows.filter((m) => m.type === 'sale' || m.type === 'void').every((m) => m.refNo), 'invoice numbers recovered from the reason text');
  eq((await dbAll('customers')).map((c) => c.code).sort(), ['C-0001', 'C-0002'], 'short codes were given to restored customers');
  assert((await dbAll('products')).every((p) => /^P-\d{4}$/.test(p.code)));
  eq((await dbAll('salesReturns')).length, 0);
  void rice;
});

test('backup: restoring a file that does not contain the signed-in user signs that user out', async () => {
  await books();
  const file = await createBackupFile();
  const boss = await auth.createUser({ username: 'boss', displayName: 'Boss', role: 'admin', password: 'bosspass1', pin: '7777' });
  auth.logout();
  await auth.login('boss', 'bosspass1');
  eq(auth.user().id, boss.id);
  await importDatabase(file.text); // the backup predates "boss"
  eq(auth.user(), null, 'the signed-in user no longer exists, so the session is closed');
  eq((await auth.loginChoices()).map((u) => u.displayName), ['Test Admin'], 'only the restored user can sign in');
});

// ============================================================================
// 10. Migration from the previous database version
// ============================================================================

test('migration: a version-2 database upgrades to version 3 with every old record intact and no invented history', async () => {
  const admin = await dbAll('users'); // a real user record (valid password hash) from the test environment
  const t = (d, h = '04') => `2026-09-${d}T${h}:00:00.000Z`;
  const legacy = {
    users: admin,
    settings: [{ key: 'businessName', value: 'পুরোনো দোকান' }, { key: 'deviceCode', value: 'B' }],
    meta: [{ key: 'seq:legacy', value: 5 }],
    categories: [{ id: 'cat1', name: 'Grocery', nameLower: 'grocery', createdAt: t('01') }],
    products: [
      { id: 'p1', name: 'Rice 25kg', nameLower: 'rice 25kg', sku: 'R25', categoryId: 'cat1', unit: 'bag', costPrice: 80, defaultPrice: 100, stock: 92, lowStockLevel: 10, active: true, createdAt: t('01'), updatedAt: t('20') },
      { id: 'p2', name: 'বিদ্যমান তেল', nameLower: 'বিদ্যমান তেল', sku: '', categoryId: null, unit: 'btl', costPrice: 700, defaultPrice: 900, stock: 50, lowStockLevel: 5, active: true, createdAt: t('02'), updatedAt: t('02') },
    ],
    customers: [
      { id: 'c1', name: 'Rahim', nameLower: 'rahim', phone: '01711000001', address: '', notes: '', createdAt: t('03'), updatedAt: t('03') },
      { id: 'c2', name: 'করিম', nameLower: 'করিম', phone: '01811000002', address: 'ঢাকা', notes: '', createdAt: t('02', '03'), updatedAt: t('02', '03') },
    ],
    invoices: [
      { id: 'i1', invoiceNo: 'INV-B-260910-0001', date: '2026-09-10', time: '10:00:00', month: '2026-09', createdAt: t('10'), customerId: 'c1', customerName: 'Rahim', customerPhone: '01711000001', subtotal: 1000, discount: 0, total: 1000, paid: 400, due: 600, previousDue: 0, status: 'active', notes: '', createdBy: 'u-old', createdByName: 'Old Cashier', deviceCode: 'B', syncStatus: 'synced', syncAttempts: 0, syncError: '' },
      { id: 'i2', invoiceNo: 'INV-B-260911-0001', date: '2026-09-11', time: '09:30:00', month: '2026-09', createdAt: t('11', '03'), customerId: 'c2', customerName: 'করিম', customerPhone: '01811000002', subtotal: 300, discount: 0, total: 300, paid: 0, due: 300, previousDue: 0, status: 'void', voidReason: '', voidedAt: t('11', '05'), voidedBy: 'Old Cashier', notes: '', createdBy: 'u-old', createdByName: 'Old Cashier', deviceCode: 'B', syncStatus: 'pending', syncAttempts: 1, syncError: 'Timed out' },
    ],
    invoiceItems: [
      { id: 'l1', invoiceId: 'i1', line: 1, productId: 'p1', name: 'Rice 25kg', unit: 'bag', qty: 10, unitPrice: 100, costPrice: 80, total: 1000 },
      { id: 'l2', invoiceId: 'i2', line: 1, productId: 'p1', name: 'Rice 25kg', unit: 'bag', qty: 3, unitPrice: 100, costPrice: 80, total: 300 },
    ],
    payments: [{ id: 'pay1', customerId: 'c1', customerName: 'Rahim', customerPhone: '01711000001', amount: 100, note: 'old payment', date: '2026-09-12', time: '11:00:00', month: '2026-09', createdAt: t('12', '05'), syncStatus: 'pending', syncAttempts: 0, syncError: '' }],
    auditLog: [{ id: 'a1', createdAt: t('10'), action: 'invoice.create', target: 'INV-B-260910-0001', detail: '', userId: 'u-old', userName: 'Old Cashier' }],
    syncLog: [],
    stockMovements: [
      { id: 'm1', productId: 'p1', productName: 'Rice 25kg', type: 'initial', qty: 100, balance: 100, reason: 'Opening stock', ref: null, userName: 'Old Cashier', createdAt: t('01') },
      { id: 'm2', productId: 'p1', productName: 'Rice 25kg', type: 'sale', qty: -10, balance: 90, reason: 'Sale INV-B-260910-0001', ref: 'i1', userName: 'Old Cashier', createdAt: t('10') },
      { id: 'm3', productId: 'p1', productName: 'Rice 25kg', type: 'sale', qty: -3, balance: 87, reason: 'Sale INV-B-260911-0001', ref: 'i2', userName: 'Old Cashier', createdAt: t('11', '03') },
      { id: 'm4', productId: 'p1', productName: 'Rice 25kg', type: 'void', qty: 3, balance: 90, reason: 'Void INV-B-260911-0001', ref: 'i2', userName: 'Old Cashier', createdAt: t('11', '05') },
      { id: 'm5', productId: 'p1', productName: 'Rice 25kg', type: 'adjustment', qty: 2, balance: 92, reason: 'Stock count', ref: null, userName: 'Old Cashier', createdAt: t('20') },
    ],
  };
  eq(Object.keys(legacy).sort(), [...V2_STORE_NAMES].sort(), 'the fixture fills every store of the old schema');
  const original = JSON.parse(JSON.stringify(legacy));

  (await openDB()).close();
  _resetForTests();
  await createV2Database(legacy);
  clearCache();
  await settings.load(); // opening the database runs the upgrade 2 → 3

  const db = await openDB();
  eq(db.version, 3);
  assert(db.objectStoreNames.contains('salesReturns'), 'new store exists');
  const tx = db.transaction(['invoices', 'stockMovements', 'payments'], 'readonly');
  for (const [store, index, unique] of [['invoices', 'requestId', true], ['stockMovements', 'opKey', true], ['stockMovements', 'type', false], ['stockMovements', 'date', false], ['payments', 'requestId', true]]) {
    const ix = tx.objectStore(store).index(index);
    eq([`${store}.${index}`, ix.unique], [`${store}.${index}`, unique]);
  }
  // 1. nothing lost, nothing changed: every ORIGINAL field of every row is still there with the same value
  for (const name of V2_STORE_NAMES) {
    const now = await dbAll(name);
    if (name === 'meta') eq(now.filter((r) => !original.meta.some((o) => o.key === r.key)).map((r) => [r.key, r.value]).sort(), [['seq:customer:B', 2], ['seq:product:B', 2]], 'meta: only the two new code counters were added');
    else eq(now.length, original[name].length, `${name}: same number of records`);
    for (const old of original[name]) {
      const row = now.find((r) => r[SCHEMA[name].keyPath] === old[SCHEMA[name].keyPath]);
      assert(row, `${name}: record kept`);
      for (const [k, v] of Object.entries(old)) eq(row[k], v, `${name}.${old[SCHEMA[name].keyPath]}.${k}`);
    }
  }
  // 2. stock rows gained only facts derived from what they already held
  const mv = Object.fromEntries((await dbAll('stockMovements')).map((m) => [m.id, m]));
  eq([mv.m1.previousStock, mv.m2.previousStock, mv.m3.previousStock, mv.m4.previousStock, mv.m5.previousStock], [0, 100, 90, 87, 90]);
  eq([mv.m2.date, mv.m3.date, mv.m1.date], ['2026-09-10', '2026-09-11', '2026-09-01'], 'Dhaka calendar day of the stored time');
  eq([mv.m2.refNo, mv.m4.refNo, mv.m5.refNo], ['INV-B-260910-0001', 'INV-B-260911-0001', undefined], 'invoice number only where the old reason text already said it');
  eq((await dbAll('stockMovements')).length, 5, 'no history rows were invented (not even a "created" row for old products)');
  // 3. short codes, oldest first
  const cust = Object.fromEntries((await dbAll('customers')).map((c) => [c.id, c.code]));
  eq(Object.entries(cust).sort(), [['c1', 'C-B-0002'], ['c2', 'C-B-0001']], 'oldest customer gets 0001');
  eq((await dbAll('products')).map((p) => [p.id, p.code]).sort(), [['p1', 'P-B-0001'], ['p2', 'P-B-0002']]);
  // 4. the app works on the migrated data: balances, reports, sign-in, new sales continue the stock chain
  eq(computeBalances(await dbAll('invoices'), await dbAll('payments'), await dbAll('salesReturns')).get('c1'), 500, 'Rahim owes 600 − 100');
  eq((await dailyReport('2026-09-10')).summary.netSales, 1000);
  eq((await dailyReport('2026-09-11')).summary.invoices, 0, 'the voided invoice still does not count');
  auth.logout();
  eq((await auth.login('admin', TEST_ADMIN.password)).role, 'admin', 'the old user and password still work');
  const hist = await productHistory('p1');
  eq([hist.check.ok, hist.movements.length], [true, 5]);
  const sale = await createInvoice({ customerId: 'c1', items: [{ productId: 'p1', qty: 2, unitPrice: 100 }], paid: 0 }, null);
  const after = (await queryMovements({ productId: 'p1', type: 'sale' })).rows[0];
  eq([after.previousStock, after.balance, after.refNo], [92, 90, sale.invoiceNo]);
  eq((await verifyStockLedger()).problems, []);
  eq((await verifyStockLedger()).untracked, [{ productId: 'p2', name: 'বিদ্যমান তেল', untracked: 50 }], 'stock without any history is reported, not invented');
  // 5. opening the upgraded database again changes nothing (idempotent)
  const snapshot = await dump();
  (await openDB()).close();
  _resetForTests();
  await settings.load();
  same(await dump(), snapshot);
}, { bare: false });

// ============================================================================
// 9. Google Sheets sync — the real client with the REAL Code.gs
// ============================================================================

async function syncReady(script) {
  await settings.set({ syncEnabled: true, syncUrl: 'https://script.google.com/macros/s/TESTDEPLOY/exec', syncToken: 'secret' });
  return (o = {}) => syncNow({ fetchImpl: script.fetch, ...o });
}

test('sync: an invoice voided WHILE it is uploading is not lost — the void reaches the sheet', async () => {
  const script = await realScript();
  const run = await syncReady(script);
  const { inv } = await books();
  let done = false;
  script.hooks.beforeRespond = async (body) => {
    if (body.action === 'syncInvoices' && !done) {
      done = true;
      await voidInvoice(inv.id, 'customer left'); // the cashier voids it while the request is in flight
    }
  };
  await run();
  const row = await getInvoice(inv.id);
  eq([row.status, row.syncStatus, row.rev], ['void', 'synced', 2]);
  eq(script.sheet('Invoices').rows().map((r) => [r[11], r[16], r[17]]), [['Void', 2, 'customer left']], 'the sheet shows the void with its reason');
  eq(script.calls.filter((a) => a === 'syncInvoices').length, 2, 'first the sale, then the void');
  const calls = script.calls.length;
  await run();
  eq(script.calls.filter((a) => a === 'syncInvoices').length, 2, 'nothing left to send');
  assert(script.calls.length >= calls);
});

test('sync: a lost response or a network failure is retried safely — the sheet never gets a duplicate', async () => {
  const script = await realScript();
  const run = await syncReady(script);
  const { rice, rahim } = await books();
  await sell(rahim, [line(rice, 1, 100)], { paid: 100 });
  await receivePayment({ customerId: rahim.id, amount: 50, method: 'bkash' });
  // 1. the server saves the invoices but the answer never arrives
  let lose = true;
  script.hooks.beforeRespond = async (body) => {
    if (body.action === 'syncInvoices' && lose) {
      lose = false;
      throw new TypeError('network dropped after the server saved it');
    }
  };
  const first = await run();
  eq(first.failed, true);
  eq(script.sheet('Invoices').rows().length, 2, 'the server did save them');
  eq((await getSyncStatus()).failed >= 0, true);
  eq((await dbAll('invoices')).every((i) => i.syncStatus === 'pending'), true, 'still marked pending locally');
  // 2. then two plain network failures
  script.fail.times = 2;
  assert((await run()).failed);
  assert((await run()).failed);
  // 3. finally it goes through: the server recognises everything it already has
  const ok = await run();
  eq(ok.failed, false);
  eq(script.sheet('Invoices').rows().length, 2, 'no duplicate rows after all those retries');
  eq((await dbAll('invoices')).every((i) => i.syncStatus === 'synced'), true);
  eq(script.sheet('Payments').rows().length, 1);
  eq(script.sheet('Payments').rows()[0][7], 'bKash', 'payment method reaches the sheet');
  eq((await dbAll('payments')).every((p) => p.syncStatus === 'synced'), true);
  assert(ok.duplicates >= 1, 'the retry was recognised as already-delivered');
});

test('sync: quota errors back off for 30+ minutes, and neither the token nor the script URL ever reaches a log or the screen', async () => {
  const script = await realScript();
  const run = await syncReady(script);
  const { inv } = await books();
  script.fail = { times: 1, message: 'Service invoked too many times for one day: urlfetch. See https://script.google.com/macros/s/AKfycbxLEAKME/exec (token secret)' };
  const out = await run();
  eq(out.failed, true);
  const st = getSyncStatus();
  for (const text of [st.lastError, JSON.stringify(await getSyncLog(20)), JSON.stringify(await dbAll('invoices')), JSON.stringify(await getQueue())]) {
    assert(!text.includes('secret') && !text.includes('AKfycbxLEAKME'), `a secret leaked: ${text.slice(0, 160)}`);
  }
  assert(/\[hidden\]|\[script-url\]/.test(st.lastError), st.lastError);
  assert(Date.parse(st.nextRetryAt) - Date.now() > 29 * 60000, `a quota error waits at least 30 minutes (${st.nextRetryAt})`);
  const skipped = await run({ auto: true });
  eq(skipped.skipped, 'backoff', 'automatic attempts respect the wait');
  assert((await run()).failed === false, 'the manual "Sync now" button still works');
  eq((await getInvoice(inv.id)).syncStatus, 'synced');
});

test('sync: two devices — a reused invoice number is parked as a conflict (others continue); stock written by another device is flagged', async () => {
  const script = await realScript();
  const run = await syncReady(script);
  const { rice, rahim, inv } = await books();
  const other = await sell(rahim, [line(rice, 1, 100)], { paid: 100 });
  // "device B" already uploaded a DIFFERENT invoice that used the same number as our first one
  script.call({ action: 'syncInvoices', invoices: [{ id: 'device-b-invoice', invoiceNo: inv.invoiceNo, date: '2026-10-30', time: '09:00:00', customer: 'Someone', phone: '', status: 'Active', discount: 0, total: 100, paid: 100, due: 0, method: 'Cash', rev: 1, voidReason: '', voidedAt: '', items: [{ name: 'X', qty: 1, unitPrice: 100, total: 100 }] }] });
  await run();
  const a = await getInvoice(inv.id);
  const b = await getInvoice(other.id);
  eq([a.syncStatus, b.syncStatus], ['failed', 'synced'], 'the clashing one is parked, the next one is not blocked');
  assert(/already used by another invoice/.test(a.syncError), a.syncError);
  const q = await getQueue();
  eq(q.length, 1);
  assert(/Invoice number/.test(q[0].error));
  eq(script.sheet('Invoices').rows().filter((r) => r[10] === inv.id).length, 0, 'nothing was written for the clashing invoice');
  // stock: device B overwrites the product row with its own count; our next change is flagged
  const meId = await getDeviceId();
  assert(/^d[0-9a-f]{8}$/.test(meId), 'device id never looks like a number to Sheets');
  eq(await getDeviceId(), meId, 'stable per installation');
  script.call({ action: 'upsertProducts', products: [{ id: rice.id, code: 'P-0001', name: 'Rice 25kg', sku: '', category: '', unit: 'bag', costPrice: 80, defaultPrice: 100, stock: 3, lowStockLevel: 5, status: 'Active', device: 'dOTHER000' }] });
  await adjustStock({ productId: rice.id, mode: 'add', qty: 1, reason: 'local change' });
  await run();
  const s = getSyncStatus();
  eq(s.conflicts, 1);
  assert(/another device/i.test(s.notice), s.notice);
});

test('sync: returns reach the Returns tab once; an older script without returns keeps them queued with a clear notice', async () => {
  const script = await realScript();
  const run = await syncReady(script);
  const { inv } = await books();
  await returnSale({ invoiceId: inv.id, items: [{ itemId: (await getInvoice(inv.id)).items[0].id, qty: 2 }], reason: 'torn', refundMethod: 'bkash' });
  await run();
  eq(script.sheet('Returns').rows().length, 1);
  eq(script.sheet('Returns').rows()[0][11], 200, 'Return Value');
  eq((await dbAll('salesReturns')).every((r) => r.syncStatus === 'synced'), true);
  const calls = script.calls.filter((a) => a === 'syncReturns').length;
  await run();
  eq(script.calls.filter((a) => a === 'syncReturns').length, calls, 'sent once');
  // an old script version: knows invoices and payments, not returns
  const old = await realScript();
  const wrap = old.fetch;
  old.fetch = async (u, init) => (JSON.parse(init.body).action === 'syncReturns' ? { ok: true, status: 200, text: async () => JSON.stringify({ ok: false, error: 'Unknown action: syncReturns' }) } : wrap(u, init));
  await settings.set({ syncUrl: 'https://script.google.com/macros/s/OLD/exec' });
  await returnSale({ invoiceId: inv.id, items: [{ itemId: (await getInvoice(inv.id)).items[0].id, qty: 1 }], reason: 'one more' });
  const res = await syncNow({ fetchImpl: old.fetch });
  eq(res.failed, false, 'the rest of the sync is not blocked');
  assert(/older version.*sales returns/i.test(getSyncStatus().notice), getSyncStatus().notice);
  eq((await dbAll('salesReturns')).filter((r) => r.syncStatus === 'pending').length, 1, 'the return waits until Code.gs is updated');
});

// ============================================================================
// 11. Receipts and Dhaka time   ·   12. Restart
// ============================================================================

const inkHash = async (canvas) => {
  const px = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data;
  let h = 2166136261;
  let ink = 0;
  for (let i = 0; i < px.length; i += 4) {
    const dark = px[i] < 128 ? 1 : 0;
    ink += dark;
    h = Math.imul(h ^ dark, 16777619) >>> 0;
  }
  return { h, ink };
};

test('receipt: Bengali shop, customer and product names are drawn as real glyphs; invoice time is Asia/Dhaka', async () => {
  const invoice = { invoiceNo: 'INV-1', date: '2026-10-05', time: '02:34:09', createdAt: '2026-10-04T20:34:09.000Z', createdByName: 'রহিম', customerName: 'করিম স্টোর', customerPhone: '01711000001', subtotal: 100, discount: 0, total: 100, paid: 100, due: 0, previousDue: 0 };
  const model = (name) => buildReceiptModel(invoice, [{ name, unit: 'কেজি', qty: 1, unitPrice: 100, total: 100 }], { ...settings.all(), businessName: 'আমার দোকান', showPreviousDue: false });
  eq(model('x').meta, { invoiceNo: 'INV-1', date: '2026-10-05', time: '02:34', cashier: 'রহিম' }, 'the receipt shows Dhaka date and time');
  eq(fmtDhakaTime(invoice.createdAt), '02:34');
  const bn1 = await inkHash(await renderReceiptCanvas(model('কলম'), { width: 576 }));
  const bn2 = await inkHash(await renderReceiptCanvas(model('খাতা'), { width: 576 }));
  const en = await inkHash(await renderReceiptCanvas(model('Pen'), { width: 576 }));
  assert(bn1.ink > 1500, `the receipt is not blank (${bn1.ink} dark dots)`);
  assert(bn1.h !== bn2.h, 'two different Bengali words draw differently (real glyphs, not identical empty boxes)');
  assert(bn1.h !== en.h && bn2.h !== en.h);
  const again = await inkHash(await renderReceiptCanvas(model('কলম'), { width: 576 }));
  eq(again.h, bn1.h, 'rendering is deterministic');
  // a real sale made now is stamped with the SHOP's clock, whatever the device zone says
  const { inv } = await books();
  const p = dhakaParts(inv.createdAt);
  eq([inv.date, inv.time, inv.month], [p.date, p.time, p.month]);
  eq(dhakaDate(inv.createdAt), inv.date);
});

test('restart: after the app is closed and reopened every customer history, stock history and setting is still there', async () => {
  const { rice, rahim } = await richBooks();
  const before = await dump();
  const prof = JSON.stringify((await customerProfile(rahim.id)).entries);
  const hist = JSON.stringify((await productHistory(rice.id)).movements);
  const sets = JSON.stringify(settings.all());
  const status = JSON.stringify((await verifyStockLedger()));
  // "restart": drop the connection, forget every cache and in-memory state, read everything from disk again
  (await openDB()).close();
  _resetForTests();
  clearCache();
  auth.logout();
  await settings.load();
  same(await dump(), before, 'everything read back from disk is identical');
  await auth.login('admin', TEST_ADMIN.password);
  eq(JSON.stringify((await customerProfile(rahim.id)).entries), prof);
  eq(JSON.stringify((await productHistory(rice.id)).movements), hist);
  eq(JSON.stringify(settings.all()), sets);
  eq(JSON.stringify(await verifyStockLedger()), status);
  eq((await getCustomer(rahim.id)).code, 'C-0001');
  // the counters carried on: the next invoice number continues, the next code continues
  const next = await sell(rahim, [line(rice, 1, 100)], { paid: 100 });
  eq(next.invoiceNo.slice(-4), '0003');
  eq((await saveCustomer({ name: 'After restart' })).code, 'C-0003');
  void uuid;
});

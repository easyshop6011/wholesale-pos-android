/**
 * suite.js — integration tests for the business logic: invoicing, stock,
 * customers/dues, reports, sync (no duplicates!), backup, auth and printing.
 * Each test starts from an empty database (see env.js).
 */
import { test, assert, eq, rejects } from './harness.js';
import { settings } from '../../js/services/settings.js';
import { saveProduct, saveCategory, deleteProduct, listProducts } from '../../js/services/catalog.js';
import { saveCustomer, receivePayment, customerLedger, listCustomers, deleteCustomer } from '../../js/services/customers.js';
import { createInvoice, getInvoice, listInvoices, voidInvoice, lastPricesFor } from '../../js/services/sales.js';
import { adjustStock, listMovements } from '../../js/services/inventory.js';
import { dashboard, dailyReport, monthlyReport, customerDueReport, productSalesReport, inventoryReport } from '../../js/services/reports.js';
import { syncNow, retryFailed, postToScript } from '../../js/services/sync.js';
import { exportDatabase, importDatabase, validateBackup } from '../../js/services/backup.js';
import { auth } from '../../js/services/auth.js';
import { dbByIndex } from '../../js/core/db.js';
import { dateParts } from '../../js/core/utils.js';
import { TRANSPORTS, printInvoice, sampleInvoice, printModel } from '../../js/printing/printer.js';
import { buildReceiptModel } from '../../js/printing/receipt.js';
import { renderReceiptCanvas } from '../../js/printing/receipt-canvas.js';

const user = { id: 'u1', displayName: 'Tester' };
const today = () => dateParts().date;

/** Seed: one product (stock 10, cost 100, price 120) and one customer. */
async function seed(extra = {}) {
  const product = await saveProduct({ name: 'Rice 25kg', unit: 'bag', costPrice: 100, defaultPrice: 120, stock: 10, lowStockLevel: 5, ...extra });
  const customer = await saveCustomer({ name: 'Rahim Traders', phone: '01711000001' });
  return { product, customer };
}

// ============================================================================
// Invoices
// ============================================================================

test('invoice: totals, due, stock reduction and numbering', async () => {
  const { product, customer } = await seed();
  const inv = await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 3, unitPrice: 125 }], discount: 15, paid: 200 }, user);
  eq([inv.subtotal, inv.discount, inv.total, inv.paid, inv.due], [375, 15, 360, 200, 160], 'money');
  assert(/^INV-\d{6}-0001$/.test(inv.invoiceNo), `invoice number format: ${inv.invoiceNo}`);
  assert(/^\d{4}-\d{2}-\d{2}$/.test(inv.date) && /^\d{2}:\d{2}:\d{2}$/.test(inv.time), 'auto date/time');
  assert(inv.id && inv.id.length >= 32, 'has uuid');
  const p = (await listProducts()).find((x) => x.id === product.id);
  eq(p.stock, 7, 'stock reduced');
  const second = await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 120 }], paid: 120 }, user);
  assert(second.invoiceNo.endsWith('-0002'), 'sequence increments');
  assert(second.id !== inv.id, 'unique ids');
  const loaded = await getInvoice(inv.id);
  eq(loaded.items.length, 1);
  eq(loaded.items[0].total, 375, 'line total = qty × price');
});

test('invoice: fractional quantity and multiple lines', async () => {
  const { product } = await seed();
  const other = await saveProduct({ name: 'Lentils', unit: 'kg', costPrice: 100, defaultPrice: 120, stock: 50 });
  const inv = await createInvoice({ customerId: null, items: [{ productId: product.id, qty: 2.5, unitPrice: 100.4 }, { productId: other.id, qty: 10, unitPrice: 7.25 }], paid: 323.5 }, user);
  eq(inv.items.map((i) => i.total), [251, 72.5], 'line totals');
  eq([inv.total, inv.due], [323.5, 0]);
  eq(inv.customerName, 'Walk-in Customer');
});

test('invoice: line order is preserved when reloaded (receipt + Google Sheets rows)', async () => {
  const names = ['Zeta', 'Alpha', 'Mid', 'Beta', 'Omega', 'Gamma', 'Delta', 'Kappa'];
  const products = [];
  for (const n of names) products.push(await saveProduct({ name: n, unit: 'pc', costPrice: 1, defaultPrice: 2, stock: 100 }));
  const inv = await createInvoice({ items: products.map((p, i) => ({ productId: p.id, qty: i + 1, unitPrice: 2 })), paid: 72 }, user);
  eq((await getInvoice(inv.id)).items.map((i) => i.name), names, 'getInvoice keeps entry order');
  const sent = [];
  await settings.set({ syncEnabled: true, syncUrl: 'https://example.test/exec', syncToken: 't' });
  await syncNow({ fetchImpl: async (_u, o) => { const b = JSON.parse(o.body); sent.push(b); return { ok: true, status: 200, text: async () => JSON.stringify({ ok: true, results: (b.invoices || []).map((i) => ({ id: i.id, result: 'inserted' })) }) }; } });
  eq(sent[0].invoices[0].items.map((i) => i.name), names, 'sheet payload keeps entry order');
});

test('invoice: device code appears in the number', async () => {
  const { product } = await seed();
  await settings.set({ deviceCode: 'B', invoicePrefix: 'SHOP' });
  const inv = await createInvoice({ items: [{ productId: product.id, qty: 1, unitPrice: 1 }], paid: 1 }, user);
  assert(/^SHOP-B-\d{6}-0001$/.test(inv.invoiceNo), inv.invoiceNo);
});

test('invoice: validation rules', async () => {
  const { product, customer } = await seed();
  const line = { productId: product.id, qty: 1, unitPrice: 100 };
  await rejects(() => createInvoice({ items: [] }), /at least one product/);
  await rejects(() => createInvoice({ items: [{ ...line, qty: 0 }] }), /greater than zero/);
  await rejects(() => createInvoice({ items: [{ ...line, unitPrice: -1 }] }), /negative/);
  await rejects(() => createInvoice({ items: [line], discount: 500, paid: 0, customerId: customer.id }), /Discount/);
  await rejects(() => createInvoice({ items: [line], paid: 150 }), /cannot exceed/);
  await rejects(() => createInvoice({ items: [line], paid: 0 }), /Select a customer/, 'credit sale needs customer');
  await rejects(() => createInvoice({ items: [{ ...line, qty: 11 }], paid: 1100 }), /Not enough stock/);
  // none of the failed attempts changed anything
  eq((await listProducts())[0].stock, 10);
  eq((await listInvoices()).length, 0);
  // …and the next successful invoice is still number 0001 (no gaps)
  const ok = await createInvoice({ items: [line], paid: 100 }, user);
  assert(ok.invoiceNo.endsWith('-0001'), ok.invoiceNo);
});

test('invoice: overselling allowed only when the setting is on', async () => {
  const { product } = await seed();
  await settings.set({ allowNegativeStock: true });
  await createInvoice({ items: [{ productId: product.id, qty: 12, unitPrice: 100 }], paid: 1200 }, user);
  eq((await listProducts())[0].stock, -2);
});

test('invoice: void restores stock and removes it from sales and dues', async () => {
  const { product, customer } = await seed();
  const inv = await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 4, unitPrice: 100 }], paid: 100 }, user);
  eq((await listProducts())[0].stock, 6);
  eq((await listCustomers())[0].due, 300);
  await voidInvoice(inv.id, 'wrong customer', user);
  eq((await listProducts())[0].stock, 10, 'stock restored');
  eq((await listCustomers())[0].due, 0, 'due removed');
  eq((await dailyReport(today())).summary.netSales, 0, 'not in sales');
  eq((await getInvoice(inv.id)).syncStatus, 'pending', 're-queued for sync so the sheet shows Void');
  await rejects(() => voidInvoice(inv.id, 'again', user), /already void/);
  const other = await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 100 }], paid: 100 }, user);
  await rejects(() => voidInvoice(other.id, '  ', user), /reason/, 'a reason is required');
  eq((await getInvoice(other.id)).status, 'active', 'a refused void changes nothing');
});

test('invoice: last price per customer hint', async () => {
  const { product, customer } = await seed();
  await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 111 }], paid: 111 }, user);
  await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 118 }], paid: 118 }, user);
  eq((await lastPricesFor(customer.id)).get(product.id), 118);
});

// ============================================================================
// Products, categories, inventory
// ============================================================================

test('products: add, edit, search, category, duplicate name rejected', async () => {
  const cat = await saveCategory({ name: 'Grocery' });
  const p = await saveProduct({ name: 'Sugar 50kg', categoryId: cat.id, unit: 'bag', costPrice: 10, defaultPrice: 12, stock: 5 });
  await saveProduct({ id: p.id, name: 'Sugar 50kg (white)', categoryId: cat.id, unit: 'bag', costPrice: 11, defaultPrice: 13 });
  const found = await listProducts({ search: 'white' });
  eq(found.length, 1);
  eq(found[0].categoryName, 'Grocery');
  eq(found[0].stock, 5, 'editing does not touch stock');
  eq((await listProducts({ categoryId: cat.id })).length, 1);
  await rejects(() => saveProduct({ name: 'sugar 50kg (WHITE)' }), /already exists/);
  await rejects(() => saveCategory({ name: 'grocery' }), /already exists/);
});

test('products: delete ARCHIVES (stock history is never destroyed), sold or not', async () => {
  const { product } = await seed();
  const unused = await saveProduct({ name: 'Unused', stock: 1 });
  eq((await deleteProduct(unused.id)).archived, true, 'it has stock history, so it is kept');
  eq((await listMovements({ productId: unused.id })).map((m) => m.type).sort(), ['created', 'initial'], 'history survives the delete');
  await createInvoice({ items: [{ productId: product.id, qty: 1, unitPrice: 1 }], paid: 1 }, user);
  eq((await deleteProduct(product.id)).archived, true);
  eq((await listProducts()).length, 0, 'hidden from lists');
  eq((await listProducts({ includeInactive: true })).length, 2, 'both kept');
  // the name can be reused once the old product is archived
  await saveProduct({ name: 'Unused', stock: 0 });
});

test('inventory: adjust add / remove / set, logged, cannot go negative', async () => {
  const { product } = await seed();
  await adjustStock({ productId: product.id, mode: 'add', qty: 5, reason: 'delivery' }, user);
  await adjustStock({ productId: product.id, mode: 'remove', qty: 3 }, user);
  await adjustStock({ productId: product.id, mode: 'set', qty: 8, reason: 'count' }, user);
  eq((await listProducts())[0].stock, 8);
  await rejects(() => adjustStock({ productId: product.id, mode: 'remove', qty: 99 }, user), /Not enough stock for "Rice 25kg" — available 8/);
  const log = await listMovements({ productId: product.id });
  eq(log.map((m) => m.type).sort(), ['adjustment', 'adjustment', 'adjustment', 'created', 'initial']);
  eq(log[0].balance, 8);
});

test('inventory: low stock level flagged on dashboard', async () => {
  const { product } = await seed({ lowStockLevel: 8 });
  await createInvoice({ items: [{ productId: product.id, qty: 3, unitPrice: 100 }], paid: 300 }, user); // stock 7 <= 8
  const d = await dashboard();
  eq(d.lowStock.length, 1);
  eq(d.lowStock[0].name, 'Rice 25kg');
});

// ============================================================================
// Customers & dues
// ============================================================================

test('customers: unique phone, search, delete guarded by history', async () => {
  const c = await saveCustomer({ name: 'Karim Store', phone: '+880 1811-000002' });
  await rejects(() => saveCustomer({ name: 'Other', phone: '+8801811000002' }), /already belongs/);
  eq((await listCustomers({ search: '01811' })).length, 1, 'search by partial phone');
  eq((await listCustomers({ search: 'karim' })).length, 1);
  const { product } = await seed();
  await createInvoice({ customerId: c.id, items: [{ productId: product.id, qty: 1, unitPrice: 100 }], paid: 100 }, user);
  await rejects(() => deleteCustomer(c.id), /transaction history/);
});

test('dues: credit sale, payments, ledger with running balance', async () => {
  const { product, customer } = await seed();
  await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 3, unitPrice: 125 }], discount: 15, paid: 200 }, user); // due 160
  eq((await listCustomers())[0].due, 160);
  await receivePayment({ customerId: customer.id, amount: 100, note: 'cash' }, user);
  eq((await listCustomers())[0].due, 60);
  await rejects(() => receivePayment({ customerId: customer.id, amount: 100 }, user), /exceeds/);
  await rejects(() => receivePayment({ customerId: customer.id, amount: 0 }, user), /greater than zero/);
  const ledger = await customerLedger(customer.id);
  eq(ledger.entries.map((e) => e.balance), [160, 60]);
  eq(ledger.balance, 60);
  // the invoice itself is immutable (so the synced sheet row stays valid)
  eq((await listInvoices())[0].due, 160);
});

test('dues: previous due is captured on the next invoice', async () => {
  const { product, customer } = await seed();
  await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 100 }], paid: 0 }, user);
  const second = await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 100 }], paid: 100 }, user);
  eq(second.previousDue, 100);
});

// ============================================================================
// Reports
// ============================================================================

test('reports: daily, monthly, dues, product sales, inventory, dashboard agree', async () => {
  const { product, customer } = await seed();
  await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 3, unitPrice: 125 }], discount: 15, paid: 200 }, user); // total 360 due 160
  await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 2, unitPrice: 120 }], paid: 240 }, user); // total 240
  await receivePayment({ customerId: customer.id, amount: 100 }, user);
  const t = today();

  const d = (await dailyReport(t)).summary;
  eq([d.invoices, d.netSales, d.discount, d.paidAtSale, d.dueCreated, d.paymentsReceived, d.cashCollected], [2, 600, 15, 440, 160, 100, 540], 'daily');

  const m = await monthlyReport(t.slice(0, 7));
  eq([m.totals.invoices, m.totals.sales, m.totals.paymentsReceived], [2, 600, 100], 'monthly');

  const due = await customerDueReport();
  eq([due.rows.length, due.total], [1, 60], 'due report');

  const ps = await productSalesReport({ from: t, to: t });
  eq(ps.rows[0].qty, 5);
  // product revenue is the sum of line totals (3×125 + 2×120 = 615), i.e. BEFORE the invoice-level discount of 15
  eq([ps.totals.revenue, ps.totals.profit], [615, 115], 'product sales (profit = 615 − 5×100)');

  const inv = await inventoryReport();
  eq([inv.rows[0].stock, inv.totals.costValue, inv.totals.retailValue, inv.rows[0].status], [5, 500, 600, 'Low'], 'inventory');

  const dash = await dashboard();
  eq([dash.todaySales, dash.monthSales, dash.totalDue, dash.totalCustomers, dash.totalProducts], [600, 600, 60, 1, 1], 'dashboard');
});

// ============================================================================
// Google Sheets sync (against a faithful fake of the Apps Script contract)
// ============================================================================

/** Fake web app: remembers invoice ids exactly like Code.gs column K does. */
function fakeServer({ failFirstResponses = 0, rejectIds = [] } = {}) {
  const server = { invoices: new Map(), payments: new Set(), calls: 0, rows: 0, lostResponses: failFirstResponses };
  server.fetch = async (url, init) => {
    server.calls++;
    const body = JSON.parse(init.body);
    if (body.token !== 'secret') return mk({ ok: false, error: 'Unauthorized' });
    let out;
    if (body.action === 'ping') out = { ok: true };
    else if (body.action === 'syncInvoices') {
      out = {
        ok: true,
        results: body.invoices.map((i) => {
          if (rejectIds.includes(i.id)) return { id: i.id, result: 'invalid' };
          if (server.invoices.has(i.id)) return { id: i.id, result: 'duplicate' };
          server.invoices.set(i.id, i);
          server.rows += i.items.length; // one sheet row per product line
          return { id: i.id, result: 'inserted' };
        }),
      };
    } else if (body.action === 'syncPayments') {
      out = { ok: true, results: body.payments.map((p) => (server.payments.has(p.id) ? { id: p.id, result: 'duplicate' } : (server.payments.add(p.id), { id: p.id, result: 'inserted' }))) };
    } else out = { ok: false, error: 'unknown' };
    if (server.lostResponses > 0 && body.action !== 'ping') {
      server.lostResponses--;
      throw new TypeError('Failed to fetch'); // server processed it, but the reply never arrived
    }
    return mk(out);
  };
  const mk = (o) => ({ ok: true, status: 200, text: async () => JSON.stringify(o) });
  return server;
}
const pending = async () => (await dbByIndex('invoices', 'syncStatus', 'pending')).length;

async function syncSeed() {
  await settings.set({ syncUrl: 'https://script.google.com/macros/s/X/exec', syncToken: 'secret' });
  const { product, customer } = await seed({ stock: 100 });
  const ids = [];
  for (let i = 0; i < 3; i++) ids.push((await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 100 }, { productId: product.id, qty: 2, unitPrice: 90 }], paid: 280 }, user)).id);
  return { product, customer, ids };
}

test('sync: uploads pending invoices once; second run sends nothing', async () => {
  await syncSeed();
  eq(await pending(), 3);
  const srv = fakeServer();
  const r = await syncNow({ fetchImpl: srv.fetch });
  eq([r.sent, r.failed], [3, false]);
  eq(await pending(), 0);
  eq(srv.rows, 6, '2 lines × 3 invoices');
  const callsAfter = srv.calls;
  await syncNow({ fetchImpl: srv.fetch });
  eq(srv.calls, callsAfter, 'nothing pending => no request at all');
});

test('sync: lost response does NOT create duplicates (server answers "duplicate")', async () => {
  await syncSeed();
  const srv = fakeServer({ failFirstResponses: 1 });
  const first = await syncNow({ fetchImpl: srv.fetch });
  eq(first.failed, true, 'client saw a network error');
  eq(await pending(), 3, 'still pending locally');
  eq(srv.invoices.size, 3, 'but the server already stored them');
  const second = await syncNow({ fetchImpl: srv.fetch });
  eq([second.failed, second.duplicates, second.sent], [false, 3, 0]);
  eq(await pending(), 0);
  eq(srv.rows, 6, 'sheet rows unchanged — no duplicates');
});

test('sync: offline (fetch throws) keeps data pending, recovers later', async () => {
  await syncSeed();
  const offline = async () => { throw new TypeError('Failed to fetch'); };
  const r = await syncNow({ fetchImpl: offline });
  eq(r.failed, true);
  eq(await pending(), 3);
  const srv = fakeServer();
  eq((await syncNow({ fetchImpl: srv.fetch })).sent, 3);
});

test('sync: rejected invoices are flagged failed and can be retried', async () => {
  const { ids } = await syncSeed();
  const srv = fakeServer({ rejectIds: [ids[1]] });
  await syncNow({ fetchImpl: srv.fetch });
  eq((await dbByIndex('invoices', 'syncStatus', 'failed')).map((i) => i.id), [ids[1]]);
  srv.fetch = fakeServer().fetch; // "fixed" server
  eq(await pending(), 0);
});

test('sync: customer payments are uploaded once', async () => {
  const { product, customer } = await syncSeed();
  await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 100 }], paid: 0 }, user); // credit sale => due 100
  const srv = fakeServer();
  await syncNow({ fetchImpl: srv.fetch });
  await receivePayment({ customerId: customer.id, amount: 10 }, user);
  eq((await dbByIndex('payments', 'syncStatus', 'pending')).length, 1);
  await syncNow({ fetchImpl: srv.fetch });
  eq(srv.payments.size, 1);
  eq((await dbByIndex('payments', 'syncStatus', 'pending')).length, 0);
});

test('sync: wrong token and unconfigured state', async () => {
  await syncSeed();
  await settings.set({ syncToken: 'wrong' });
  const r = await syncNow({ fetchImpl: fakeServer().fetch });
  eq(r.failed, true);
  await rejects(() => postToScript('https://x', { token: 'wrong' }, { fetchImpl: fakeServer().fetch }), /Unauthorized/);
  await settings.set({ syncUrl: '' });
  eq(await syncNow({ fetchImpl: fakeServer().fetch }), { sent: 0, duplicates: 0, catalog: 0, failed: false });
});

// ============================================================================
// Backup
// ============================================================================

test('backup: export → modify → import restores the exact earlier state', async () => {
  const { product, customer } = await seed();
  await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 100 }], paid: 100 }, user);
  const backup = JSON.parse(JSON.stringify(await exportDatabase())); // simulate the file round-trip
  await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 2, unitPrice: 100 }], paid: 200 }, user);
  eq((await listInvoices()).length, 2);
  const res = await importDatabase(backup);
  eq(res.stores.invoices, 1);
  eq((await listInvoices()).length, 1);
  eq((await listProducts())[0].stock, 9);
  // numbering continues without clashing
  const next = await createInvoice({ customerId: customer.id, items: [{ productId: product.id, qty: 1, unitPrice: 100 }], paid: 100 }, user);
  assert(next.invoiceNo.endsWith('-0002'), next.invoiceNo);
});

test('backup: rejects foreign / newer / corrupt files before touching data', async () => {
  const { product } = await seed();
  await rejects(() => importDatabase('{"hello":1}'), /not a Wholesale POS backup/);
  await rejects(() => importDatabase({ format: 'wholesale-pos-backup', version: 99, stores: {} }), /newer version/);
  await rejects(() => importDatabase({ format: 'wholesale-pos-backup', version: 1, stores: { evil: [] } }), /Unknown data set/);
  await rejects(() => importDatabase('not json'), /JSON/);
  eq((await listProducts())[0].id, product.id, 'data intact');
  assert(validateBackup(await exportDatabase()));
});

// ============================================================================
// Security
// ============================================================================

test('auth: setup, roles, login, PIN lock, permissions', async () => {
  eq(await auth.needsSetup(), true);
  await auth.setupAdmin({ username: 'owner', displayName: 'Owner', password: 'secret1', pin: '1234' });
  eq(await auth.needsSetup(), false);
  assert(auth.can('reports') && auth.can('settings'), 'admin can do everything');
  await auth.createUser({ username: 'sam', displayName: 'Sam', role: 'employee', password: 'sampass', pin: '4321' });
  await rejects(() => auth.createUser({ username: 'SAM', password: 'sampass', pin: '1111' }), /already taken/);
  await rejects(() => auth.createUser({ username: 'x', password: 'sampass', pin: '1111' }), /Username/);
  await rejects(() => auth.createUser({ username: 'abc', password: '123', pin: '1111' }), /Password/);
  await rejects(() => auth.createUser({ username: 'abc', password: '123456', pin: '12' }), /PIN/);

  auth.logout();
  await rejects(() => auth.login('sam', 'wrong'), /Invalid username or password/);
  await auth.login('sam', 'sampass');
  assert(auth.can('pos') && auth.can('invoices') && auth.can('customers'), 'employee can sell');
  assert(!auth.can('reports') && !auth.can('settings') && !auth.can('products.edit') && !auth.can('inventory.adjust') && !auth.can('invoices.void'), 'employee is restricted');

  auth.lock();
  eq(auth.isLocked(), true);
  await rejects(() => auth.unlock('0000'), /Incorrect PIN/);
  await auth.unlock('4321');
  eq(auth.isLocked(), false);
}, { bare: true });

test('auth: repeated failures trigger a cool-down; last admin cannot be disabled', async () => {
  await auth.setupAdmin({ username: 'owner', displayName: 'Owner', password: 'secret1', pin: '1234' });
  auth.logout();
  for (let i = 0; i < 5; i++) await rejects(() => auth.login('owner', 'nope'), /Invalid/);
  await rejects(() => auth.login('owner', 'secret1'), /Too many attempts/, 'even the right password waits');
  localStorage.clear();
  await auth.login('owner', 'secret1');
  const me = auth.user();
  await rejects(() => auth.updateUser(me.id, { active: false }), /cannot disable your own account/);
  await rejects(() => auth.updateUser(me.id, { role: 'employee' }), /At least one active administrator/, 'the only admin cannot demote themselves');
}, { bare: true });

test('auth: secrets are stored hashed, never in clear text', async () => {
  await auth.setupAdmin({ username: 'owner', displayName: 'Owner', password: 'MyS3cretPass', pin: '9876' });
  const dump = JSON.stringify(await exportDatabase());
  assert(!dump.includes('MyS3cretPass') && !dump.includes('9876'), 'no plain-text secrets in backup');
  assert(dump.includes('pbkdf2'), 'PBKDF2 used');
}, { bare: true });

// ============================================================================
// Receipt + printing
// ============================================================================

test('receipt: raster canvas is 80 mm wide (576 dots) and not blank', async () => {
  const { invoice, items } = sampleInvoice();
  const model = buildReceiptModel(invoice, items, settings.all());
  const canvas = await renderReceiptCanvas(model, { width: 576 });
  eq(canvas.width, 576);
  assert(canvas.height > 400, `receipt height ${canvas.height}`);
  const px = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data;
  let dark = 0;
  for (let i = 0; i < px.length; i += 4) if (px[i] < 100) dark++;
  assert(dark > 2000, `expected printed content, dark pixels = ${dark}`);
});

test('printing: raster job = ESC @ … GS v 0 image … cut; copies repeat the job', async () => {
  const sent = [];
  TRANSPORTS.push({ id: 'fake', label: 'fake', supported: () => true, name: () => 'fake', async connect() {}, async send(b) { sent.push(b); }, disconnect() {} });
  await settings.set({ printTransport: 'fake', printMode: 'raster', cutPaper: true, copies: 1 });
  const { invoice, items } = sampleInvoice();
  await printInvoice(invoice, items);
  const b = sent[0];
  eq([b[0], b[1]], [0x1b, 0x40], 'starts with ESC @');
  const hasRaster = b.some((v, i) => v === 0x1d && b[i + 1] === 0x76 && b[i + 2] === 0x30);
  assert(hasRaster, 'contains GS v 0 raster header');
  eq([...b.slice(-4)], [0x1d, 0x56, 0x42, 0x00], 'ends with partial cut');
  await settings.set({ copies: 2 });
  await printInvoice(invoice, items);
  eq(sent[1].length, b.length * 2, 'two copies');
});

test('printing: text mode produces readable ASCII receipt with totals', async () => {
  const sent = [];
  TRANSPORTS.push({ id: 'fake', label: 'fake', supported: () => true, name: () => 'fake', async connect() {}, async send(b) { sent.push(b); }, disconnect() {} });
  await settings.set({ printTransport: 'fake', printMode: 'text', businessName: 'Acme Wholesale', footer: 'Thanks!' });
  const { invoice, items } = sampleInvoice();
  await printInvoice(invoice, items);
  const text = new TextDecoder('latin1').decode(sent[0]);
  for (const s of ['Acme Wholesale', 'TEST-000001', 'Basmati Rice', 'TOTAL:', 'DUE:', 'Thanks!', 'Tk26,500.00']) assert(text.includes(s), `receipt text should contain "${s}"`);
});

test('printing: a failing printer throws a friendly error and drops the connection', async () => {
  let disconnected = false;
  TRANSPORTS.push({ id: 'fake', label: 'fake', supported: () => true, name: () => 'fake', async connect() {}, async send() { throw new Error('socket closed'); }, disconnect() { disconnected = true; } });
  await settings.set({ printTransport: 'fake', printMode: 'text' });
  const { invoice, items } = sampleInvoice();
  await rejects(() => printInvoice(invoice, items), /Printing failed: socket closed/);
  assert(disconnected, 'transport reset after failure');
});

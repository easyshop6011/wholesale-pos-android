/**
 * cloud.mjs — end-to-end test of the SaaS start-up flow in headless Chromium.
 *
 *   npm run test:e2e:cloud
 *
 * The app runs for real (real DOM, real IndexedDB, real localStorage); only the SERVER is a stand-in:
 * tests/helpers/fake-supabase.mjs answers the Supabase Auth / PostgREST calls. So this proves the screens and the
 * client follow the contract we wrote down — it does NOT prove the real Supabase project behaves the same.
 *
 * Walks through: sign-in screens in Bengali → register → e-mail code (Bengali digits) → business application →
 * waiting → Super Admin (MFA) approves → the POS opens with a per-business local database and a quick-unlock PIN →
 * cold start asks for the PIN → suspension reaches a RUNNING app → rejection with reason, correction, resubmission →
 * Google (PKCE) → e-mail-code sign-in → password reset → two businesses on one browser stay apart → offline start →
 * phone layout.
 */
import { createAppServer } from '../../tools/serve.mjs';
import { loadPlaywright } from './playwright.mjs';
import { createFakeSupabase } from '../helpers/fake-supabase.mjs';

const fake = createFakeSupabase();
const server = createAppServer();
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${server.address().port}`;
const { chromium } = await loadPlaywright();
const browser = await chromium.launch();

const problems = [];
let passed = 0;
const bn = (s) => String(s).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[d]);
const act = (p, name) => p.locator(`[data-act="${name}"]`);
const expect = (ok, msg) => {
  if (!ok) throw new Error(`expected: ${msg}`);
};
async function step(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`✔ ${name}`);
  } catch (e) {
    console.log(`✘ ${name}\n   ${e.stack?.split('\n').slice(0, 4).join('\n   ') || e}`);
    await finish(1);
  }
}
async function finish(code) {
  await browser.close().catch(() => {});
  server.close();
  if (problems.length) {
    console.log(`\nbrowser problems:\n${[...new Set(problems)].join('\n')}`);
    if (!code) code = 1;
  }
  console.log(code ? '\nFAILED' : `\n${passed} steps passed`);
  process.exit(code);
}

/** A fresh browser profile: own localStorage / IndexedDB, the fake server wired in, the cloud switched on. */
async function profile({ viewport = { width: 1280, height: 900 }, watchMs } = {}) {
  const ctx = await browser.newContext({ viewport, serviceWorkers: 'block' });
  await ctx.addInitScript(({ url, key, watchMs: w }) => {
    window.__POS_CLOUD__ = { url, publishableKey: key, ...(w ? { watchMs: w } : {}) };
  }, { url: fake.url, key: fake.key, watchMs });
  await ctx.route(`${fake.url}/**`, fake.routeHandler);
  const page = await ctx.newPage();
  page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
  page.on('console', (m) => m.type() === 'error' && !/Failed to load resource/.test(m.text()) && problems.push(`console: ${m.text()}`));
  return { ctx, page };
}
const toastText = async (p) => (await p.locator('#toast-root').innerText()).trim();
const waitToast = async (p, re) => {
  await p.waitForFunction((src) => new RegExp(src).test(document.querySelector('#toast-root')?.innerText || ''), re.source, { timeout: 8000 });
};
const ALLOWED_LATIN = new Set(['Google', 'Wholesale', 'POS', 'OTP', 'QR', 'Authenticator']);
const latinLeaks = (text, extra = []) => [...text.matchAll(/[A-Za-z]{3,}/g)].map((m) => m[0]).filter((w) => !ALLOWED_LATIN.has(w) && !extra.includes(w));

const OWNER = { email: 'rahman@shop.test', password: 'Str0ngPassw0rd', name: 'আব্দুর রহমান', biz: 'রহমান ট্রেডার্স' };
let owner; // the owner's browser profile
let admin; // the Super Admin's

// =====================================================================================================================
await step('a SECRET / service-role key in the configuration stops the app instead of shipping it', async () => {
  const c = await browser.newContext({ serviceWorkers: 'block' });
  await c.addInitScript(() => {
    window.__POS_CLOUD__ = { url: 'https://x.supabase.co', publishableKey: 'sb_secret_abcdefghijklmnopqrstuvwxyz' };
  });
  const p = await c.newPage();
  await p.goto(base);
  await p.waitForSelector('.auth-card h2');
  expect((await p.locator('.auth-card').innerText()).includes('SECRET key'), 'the refusal is shown');
  expect((await p.locator('[data-act="login-submit"]').count()) === 0, 'no sign-in form is offered');
  await c.close();
});

await step('the sign-in screen is Bengali: Google, password and e-mail-code (OTP), no English leaks', async () => {
  owner = await profile({ watchMs: 700 });
  const p = owner.page;
  await p.goto(base);
  await p.waitForSelector('[data-act="google"]');
  expect((await p.evaluate(() => document.documentElement.lang)) === 'bn', 'html lang is bn');
  const text = await p.locator('.auth-card').innerText();
  expect(text.includes('লগইন') && text.includes('Google দিয়ে চালিয়ে যান') && text.includes('পাসওয়ার্ড ভুলে গেছেন?'), `Bengali login text: ${text}`);
  expect(latinLeaks(text).length === 0, `English words on the login screen: ${latinLeaks(text)}`);
  await p.getByRole('tab', { name: 'ইমেইল কোড (OTP)' }).click();
  await p.waitForSelector('[data-act="otp-send"]');
  expect(latinLeaks(await p.locator('.auth-card').innerText()).length === 0, 'OTP tab has no English leaks');
});

await step('register: weak password and mismatch are refused in Bengali; the e-mailed code (typed in Bengali digits) verifies', async () => {
  const p = owner.page;
  await p.getByRole('tab', { name: 'পাসওয়ার্ড' }).click();
  await act(p, 'register-link').click();
  await p.waitForSelector('[data-act="register-submit"]');
  expect(latinLeaks(await p.locator('.auth-card').innerText()).length === 0, 'register screen has no English leaks');
  await p.fill('[name=fullName]', OWNER.name);
  await p.fill('[name=email]', OWNER.email);
  await p.fill('[name=password]', 'alllowercase1');
  await p.fill('[name=password2]', 'alllowercase1');
  await act(p, 'register-submit').click();
  await waitToast(p, /দুর্বল/);
  await p.fill('[name=password]', OWNER.password);
  await p.fill('[name=password2]', `${OWNER.password}x`);
  await act(p, 'register-submit').click();
  await waitToast(p, /মেলেনি/);
  await p.fill('[name=password2]', OWNER.password);
  await act(p, 'register-submit').click();
  await p.waitForSelector('[data-act="verify-submit"]');
  const text = await p.locator('.auth-card').innerText();
  expect(text.includes(OWNER.email) && text.includes('৬ সংখ্যার'), 'the verify screen names the address');
  expect(latinLeaks(text, ['rahman', 'shop', 'test']).length === 0, `English on verify: ${latinLeaks(text, ['rahman', 'shop', 'test'])}`);
  expect(await act(p, 'resend').isDisabled(), 'resend is disabled during the 60 s wait');
  expect(/[০-৯]/.test(await act(p, 'resend').innerText()), 'the countdown shows Bengali digits');
  await p.fill('[name=code]', '০০০০০০');
  await act(p, 'verify-submit').click();
  await waitToast(p, /ভুল বা মেয়াদোত্তীর্ণ/);
  await p.fill('[name=code]', bn(fake.lastCode(OWNER.email, 'signup')));
  await act(p, 'verify-submit').click();
  await p.waitForSelector('[data-act="apply-submit"]');
  expect((await p.inputValue('[name=ownerName]')) === OWNER.name, 'the owner name is prefilled from the sign-up');
});

await step('business application: Bengali digits in the phone number are normalised; it waits for approval', async () => {
  const p = owner.page;
  expect(latinLeaks(await p.locator('.auth-card').innerText()).length === 0, 'application form has no English leaks');
  await p.fill('[name=bizName]', OWNER.biz);
  await p.fill('[name=phone]', '০১৭১২-৩৪৫৬৭৮৯৯'); // too long → refused before any request
  await act(p, 'apply-submit').click();
  await waitToast(p, /সঠিক মোবাইল নম্বর/);
  await p.fill('[name=phone]', '০১৭১২-৩৪৫৬৭৮');
  await p.fill('[name=address]', 'ঢাকা');
  await p.fill('[name=district]', 'ঢাকা');
  await act(p, 'apply-submit').click();
  await p.waitForSelector('[data-act="refresh"]');
  const text = await p.locator('.auth-card').innerText();
  expect(text.includes('অনুমোদনের অপেক্ষা') && text.includes(OWNER.biz), 'the waiting screen shows the business');
  expect(latinLeaks(text).length === 0, `English on the waiting screen: ${latinLeaks(text)}`);
  const b = fake.business(OWNER.biz);
  expect(b.status === 'pending' && b.phone === '01712345678', `stored as pending with a normalised phone (${b?.phone})`);
  expect((await p.locator('.shell').count()) === 0, 'the POS is NOT reachable while pending');
});

await step('the Super Admin must pass two-step security before the review panel appears', async () => {
  fake.createUser({ email: 'root@platform.test', password: 'Str0ngPassw0rd' });
  fake.addAdmin('root@platform.test');
  admin = await profile();
  const p = admin.page;
  await p.goto(base);
  await p.fill('[name=email]', 'root@platform.test');
  await p.fill('[name=password]', 'Str0ngPassw0rd');
  await act(p, 'login-submit').click();
  await p.waitForSelector('[data-act="mfa-submit"]');
  expect((await p.locator('.cloud-qr').count()) === 1, 'a QR code is shown');
  expect((await p.locator('[data-secret]').innerText()).length > 8, 'the text key is shown');
  expect((await p.locator('.cloud-admin').count()) === 0, 'no admin powers before MFA');
  const mfaText = await p.evaluate(() => {
    const c = document.querySelector('.auth-card').cloneNode(true);
    c.querySelector('[data-secret]')?.remove(); // the authenticator key itself is data, not wording
    return c.textContent;
  });
  expect(latinLeaks(mfaText).length === 0, `MFA screen has English words: ${latinLeaks(mfaText)}`);
  await p.fill('[name=code]', '000000');
  await act(p, 'mfa-submit').click();
  await waitToast(p, /নিরাপত্তা কোডটি ভুল/);
  await p.fill('[name=code]', bn(fake.totpCode));
  await act(p, 'mfa-submit').click();
  await p.waitForSelector('.cloud-admin');
  await p.waitForSelector(`.cloud-biz[data-business="${OWNER.biz}"]`);
  const card = await p.locator(`.cloud-biz[data-business="${OWNER.biz}"]`).innerText();
  expect(card.includes(OWNER.email) && card.includes('01712345678'.replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[d])), `the card shows owner e-mail and phone in Bengali digits: ${card}`);
});

await step('the Super Admin approves; the owner presses refresh and the POS opens with its own local database', async () => {
  const pa = admin.page;
  await pa.locator(`.cloud-biz[data-business="${OWNER.biz}"] [data-act="approve"]`).click();
  await pa.locator('#modal-root button.btn-primary').click();
  await waitToast(pa, /অনুমোদন করা হয়েছে/);
  await pa.waitForSelector('[data-empty]');
  await pa.getByRole('tab', { name: 'অনুমোদিত', exact: true }).click();
  await pa.waitForSelector(`.cloud-biz[data-business="${OWNER.biz}"]`);

  const p = owner.page;
  await act(p, 'refresh').click();
  await p.waitForSelector('.shell', { timeout: 15000 });
  await p.waitForSelector('input[name=pin]'); // the quick-unlock PIN is asked once
  await p.fill('[name=pin]', '১২৩৪৫৬');
  await p.fill('[name=pin2]', '১২৩৪৫৭');
  await act(p, 'pin-submit').click();
  await waitToast(p, /পিন মেলেনি/);
  await p.fill('[name=pin2]', '১২৩৪৫৬');
  await act(p, 'pin-submit').click();
  await p.waitForSelector('input[name=pin]', { state: 'detached' });

  const id = fake.business(OWNER.biz).id;
  const dbs = (await p.evaluate(() => indexedDB.databases())).map((d) => d.name);
  expect(dbs.includes(`wholesale-pos:${id}`), `the business has its own database: ${dbs}`);
  expect(!dbs.includes('wholesale-pos'), 'the shared classic database was not touched');
  const me = await p.evaluate(async () => {
    const { auth } = await import('/js/services/auth.js');
    const { settings } = await import('/js/services/settings.js');
    return { role: auth.user().role, name: auth.user().displayName, pin: auth.needsPin(), biz: settings.get('businessName') };
  });
  expect(me.role === 'admin' && me.name === OWNER.name && !me.pin && me.biz === OWNER.biz, `local session comes from the server's answer: ${JSON.stringify(me)}`);
});

await step('a cold start asks for the PIN (shared counter); a wrong PIN stays locked', async () => {
  const p = owner.page;
  await p.reload();
  await p.waitForSelector('.keypad', { timeout: 15000 });
  await p.keyboard.type('111111');
  await p.keyboard.press('Enter');
  await p.waitForTimeout(500);
  expect((await p.locator('.shell').count()) === 0, 'a wrong PIN does not open the app');
  await p.keyboard.type('123456');
  await p.keyboard.press('Enter');
  await p.waitForSelector('.shell', { timeout: 8000 });
});

await step('"Sign out" in the app ends the cloud session; signing in again needs no PIN screen', async () => {
  const p = owner.page;
  await p.locator('.sidebar .icon-btn[title="Sign out"]').click();
  await p.waitForSelector('[data-act="login-submit"]', { timeout: 15000 });
  expect((await p.evaluate(() => localStorage.getItem('pos:cloud:session'))) === null, 'the cloud session is gone');
  await p.fill('[name=email]', OWNER.email);
  await p.fill('[name=password]', 'wrong-password-1A');
  await act(p, 'login-submit').click();
  await waitToast(p, /ইমেইল বা পাসওয়ার্ড সঠিক নয়/);
  await p.fill('[name=password]', OWNER.password);
  await act(p, 'login-submit').click();
  await p.waitForSelector('.shell', { timeout: 15000 });
  expect((await p.locator('.keypad').count()) === 0, 'a fresh sign-in does not ask for the PIN');
});

await step('a suspension reaches the RUNNING app by itself; the reason is shown; reinstating lets the owner back in', async () => {
  const pa = admin.page;
  await pa.getByRole('tab', { name: 'অনুমোদিত', exact: true }).click();
  await pa.waitForSelector(`.cloud-biz[data-business="${OWNER.biz}"] [data-act="suspend"]`);
  await pa.locator(`.cloud-biz[data-business="${OWNER.biz}"] [data-act="suspend"]`).click();
  await pa.fill('#modal-root input', 'ab');
  await pa.locator('#modal-root button.btn-primary').click();
  await waitToast(pa, /কমপক্ষে ৫ অক্ষর/);
  await pa.locator(`.cloud-biz[data-business="${OWNER.biz}"] [data-act="suspend"]`).click();
  await pa.fill('#modal-root input', 'বকেয়া বিরোধ যাচাই চলছে');
  await pa.locator('#modal-root button.btn-primary').click();
  await waitToast(pa, /স্থগিত করা হয়েছে/);

  const p = owner.page; // never touched: the app was running; the periodic check (700 ms here) must notice
  await p.waitForSelector('text=ব্যবসা স্থগিত', { timeout: 15000 });
  const text = await p.locator('.auth-card').innerText();
  expect(text.includes('বকেয়া বিরোধ যাচাই চলছে') && text.includes(OWNER.biz), `the suspended screen explains why: ${text}`);
  expect((await p.locator('.shell').count()) === 0, 'the POS is closed');
  expect(latinLeaks(text).length === 0, `English on the suspended screen: ${latinLeaks(text)}`);

  await pa.getByRole('tab', { name: 'স্থগিত', exact: true }).click();
  await pa.waitForSelector(`.cloud-biz[data-business="${OWNER.biz}"] [data-act="reinstate"]`);
  await pa.locator(`.cloud-biz[data-business="${OWNER.biz}"] [data-act="reinstate"]`).click();
  await pa.locator('#modal-root button.btn-primary').click();
  await waitToast(pa, /আবার চালু করা হয়েছে/);
  await act(p, 'refresh').click();
  await p.waitForSelector('.keypad', { timeout: 15000 }); // the app was restarted by the block → a cold start → PIN screen
  await p.keyboard.type('123456');
  await p.keyboard.press('Enter');
  await p.waitForSelector('.shell', { timeout: 8000 });
});

await step('rejection: reason required, the owner sees it, corrects the details, resubmits, is approved', async () => {
  fake.createUser({ email: 'karim@shop.test', password: 'Str0ngPassw0rd', fullName: 'করিম' });
  const k = await profile();
  const p = k.page;
  await p.goto(base);
  await p.fill('[name=email]', 'karim@shop.test');
  await p.fill('[name=password]', 'Str0ngPassw0rd');
  await act(p, 'login-submit').click();
  await p.waitForSelector('[data-act="apply-submit"]');
  await p.fill('[name=bizName]', 'করিম স্টোর');
  await p.fill('[name=phone]', '01812345678');
  await act(p, 'apply-submit').click();
  await p.waitForSelector('[data-act="refresh"]');

  const pa = admin.page;
  await pa.getByRole('tab', { name: 'অপেক্ষায়', exact: true }).click();
  await pa.waitForSelector('.cloud-biz[data-business="করিম স্টোর"]');
  await pa.locator('.cloud-biz[data-business="করিম স্টোর"] [data-act="reject"]').click();
  await pa.fill('#modal-root input', '');
  await pa.locator('#modal-root button.btn-primary').click();
  await waitToast(pa, /কমপক্ষে ৫ অক্ষর/);
  await pa.locator('.cloud-biz[data-business="করিম স্টোর"] [data-act="reject"]').click();
  await pa.fill('#modal-root input', 'ট্রেড লাইসেন্সের তথ্য নেই');
  await pa.locator('#modal-root button.btn-primary').click();
  await waitToast(pa, /প্রত্যাখ্যান করা হয়েছে/);

  await act(p, 'refresh').click();
  await p.waitForSelector('[data-act="resubmit"]');
  const text = await p.locator('.auth-card').innerText();
  expect(text.includes('ট্রেড লাইসেন্সের তথ্য নেই') && text.includes('আবেদন প্রত্যাখ্যাত'), `the owner sees the reason: ${text}`);
  expect((await p.inputValue('[name=bizName]')) === 'করিম স্টোর', 'the form is prefilled with the application');
  await p.fill('[name=license]', 'TL-2026-77');
  await act(p, 'resubmit').click();
  await p.waitForSelector('text=অনুমোদনের অপেক্ষা');
  expect(fake.business('করিম স্টোর').trade_license === 'TL-2026-77' && fake.business('করিম স্টোর').status === 'pending', 'corrected and pending again');

  await pa.getByRole('tab', { name: 'অপেক্ষায়', exact: true }).click();
  await pa.waitForSelector('.cloud-biz[data-business="করিম স্টোর"] [data-act="approve"]');
  await pa.locator('.cloud-biz[data-business="করিম স্টোর"] [data-act="approve"]').click();
  await pa.locator('#modal-root button.btn-primary').click();
  await waitToast(pa, /অনুমোদন করা হয়েছে/);
  await act(p, 'refresh').click();
  await p.waitForSelector('.shell', { timeout: 15000 });
  await k.ctx.close();
});

await step('two businesses signing in on ONE browser stay apart: separate local databases, separate users', async () => {
  const p = owner.page; // the first owner's browser; now the second owner uses it too
  await p.locator('.sidebar .icon-btn[title="Sign out"]').click();
  await p.waitForSelector('[data-act="login-submit"]', { timeout: 15000 });
  await p.fill('[name=email]', 'karim@shop.test');
  await p.fill('[name=password]', 'Str0ngPassw0rd');
  await act(p, 'login-submit').click();
  await p.waitForSelector('.shell', { timeout: 15000 });
  await p.waitForSelector('input[name=pin]'); // karim has not chosen a PIN on THIS browser yet
  await p.fill('[name=pin]', '2468');
  await p.fill('[name=pin2]', '2468');
  await act(p, 'pin-submit').click();
  await p.waitForSelector('input[name=pin]', { state: 'detached' });

  const a = fake.business(OWNER.biz).id;
  const b = fake.business('করিম স্টোর').id;
  const dbs = (await p.evaluate(() => indexedDB.databases())).map((d) => d.name).sort();
  expect(dbs.includes(`wholesale-pos:${a}`) && dbs.includes(`wholesale-pos:${b}`), `one database per business: ${dbs}`);
  const names = await p.evaluate(async ([x, y]) => {
    const read = (db) => new Promise((res) => {
      const r = indexedDB.open(db);
      r.onsuccess = () => {
        const q = r.result.transaction('users').objectStore('users').getAll();
        q.onsuccess = () => {
          r.result.close();
          res(q.result.map((u) => u.displayName));
        };
      };
    });
    return { a: await read(`wholesale-pos:${x}`), b: await read(`wholesale-pos:${y}`) };
  }, [a, b]);
  expect(names.a.length === 1 && names.a[0] === OWNER.name, `business A's database knows only its own owner: ${names.a}`);
  expect(names.b.length === 1 && names.b[0] === 'করিম', `business B's database knows only its own owner: ${names.b}`);
});

await step('Google sign-in uses PKCE and returns to the app with a clean address bar', async () => {
  const g = await profile();
  const p = g.page;
  await p.goto(base);
  await act(p, 'google').click();
  await p.waitForSelector('[data-act="apply-submit"]', { timeout: 15000 });
  expect(!/[?&]code=/.test(p.url()), `the one-time code is not left in the address bar: ${p.url()}`);
  expect(fake.state.log.includes('POST /auth/v1/token?pkce'), 'the code was exchanged with a verifier');
  expect((await p.evaluate(() => localStorage.getItem('pos:cloud:pkce'))) === null, 'the verifier was used up');
  await g.ctx.close();
});

await step('e-mail-code sign-in: an unknown address looks the same and sends nothing; a known one signs in', async () => {
  fake.createUser({ email: 'otp.user@shop.test', fullName: 'কোড ব্যবহারকারী' });
  const o = await profile();
  const p = o.page;
  await p.goto(base);
  await p.getByRole('tab', { name: 'ইমেইল কোড (OTP)' }).click();
  const before = fake.state.mails.length;
  await p.fill('[name=email]', 'nobody@shop.test');
  await act(p, 'otp-send').click();
  await p.waitForSelector('[data-act="verify-submit"]');
  expect((await p.locator('.auth-card').innerText()).includes('অ্যাকাউন্ট থাকলে'), 'same wording for an unknown address');
  expect(fake.state.mails.length === before, 'nothing was sent to the unknown address');
  await act(p, 'change-email').click();
  await p.getByRole('tab', { name: 'ইমেইল কোড (OTP)' }).click();
  await p.fill('[name=email]', 'otp.user@shop.test');
  await act(p, 'otp-send').click();
  await p.waitForSelector('[data-act="verify-submit"]');
  await p.fill('[name=code]', bn(fake.lastCode('otp.user@shop.test', 'email')));
  await act(p, 'verify-submit').click();
  await p.waitForSelector('[data-act="apply-submit"]');
  await o.ctx.close();
});

await step('password reset: code → new password (mismatch refused) → signed in', async () => {
  fake.createUser({ email: 'forgot@shop.test', password: 'Old0Password1' });
  const f = await profile();
  const p = f.page;
  await p.goto(base);
  await p.fill('[name=email]', 'forgot@shop.test');
  await act(p, 'forgot').click();
  await p.waitForSelector('[data-act="reset-send"]');
  expect((await p.inputValue('[name=email]')) === 'forgot@shop.test', 'the address is carried over');
  await act(p, 'reset-send').click();
  await p.waitForSelector('[data-act="verify-submit"]');
  await p.fill('[name=code]', bn(fake.lastCode('forgot@shop.test', 'recovery')));
  await act(p, 'verify-submit').click();
  await p.waitForSelector('[data-act="newpass-submit"]');
  await p.fill('[name=newPassword]', 'New0Password2');
  await p.fill('[name=password2]', 'New0Password3');
  await act(p, 'newpass-submit').click();
  await waitToast(p, /মেলেনি/);
  await p.fill('[name=password2]', 'New0Password2');
  await act(p, 'newpass-submit').click();
  await p.waitForSelector('[data-act="apply-submit"]');
  expect(fake.user('forgot@shop.test').password === 'New0Password2', 'the password was changed on the server');
  await f.ctx.close();
});

await step('OFFLINE: the app opens from the last verified answer, says so, and the POS works', async () => {
  const p = owner.page; // signed in as karim (approved) on this browser, PIN 2468
  fake.setOffline(true);
  await p.reload();
  await p.waitForSelector('.keypad', { timeout: 15000 });
  await p.keyboard.type('2468');
  await p.keyboard.press('Enter');
  await p.waitForSelector('.shell', { timeout: 8000 });
  const banner = await p.locator('#cloud-banner').innerText();
  expect(banner.includes('অফলাইন'), `the offline notice is shown: ${banner}`);
  fake.setOffline(false);
});

await step('phone layout (390 px): no horizontal scroll on the sign-in, register, application and waiting screens', async () => {
  const ph = await profile({ viewport: { width: 390, height: 844 } });
  const p = ph.page;
  const overflow = () => p.evaluate(() => document.documentElement.scrollWidth - 390);
  await p.goto(base);
  await p.waitForSelector('[data-act="google"]');
  expect((await overflow()) <= 1, `login overflow ${await overflow()}px`);
  await act(p, 'register-link').click();
  await p.waitForSelector('[data-act="register-submit"]');
  expect((await overflow()) <= 1, `register overflow ${await overflow()}px`);
  await act(p, 'login-link').click();
  fake.createUser({ email: 'phone@shop.test', password: 'Str0ngPassw0rd' });
  await p.fill('[name=email]', 'phone@shop.test');
  await p.fill('[name=password]', 'Str0ngPassw0rd');
  await act(p, 'login-submit').click();
  await p.waitForSelector('[data-act="apply-submit"]');
  expect((await overflow()) <= 1, `application overflow ${await overflow()}px`);
  await ph.ctx.close();
});

await finish(0);

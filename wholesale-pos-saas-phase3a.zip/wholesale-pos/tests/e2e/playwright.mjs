/**
 * Locate Playwright: a normal project install first, then NODE_PATH-style
 * global locations. Keeps the tests runnable on CI and on dev machines.
 */
import { createRequire } from 'node:module';

export async function loadPlaywright() {
  const require = createRequire(import.meta.url);
  const candidates = ['playwright', 'playwright-core', '/opt/npm-tools/node_modules/playwright', ...(process.env.PLAYWRIGHT_PATH ? [process.env.PLAYWRIGHT_PATH] : [])];
  for (const c of candidates) {
    try {
      return require(c);
    } catch {
      /* try next */
    }
  }
  throw new Error('Playwright not found. Install it with: npm i -D playwright && npx playwright install chromium');
}

/**
 * smoke.mjs — end-to-end UI test in headless Chromium.
 *
 *   npm run test:e2e            (SHOTS=/some/dir to keep screenshots)
 *
 * Walks through the real screens like a shop owner would: first-run setup →
 * sell products (manual qty + price) → print (fake printer, bytes verified) →
 * invoice history → customer due + payment → reports + CSV → Google Sheets sync
 * (Apps Script emulated at the network layer; duplicates checked) → backup →
 * PIN lock → employee permissions → OFFLINE use (service worker) → phone layout.
 */
import { mkdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadPlaywright } from './playwright.mjs';
import { createAppServer } from '../../tools/serve.mjs';

const ROOT = resolve(fileURLToPath(new URL('../..', import.meta.url)));
const SHOTS = process.env.SHOTS || '';
if (SHOTS) await mkdir(SHOTS, { recursive: true });

// fresh service worker so offline caching is tested against the current files
spawnSync(process.execPath, [join(ROOT, 'tools/gen-sw.mjs')], { stdio: 'ignore' });

const server = createAppServer();
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${server.address().port}`;

const { chromium } = await loadPlaywright();
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
const page = await context.newPage();

const problems = [];
page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
page.on('console', (m) => m.type() === 'error' && !/Failed to load resource/.test(m.text()) && problems.push(`console: ${m.text()}`));

let passed = 0;
async function step(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`✔ ${name}`);
  } catch (e) {
    console.log(`✘ ${name}\n    ${String(e.message).split('\n').slice(0, 6).join('\n    ')}`);
    // what was on screen when it failed (modals + the first lines of the page) — makes a red step diagnosable from the log alone
    const modals = await page.locator('#modal-root').innerText().catch(() => '');
    const inputs = await page.evaluate(() => [...document.querySelectorAll('#modal-root input')].map((i) => `${i.dataset.field || i.type}=${i.value}`)).catch(() => []);
    console.log(`    [on screen] url=${await page.evaluate(() => location.hash).catch(() => '?')} modals="${modals.replace(/\s+/g, ' ').slice(0, 220)}" inputs=${JSON.stringify(inputs)}`);
    if (SHOTS) await page.screenshot({ path: join(SHOTS, `FAIL-${name.replace(/\W+/g, '_')}.png`) }).catch(() => {});
    await finish(1);
  }
}
// Screenshots wait for the page's fade-in to finish and hide transient toasts so the pictures are clean.
async function shot(name) {
  if (!SHOTS) return;
  await page.waitForTimeout(500);
  await page.evaluate(() => document.querySelectorAll('.toast').forEach((t) => (t.style.display = 'none'))).catch(() => {});
  await page.screenshot({ path: join(SHOTS, `${name}.png`), fullPage: false });
}
async function finish(code) {
  await browser.close();
  server.close();
  if (problems.length) console.log(`\nBrowser errors:\n  ${[...new Set(problems)].join('\n  ')}`);
  console.log(`\n${passed} steps passed${code ? ' — FAILED' : ''}`);
  process.exit(code || (problems.length ? 1 : 0));
}
const expect = (cond, msg) => {
  if (!cond) throw new Error(msg);
};
const field = (text) => page.locator('label.field', { hasText: text }).locator('input,select,textarea').first();
const text = (t) => page.getByText(t, { exact: false }).first();
const nav = (hash) => page.evaluate((h) => (location.hash = h), hash);
/** The app auto-focuses the first field of a dialog (after 30 ms) and the new invoice line (after 60 ms). Typing before that lands in the wrong box. */
const settle = () => page.waitForTimeout(200);

// ---- Emulated Google Apps Script (same contract + dedupe as Code.gs) --------
const sheet = { rows: [], invoiceIds: new Set(), paymentIds: new Set(), requests: [] };
await context.route('https://script.google.com/**', async (route) => {
  const body = JSON.parse(route.request().postData() || '{}');
  sheet.requests.push(body.action);
  let out = { ok: false, error: 'bad request' };
  if (body.token !== 'e2e-secret') out = { ok: false, error: 'Unauthorized: wrong or missing token' };
  else if (body.action === 'ping') out = { ok: true, message: 'pong' };
  else if (body.action === 'syncInvoices') {
    out = {
      ok: true,
      results: body.invoices.map((i) => {
        if (sheet.invoiceIds.has(i.id)) return { id: i.id, result: 'duplicate' };
        sheet.invoiceIds.add(i.id);
        i.items.forEach((it, n) => sheet.rows.push([i.invoiceNo, i.date, i.time, i.customer, it.name, it.qty, it.unitPrice, it.total, n ? '' : i.paid, n ? '' : i.due]));
        return { id: i.id, result: 'inserted' };
      }),
    };
  } else if (body.action === 'syncPayments') {
    out = { ok: true, results: body.payments.map((p) => (sheet.paymentIds.has(p.id) ? { id: p.id, result: 'duplicate' } : (sheet.paymentIds.add(p.id), { id: p.id, result: 'inserted' }))) };
  }
  await route.fulfill({ status: 200, contentType: 'text/plain', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(out) });
});

// ============================================================================
await step('first-run setup creates the admin and loads sample data', async () => {
  await page.goto(base);
  await page.waitForSelector('form');
  await field('Business name').fill('Dhaka Wholesale Traders');
  await field('Your name').fill('Irfan');
  await field('Password (min 6)').fill('secret123');
  await field('Repeat password').fill('secret123');
  await field('Quick-unlock PIN').fill('2468');
  await page.locator('label.check input').check();
  await shot('01-setup');
  await page.getByRole('button', { name: /Create account/ }).click();
  await page.waitForSelector('.stats');
  expect(await text("Today's sales").isVisible(), 'dashboard visible');
  await shot('02-dashboard-empty');
});

await step('POS: pick customer + products, type qty and unit price, totals are right', async () => {
  await nav('#/pos');
  await page.getByRole('button', { name: 'Select customer' }).click();
  await page.locator('.pick-row', { hasText: 'Rahim Traders' }).click();
  await settle();
  await page.getByRole('button', { name: /Add product/ }).first().click();
  await page.locator('.pick-row', { hasText: 'Basmati Rice' }).click();
  await settle();
  await page.locator('.line').nth(0).locator('.qty-in').fill('4');
  await page.locator('.line').nth(0).locator('.price-in').fill('2450');
  await page.getByRole('button', { name: /Add product/ }).first().click();
  await page.locator('.pick-row', { hasText: 'Soybean Oil' }).click();
  await settle();
  await page.locator('.line').nth(1).locator('.qty-in').fill('10');
  await page.locator('.line').nth(1).locator('.price-in').fill('880');
  await page.getByLabel('Discount').fill('600');
  await page.getByLabel('Paid amount').fill('10000');
  const grand = await page.locator('.sum-row.grand').innerText();
  const due = await page.locator('.sum-row.due').innerText();
  expect(grand.includes('18,000.00'), `grand total: ${grand}`); // 9800 + 8800 − 600
  expect(due.includes('8,000.00'), `due: ${due}`);
  expect((await page.locator('.line').nth(0).locator('.line-total').innerText()).includes('9,800.00'), 'line total = qty × price');
  await shot('03-pos');
});

await step('Save & Print sends a valid ESC/POS job to the printer', async () => {
  await page.evaluate(async () => {
    const { TRANSPORTS } = await import('/js/printing/printer.js');
    const { settings } = await import('/js/services/settings.js');
    window.__jobs = [];
    TRANSPORTS.push({ id: 'fake', label: 'Fake', supported: () => true, name: () => 'Fake', async connect() {}, async send(b) { window.__jobs.push(Array.from(b.slice(0, 2)).concat(b.length)); }, disconnect() {} });
    await settings.set({ printTransport: 'fake', printMode: 'raster' });
  });
  await page.getByRole('button', { name: /Save & Print/ }).click();
  await page.waitForSelector('.done');
  const no = await page.locator('.done .big').innerText();
  expect(/^INV-\d{6}-0001$/.test(no), `invoice number ${no}`);
  const jobs = await page.evaluate(() => window.__jobs);
  expect(jobs.length === 1 && jobs[0][0] === 0x1b && jobs[0][1] === 0x40 && jobs[0][2] > 5000, `print job: ${JSON.stringify(jobs)}`);
  await page.getByRole('button', { name: 'Preview' }).click();
  await page.waitForSelector('.receipt-canvas');
  await shot('04-receipt-preview');
  if (SHOTS) await page.locator('.receipt-canvas').screenshot({ path: join(SHOTS, 'receipt-80mm.png') });
  await page.keyboard.press('Escape');
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'New sale' }).click();
});

await step('stock was reduced automatically', async () => {
  await nav('#/inventory');
  await page.waitForSelector('.list');
  const t = await page.locator('.list li', { hasText: 'Basmati Rice' }).innerText();
  expect(/76\s*bag/.test(t), `stock text: ${t}`); // 80 − 4
  expect(/Low/.test(await page.locator('.list li', { hasText: 'Ghee 1kg' }).innerText()), 'low-stock badge shown for Ghee');
  await shot('05-inventory');
});

await step('invoice history shows the invoice with pending sync', async () => {
  await nav('#/invoices');
  await page.waitForSelector('tr.click');
  expect((await page.locator('.result-meta').innerText()).includes('1 invoice'), 'result count shown');
  await page.locator('tr.click', { hasText: 'Rahim Traders' }).click();
  await page.waitForSelector('.modal');
  expect((await page.locator('.modal').innerText()).includes('Pending sync'), 'pending badge');
  await shot('06-invoice-detail');
  await page.keyboard.press('Escape');
});

await step('customer profile: totals, due, payment, full history with product lines, date filter', async () => {
  await nav('#/customers');
  await page.locator('tr.click', { hasText: 'Rahim Traders' }).click();
  await page.waitForSelector('[data-stat="due"]');
  const stat = (k) => page.locator(`[data-stat="${k}"]`).innerText();
  expect((await stat('due')).includes('8,000.00'), `due 8,000 (${await stat('due')})`);
  expect(/C-\d{4}/.test(await page.locator('.profile-card h2').innerText()), 'short customer code is shown');
  expect(/^[0-9a-f-]{36}$/.test(await page.locator('[data-field="customer-id"]').innerText()), 'unique customer ID is shown');
  expect((await stat('invoices')).trim() === '1', 'one invoice');
  expect((await page.locator('.hist-entry[data-kind="invoice"]').count()) === 1, 'the sale is in the history');
  // product lines are in the history (expand the invoice)
  await page.locator('.hist-entry[data-kind="invoice"] details summary').click();
  expect((await page.locator('.hist-entry[data-kind="invoice"]').innerText()).includes('Basmati'), 'product names inside the history entry');
  await page.getByRole('button', { name: /Receive payment/ }).click();
  await settle();
  await field('Amount received').fill('3000');
  await field('Paid by').selectOption('bkash');
  await page.getByRole('button', { name: 'Record payment' }).click();
  await page.waitForFunction(() => document.querySelector('[data-stat="due"]')?.innerText.includes('5,000.00'));
  expect((await page.locator('.hist-entry[data-kind="payment"]').count()) === 1, 'the payment is in the history');
  expect((await page.locator('.hist-entry[data-kind="payment"]').innerText()).includes('bKash'), 'payment method shown');
  expect((await page.locator('.hist-entry').first().getAttribute('data-kind')) === 'payment', 'newest first');
  expect((await page.locator('.hist-entry').first().innerText()).includes('Balance after'), 'running balance shown');
  expect(/\d{1,2} \w{3} 20\d\d, \d\d:\d\d:\d\d/.test(await page.locator('.hist-entry').first().innerText()), 'exact date and time with seconds');
  await shot('07-customer');
  await page.locator('.hist-list').scrollIntoViewIfNeeded();
  await shot('07a-customer-history');
  await page.evaluate(() => window.scrollTo(0, 0));
  // date filter: a range in the future has no entries and says so; "All time" brings them back
  await page.locator('input[aria-label="From date"]').fill('2099-01-01');
  await page.locator('input[aria-label="To date"]').fill('2099-01-31');
  await page.getByText('No transactions in this period.').waitFor();
  await page.getByRole('button', { name: 'All time' }).click();
  await page.waitForSelector('.hist-entry');
  expect((await page.locator('.hist-entry').count()) === 2, 'both entries back');
});

await step('customer profile: CSV export and printable statement', async () => {
  const [dl] = await Promise.all([page.waitForEvent('download'), page.locator('[data-action="csv"]').click()]);
  const csv = await (await import('node:fs/promises')).readFile(await dl.path(), 'utf8');
  expect(csv.charCodeAt(0) === 0xfeff, 'CSV starts with a BOM so Excel reads Bengali text');
  expect(/Rahim Traders/.test(csv) && /Basmati/.test(csv) && /Payment received/.test(csv) && /bKash/.test(csv), 'CSV has the invoice line and the payment');
  expect(/Date & time \(Asia\/Dhaka\)/.test(csv.split('\n')[0]), 'CSV header names the time zone');
  // printing: capture what would be printed instead of opening the print dialog
  await page.evaluate(() => { window.__printed = null; window.print = () => { window.__printed = document.querySelector('.print-sheet')?.innerText || 'NO SHEET'; }; });
  await page.locator('[data-action="print"]').click();
  const printed = await page.evaluate(() => window.__printed);
  expect(/Customer statement/.test(printed) && /Rahim Traders/.test(printed) && /Basmati/.test(printed) && /Asia\/Dhaka/.test(printed), `statement content: ${String(printed).slice(0, 120)}`);
});

await step('customer profile: "New sale" opens the POS with that customer already selected', async () => {
  await nav('#/customers');
  await page.locator('tr.click', { hasText: 'Rahim Traders' }).click();
  await page.waitForSelector('[data-stat="due"]');
  await page.getByRole('button', { name: 'New sale' }).click();
  await page.waitForFunction(() => /Rahim Traders/.test(document.querySelector('#view')?.innerText || ''), null, { timeout: 15000 });
  expect(!(await page.locator('#view').innerText()).includes('Walk-in customer'), 'the customer is selected, not walk-in');
  await nav('#/customers'); // leave the POS first — it saves its draft once more when it closes
  await page.waitForSelector('tr.click');
  await page.waitForTimeout(300);
  await page.evaluate(() => localStorage.removeItem('pos:draft')); // leave no half-made sale behind for the next steps
});

await step('reports: overview graphs, sales, customers ageing, products, inventory + CSV export', async () => {
  await nav('#/reports');
  await page.waitForSelector('.kpis');
  await page.waitForSelector('.chart svg');
  expect((await page.locator('.kpis').innerText()).includes('18,000.00'), 'overview sales KPI');
  expect((await page.locator('.delta').count()) > 0, 'comparison badges shown');
  await shot('08a-reports-overview');
  await page.getByRole('tab', { name: 'Customers', exact: true }).click();
  await page.waitForFunction(() => document.body.innerText.includes('Customer dues by age') && document.body.innerText.includes('5,000.00'));
  await page.getByRole('tab', { name: 'Products', exact: true }).click();
  await page.waitForFunction(() => document.body.innerText.includes('Soybean Oil'));
  await page.getByRole('tab', { name: 'Profit', exact: true }).click();
  await page.waitForFunction(() => document.body.innerText.includes('Gross profit'));
  await page.getByRole('tab', { name: 'Busy hours', exact: true }).click();
  await page.waitForSelector('.heat');
  await page.getByRole('tab', { name: 'Staff', exact: true }).click();
  await page.waitForFunction(() => document.body.innerText.includes('Sales by cashier'));
  await page.getByRole('tab', { name: 'Inventory', exact: true }).click();
  await page.waitForFunction(() => document.body.innerText.includes('Re-order suggestions'));
  await shot('08-reports-inventory');
  await page.getByRole('tab', { name: 'Daily sheet', exact: true }).click();
  await page.waitForFunction(() => document.body.innerText.includes('Net sales') && document.body.innerText.includes('18,000.00'));
  await page.getByRole('tab', { name: 'Sales', exact: true }).click();
  await page.waitForSelector('table.table');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: /Export CSV/ }).click()]);
  expect(/sales-(day|week|month)-\d{4}-\d{2}-\d{2}_to_.*\.csv/.test(dl.suggestedFilename()), dl.suggestedFilename());
  const csv = await (await import('node:fs/promises')).readFile(await dl.path(), 'utf8');
  expect(csv.includes('Invoices') && csv.includes('18000'), `csv: ${csv.slice(0, 120)}`);
});

await step('dashboard: trend chart, deltas, top products, 7/30-day switch', async () => {
  await nav('#/dashboard');
  await page.waitForSelector('.chart svg');
  expect((await page.locator('.hbars').count()) >= 1, 'top products bars');
  await page.getByRole('tab', { name: '7 days' }).click();
  await page.waitForSelector('.chart svg rect', { state: 'attached' });
  await shot('08b-dashboard');
});

await step('global search palette finds products, customers and invoices (Ctrl+K)', async () => {
  await page.keyboard.press('Control+k');
  await page.waitForSelector('.palette input');
  await page.locator('.palette input').fill('rahim');
  await page.waitForSelector('.palette-item');
  expect((await page.locator('.palette').innerText()).includes('Rahim Traders'), 'customer found');
  await shot('08c-palette');
  await page.locator('.palette input').fill('basmati');
  await page.waitForFunction(() => document.querySelector('.palette')?.innerText.includes('Basmati'));
  await page.keyboard.press('Enter');
  await page.waitForFunction(() => location.hash.startsWith('#/products'));
  // wait for the CONDITION (the list may repaint once while background sync finishes) instead of sampling once
  await page.waitForFunction(() => document.querySelectorAll('.list li').length >= 1, null, { timeout: 15000 });
});

await step('filters: invoices by payment state, customers with dues', async () => {
  await nav('#/invoices');
  await page.waitForSelector('.filters');
  await page.locator('.filters select[aria-label="Payment"]').selectOption('paid');
  await page.waitForFunction(() => document.body.innerText.includes('No invoices match'));
  await page.locator('.filters select[aria-label="Payment"]').selectOption('due');
  await page.waitForSelector('tr.click');
  expect((await page.locator('.fchip').count()) === 1, 'active filter chip');
  await page.getByRole('button', { name: 'More filters' }).click();
  await shot('08d-invoice-filters');
  await nav('#/customers?due=has');
  await page.waitForSelector('tr.click');
  expect((await page.locator('tr.click').count()) === 1, 'only the customer with a due');
});

await step('Google Sheets sync: uploads once, no duplicates on repeat', async () => {
  await nav('#/settings');
  await page.getByRole('tab', { name: 'Sync', exact: true }).click();
  await page.getByLabel('Google Apps Script Web App URL').fill('https://script.google.com/macros/s/AKfycbxTEST/exec');
  await field('Secret token').fill('e2e-secret');
  await page.getByRole('button', { name: 'Save settings' }).click();
  await page.getByRole('button', { name: 'Test connection' }).click();
  await page.waitForSelector('.toast.success');
  await page.getByRole('button', { name: /Sync now/ }).click();
  await page.waitForFunction(() => document.body.innerText.includes('All synced'), null, { timeout: 15000 });
  expect(sheet.rows.length === 2, `sheet rows: ${sheet.rows.length}`);
  expect(JSON.stringify(sheet.rows[0]) === JSON.stringify(['INV-' + sheet.rows[0][0].slice(4), sheet.rows[0][1], sheet.rows[0][2], 'Rahim Traders', 'Basmati Rice 25kg', 4, 2450, 9800, 10000, 8000]), `row0 ${JSON.stringify(sheet.rows[0])}`);
  expect(sheet.paymentIds.size === 1, 'payment uploaded');
  // force a re-send of the same invoice: server must answer "duplicate" and add no rows
  await page.evaluate(async () => {
    const { dbAll, run } = await import('/js/core/db.js');
    const { syncNow } = await import('/js/services/sync.js');
    const [inv] = await dbAll('invoices');
    await run(['invoices'], 'readwrite', (tx) => tx.put('invoices', { ...inv, syncStatus: 'pending' }));
    window.__second = await syncNow();
  });
  expect((await page.evaluate(() => window.__second)).duplicates === 1, 'server reported duplicate');
  expect(sheet.rows.length === 2, 'no duplicate rows');
  await shot('09-sync');
});

await step('sync health: queue empty, verify uploads, recent runs listed', async () => {
  const text = await page.locator('#view').innerText();
  expect(text.includes('Sync health') && text.includes('Recent sync runs'), 'health panel');
  await page.getByRole('button', { name: 'Verify uploads' }).click();
  await page.waitForSelector('.toast');
});

await step('backup: export as a plain file, and as an ENCRYPTED file (no readable data, no key inside)', async () => {
  await page.getByRole('tab', { name: 'Backup', exact: true }).click();
  const fs = await import('node:fs/promises');
  // plain: switch the encryption box off
  await page.getByRole('button', { name: /Export database/ }).click();
  await settle();
  await page.locator('[data-field="encrypt"]').uncheck();
  let [dl] = await Promise.all([page.waitForEvent('download'), page.locator('[data-action="confirm-passphrase"]').click()]);
  const plain = JSON.parse(await fs.readFile(await dl.path(), 'utf8'));
  expect(plain.format === 'wholesale-pos-backup' && plain.version === 2 && plain.stores.invoices.length === 1 && plain.stores.users.length === 1, 'backup content');
  expect(!JSON.stringify(plain).includes('e2e-secret'), 'the sync token is never in a backup');
  // encrypted
  await page.getByRole('button', { name: /Export database/ }).click();
  await settle();
  await page.locator('[data-field="passphrase"]').fill('short');
  await page.locator('[data-field="passphrase2"]').fill('short');
  await page.locator('[data-action="confirm-passphrase"]').click();
  await page.waitForFunction(() => document.querySelector('[data-field="pass-error"]')?.textContent.includes('at least 8'));
  await page.locator('[data-field="passphrase"]').fill('my shop passphrase 2026');
  await page.locator('[data-field="passphrase2"]').fill('my shop passphrase 2026');
  await shot('09f-backup-encrypt-dialog');
  [dl] = await Promise.all([page.waitForEvent('download'), page.locator('[data-action="confirm-passphrase"]').click()]);
  const raw = await fs.readFile(await dl.path(), 'utf8');
  expect(dl.suggestedFilename().endsWith('.enc.json'), `file name ${dl.suggestedFilename()}`);
  const env = JSON.parse(raw);
  expect(env.format === 'wholesale-pos-backup-encrypted' && env.cipher.name === 'AES-GCM' && env.kdf.name === 'PBKDF2', 'encrypted envelope');
  expect(!/Rahim|Basmati|my shop passphrase|invoices|passHash/.test(raw), 'nothing readable and no passphrase in the file');
});

await step('automatic backup: snapshot is taken, listed and can be restored from the list', async () => {
  await page.getByRole('button', { name: /Take a snapshot now/ }).click();
  await page.waitForSelector('.snap-row');
  expect((await page.locator('.snap-row').first().innerText()).includes('1 invoices'), 'snapshot counts');
  expect((await page.locator('#view').innerText()).includes('Automatic backup'), 'auto backup card');
  await shot('09b-backup');
});

await step('appearance: dark theme and compact density apply instantly', async () => {
  await page.getByRole('tab', { name: 'Appearance', exact: true }).click();
  await page.getByRole('button', { name: /Dark/ }).click();
  await page.waitForFunction(() => document.documentElement.dataset.theme === 'dark');
  await page.getByRole('button', { name: 'Compact' }).click();
  await page.waitForFunction(() => document.documentElement.dataset.density === 'compact');
  await shot('09c-dark-compact');
  await page.getByRole('button', { name: /Match device/ }).click();
  await page.getByRole('button', { name: 'Comfortable' }).click();
  await page.waitForFunction(() => !document.documentElement.dataset.theme && document.documentElement.dataset.density === 'comfortable');
});

await step('business settings update the app and the receipt', async () => {
  await page.getByRole('tab', { name: 'Business', exact: true }).click();
  await field('Business name').fill('Dhaka Wholesale Ltd');
  await field('Address').fill('12 Karwan Bazar, Dhaka');
  await field('Phone number').fill('01700-123456');
  await field('Receipt footer message').fill('Thank you! Goods once sold are not returnable.');
  await page.getByRole('button', { name: 'Save settings' }).click();
  await page.waitForFunction(() => document.getElementById('brand-name')?.textContent === 'Dhaka Wholesale Ltd');
  await shot('10-settings-business');
  await page.getByRole('tab', { name: 'Printer', exact: true }).click();
  await shot('11-settings-printer');
});

await step('PIN lock: lock, wrong PIN rejected, correct PIN unlocks', async () => {
  await page.locator('button[title="Lock screen"]').first().click();
  await page.waitForSelector('.keypad');
  for (const d of '0000') await page.locator('.key', { hasText: d }).first().click();
  await page.locator('.key.ok').click();
  await page.waitForFunction(() => document.querySelector('.pin-msg')?.textContent.includes('Incorrect'));
  for (const d of '2468') await page.locator('.key', { hasText: d }).first().click();
  await page.locator('.key.ok').click();
  await page.waitForSelector('.sidebar');
  await shot('12-after-unlock');
});

await step('employee login has restricted access', async () => {
  await page.evaluate(async () => {
    const { auth } = await import('/js/services/auth.js');
    await auth.createUser({ username: 'sam', displayName: 'Sam', role: 'employee', password: 'sampass1', pin: '1357' });
    auth.logout();
  });
  await page.waitForSelector('input[autocomplete=username]');
  await settle();
  await page.locator('input[autocomplete=username]').fill('sam');
  await page.locator('input[type=password]').fill('sampass1');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.waitForSelector('.sidebar');
  const navText = await page.locator('.sidebar .nav').innerText();
  expect(!/Reports/.test(navText) && /New Sale/.test(navText), `nav for employee: ${navText}`);
  await nav('#/reports');
  await page.waitForTimeout(300);
  expect(!(await page.locator('#view').innerText()).includes('Product sales'), 'reports hidden');
  await nav('#/settings');
  await page.waitForSelector('.segmented');
  const tabs = await page.locator('.segmented').innerText();
  expect(!/Sync|Backup|Users|Business/.test(tabs) && /Printer/.test(tabs), `settings tabs for employee: ${tabs}`);
  await nav('#/products');
  await page.waitForSelector('.card');
  expect((await page.getByRole('button', { name: /Add product/ }).count()) === 0, 'employee cannot add products');
});

await step('multiple users: lock screen switches user with their own PIN; activity log records it', async () => {
  await page.evaluate(async () => (await import('/js/services/auth.js')).auth.logout());
  await page.waitForSelector('input[autocomplete=username]');
  await settle(); // the sign-in form focuses its first field a moment after it appears
  await page.locator('input[autocomplete=username]').fill('admin');
  await page.locator('input[type=password]').fill('secret123');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.waitForSelector('.sidebar');
  await page.locator('button[title="Lock screen"]').first().click();
  await page.waitForSelector('.lock-user');
  await page.locator('.lock-user', { hasText: 'Sam' }).click();
  for (const d of '1357') await page.locator('.key', { hasText: d }).first().click();
  await page.locator('.key.ok').click();
  await page.waitForFunction(() => document.querySelector('.side-user')?.innerText.includes('Sam'));
  expect((await page.locator('.side-user').innerText()).includes('Cashier'), 'role label shown');
  await page.evaluate(async () => (await import('/js/services/auth.js')).auth.logout());
  await page.waitForSelector('input[autocomplete=username]');
  await settle(); // the sign-in form focuses its first field a moment after it appears
  await page.locator('input[autocomplete=username]').fill('admin');
  await page.locator('input[type=password]').fill('secret123');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.waitForSelector('.sidebar');
  await nav('#/settings');
  await page.getByRole('tab', { name: 'Users', exact: true }).click();
  await page.waitForSelector('.user-card');
  await page.locator('.user-card', { hasText: 'Sam' }).getByRole('button', { name: 'Edit' }).click();
  await settle();
  await page.locator('label.check', { hasText: 'Customise' }).locator('input').check();
  await page.locator('label.check', { hasText: 'See reports' }).locator('input').check();
  await page.getByRole('button', { name: 'Save', exact: true }).click();
  await page.waitForFunction(() => document.body.innerText.includes('Custom'));
  await shot('09d-users');
  await page.getByRole('tab', { name: 'Activity', exact: true }).click();
  await page.waitForFunction(() => document.body.innerText.includes('auth.switch'));
  await shot('09e-activity');
});

await step('OFFLINE: app reloads from cache and sells with no network; syncs after reconnect', async () => {
  // admin back in
  await page.evaluate(async () => (await import('/js/services/auth.js')).auth.logout());
  await page.waitForSelector('input[autocomplete=username]');
  await settle(); // the sign-in form focuses its first field a moment after it appears
  await page.locator('input[autocomplete=username]').fill('admin');
  await page.locator('input[type=password]').fill('secret123');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.waitForSelector('.sidebar');
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.waitForFunction(() => navigator.serviceWorker.controller || true);
  await page.reload();
  await page.waitForFunction(() => !!navigator.serviceWorker.controller, null, { timeout: 10000 });

  await context.setOffline(true);
  await page.reload();
  await page.waitForSelector('.sidebar, .keypad, input[autocomplete=username]', { timeout: 15000 });
  if (await page.locator('.keypad').count()) {
    for (const d of '2468') await page.locator('.key', { hasText: d }).first().click();
    await page.locator('.key.ok').click();
  }
  await page.waitForSelector('.sidebar');
  await nav('#/pos');
  await page.waitForFunction(() => /Add product/.test(document.querySelector('#view')?.innerText || ''), null, { timeout: 15000 }).catch(async () => {
    throw new Error(`POS page did not open offline. hash=${await page.evaluate(() => location.hash)} view="${(await page.locator('#view').innerText()).slice(0, 160).replace(/\n/g, ' | ')}"`);
  });
  await page.getByRole('button', { name: /Add product/ }).first().click();
  await page.locator('.pick-row', { hasText: 'Mineral Water' }).click();
  await settle();
  await page.locator('.line .qty-in').fill('5');
  await page.locator('.line .price-in').fill('210');
  await page.getByRole('button', { name: /Save & Print/ }).click(); // fake printer is gone after reload => friendly error toast, sale still saved
  await page.waitForSelector('.done', { timeout: 10000 });
  const offlineNo = await page.locator('.done .big').innerText();
  expect(/-0002$/.test(offlineNo), `second invoice number ${offlineNo}`);
  await page.getByRole('button', { name: 'New sale' }).click();
  await shot('13-offline-sale');
  const before = sheet.rows.length;
  await page.waitForTimeout(500);
  expect(sheet.rows.length === before, 'nothing uploaded while offline');
  const pendingOffline = await page.evaluate(async () => (await (await import('/js/services/sync.js')).refreshStatus()).pending);
  expect(pendingOffline === 1, `pending while offline: ${pendingOffline}`);

  await context.setOffline(false);
  await page.evaluate(() => window.dispatchEvent(new Event('online')));
  await page.waitForFunction(() => document.body.innerText.includes('All synced'), null, { timeout: 15000 });
  expect(sheet.rows.length === before + 1, `sheet rows after reconnect: ${sheet.rows.length}`);
});

await step('stock history page: every change with exact time, filters, CSV; product profile; receive stock from the UI', async () => {
  await nav('#/stock-history');
  await page.waitForSelector('tr.move-row');
  await shot('07d-stock-history-page');
  const first = await page.locator('tr.move-row').first().innerText();
  expect(/\d{1,2} \w{3} 20\d\d, \d\d:\d\d:\d\d/.test(first), `exact time with seconds: ${first}`);
  const all = await page.locator('tr.move-row').count();
  expect(all >= 5, `history rows: ${all}`);
  expect((await page.locator('tr.move-row', { hasText: 'Opening stock' }).count()) >= 1 && (await page.locator('tr.move-row', { hasText: 'Product created' }).count()) >= 1, 'new products have created + opening stock rows');
  expect((await page.locator('tr.move-row', { hasText: 'Sale' }).count()) >= 1, 'the sale reduced stock with a history row');
  // newest first
  const times = await page.locator('tr.move-row td:first-child span').allInnerTexts();
  expect(times.length === all, 'a time on every row');
  // filter by change type
  await page.locator('.filters select').nth(1).selectOption('sale');
  await page.waitForFunction((n) => document.querySelectorAll('tr.move-row').length < n, all);
  expect((await page.locator('tr.move-row').count()) >= 1 && (await page.locator('tr.move-row', { hasText: 'Opening stock' }).count()) === 0, 'type filter works');
  await page.locator('.filters select').nth(1).selectOption('');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.locator('[data-action="csv"]').click()]);
  const csv = await (await import('node:fs/promises')).readFile(await dl.path(), 'utf8');
  expect(/Previous stock,Change,New stock/.test(csv.split('\n')[0]) && /Asia\/Dhaka/.test(csv.split('\n')[0]), 'CSV columns');
  // open a product: full history + actions
  await page.locator('tr.move-row a', { hasText: 'Basmati' }).first().click();
  await page.waitForSelector('[data-field="product-id"]');
  expect(/^[0-9a-f-]{36}$/.test(await page.locator('[data-field="product-id"]').innerText()), 'unique Product ID shown');
  const before = await page.locator('tr.move-row').count();
  await page.locator('[data-action="receive"]').click();
  await settle();
  await field('Quantity').fill('25');
  await page.locator('[data-field="supplier"]').fill('Karim Mill');
  await page.locator('[data-field="batch"]').fill('B-2026-10');
  await shot('07e-receive-stock-dialog');
  await page.getByRole('button', { name: 'Add to stock' }).click();
  await page.waitForFunction((n) => document.querySelectorAll('tr.move-row').length === n + 1, before);
  const top = await page.locator('tr.move-row').first().innerText();
  expect(/Stock received/.test(top) && /\+25/.test(top) && /Test|Irfan/.test(top), `new row on top: ${top}`);
  await shot('07b-stock-history');
  // damaged goods write-off and a count correction add NEW rows (old rows untouched)
  await page.locator('[data-action="damage"]').click();
  await settle();
  await field('Quantity').fill('2');
  await field('What happened?').fill('rain damage');
  await page.getByRole('button', { name: 'Write off' }).click();
  await page.waitForFunction((n) => document.querySelectorAll('tr.move-row').length === n + 2, before);
  expect(/Damaged \/ lost/.test(await page.locator('tr.move-row').first().innerText()), 'damage row');
});

await step('returns: take goods back from the invoice screen; stock, history and refund follow', async () => {
  const inv = await page.evaluate(async () => {
    const { createInvoice } = await import('/js/services/sales.js');
    const { listProducts } = await import('/js/services/catalog.js');
    const p = (await listProducts()).find((x) => /Basmati/.test(x.name));
    const i = await createInvoice({ customerId: null, items: [{ productId: p.id, qty: 4, unitPrice: 2450 }], paid: 9800 }, null);
    return { no: i.invoiceNo, pre: p.stock };
  });
  await nav('#/invoices');
  await page.locator('tr.click', { hasText: inv.no }).click();
  await page.waitForSelector('.modal');
  await page.locator('[data-action="return"]').click();
  await settle();
  const submit = page.locator('button[type="submit"]', { hasText: 'Take goods back' });
  await page.locator('input[data-item]').first().fill('1');
  await page.locator('[data-field="reason"]').fill('One bag torn');
  await shot('07f-return-dialog');
  await page.locator('[data-field="reason"]').fill('');
  await submit.click(); // no reason yet: refused with a clear message
  await page.waitForFunction(() => document.body.innerText.includes('reason for the return'));
  await page.locator('[data-field="reason"]').fill('One bag torn');
  await submit.click();
  await page.waitForFunction(() => /RET-\d{6}-0001/.test(document.body.innerText));
  await page.locator('tr.click', { hasText: inv.no }).click();
  await page.waitForSelector('[data-box="returns"]');
  expect((await page.locator('[data-box="returns"]').innerText()).includes('2,450.00'), 'the return is listed on the invoice with its value');
  await page.keyboard.press('Escape');
  const stock = await page.evaluate(async () => (await (await import('/js/services/catalog.js')).listProducts()).find((x) => /Basmati/.test(x.name)).stock);
  expect(stock === inv.pre - 4 + 1, `stock after selling 4 (from ${inv.pre}) and returning 1: ${stock}`);
  await nav('#/stock-history');
  await page.waitForSelector('tr.move-row');
  expect((await page.locator('tr.move-row', { hasText: 'Customer return' }).first().innerText()).includes('RET-'), 'return row with its reference number');
});

await step('void needs a reason; the customer history keeps the voided invoice, its reason and time', async () => {
  await nav('#/invoices');
  await page.waitForSelector('tr.click');
  await page.locator('tr.click', { hasText: '18,000.00' }).click();
  await page.waitForSelector('.modal');
  await page.locator('[data-action="void"]').click();
  await settle();
  await page.locator('.modal input').last().fill('x');
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.waitForFunction(() => document.body.innerText.includes('at least 3 characters')); // refused — and asked again
  await settle();
  await page.locator('.modal input').last().fill('Customer changed his mind');
  await shot('07g-void-reason-dialog');
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: 'Void', exact: true }).last().click();
  await page.waitForFunction(() => document.body.innerText.includes('Invoice voided'));
  await nav('#/customers');
  await page.locator('tr.click', { hasText: 'Rahim Traders' }).click();
  await page.waitForSelector('.hist-entry[data-kind="void"]');
  const v = await page.locator('.hist-entry[data-kind="void"]').innerText();
  expect(/Customer changed his mind/.test(v) && /Admin|Irfan/.test(v) && /\d\d:\d\d:\d\d/.test(v), `void entry: ${v}`);
  expect((await page.locator('.hist-entry[data-kind="invoice"].void').count()) === 1, 'the invoice itself is still listed, marked void');
  expect(/Credit balance/.test(await page.locator('.stat-tile', { has: page.locator('[data-stat="due"]') }).innerText()), 'paying for a voided invoice leaves the customer with credit, shown as such');
  await shot('07c-void-history');
});

await step('phone layout: bottom navigation, no horizontal scroll on key screens', async () => {
  const phone = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const p = await phone.newPage();
  await p.goto(base);
  await p.waitForSelector('form');
  await p.locator('label.field', { hasText: 'Your name' }).locator('input').fill('Phone User');
  await p.locator('label.field', { hasText: 'Password (min 6)' }).locator('input').fill('secret123');
  await p.locator('label.field', { hasText: 'Repeat password' }).locator('input').fill('secret123');
  await p.locator('label.field', { hasText: 'Quick-unlock PIN' }).locator('input').fill('1234');
  await p.locator('label.check input').check();
  await p.getByRole('button', { name: /Create account/ }).click();
  await p.waitForSelector('.bottom-nav');
  // give this fresh phone profile some history so the new pages have something to show (the sample data is seeded just after the shell appears)
  for (let i = 0; i < 80; i++) { // poll from the test side (an async predicate in waitForFunction is not awaited)
    const ready = await p.evaluate(async () => (await (await import('/js/services/customers.js')).listCustomers()).length > 0 && (await (await import('/js/services/catalog.js')).listProducts()).length > 0);
    if (ready) break;
    await p.waitForTimeout(250);
  }
  const ids = await p.evaluate(async () => {
    const { createInvoice, voidInvoice, getInvoice } = await import('/js/services/sales.js');
    const { listProducts } = await import('/js/services/catalog.js');
    const { listCustomers, receivePayment } = await import('/js/services/customers.js');
    const { returnSale } = await import('/js/services/returns.js');
    const prod = (await listProducts())[0];
    const cust = (await listCustomers())[0];
    const a = await createInvoice({ customerId: cust.id, items: [{ productId: prod.id, qty: 6, unitPrice: 2450 }], paid: 5000, paymentMethod: 'bkash' }, null);
    await receivePayment({ customerId: cust.id, amount: 2000, method: 'cash' });
    const b = await createInvoice({ customerId: cust.id, items: [{ productId: prod.id, qty: 1, unitPrice: 2450 }], paid: 0 }, null);
    await voidInvoice(b.id, 'Wrong order');
    await returnSale({ invoiceId: a.id, items: [{ itemId: (await getInvoice(a.id)).items[0].id, qty: 1 }], reason: 'Torn bag' });
    return { cust: cust.id, prod: prod.id };
  });
  for (const hash of ['dashboard', 'pos', 'invoices', 'customers', 'products', 'reports', 'settings', 'stock-history', `customers/${ids.cust}`, `products/${ids.prod}`]) {
    await p.evaluate((h) => (location.hash = `#/${h}`), hash);
    await p.waitForTimeout(550); // let the page's fade-in finish before measuring / photographing
    // measured against the phone's REAL width (390), not window.innerWidth: in mobile emulation the browser widens the
    // layout viewport to fit overflowing content, so innerWidth would always agree with scrollWidth and hide the problem
    const overflow = await p.evaluate(() => document.documentElement.scrollWidth - 390);
    expect(overflow <= 1, `horizontal overflow ${overflow}px on #/${hash}`);
    const shotName = hash.startsWith('customers/') ? 'customer-profile' : hash.startsWith('products/') ? 'product-history' : hash;
    if (SHOTS) await p.screenshot({ path: join(SHOTS, `phone-${shotName}.png`) });
  }
  // the "More" menu lists Stock History on a phone
  await p.evaluate((h) => (location.hash = h), '#/dashboard');
  await p.waitForTimeout(250);
  await p.locator('.bottom-nav button').last().click({ force: true }); // the "More" button
  await p.waitForTimeout(300);
  expect((await p.locator('.more-menu:not(.hidden)').innerText()).includes('Stock History'), 'Stock History is reachable from the phone menu');
  if (SHOTS) await p.screenshot({ path: join(SHOTS, 'phone-more-menu.png') });
  await phone.close();
});

await finish(0);

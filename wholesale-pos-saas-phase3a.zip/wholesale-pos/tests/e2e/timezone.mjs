/**
 * timezone.mjs — end-to-end test of BUSINESS TIME and RESTART in headless Chromium.
 *
 *   npm run test:e2e   (runs after smoke.mjs)
 *
 * The browser is deliberately set to the WRONG time zone (America/Los_Angeles, UTC−7/−8) and
 * Bengali text is used for names. It proves that:
 *   • invoice date / time and every displayed time are Asia/Dhaka, not the device's zone;
 *   • the "today" sales figure uses the Dhaka business day;
 *   • customer history and stock history show Dhaka times with seconds;
 *   • Bengali names are intact in the screens, the CSV and the printed statement;
 *   • after the app is restarted (page reload + PIN) every history is still there.
 */
import { spawnSync } from 'node:child_process';
import { join, resolve } from 'node:path';
import { readFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { loadPlaywright } from './playwright.mjs';
import { createAppServer } from '../../tools/serve.mjs';

const ROOT = resolve(fileURLToPath(new URL('../..', import.meta.url)));
spawnSync(process.execPath, [join(ROOT, 'tools/gen-sw.mjs')], { stdio: 'ignore' });
const server = createAppServer();
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${server.address().port}`;
const { chromium } = await loadPlaywright();
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true, timezoneId: 'America/Los_Angeles', locale: 'en-US' });
const page = await context.newPage();
const problems = [];
page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
page.on('console', (m) => m.type() === 'error' && !/Failed to load resource/.test(m.text()) && problems.push(`console: ${m.text()}`));

const SHOTS = process.env.SHOTS || '';
if (SHOTS) await mkdir(SHOTS, { recursive: true });
// wait for the page's fade-in to finish and hide transient toasts so the pictures are clean
const shot = async (name) => {
  if (!SHOTS) return;
  await page.waitForTimeout(500);
  await page.evaluate(() => document.querySelectorAll('.toast').forEach((t) => (t.style.display = 'none'))).catch(() => {});
  await page.screenshot({ path: join(SHOTS, `${name}.png`) });
};

let passed = 0;
async function step(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`✔ ${name}`);
  } catch (e) {
    console.log(`✘ ${name}\n    ${String(e.message).split('\n').slice(0, 6).join('\n    ')}`);
    await finish(1);
  }
}
async function finish(code) {
  await browser.close();
  server.close();
  if (problems.length) console.log(`\nBrowser errors:\n  ${[...new Set(problems)].join('\n  ')}`);
  console.log(`\n${passed} steps passed${code ? ' — FAILED' : ''}`);
  process.exit(code || (problems.length ? 1 : 0));
}
const expect = (cond, msg) => {
  if (!cond) throw new Error(msg);
};
const field = (t) => page.locator('label.field', { hasText: t }).locator('input,select,textarea').first();
const nav = (hash) => page.evaluate((h) => (location.hash = h), hash);
const settle = () => page.waitForTimeout(200);

/** The expected Dhaka wall-clock text of an ISO instant, computed independently of the app (Node's Intl). */
const dhaka = (iso, seconds = true) => {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Dhaka', hourCycle: 'h23', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }).formatToParts(new Date(iso)).map((x) => [x.type, x.value]));
  return `${Number(p.day)} ${p.month} ${p.year}, ${p.hour}:${p.minute}${seconds ? `:${p.second}` : ''}`;
};
const dhakaDay = (iso) => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Dhaka', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(iso));

let sale;
let customerName = 'রহিম ট্রেডার্স';

await step('the browser really is in another time zone than the shop (Los Angeles vs Dhaka)', async () => {
  await page.goto(base);
  const zone = await page.evaluate(() => Intl.DateTimeFormat().resolvedOptions().timeZone);
  expect(zone === 'America/Los_Angeles', `device zone: ${zone}`);
  const offset = await page.evaluate(() => new Date().getTimezoneOffset());
  expect(offset === 420 || offset === 480, `device offset (minutes behind UTC): ${offset}`);
});

await step('first-run setup, then a Bengali-named customer and product', async () => {
  await page.waitForSelector('form');
  await field('Business name').fill('ঢাকা হোলসেল');
  await field('Your name').fill('ইরফান');
  await field('Password (min 6)').fill('secret123');
  await field('Repeat password').fill('secret123');
  await field('Quick-unlock PIN').fill('2468');
  await page.getByRole('button', { name: /Create account/ }).click();
  await page.waitForSelector('.stats');
  await page.evaluate(async (name) => {
    const { saveCustomer } = await import('/js/services/customers.js');
    const { saveProduct } = await import('/js/services/catalog.js');
    await saveCustomer({ name, phone: '০১৭১১০০০০০১', address: 'মিরপুর, ঢাকা' });
    await saveProduct({ name: 'মিনিকেট চাল ২৫ কেজি', unit: 'বস্তা', costPrice: 1500, defaultPrice: 1700, stock: 40 });
  }, customerName);
});

await step('a sale is stamped with the SHOP\'s date and time, not the device\'s', async () => {
  sale = await page.evaluate(async () => {
    const { createInvoice } = await import('/js/services/sales.js');
    const { listProducts } = await import('/js/services/catalog.js');
    const { listCustomers } = await import('/js/services/customers.js');
    const p = (await listProducts())[0];
    const c = (await listCustomers())[0];
    const inv = await createInvoice({ customerId: c.id, items: [{ productId: p.id, qty: 3, unitPrice: 1700 }], paid: 2000, paymentMethod: 'bkash' }, null);
    return { id: inv.id, no: inv.invoiceNo, date: inv.date, time: inv.time, month: inv.month, createdAt: inv.createdAt, customerId: c.id, productId: p.id };
  });
  const want = dhaka(sale.createdAt);
  expect(`${sale.date}`.length === 10 && sale.date === dhakaDay(sale.createdAt), `invoice date ${sale.date} must be the Dhaka day ${dhakaDay(sale.createdAt)}`);
  expect(sale.time === want.split(', ')[1], `invoice time ${sale.time} must be Dhaka ${want.split(', ')[1]}`);
  expect(sale.month === sale.date.slice(0, 7), 'month follows the Dhaka date');
  // the device clock reads a different hour — prove the two really differ
  const local = await page.evaluate((iso) => new Date(iso).getHours(), sale.createdAt);
  const dhakaHour = Number(sale.time.slice(0, 2));
  expect(local !== dhakaHour, `device hour ${local} vs shop hour ${dhakaHour} must differ for this test to mean anything`);
});

await step('screens show Dhaka time: invoice list, invoice detail, customer history, stock history', async () => {
  await nav('#/invoices');
  await page.waitForSelector('tr.click');
  await page.locator('tr.click', { hasText: sale.no }).click();
  await page.waitForSelector('[data-field="invoice-time"]');
  const shown = await page.locator('[data-field="invoice-time"]').innerText();
  expect(shown === dhaka(sale.createdAt), `invoice detail time "${shown}" vs expected "${dhaka(sale.createdAt)}"`);
  await page.keyboard.press('Escape');
  await nav(`#/customers/${sale.customerId}`);
  await page.waitForSelector('.hist-entry[data-kind="invoice"]');
  const entry = await page.locator('.hist-entry[data-kind="invoice"]').innerText();
  expect(entry.includes(dhaka(sale.createdAt)), `customer history shows "${dhaka(sale.createdAt)}": ${entry.slice(0, 160)}`);
  expect((await page.locator('.profile-card h2').innerText()).includes(customerName), 'Bengali customer name intact');
  expect((await page.locator('.profile-card').innerText()).includes('মিরপুর, ঢাকা'), 'Bengali address intact');
  await shot('bn-customer-profile');
  await nav('#/stock-history');
  await page.waitForSelector('tr.move-row');
  const rows = await page.locator('tr.move-row', { hasText: 'Sale' }).first().innerText();
  expect(rows.includes(dhaka(sale.createdAt)) && rows.includes('মিনিকেট চাল'), `stock history row: ${rows.slice(0, 200)}`);
  await shot('bn-stock-history');
  // the receipt preview with Bengali names and the shop's time
  await nav('#/invoices');
  await page.waitForSelector('tr.click');
  await page.locator('tr.click', { hasText: sale.no }).click();
  await page.waitForSelector('.modal');
  await settle();
  await page.getByRole('button', { name: 'Preview' }).click();
  await page.waitForSelector('.receipt-canvas');
  await page.waitForTimeout(400);
  if (SHOTS) await page.locator('.receipt-canvas').screenshot({ path: join(SHOTS, 'bn-receipt-80mm.png') });
  await page.keyboard.press('Escape');
  await page.keyboard.press('Escape');
});

await step('the dashboard counts the sale on the Dhaka business day', async () => {
  const today = await page.evaluate(async () => (await (await import('/js/services/reports.js')).dashboard()).todaySales);
  // Los Angeles may still be on the PREVIOUS calendar day; the sale must nevertheless count as today's sale in Dhaka
  expect(today === 5100, `today's sales ${today} (3 × 1,700 = 5,100)`);
});

await step('Bengali names survive CSV export and the printed statement', async () => {
  await nav(`#/customers/${sale.customerId}`);
  await page.waitForSelector('[data-action="csv"]');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.locator('[data-action="csv"]').click()]);
  const csv = await readFile(await dl.path(), 'utf8');
  expect(csv.charCodeAt(0) === 0xfeff, 'BOM so Excel reads the Bengali text');
  expect(csv.includes(customerName) && csv.includes('মিনিকেট চাল ২৫ কেজি') && csv.includes('বস্তা') && csv.includes('bKash'), 'Bengali customer, product and unit in the CSV');
  const stamp = dhaka(sale.createdAt).replace(/^\d+ \w+ \d+, /, '');
  const iso = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Dhaka', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(sale.createdAt));
  expect(csv.includes(`${iso} ${stamp}`), `CSV stamp "${iso} ${stamp}" (Asia/Dhaka)`);
  await page.evaluate(() => { window.__printed = null; window.print = () => { window.__printed = document.querySelector('.print-sheet')?.innerText || 'NO SHEET'; }; });
  await page.locator('[data-action="print"]').click();
  const printed = await page.evaluate(() => window.__printed);
  expect(printed.includes(customerName) && printed.includes('মিনিকেট চাল') && printed.includes(dhaka(sale.createdAt, false)), `statement: ${String(printed).slice(0, 200)}`);
  // stock history CSV
  await nav('#/stock-history');
  await page.waitForSelector('[data-action="csv"]');
  const [dl2] = await Promise.all([page.waitForEvent('download'), page.locator('[data-action="csv"]').click()]);
  const csv2 = await readFile(await dl2.path(), 'utf8');
  expect(csv2.includes('মিনিকেট চাল ২৫ কেজি') && csv2.includes(sale.no), 'stock history CSV has the Bengali product and the invoice number');
});

await step('RESTART: reload the app, unlock with the PIN — customer and stock history are all still there', async () => {
  const before = await page.evaluate(async (id) => {
    const { customerProfile } = await import('/js/services/customers.js');
    const { queryMovements } = await import('/js/services/inventory.js');
    const p = await customerProfile(id);
    return { entries: p.entries.length, due: p.summary.currentDue, moves: (await queryMovements({})).total };
  }, sale.customerId);
  await page.reload();
  await page.waitForSelector('.keypad, .sidebar');
  if (await page.locator('.keypad').count()) {
    for (const d of '2468') await page.locator('.key', { hasText: d }).first().click();
    await page.locator('.key.ok').click();
  }
  await page.waitForSelector('.sidebar');
  const after = await page.evaluate(async (id) => {
    const { customerProfile } = await import('/js/services/customers.js');
    const { queryMovements } = await import('/js/services/inventory.js');
    const p = await customerProfile(id);
    return { entries: p.entries.length, due: p.summary.currentDue, moves: (await queryMovements({})).total };
  }, sale.customerId);
  expect(JSON.stringify(before) === JSON.stringify(after), `before ${JSON.stringify(before)} after ${JSON.stringify(after)}`);
  expect(before.entries === 1 && before.due === 3100 && before.moves === 3, `history sizes ${JSON.stringify(before)} (1 invoice, due 5100−2000, created + opening + sale)`);
  await nav(`#/customers/${sale.customerId}`);
  await page.waitForSelector('.hist-entry[data-kind="invoice"]');
  expect((await page.locator('.hist-entry[data-kind="invoice"]').innerText()).includes(dhaka(sale.createdAt)), 'same Dhaka time after restart');
});

await finish(0);

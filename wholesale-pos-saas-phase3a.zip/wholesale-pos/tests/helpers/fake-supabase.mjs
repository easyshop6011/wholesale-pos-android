/**
 * fake-supabase.mjs — an in-memory stand-in for Supabase Auth (GoTrue) + the PostgREST calls the app makes.
 *
 * It encodes OUR understanding of the real contract (endpoints, bodies, error shapes, single-use refresh
 * tokens, PKCE check, MFA → aal2, the rules of the SQL functions in supabase/migrations/…0005). Tests that pass
 * against it prove the client and the screens follow that contract — they do NOT prove that the real server
 * behaves the same. The first run against a real project (docs/CLOUD-SETUP.md) is the real proof.
 *
 *   Node:        createCloudClient({ url: fake.url, key: fake.key, fetchImpl: fake.fetch })
 *   Playwright:  await page.route(`${fake.url}/**`, fake.routeHandler)
 */
import { createHash, randomUUID } from 'node:crypto';
import { PERMISSION_LIST } from '../../js/services/permissions.js';

const b64u = (v) => Buffer.from(v).toString('base64url');
const makeJwt = (payload) => `${b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))}.${b64u(JSON.stringify(payload))}.${b64u('fake-signature')}`;
const ALL_PERMS = PERMISSION_LIST.map((p) => p.key);
const strongPassword = (p) => String(p || '').length >= 10 && /[a-z]/.test(p) && /[A-Z]/.test(p) && /\d/.test(p);

export function createFakeSupabase({ url = 'https://fake.supabase.test', key = 'fake-publishable-key', now = () => Date.now(), otpCode = '424242', totpCode = '123456', googleEmail = 'google.user@example.test' } = {}) {
  const state = {
    users: new Map(),
    sessions: new Map(),
    refresh: new Map(),
    codes: new Map(),
    mails: [],
    pkce: new Map(),
    businesses: new Map(),
    members: [],
    approvals: [],
    devices: [],
    admins: new Set(),
    expiredOwners: new Set(),
    log: [],
    offline: false,
    clock: { skewMs: 0 },
  };
  const nowMs = () => now() + state.clock.skewMs;
  const nowS = () => Math.floor(nowMs() / 1000);

  const json = (status, body) => ({ status, body: body === undefined ? '' : JSON.stringify(body), headers: {} });
  const gotrue = (status, error_code, msg) => json(status, { code: status, error_code, msg });
  const pg = (status, code, message) => json(status, { code, message, details: null, hint: null });

  // ---- users & sessions -------------------------------------------------------------------------------
  const byEmail = (email) => [...state.users.values()].find((u) => u.email === String(email || '').toLowerCase());
  const publicUser = (u) => ({
    id: u.id,
    email: u.email,
    email_confirmed_at: u.confirmed ? new Date(nowMs()).toISOString() : null,
    user_metadata: { full_name: u.fullName },
    factors: u.factors.map((f) => ({ id: f.id, factor_type: f.type, status: f.status, friendly_name: f.name })),
  });
  function createUser({ email, password = 'Str0ngPassw0rd', confirmed = true, fullName = '' }) {
    const u = { id: randomUUID(), email: String(email).toLowerCase(), password, confirmed, fullName, factors: [], disabled: false };
    state.users.set(u.id, u);
    return u;
  }
  function issue(user, { aal = 'aal1', sessionId = randomUUID() } = {}) {
    state.sessions.set(sessionId, { userId: user.id, revoked: state.sessions.get(sessionId)?.revoked || false });
    const exp = nowS() + 3600;
    const access = makeJwt({ sub: user.id, email: user.email, role: 'authenticated', aal, session_id: sessionId, iat: nowS(), exp });
    const refreshToken = randomUUID().replace(/-/g, '');
    state.refresh.set(refreshToken, { sessionId, userId: user.id, aal, used: false });
    return { access_token: access, token_type: 'bearer', expires_in: 3600, expires_at: exp, refresh_token: refreshToken, user: publicUser(user) };
  }
  function sendCode(type, email) {
    state.codes.set(`${type}:${email}`, { code: otpCode, at: nowMs() });
    state.mails.push({ to: email, type, code: otpCode });
  }
  function takeCode(type, email, token) {
    const c = state.codes.get(`${type}:${email}`);
    if (!c || c.code !== token || nowMs() - c.at > 600000) return false;
    state.codes.delete(`${type}:${email}`);
    return true;
  }
  function bearer(headers) {
    const m = /^Bearer (.+)$/.exec(headers.authorization || '');
    if (!m) return { error: json(401, { message: 'No API key found in request' }) };
    let claims;
    try {
      claims = JSON.parse(Buffer.from(m[1].split('.')[1], 'base64url').toString());
    } catch {
      return { error: pg(401, 'PGRST301', 'JWT invalid') };
    }
    if (claims.exp <= nowS()) return { error: pg(401, 'PGRST301', 'JWT expired') };
    const sess = state.sessions.get(claims.session_id);
    const user = state.users.get(claims.sub);
    if (!user || !sess) return { error: pg(401, 'PGRST301', 'JWT invalid') };
    return { user, claims, session: sess };
  }

  // ---- the database functions (mirror supabase/migrations/…0005) -----------------------------------------
  const isAdmin = (user, claims) => state.admins.has(user.id) && claims.aal === 'aal2';
  const subscription = (ownerId) => ({ plan: 'free', status: state.expiredOwners.has(ownerId) ? 'expired' : 'active' });

  function accessState(user, claims, session) {
    const businesses = state.members
      .filter((m) => m.user_id === user.id)
      .map((m) => {
        const b = state.businesses.get(m.business_id);
        const sub = subscription(b.owner_id);
        const live = b.status === 'approved' && m.status === 'active';
        return {
          business_id: b.id,
          name: b.name,
          status: b.status,
          status_reason: b.status_reason,
          role: m.role,
          member_status: m.status,
          permissions: m.role === 'owner' || m.role === 'admin' ? ALL_PERMS : m.permissions || [],
          can_read: live,
          can_write: live && sub.status === 'active',
          plan: sub.plan,
          subscription_status: sub.status,
          period_end: null,
        };
      });
    return {
      user_id: user.id,
      active: !user.disabled,
      email_verified: user.confirmed,
      session_revoked: session.revoked,
      super_admin_candidate: state.admins.has(user.id),
      super_admin: isAdmin(user, claims),
      businesses,
      customer_links: 0,
    };
  }

  const rpc = {
    my_access_state: (a, { user, claims, session }) => json(200, accessState(user, claims, session)),
    register_business: (a, { user }) => {
      if (!user.confirmed) return pg(403, '42501', 'email_not_verified');
      const phone = String(a.p_phone || '');
      if (String(a.p_name || '').trim().length < 2) return pg(400, '22023', 'invalid_name');
      if (String(a.p_owner_name || '').trim().length < 2) return pg(400, '22023', 'invalid_owner_name');
      if (!/^01[3-9]\d{8}$/.test(phone)) return pg(400, '22023', 'invalid_phone');
      const owned = [...state.businesses.values()].filter((b) => b.owner_id === user.id && b.status !== 'rejected');
      if (owned.length >= 1) return pg(400, 'P0001', 'plan_limit:businesses');
      if (owned.some((b) => b.name.toLowerCase() === a.p_name.trim().toLowerCase())) return pg(409, '23505', 'duplicate_business_name');
      const b = { id: randomUUID(), owner_id: user.id, name: a.p_name.trim(), owner_name: a.p_owner_name.trim(), phone, email: a.p_email, address: a.p_address || '', district: a.p_district || '', trade_license: a.p_trade_license || '', status: 'pending', status_reason: '', submitted_at: new Date(nowMs()).toISOString(), reviewed_at: null, deleted_at: null };
      state.businesses.set(b.id, b);
      state.members.push({ business_id: b.id, user_id: user.id, role: 'owner', status: 'active' });
      state.approvals.push({ business_id: b.id, decision: 'submitted' });
      return json(200, b.id);
    },
    resubmit_business: (a, { user }) => {
      const b = state.businesses.get(a.p_business);
      if (!b || b.owner_id !== user.id) return pg(400, 'P0002', 'business_not_found');
      if (b.status !== 'rejected') return pg(400, 'P0001', 'invalid_transition');
      Object.assign(b, { status: 'pending', status_reason: '', submitted_at: new Date(nowMs()).toISOString() });
      state.approvals.push({ business_id: b.id, decision: 'resubmitted' });
      return json(200, null);
    },
    review_business: (a, ctx) => {
      if (!isAdmin(ctx.user, ctx.claims)) return pg(403, '42501', 'not_platform_admin');
      const b = state.businesses.get(a.p_business);
      if (!b) return pg(400, 'P0002', 'business_not_found');
      if (b.status !== 'pending') return pg(400, 'P0001', 'invalid_transition');
      const reason = String(a.p_reason || '').trim();
      if (a.p_decision === 'approve') Object.assign(b, { status: 'approved', status_reason: '' });
      else if (a.p_decision === 'reject') {
        if (reason.length < 5) return pg(400, '22023', 'reason_required');
        Object.assign(b, { status: 'rejected', status_reason: reason });
      } else return pg(400, '22023', 'invalid_decision');
      b.reviewed_at = new Date(nowMs()).toISOString();
      state.approvals.push({ business_id: b.id, decision: a.p_decision === 'approve' ? 'approved' : 'rejected', reason });
      return json(200, null);
    },
    set_business_suspension: (a, ctx) => {
      if (!isAdmin(ctx.user, ctx.claims)) return pg(403, '42501', 'not_platform_admin');
      const b = state.businesses.get(a.p_business);
      if (!b) return pg(400, 'P0002', 'business_not_found');
      const reason = String(a.p_reason || '').trim();
      if (a.p_suspend) {
        if (b.status !== 'approved') return pg(400, 'P0001', 'invalid_transition');
        if (reason.length < 5) return pg(400, '22023', 'reason_required');
        Object.assign(b, { status: 'suspended', status_reason: reason });
      } else {
        if (b.status !== 'suspended') return pg(400, 'P0001', 'invalid_transition');
        Object.assign(b, { status: 'approved', status_reason: '' });
      }
      return json(200, null);
    },
    record_login: (a, { user, claims }) => {
      const known = state.devices.some((d) => d.user_id === user.id && d.device_id === a.p_device_id);
      const others = state.devices.filter((d) => d.user_id === user.id && d.device_id !== a.p_device_id).length;
      if (!known) state.devices.push({ user_id: user.id, device_id: a.p_device_id, label: a.p_label, platform: a.p_platform, session_id: claims.session_id });
      return json(200, { new_device: !known, other_devices: others, suspicious: false });
    },
    log_security_event: () => json(200, null),
  };

  // ---- PostgREST reads / patches on `businesses` ------------------------------------------------------------
  function visibleBusinesses({ user, claims }) {
    if (isAdmin(user, claims)) return [...state.businesses.values()];
    const mine = new Set(state.members.filter((m) => m.user_id === user.id).map((m) => m.business_id));
    return [...state.businesses.values()].filter((b) => b.owner_id === user.id || (mine.has(b.id) && b.status === 'approved'));
  }
  const matches = (row, [col, expr]) => {
    if (['select', 'order', 'limit'].includes(col)) return true;
    const [op, ...rest] = String(expr).split('.');
    const val = rest.join('.');
    if (op === 'eq') return String(row[col]) === val;
    if (op === 'is') return val === 'null' ? row[col] == null : row[col] != null;
    return true;
  };

  // ---- the HTTP surface ------------------------------------------------------------------------------------------
  async function handle({ method, url: full, headers: rawHeaders = {}, body: rawBody }) {
    if (state.offline) throw new TypeError('fetch failed');
    const headers = Object.fromEntries(Object.entries(rawHeaders).map(([k, v]) => [k.toLowerCase(), v]));
    const u = new URL(full);
    const path = u.pathname;
    state.log.push(`${method} ${path}${u.searchParams.get('grant_type') ? `?${u.searchParams.get('grant_type')}` : ''}`);
    if (method === 'OPTIONS') return { status: 204, body: '', headers: {} };
    if (path === '/auth/v1/authorize') return authorize(u);
    if (headers.apikey !== key) return json(401, { message: 'Invalid API key' });
    const body = rawBody ? JSON.parse(rawBody) : {};
    const q = u.searchParams;

    // --- Auth
    if (path === '/auth/v1/signup' && method === 'POST') {
      if (!strongPassword(body.password)) return json(422, { code: 422, error_code: 'weak_password', msg: 'Password should be at least 10 characters.', weak_password: { reasons: ['length'] } });
      const existing = byEmail(body.email);
      if (existing) return json(200, { id: randomUUID(), email: String(body.email).toLowerCase() }); // no enumeration
      const nu = createUser({ email: body.email, password: body.password, confirmed: false, fullName: body.data?.full_name || '' });
      sendCode('signup', nu.email);
      return json(200, { id: nu.id, email: nu.email });
    }
    if (path === '/auth/v1/verify' && method === 'POST') {
      const user = byEmail(body.email);
      if (!user || !takeCode(body.type, user.email, body.token)) return gotrue(403, 'otp_expired', 'Token has expired or is invalid');
      user.confirmed = true;
      return json(200, issue(user));
    }
    if (path === '/auth/v1/token' && method === 'POST') {
      const grant = q.get('grant_type');
      if (grant === 'password') {
        const user = byEmail(body.email);
        if (!user || user.password !== body.password) return gotrue(400, 'invalid_credentials', 'Invalid login credentials');
        if (!user.confirmed) return gotrue(400, 'email_not_confirmed', 'Email not confirmed');
        return json(200, issue(user));
      }
      if (grant === 'refresh_token') {
        const rec = state.refresh.get(body.refresh_token);
        if (!rec) return gotrue(400, 'refresh_token_not_found', 'Invalid Refresh Token: Refresh Token Not Found');
        if (rec.used) return gotrue(400, 'refresh_token_already_used', 'Invalid Refresh Token: Already Used');
        if (state.sessions.get(rec.sessionId)?.gone) return gotrue(400, 'session_not_found', 'Session not found');
        rec.used = true;
        return json(200, issue(state.users.get(rec.userId), { aal: rec.aal, sessionId: rec.sessionId }));
      }
      if (grant === 'pkce') {
        const rec = state.pkce.get(body.auth_code);
        if (!rec) return gotrue(400, 'validation_failed', 'invalid flow state, no valid flow state found');
        const challenge = createHash('sha256').update(String(body.code_verifier || '')).digest('base64url');
        if (challenge !== rec.challenge) return gotrue(400, 'validation_failed', 'code challenge does not match previously saved code verifier');
        state.pkce.delete(body.auth_code);
        return json(200, issue(state.users.get(rec.userId)));
      }
    }
    if (path === '/auth/v1/otp' && method === 'POST') {
      let user = byEmail(body.email);
      if (!user && !body.create_user) return gotrue(422, 'otp_disabled', 'Signups not allowed for otp');
      user ||= createUser({ email: body.email, confirmed: true, password: randomUUID() });
      sendCode('email', user.email);
      return json(200, {});
    }
    if (path === '/auth/v1/resend' && method === 'POST') {
      const user = byEmail(body.email);
      if (user && !user.confirmed) sendCode('signup', user.email);
      return json(200, {});
    }
    if (path === '/auth/v1/recover' && method === 'POST') {
      const user = byEmail(body.email);
      if (user) sendCode('recovery', user.email);
      return json(200, {});
    }

    // --- everything below needs a valid access token
    const who = bearer(headers);
    if (who.error) return who.error;

    if (path === '/auth/v1/user') {
      if (method === 'GET') return json(200, publicUser(who.user));
      if (method === 'PUT') {
        if (body.password !== undefined) {
          if (!strongPassword(body.password)) return json(422, { code: 422, error_code: 'weak_password', msg: 'Password should be at least 10 characters.' });
          if (body.password === who.user.password) return json(422, { code: 422, error_code: 'same_password', msg: 'New password should be different from the old password.' });
          who.user.password = body.password;
        }
        return json(200, publicUser(who.user));
      }
    }
    if (path === '/auth/v1/logout' && method === 'POST') {
      const scope = q.get('scope') || 'global';
      for (const [id, s] of state.sessions) {
        if (s.userId !== who.user.id) continue;
        if (scope === 'global' || (scope === 'local' && id === who.claims.session_id) || (scope === 'others' && id !== who.claims.session_id)) Object.assign(s, { gone: true, revoked: true });
      }
      return { status: 204, body: '', headers: {} };
    }
    if (path === '/auth/v1/factors' && method === 'POST') {
      const f = { id: randomUUID(), type: body.factor_type, status: 'unverified', name: body.friendly_name, secret: 'JBSWY3DPEHPK3PXP' };
      who.user.factors.push(f);
      return json(200, { id: f.id, type: 'totp', friendly_name: f.name, totp: { qr_code: 'data:image/svg+xml;utf-8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><rect width="40" height="40"/></svg>', secret: f.secret, uri: `otpauth://totp/Wholesale%20POS:${who.user.email}?secret=${f.secret}` } });
    }
    const fm = /^\/auth\/v1\/factors\/([^/]+)(?:\/(challenge|verify))?$/.exec(path);
    if (fm) {
      const f = who.user.factors.find((x) => x.id === fm[1]);
      if (!f) return gotrue(404, 'mfa_factor_not_found', 'MFA factor not found');
      if (method === 'DELETE') {
        who.user.factors = who.user.factors.filter((x) => x !== f);
        return json(200, { id: f.id });
      }
      if (fm[2] === 'challenge') return json(200, { id: randomUUID(), expires_at: nowS() + 300 });
      if (fm[2] === 'verify') {
        if (body.code !== totpCode) return gotrue(422, 'mfa_verification_failed', 'Invalid TOTP code entered');
        f.status = 'verified';
        return json(200, issue(who.user, { aal: 'aal2', sessionId: who.claims.session_id }));
      }
    }

    // --- PostgREST
    const rm = /^\/rest\/v1\/rpc\/(\w+)$/.exec(path);
    if (rm && method === 'POST') {
      if (!rpc[rm[1]]) return pg(404, 'PGRST202', `Could not find the function public.${rm[1]}`);
      return rpc[rm[1]](body, who);
    }
    if (path === '/rest/v1/businesses') {
      const params = [...q.entries()];
      if (method === 'GET') {
        let rows = visibleBusinesses(who).filter((b) => params.every((p) => matches(b, p)));
        rows.sort((a, b) => String(b.submitted_at).localeCompare(String(a.submitted_at)));
        if (q.get('limit')) rows = rows.slice(0, Number(q.get('limit')));
        rows = rows.map((b) => ({ ...b, owner: { email: state.users.get(b.owner_id)?.email, full_name: state.users.get(b.owner_id)?.fullName } }));
        return json(200, rows);
      }
      if (method === 'PATCH') {
        const allowed = ['name', 'owner_name', 'phone', 'email', 'address', 'district', 'trade_license'];
        if (Object.keys(body).some((k) => !allowed.includes(k))) return pg(403, '42501', 'permission denied for table businesses');
        const rows = [...state.businesses.values()].filter((b) => b.owner_id === who.user.id && b.status !== 'suspended' && params.every((p) => matches(b, p)));
        if (body.phone !== undefined && !/^01[3-9]\d{8}$/.test(body.phone)) return pg(400, '23514', 'new row violates check constraint "businesses_phone_check"');
        for (const b of rows) Object.assign(b, body);
        return json(200, rows);
      }
    }
    return json(404, { message: `fake server has no route for ${method} ${path}` });
  }

  function authorize(u) {
    if (u.searchParams.get('code_challenge_method') !== 's256' || !u.searchParams.get('code_challenge')) return json(400, { error: 'invalid_request', error_description: 'PKCE required' });
    const user = byEmail(googleEmail) || createUser({ email: googleEmail, confirmed: true, fullName: 'Google User', password: randomUUID() });
    const code = randomUUID();
    state.pkce.set(code, { challenge: u.searchParams.get('code_challenge'), userId: user.id });
    const to = u.searchParams.get('redirect_to');
    return { status: 302, body: '', headers: { location: `${to}${to.includes('?') ? '&' : '?'}code=${code}` } };
  }

  const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS', 'access-control-expose-headers': '*' };

  return {
    url,
    key,
    state,
    otpCode,
    totpCode,
    handle,
    /** Node: a fetch-compatible function */
    async fetch(input, init = {}) {
      const r = await handle({ method: init.method || 'GET', url: String(input), headers: init.headers || {}, body: init.body });
      return new Response(r.status === 204 || r.status === 302 ? null : r.body, { status: r.status, headers: { 'content-type': 'application/json', ...r.headers } });
    },
    /** Playwright: page.route(`${fake.url}/**`, fake.routeHandler) */
    async routeHandler(route) {
      const req = route.request();
      let r;
      try {
        r = await handle({ method: req.method(), url: req.url(), headers: req.headers(), body: req.postData() });
      } catch {
        return route.abort('failed');
      }
      return route.fulfill({ status: r.status, headers: { 'content-type': 'application/json', ...cors, ...r.headers }, body: r.body });
    },
    // ---- test controls
    createUser,
    addAdmin: (email) => state.admins.add(byEmail(email).id),
    lastCode: (email, type) => state.codes.get(`${type}:${String(email).toLowerCase()}`)?.code,
    business: (name) => [...state.businesses.values()].find((b) => b.name === name),
    setOffline: (v) => (state.offline = v),
    advance: (ms) => (state.clock.skewMs += ms),
    expireSubscription: (ownerEmail) => state.expiredOwners.add(byEmail(ownerEmail).id),
    revokeSessionsOf: (email) => {
      for (const s of state.sessions.values()) if (s.userId === byEmail(email).id) s.revoked = true;
    },
    disableUser: (email) => (byEmail(email).disabled = true),
    setMember: (businessName, email, patch) => Object.assign(state.members.find((m) => m.business_id === [...state.businesses.values()].find((b) => b.name === businessName).id && m.user_id === byEmail(email).id), patch),
    user: byEmail,
  };
}

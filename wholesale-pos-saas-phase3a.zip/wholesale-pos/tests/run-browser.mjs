/**
 * run-browser.mjs — runs tests/browser/suite.js inside headless Chromium
 * against a local static server (real IndexedDB, WebCrypto and canvas).
 *
 *   npm run test:browser
 *
 * Needs Playwright (`npm i -D playwright` or an existing global install).
 */
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadPlaywright } from './e2e/playwright.mjs';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };

const server = createServer(async (req, res) => {
  try {
    const path = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    const file = normalize(join(ROOT, path));
    if (!file.startsWith(ROOT) || file.includes('node_modules')) throw new Error('nf');
    res.writeHead(200, { 'Content-Type': TYPES[extname(file)] || 'application/octet-stream' });
    res.end(await readFile(file));
  } catch {
    res.writeHead(404).end('nf');
  }
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${server.address().port}`;

const { chromium } = await loadPlaywright();
const browser = await chromium.launch();
let failed = 0;
try {
  const page = await (await browser.newContext()).newPage();
  page.on('pageerror', (e) => console.error('[pageerror]', e.message));
  await page.goto(`${base}/tests/browser/index.html`);
  await page.waitForFunction(() => window.__done === true, null, { timeout: 180000 });
  const results = await page.evaluate(() => window.__results);
  for (const r of results) {
    console.log(`${r.ok ? '✔' : '✘'} ${r.name}${r.ok ? ` (${r.ms} ms)` : ''}`);
    if (!r.ok) {
      failed++;
      console.log(r.error.split('\n').map((l) => `    ${l}`).join('\n'));
    }
  }
  console.log(`\n${results.length - failed}/${results.length} passed`);
} finally {
  await browser.close();
  server.close();
}
process.exit(failed ? 1 : 0);

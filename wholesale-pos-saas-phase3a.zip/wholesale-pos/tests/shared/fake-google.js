/**
 * fake-google.js — an in-memory imitation of the few Google services Code.gs uses
 * (spreadsheet, script lock, properties, text output). Plain JavaScript with no Node or
 * browser APIs, so the SAME fake runs the real Code.gs in the Node unit tests and inside
 * the browser integration tests (talking to the real client sync code).
 * It does not imitate Google's quotas, latency or number auto-parsing.
 */
class FakeRange {
  constructor(sheet, r, c, nr, nc) {
    Object.assign(this, { sheet, r, c, nr, nc });
  }
  getValues() {
    const out = [];
    for (let i = 0; i < this.nr; i++) {
      const row = [];
      for (let j = 0; j < this.nc; j++) row.push(this.sheet.data[this.r - 1 + i]?.[this.c - 1 + j] ?? '');
      out.push(row);
    }
    return out;
  }
  getValue() {
    return this.getValues()[0][0];
  }
  setValues(vals) {
    vals.forEach((row, i) => row.forEach((v, j) => {
      const rr = this.r - 1 + i;
      while (this.sheet.data.length <= rr) this.sheet.data.push([]);
      this.sheet.data[rr][this.c - 1 + j] = v;
    }));
    return this;
  }
  setValue(v) {
    return this.setValues([[v]]);
  }
  setFontWeight() { return this; }
  setNumberFormat() { return this; }
}

export class FakeSheet {
  constructor(name) {
    this.name = name;
    this.data = [];
  }
  getLastRow() { return this.data.length; }
  getLastColumn() { return this.data.reduce((m, r) => Math.max(m, r.length), 0); }
  getMaxRows() { return Math.max(1000, this.data.length); }
  setFrozenRows() {}
  getRange(r, c, nr = 1, nc = 1) { return new FakeRange(this, r, c, nr, nc); }
  /** data rows without the header row */
  rows() { return this.data.slice(1); }
}

/** The globals Code.gs expects, backed by memory. */
export function makeGoogleGlobals(token) {
  const sheets = new Map();
  const ss = {
    getSheetByName: (n) => sheets.get(n) || null,
    insertSheet: (n) => { const s = new FakeSheet(n); sheets.set(n, s); return s; },
  };
  const globals = {
    SpreadsheetApp: { getActiveSpreadsheet: () => ss, openById: () => ss },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => (k === 'POS_TOKEN' ? token : null) }) },
    ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (s) => ({ getContent: () => s, setMimeType() { return this; } }) },
    DriveApp: {},
  };
  return { globals, sheets };
}

/** Load Code.gs source into a callable server (works wherever `new Function` exists). */
export function loadScript(code, { token = 'test-token-0123456789' } = {}) {
  const { globals, sheets } = makeGoogleGlobals(token);
  const names = Object.keys(globals);
  // eslint-disable-next-line no-new-func
  const api = new Function(...names, `${code}\n;return { doPost, doGet };`)(...names.map((n) => globals[n]));
  const call = (body) => JSON.parse(api.doPost({ postData: { contents: JSON.stringify({ token, ...body }) } }).getContent());
  return { api, call, sheets, token, sheet: (n) => sheets.get(n) };
}

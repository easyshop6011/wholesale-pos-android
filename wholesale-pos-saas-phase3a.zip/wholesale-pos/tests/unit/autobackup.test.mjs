import { test } from 'node:test';
import assert from 'node:assert/strict';
import { backupDue, snapshotsToPrune } from '../../js/services/autobackup.js';

const H = 3600000;
const now = Date.parse('2026-10-28T12:00:00Z');
const ago = (h) => new Date(now - h * H).toISOString();

test('backupDue: disabled, first run, time-based and sales-based triggers', () => {
  assert.deepEqual(backupDue({ now, lastAt: '', everyHours: 24, enabled: false }), { due: false, reason: '' });
  assert.deepEqual(backupDue({ now, lastAt: '', everyHours: 24 }), { due: true, reason: 'first' });
  assert.deepEqual(backupDue({ now, lastAt: 'garbage', everyHours: 24 }), { due: true, reason: 'first' });
  assert.deepEqual(backupDue({ now, lastAt: ago(23), everyHours: 24 }), { due: false, reason: '' });
  assert.deepEqual(backupDue({ now, lastAt: ago(24), everyHours: 24 }), { due: true, reason: 'time' });
  assert.deepEqual(backupDue({ now, lastAt: ago(1), everyHours: 24, invoicesSince: 30, afterSales: 30 }), { due: true, reason: 'sales' });
  assert.equal(backupDue({ now, lastAt: ago(1), everyHours: 24, invoicesSince: 29, afterSales: 30 }).due, false);
  assert.equal(backupDue({ now, lastAt: ago(1), everyHours: 24, invoicesSince: 999, afterSales: 0 }).due, false);
});

test('snapshotsToPrune keeps the newest N normal snapshots and 3 safety snapshots', () => {
  const mk = (id, day, reason = 'auto') => ({ id, reason, createdAt: `2026-10-${String(day).padStart(2, '0')}T00:00:00Z` });
  const list = [mk('a', 1), mk('b', 2), mk('c', 3), mk('d', 4, 'manual'), mk('s1', 5, 'before-restore'), mk('s2', 6, 'before-restore'), mk('s3', 7, 'before-restore'), mk('s4', 8, 'before-restore')];
  assert.deepEqual(snapshotsToPrune(list, 2).sort(), ['a', 'b', 's1']);
  assert.deepEqual(snapshotsToPrune(list, 10), ['s1']);
  assert.equal(snapshotsToPrune([mk('only', 1)], 0).length, 0, 'always keeps at least one');
});

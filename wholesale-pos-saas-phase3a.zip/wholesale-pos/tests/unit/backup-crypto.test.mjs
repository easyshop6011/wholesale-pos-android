import test from 'node:test';
import assert from 'node:assert/strict';
import { encryptText, decryptEnvelope, isEncryptedBackup, ENCRYPTED_FORMAT, PassphraseRequired, MIN_PASSPHRASE } from '../../js/services/backup-crypto.js';

const secret = JSON.stringify({ customers: ['রহিম ট্রেডার্স', 'Karim'], note: 'sensitive 01711000001' });
const PASS = 'correct horse battery staple';
const fast = { iterations: 100000 };

test('encrypts and decrypts, including Bengali text', async () => {
  const env = await encryptText(secret, PASS, fast);
  assert.equal(isEncryptedBackup(env), true);
  assert.equal(env.format, ENCRYPTED_FORMAT);
  assert.equal(await decryptEnvelope(env, PASS), secret);
});

test('the file holds salt, IV, rounds and ciphertext — never the passphrase, the key or any plain text', async () => {
  const env = await encryptText(secret, PASS, fast);
  const text = JSON.stringify(env);
  for (const leak of [PASS, 'রহিম', 'Karim', '01711000001', 'sensitive']) assert.equal(text.includes(leak), false, `leaks "${leak}"`);
  assert.deepEqual(Object.keys(env).sort(), ['cipher', 'data', 'format', 'kdf', 'version']);
  assert.deepEqual(Object.keys(env.kdf).sort(), ['hash', 'iterations', 'name', 'salt']);
  assert.deepEqual(Object.keys(env.cipher).sort(), ['iv', 'name']);
});

test('every encryption is different (random salt and IV) yet each opens with the same passphrase', async () => {
  const a = await encryptText(secret, PASS, fast);
  const b = await encryptText(secret, PASS, fast);
  assert.notEqual(a.data, b.data);
  assert.notEqual(a.kdf.salt, b.kdf.salt);
  assert.notEqual(a.cipher.iv, b.cipher.iv);
  assert.equal(await decryptEnvelope(b, PASS), secret);
});

test('a wrong passphrase, a missing passphrase and any tampering are refused — nothing is half-decrypted', async () => {
  const env = await encryptText(secret, PASS, fast);
  await assert.rejects(() => decryptEnvelope(env, 'wrong passphrase!'), /Wrong passphrase, or the backup file was changed/);
  await assert.rejects(() => decryptEnvelope(env, ''), PassphraseRequired);
  const flip = (s) => (s[10] === 'A' ? `${s.slice(0, 10)}B${s.slice(11)}` : `${s.slice(0, 10)}A${s.slice(11)}`);
  await assert.rejects(() => decryptEnvelope({ ...env, data: flip(env.data) }, PASS), /Wrong passphrase|damaged/);
  await assert.rejects(() => decryptEnvelope({ ...env, kdf: { ...env.kdf, iterations: env.kdf.iterations + 1 } }, PASS), /Wrong passphrase|damaged/, 'the header is authenticated too');
  await assert.rejects(() => decryptEnvelope({ ...env, kdf: { ...env.kdf, salt: flip(env.kdf.salt) } }, PASS), /Wrong passphrase|damaged/);
  await assert.rejects(() => decryptEnvelope({ ...env, cipher: { ...env.cipher, iv: flip(env.cipher.iv) } }, PASS), /Wrong passphrase|damaged/);
});

test('hostile or malformed envelopes cannot freeze or confuse the app', async () => {
  const env = await encryptText(secret, PASS, fast);
  await assert.rejects(() => decryptEnvelope({ ...env, kdf: { ...env.kdf, iterations: 2e9 } }, PASS), /damaged|not in a supported/, 'absurd round count');
  await assert.rejects(() => decryptEnvelope({ ...env, kdf: { ...env.kdf, iterations: 5 } }, PASS), /damaged|not in a supported/, 'too few rounds');
  await assert.rejects(() => decryptEnvelope({ ...env, version: 9 }, PASS), /damaged|not in a supported/);
  await assert.rejects(() => decryptEnvelope({ ...env, data: 'abc' }, PASS), /damaged|not in a supported/);
  await assert.rejects(() => decryptEnvelope({ format: 'x' }, PASS), /damaged|not in a supported/);
  assert.equal(isEncryptedBackup({ format: 'wholesale-pos-backup' }), false);
  assert.equal(isEncryptedBackup(null), false);
});

test('weak passphrases are refused at export time', async () => {
  await assert.rejects(() => encryptText(secret, 'short'), new RegExp(`at least ${MIN_PASSPHRASE}`));
  await assert.rejects(() => encryptText(secret, ''), /at least/);
  await assert.rejects(() => encryptText(secret, undefined), /at least/);
});

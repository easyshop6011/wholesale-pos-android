/**
 * The restore gate: every kind of damaged / hostile / incomplete backup must be refused
 * BEFORE any data is touched. Each case starts from a valid backup and breaks one thing.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { inspectBackup, validateBackup } from '../../js/services/backup-validate.js';
import { validBackup } from './helpers/backup-fixture.mjs';

const broken = (mutate) => {
  const b = validBackup();
  mutate(b.stores, b);
  return inspectBackup(b);
};
const refuses = (name, mutate, re) => test(`refuses a backup that ${name}`, () => {
  const r = broken(mutate);
  assert.equal(r.ok, false, 'must not be accepted');
  assert.match(r.errors.join(' | '), re);
});

test('a complete, consistent backup is accepted (and so is Bengali text)', () => {
  const r = inspectBackup(validBackup());
  assert.deepEqual(r.errors, []);
  assert.equal(r.ok, true);
  assert.equal(r.counts.invoices, 1);
  assert.doesNotThrow(() => validateBackup(validBackup()));
});

test('a version-1 backup (no sales-returns data yet) is still accepted', () => {
  const b = validBackup();
  b.version = 1;
  delete b.stores.salesReturns;
  assert.equal(inspectBackup(b).ok, true);
});

for (const [name, bad] of [['null', null], ['a string', '{}'], ['an array', []], ['another app\'s file', { format: 'other', version: 1, stores: {} }], ['no stores', { format: 'wholesale-pos-backup', version: 1 }]]) {
  test(`refuses ${name}`, () => assert.equal(inspectBackup(bad).ok, false));
}
test('refuses a missing / future / fractional version', () => {
  for (const v of [undefined, 0, 99, 1.5, '2']) {
    const b = validBackup();
    b.version = v;
    assert.equal(inspectBackup(b).ok, false, String(v));
  }
});

refuses('is missing a whole store (truncated file)', (s) => delete s.users, /"users" data is missing/);
refuses('has a store that is not a list', (s) => (s.products = { oops: true }), /"products" data is not a list/);
refuses('has an unknown store', (s) => (s.evil = []), /Unknown data set "evil"/);
refuses('has a record that is not an object', (s) => s.customers.push('nope'), /not a valid record/);
refuses('has a product with a non-numeric stock', (s) => (s.products[0].stock = '8'), /"stock" must be a number/);
refuses('has an invoice without a date', (s) => delete s.invoices[0].date, /"date" must be a date/);
refuses('has a negative quantity on an invoice line', (s) => (s.invoiceItems[0].qty = -3), /"qty" must be a number > 0/);
refuses('has a payment of zero', (s) => (s.payments[0].amount = 0), /"amount" must be an amount > 0/);
refuses('has an unknown stock-movement type', (s) => (s.stockMovements[0].type = 'magic'), /"type" must be a known movement type/);
refuses('has two records with the same id', (s) => s.customers.push({ ...s.customers[0] }), /appears twice/);
refuses('has two invoices with one invoice number', (s) => s.invoices.push({ ...s.invoices[0], id: 'i2' }), /INV-261029-0001.*two records|used by two/);
refuses('has two users with one username', (s) => s.users.push({ ...s.users[0], id: 'u2' }), /used by two records/);
refuses('has an invoice line whose invoice is missing', (s) => (s.invoiceItems[0].invoiceId = 'ghost'), /belongs to an invoice that is not in the backup/);
refuses('has an invoice whose customer is missing', (s) => (s.invoices[0].customerId = 'ghost'), /customer who is not in the backup/);
refuses('has a payment whose customer is missing', (s) => (s.payments[0].customerId = 'ghost'), /customer who is not in the backup/);
refuses('has stock history for a product that is not there', (s) => (s.stockMovements[0].productId = 'ghost'), /product that is not in the backup/);
refuses('has an invoice with no lines', (s) => (s.invoiceItems = []), /has no product lines/);
refuses('has invoice money that does not add up (total)', (s) => (s.invoices[0].total = 250), /total 250 ≠ subtotal/);
refuses('has invoice money that does not add up (due)', (s) => (s.invoices[0].due = 0), /due 0 ≠ total/);
refuses('has lines that do not add up to the subtotal', (s) => (s.invoiceItems[0].total = 299), /lines add up to/);
refuses('has a due amount for a walk-in customer', (s) => { s.invoices[0].customerId = null; }, /due amount but no customer/);
refuses('would leave nobody able to sign in as administrator', (s) => (s.users[0].role = 'employee'), /no active administrator/);
refuses('has only a DISABLED administrator', (s) => (s.users[0].active = false), /no active administrator/);
refuses('has a user without a password hash', (s) => delete s.users[0].passHash, /"passHash" must be a password hash/);
refuses('has a return that does not add up', (s) => (s.salesReturns = [{ id: 'r1', returnNo: 'RET-1', invoiceId: 'i1', customerId: 'c1', items: [{ itemId: 'l1', qty: 1 }], amount: 100, creditApplied: 10, refund: 10, createdAt: '2026-10-29T05:00:00.000Z', date: '2026-10-29' }]), /credit 10 \+ refund 10 ≠ value 100/);

test('stock that differs from the recorded history is a WARNING (old products), not a refusal', () => {
  const r = broken((s) => (s.products[0].stock = 9));
  assert.equal(r.ok, true);
  assert.match(r.warnings.join(' '), /stock 9 differs from its last recorded/);
});

test('a refusal names what is wrong, in plain words, and caps a flood of problems', () => {
  const damaged = validBackup();
  damaged.stores.products[0].stock = '8';
  assert.throws(() => validateBackup(damaged), /cannot be restored — nothing was changed.*"stock" must be a number/);
  const b = validBackup();
  b.stores.customers = Array.from({ length: 500 }, (_, i) => ({ id: `c${i}`, name: '', nameLower: '', phone: 1 }));
  const r = inspectBackup(b);
  assert.equal(r.ok, false);
  assert.ok(r.errors.length <= 42, `reported ${r.errors.length}`);
  assert.match(r.errors.at(-1), /more problem/);
});

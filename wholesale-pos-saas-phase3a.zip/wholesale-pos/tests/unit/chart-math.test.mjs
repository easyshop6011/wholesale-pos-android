import { test } from 'node:test';
import assert from 'node:assert/strict';
import { niceScale, compact, xAt, yAt, linePath, areaPath, nearestIndex, donutSlices, arcPath, pctChange, labelIndexes } from '../../js/ui/chart-math.js';

test('niceScale gives round maxima and evenly spaced ticks', () => {
  assert.deepEqual(niceScale(0).ticks, [0, 0.25, 0.5, 0.75, 1]);
  assert.deepEqual(niceScale(87), { max: 100, step: 25, ticks: [0, 25, 50, 75, 100] });
  assert.deepEqual(niceScale(1000).ticks, [0, 250, 500, 750, 1000]);
  const s = niceScale(23456);
  assert.ok(s.max >= 23456 && s.ticks[0] === 0 && s.ticks.at(-1) === s.max);
  assert.ok(niceScale(0.37).max >= 0.37);
  assert.ok(niceScale(NaN).max > 0);
});

test('compact abbreviates thousands/millions', () => {
  assert.equal(compact(950), '950');
  assert.equal(compact(12400), '12.4k');
  assert.equal(compact(3200000), '3.2M');
  assert.equal(compact(-1500), '-1.5k');
  assert.equal(compact(0), '0');
  assert.equal(compact(1000), '1k');
});

test('coordinate helpers', () => {
  assert.equal(xAt(0, 5, 10, 110), 10);
  assert.equal(xAt(4, 5, 10, 110), 110);
  assert.equal(xAt(0, 1, 10, 110), 60);
  assert.equal(yAt(50, 100, 200, 0), 100);
  assert.equal(yAt(0, 0, 200, 0), 200);
});

test('paths: straight, smooth and area', () => {
  assert.equal(linePath([]), '');
  assert.equal(linePath([[0, 10], [10, 0]], false), 'M0,10L10,0');
  assert.match(linePath([[0, 10], [10, 0]]), /^M0,10C5,10 5,0 10,0$/);
  assert.equal(areaPath([[0, 10], [10, 0]], 20, false), 'M0,10L10,0L10,20L0,20Z');
});

test('nearestIndex picks the closest x', () => {
  assert.equal(nearestIndex([0, 10, 20, 30], 12), 1);
  assert.equal(nearestIndex([0, 10, 20, 30], 99), 3);
  assert.equal(nearestIndex([5], 0), 0);
});

test('donutSlices: shares add up, small slices merge into Other, zeros dropped', () => {
  const s = donutSlices([{ label: 'A', value: 50 }, { label: 'B', value: 30 }, { label: 'C', value: 19 }, { label: 'D', value: 1 }, { label: 'Z', value: 0 }]);
  assert.deepEqual(s.map((x) => x.label), ['A', 'B', 'C', 'Other']);
  assert.ok(Math.abs(s.reduce((a, x) => a + x.share, 0) - 1) < 1e-9);
  assert.ok(Math.abs(s.at(-1).end - Math.PI * 2) < 1e-9);
  assert.deepEqual(donutSlices([]), []);
  const many = donutSlices(Array.from({ length: 10 }, (_, i) => ({ label: `P${i}`, value: 10 })));
  assert.equal(many.length, 6);
  assert.equal(many.at(-1).label, 'Other');
});

test('arcPath is a closed path and handles a full circle', () => {
  assert.match(arcPath(50, 50, 40, 25, 0, Math.PI / 2), /^M.*A40,40 0 0 1.*L.*A25,25 0 0 0.*Z$/);
  assert.match(arcPath(50, 50, 40, 25, 0, Math.PI * 2), /A40,40 0 1 1/);
});

test('pctChange and labelIndexes', () => {
  assert.equal(pctChange(150, 100), 50);
  assert.equal(pctChange(50, 100), -50);
  assert.equal(pctChange(10, 0), null);
  assert.deepEqual(labelIndexes(3, 7), [0, 1, 2]);
  const l = labelIndexes(30, 7);
  assert.equal(l.at(-1), 29);
  assert.ok(l.length <= 7);
  const gaps = new Set(l.slice(1).map((v, i) => v - l[i]));
  assert.equal(gaps.size, 1, 'evenly spaced');
});

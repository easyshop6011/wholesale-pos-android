import test from 'node:test';
import assert from 'node:assert/strict';
import { createFakeSupabase } from '../helpers/fake-supabase.mjs';
import { createCloudClient, memoryStorage, decodeJwt, readOAuthRedirect, SESSION_KEY } from '../../js/cloud/client.js';
import { cloudConfig, assertPublicKey } from '../../js/cloud/config.js';
import { CloudError, errorText } from '../../js/cloud/errors.js';
import { setLocale } from '../../js/core/i18n.js';

const START = Date.parse('2026-11-05T10:00:00Z');
function setup() {
  const clock = { t: START };
  const fake = createFakeSupabase({ now: () => clock.t });
  const storage = memoryStorage();
  const mk = (st = storage) => createCloudClient({ url: fake.url, key: fake.key, storage: st, fetchImpl: fake.fetch, now: () => clock.t });
  return { clock, fake, storage, client: mk(), mk };
}
const rejects = async (p, code) => {
  await assert.rejects(p, (e) => e instanceof CloudError && e.code === code, `expected CloudError(${code})`);
};
const b64u = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const fakeJwt = (payload) => `${b64u({ alg: 'HS256' })}.${b64u(payload)}.sig`;

// ---- configuration ---------------------------------------------------------------------------------------

test('config: disabled until a URL and a key are given', () => {
  assert.equal(cloudConfig({}).enabled, false);
  assert.equal(cloudConfig({ url: 'https://x.supabase.co' }).enabled, false);
  const c = cloudConfig({ url: 'https://x.supabase.co/', publishableKey: 'sb_publishable_abc' });
  assert.equal(c.enabled, true);
  assert.equal(c.url, 'https://x.supabase.co');
});

test('config: a secret or service-role key stops the app instead of shipping', () => {
  assert.throws(() => assertPublicKey('sb_secret_abcdefghijklmnop'), /SECRET key/);
  assert.throws(() => assertPublicKey(fakeJwt({ role: 'service_role', iss: 'supabase' })), /service_role/);
  assert.doesNotThrow(() => assertPublicKey(fakeJwt({ role: 'anon', iss: 'supabase' })));
  assert.doesNotThrow(() => assertPublicKey('sb_publishable_abcdefgh'));
  assert.throws(() => cloudConfig({ url: 'https://x.supabase.co', publishableKey: 'sb_secret_abcdefghijklmnop' }));
});

test('config: https is required (http only for localhost)', () => {
  assert.throws(() => cloudConfig({ url: 'http://example.com', publishableKey: 'k' }), /https/);
  assert.equal(cloudConfig({ url: 'http://127.0.0.1:54321', publishableKey: 'k' }).enabled, true);
  assert.equal(cloudConfig({ url: 'http://localhost:54321', publishableKey: 'k' }).enabled, true);
});

// ---- registration & password sign-in ---------------------------------------------------------------------

test('sign-up: a weak password is refused; a strong one needs the e-mailed code', async () => {
  const { client, fake } = setup();
  await rejects(client.auth.signUp({ email: 'a@shop.test', password: 'short' }), 'weak_password');
  const r = await client.auth.signUp({ email: 'A@Shop.test', password: 'Str0ngPassw0rd', fullName: 'আব্দুল' });
  assert.equal(r.needsVerification, true);
  assert.equal(r.session, null);
  assert.equal(fake.state.mails.at(-1).to, 'a@shop.test');
  assert.equal(fake.user('a@shop.test').fullName, 'আব্দুল');
});

test('sign-up: the confirmation code verifies the e-mail and signs in; a wrong code does not', async () => {
  const { client, fake, storage } = setup();
  await client.auth.signUp({ email: 'a@shop.test', password: 'Str0ngPassw0rd' });
  await rejects(client.auth.verifyEmailOtp({ email: 'a@shop.test', token: '000000', type: 'signup' }), 'otp_expired');
  assert.equal(storage.get(SESSION_KEY), null);
  const s = await client.auth.verifyEmailOtp({ email: 'a@shop.test', token: ` ${fake.otpCode.slice(0, 3)} ${fake.otpCode.slice(3)} `, type: 'signup' }); // spaces tolerated
  assert.equal(s.user.email, 'a@shop.test');
  assert.equal(s.user.emailConfirmed, true);
  assert.ok(storage.get(SESSION_KEY));
});

test('sign-up: an e-mail that is already registered does not reveal itself', async () => {
  const { client, fake } = setup();
  fake.createUser({ email: 'taken@shop.test' });
  const r = await client.auth.signUp({ email: 'taken@shop.test', password: 'Str0ngPassw0rd' });
  assert.equal(r.needsVerification, true); // same answer as for a new address
});

test('password sign-in: unverified e-mail, wrong password and success', async () => {
  const { client, fake } = setup();
  fake.createUser({ email: 'u@shop.test', password: 'Str0ngPassw0rd', confirmed: false });
  await rejects(client.auth.signInWithPassword({ email: 'u@shop.test', password: 'Str0ngPassw0rd' }), 'email_not_confirmed');
  fake.user('u@shop.test').confirmed = true;
  await rejects(client.auth.signInWithPassword({ email: 'u@shop.test', password: 'wrong-password' }), 'invalid_credentials');
  const s = await client.auth.signInWithPassword({ email: 'u@shop.test', password: 'Str0ngPassw0rd' });
  assert.equal(s.aal, 'aal1');
  assert.equal((await client.auth.getSession()).user.id, s.user.id);
});

test('e-mail code sign-in: an unknown address is not revealed and sends nothing', async () => {
  const { client, fake } = setup();
  fake.createUser({ email: 'known@shop.test' });
  await client.auth.sendEmailOtp({ email: 'nobody@shop.test' }); // no throw
  assert.equal(fake.state.mails.length, 0);
  await client.auth.sendEmailOtp({ email: 'known@shop.test' });
  assert.equal(fake.state.mails.length, 1);
  const s = await client.auth.verifyEmailOtp({ email: 'known@shop.test', token: fake.otpCode });
  assert.equal(s.user.email, 'known@shop.test');
  await rejects(client.auth.verifyEmailOtp({ email: 'known@shop.test', token: fake.otpCode }), 'otp_expired'); // single use
});

test('e-mail code: expires after 10 minutes', async () => {
  const { client, fake, clock } = setup();
  fake.createUser({ email: 'known@shop.test' });
  await client.auth.sendEmailOtp({ email: 'known@shop.test' });
  clock.t += 11 * 60 * 1000;
  await rejects(client.auth.verifyEmailOtp({ email: 'known@shop.test', token: fake.otpCode }), 'otp_expired');
});

test('password reset: code → session → new password; the same password is refused', async () => {
  const { client, fake } = setup();
  fake.createUser({ email: 'u@shop.test', password: 'Old0Password1' });
  await client.auth.sendPasswordReset({ email: 'u@shop.test' });
  await client.auth.verifyEmailOtp({ email: 'u@shop.test', token: fake.otpCode, type: 'recovery' });
  await rejects(client.auth.updatePassword('Old0Password1'), 'same_password');
  await rejects(client.auth.updatePassword('weak'), 'weak_password');
  await client.auth.updatePassword('New0Password2');
  await client.auth.signOut();
  assert.equal((await client.auth.signInWithPassword({ email: 'u@shop.test', password: 'New0Password2' })).user.email, 'u@shop.test');
});

// ---- sessions ------------------------------------------------------------------------------------------------

async function signedIn(ctx, email = 'u@shop.test') {
  ctx.fake.createUser({ email, password: 'Str0ngPassw0rd' });
  return ctx.client.auth.signInWithPassword({ email, password: 'Str0ngPassw0rd' });
}

test('session: refreshed shortly before it expires, and only ONCE for concurrent callers', async () => {
  const ctx = setup();
  const first = await signedIn(ctx);
  ctx.clock.t += 3550 * 1000; // 50 s before expiry → inside the 60 s margin
  const results = await Promise.all([ctx.client.auth.getSession(), ctx.client.auth.getSession(), ctx.client.auth.getSession()]);
  assert.equal(ctx.fake.state.log.filter((l) => l === 'POST /auth/v1/token?refresh_token').length, 1);
  assert.ok(results.every((r) => r.accessToken === results[0].accessToken));
  assert.notEqual(results[0].accessToken, first.accessToken);
});

test('session: a token that is still fresh is not refreshed', async () => {
  const ctx = setup();
  await signedIn(ctx);
  ctx.clock.t += 600 * 1000;
  await ctx.client.auth.getSession();
  assert.equal(ctx.fake.state.log.filter((l) => l.includes('refresh_token')).length, 0);
});

test('session: two tabs refreshing at once — the loser adopts the winner’s session, nobody is signed out', async () => {
  const ctx = setup();
  const tabA = ctx.client;
  const tabB = ctx.mk(ctx.storage); // same localStorage, separate memory
  await signedIn(ctx);
  const events = [];
  tabB.auth.onChange((e) => events.push(e));
  ctx.clock.t += 3550 * 1000;
  const [a, b] = await Promise.all([tabA.auth.getSession(), tabB.auth.getSession()]);
  assert.ok(a && b);
  assert.equal(a.accessToken, b.accessToken);
  assert.ok(!events.includes('SIGNED_OUT'));
});

test('session: a refresh token the server rejects signs the person out (and says so)', async () => {
  const ctx = setup();
  await signedIn(ctx);
  const events = [];
  ctx.client.auth.onChange((e) => events.push(e));
  ctx.fake.state.refresh.clear();
  ctx.clock.t += 3550 * 1000;
  assert.equal(await ctx.client.auth.getSession(), null);
  assert.equal(ctx.storage.get(SESSION_KEY), null);
  assert.deepEqual(events, ['SIGNED_OUT']);
});

test('session: offline refresh keeps the session (marked stale) so the POS keeps working', async () => {
  const ctx = setup();
  await signedIn(ctx);
  ctx.clock.t += 3550 * 1000;
  ctx.fake.setOffline(true);
  const s = await ctx.client.auth.getSession();
  assert.equal(s.stale, true);
  assert.ok(ctx.storage.get(SESSION_KEY));
  ctx.fake.setOffline(false);
  assert.equal((await ctx.client.auth.getSession()).stale, undefined); // back online: refreshed normally
});

test('rpc: a 401 "JWT expired" triggers one refresh and the call is retried', async () => {
  const ctx = setup();
  await signedIn(ctx);
  ctx.fake.advance(4000 * 1000); // the SERVER thinks the token is old; the client does not know yet
  const access = await ctx.client.rpc('my_access_state');
  assert.equal(access.active, true);
  assert.equal(ctx.fake.state.log.filter((l) => l === 'POST /auth/v1/token?refresh_token').length, 1);
});

test('rpc without a session fails with session_expired (never calls the server)', async () => {
  const ctx = setup();
  await rejects(ctx.client.rpc('my_access_state'), 'session_expired');
  assert.equal(ctx.fake.state.log.length, 0);
});

test('sign-out clears the local session even when the server cannot be reached', async () => {
  const ctx = setup();
  await signedIn(ctx);
  ctx.fake.setOffline(true);
  await ctx.client.auth.signOut();
  assert.equal(ctx.storage.get(SESSION_KEY), null);
  assert.equal(await ctx.client.auth.getSession(), null);
});

test('global sign-out ends every other session at its next refresh (an already-issued access token lives until it expires — use revoke_device for an instant stop)', async () => {
  const ctx = setup();
  await signedIn(ctx);
  const other = ctx.mk(memoryStorage());
  await other.auth.signInWithPassword({ email: 'u@shop.test', password: 'Str0ngPassw0rd' });
  await ctx.client.auth.signOut({ scope: 'global' });
  assert.equal((await other.rpc('my_access_state')).active, true); // honest limit of stateless access tokens
  ctx.clock.t += 3550 * 1000;
  assert.equal(await other.auth.getSession(), null); // the refresh is refused → signed out
});

test('network failures become CloudError("network") with a Bengali sentence', async () => {
  const ctx = setup();
  ctx.fake.setOffline(true);
  await rejects(ctx.client.auth.signInWithPassword({ email: 'a@b.test', password: 'x' }), 'network');
  setLocale('bn');
  try {
    assert.match(errorText(new CloudError('network')), /ইন্টারনেট/);
  } finally {
    setLocale('en');
  }
});

// ---- Google (PKCE) ------------------------------------------------------------------------------------------------

test('google: the URL carries an S256 challenge; the code is exchanged with the matching verifier', async () => {
  const ctx = setup();
  const { url } = await ctx.client.auth.signInWithGoogle({ redirectTo: 'https://app.test/' });
  const u = new URL(url);
  assert.equal(u.searchParams.get('provider'), 'google');
  assert.equal(u.searchParams.get('code_challenge_method'), 's256');
  assert.ok(u.searchParams.get('code_challenge').length >= 43);
  const redirect = await ctx.fake.handle({ method: 'GET', url, headers: {} });
  assert.equal(redirect.status, 302);
  const back = new URL(redirect.headers.location);
  assert.equal(back.origin + back.pathname, 'https://app.test/');
  const parsed = readOAuthRedirect(back.search);
  assert.ok(parsed.code);
  const s = await ctx.client.auth.exchangeCode(parsed.code);
  assert.equal(s.user.email, 'google.user@example.test');
  await rejects(ctx.client.auth.exchangeCode(parsed.code), 'session_expired'); // the verifier is single use
});

test('google: a code that does not match the verifier is refused (PKCE protects the redirect)', async () => {
  const ctx = setup();
  const { url } = await ctx.client.auth.signInWithGoogle({ redirectTo: 'https://app.test/' });
  const code = new URL((await ctx.fake.handle({ method: 'GET', url, headers: {} })).headers.location).searchParams.get('code');
  ctx.storage.set('pos:cloud:pkce', 'a-different-verifier-an-attacker-might-hold-0123456789');
  await rejects(ctx.client.auth.exchangeCode(code), 'validation');
});

test('readOAuthRedirect understands code, error and nothing', () => {
  assert.deepEqual(readOAuthRedirect('?code=abc&state=1'), { code: 'abc' });
  assert.deepEqual(readOAuthRedirect('?error=access_denied&error_description=User+cancelled'), { error: 'User cancelled' });
  assert.deepEqual(readOAuthRedirect('?x=1'), {});
});

// ---- MFA ---------------------------------------------------------------------------------------------------------------

test('mfa: enrol → verify gives an aal2 session; a wrong code does not', async () => {
  const ctx = setup();
  await signedIn(ctx);
  const e = await ctx.client.auth.mfa.enroll();
  assert.match(e.qrCode, /^data:image\/svg\+xml/);
  assert.ok(e.secret);
  await rejects(ctx.client.auth.mfa.verify({ factorId: e.factorId, code: '000000' }), 'mfa_failed');
  assert.equal((await ctx.client.auth.getSession()).aal, 'aal1');
  const s = await ctx.client.auth.mfa.verify({ factorId: e.factorId, code: ctx.fake.totpCode });
  assert.equal(s.aal, 'aal2');
  assert.equal(decodeJwt(s.accessToken).aal, 'aal2');
  assert.equal((await ctx.client.auth.mfa.factors())[0].status, 'verified');
});

test('mfa: enrolling again replaces an abandoned, unverified factor', async () => {
  const ctx = setup();
  await signedIn(ctx);
  await ctx.client.auth.mfa.enroll();
  await ctx.client.auth.mfa.enroll();
  assert.equal((await ctx.client.auth.mfa.factors()).length, 1);
});

// ---- error words -------------------------------------------------------------------------------------------------------

test('errorText: known codes are translated, unknown ones read "something went wrong"', () => {
  setLocale('bn');
  try {
    assert.match(errorText(new CloudError('invalid_phone')), /মোবাইল/);
    assert.match(errorText(new CloudError('plan_limit:businesses')), /প্ল্যান/);
    assert.match(errorText(new CloudError('totally_new_code')), /ভুল/);
    assert.match(errorText(new Error('plain error')), /ভুল/);
  } finally {
    setLocale('en');
  }
  assert.equal(errorText(new CloudError('invalid_credentials')), 'The email or password is not correct.');
});

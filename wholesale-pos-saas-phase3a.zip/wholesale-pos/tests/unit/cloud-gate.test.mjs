import test from 'node:test';
import assert from 'node:assert/strict';
import { createFakeSupabase } from '../helpers/fake-supabase.mjs';
import { createCloudClient, memoryStorage, SESSION_KEY } from '../../js/cloud/client.js';
import { decideState, resolveGate, recordLogin, deviceIdentity, ACCESS_KEY, BUSINESS_KEY, OFFLINE_GRACE_MS } from '../../js/cloud/gate.js';
import { registerBusiness, updateApplication, resubmitBusiness, listBusinesses, reviewBusiness, setSuspension, normalizeBdPhone, isBdMobile } from '../../js/cloud/actions.js';
import { CloudError } from '../../js/cloud/errors.js';
import { checkOnce, startCloudWatch } from '../../js/cloud/watch.js';
import { t, setLocale, getLocale, toBnDigits, fromBnDigits, nDigits, initLocale, LOCALES } from '../../js/core/i18n.js';
import { en } from '../../js/i18n/en.js';
import { bn } from '../../js/i18n/bn.js';

const START = Date.parse('2026-11-05T10:00:00Z');
function setup() {
  const clock = { t: START };
  const fake = createFakeSupabase({ now: () => clock.t });
  const storage = memoryStorage();
  const client = createCloudClient({ url: fake.url, key: fake.key, storage, fetchImpl: fake.fetch, now: () => clock.t });
  return { clock, fake, storage, client, gate: () => resolveGate(client, { storage, now: () => clock.t }) };
}
const login = async (ctx, email, { password = 'Str0ngPassw0rd', admin = false } = {}) => {
  ctx.fake.createUser({ email, password });
  if (admin) ctx.fake.addAdmin(email);
  return ctx.client.auth.signInWithPassword({ email, password });
};
const FORM = { name: 'রহমান ট্রেডার্স', ownerName: 'আব্দুর রহমান', phone: '০১৭১২-৩৪৫৬৭৮', email: '', address: 'ঢাকা', district: 'ঢাকা', tradeLicense: '' };
const rejects = (p, code) => assert.rejects(p, (e) => e instanceof CloudError && e.code === code, `expected ${code}`);

// ---- decideState (pure) -------------------------------------------------------------------------------------

const biz = (o = {}) => ({ business_id: 'b1', name: 'Shop', status: 'approved', member_status: 'active', can_write: true, ...o });
const acc = (o = {}) => ({ active: true, session_revoked: false, super_admin_candidate: false, super_admin: false, businesses: [], ...o });

test('decideState: every state of the flow', () => {
  assert.equal(decideState(acc({ active: false })).state, 'account_disabled');
  assert.equal(decideState(acc({ session_revoked: true })).state, 'session_revoked');
  assert.equal(decideState(acc({ super_admin_candidate: true })).state, 'mfa_enroll');
  assert.equal(decideState(acc({ super_admin_candidate: true }), { hasVerifiedFactor: true }).state, 'mfa_challenge');
  assert.equal(decideState(acc({ super_admin_candidate: true, super_admin: true })).state, 'super_admin');
  assert.equal(decideState(acc()).state, 'no_business');
  assert.equal(decideState(acc({ businesses: [biz({ status: 'pending' })] })).state, 'pending');
  assert.equal(decideState(acc({ businesses: [biz({ status: 'rejected', status_reason: 'x' })] })).state, 'rejected');
  assert.equal(decideState(acc({ businesses: [biz({ status: 'suspended' })] })).state, 'suspended');
  assert.equal(decideState(acc({ businesses: [biz({ member_status: 'disabled' })] })).state, 'member_disabled');
  const ready = decideState(acc({ businesses: [biz()] }));
  assert.equal(ready.state, 'ready');
  assert.equal(ready.readOnly, false);
  assert.equal(decideState(acc({ businesses: [biz({ can_write: false })] })).readOnly, true, 'an expired subscription is read-only');
});

test('decideState: with several businesses a usable one beats a pending one; the remembered one wins when usable', () => {
  const list = [biz({ business_id: 'p', status: 'pending' }), biz({ business_id: 'a' }), biz({ business_id: 'c' })];
  assert.equal(decideState(acc({ businesses: list })).business.business_id, 'a');
  assert.equal(decideState(acc({ businesses: list }), { storedBusinessId: 'c' }).business.business_id, 'c');
  assert.equal(decideState(acc({ businesses: list }), { storedBusinessId: 'p' }).business.business_id, 'a', 'a pending business is not chosen over a usable one');
});

// ---- resolveGate against the fake server ---------------------------------------------------------------------

test('gate: signed out → no business → pending → approved (ready) → suspended → reinstated', async () => {
  const ctx = setup();
  assert.equal((await ctx.gate()).state, 'signed_out');
  await login(ctx, 'owner@shop.test');
  assert.equal((await ctx.gate()).state, 'no_business');

  await registerBusiness(ctx.client, FORM);
  const pending = await ctx.gate();
  assert.equal(pending.state, 'pending');
  assert.equal(pending.business.name, FORM.name);

  const b = ctx.fake.business(FORM.name);
  b.status = 'approved';
  const ready = await ctx.gate();
  assert.equal(ready.state, 'ready');
  assert.equal(ready.business.role, 'owner');
  assert.ok(ready.business.permissions.includes('reports.profit'));
  assert.equal(ctx.storage.get(BUSINESS_KEY), b.id, 'the chosen business is remembered');

  Object.assign(b, { status: 'suspended', status_reason: 'dispute' });
  const sus = await ctx.gate();
  assert.equal(sus.state, 'suspended');
  assert.equal(sus.business.status_reason, 'dispute');
  Object.assign(b, { status: 'approved', status_reason: '' });
  assert.equal((await ctx.gate()).state, 'ready');
});

test('gate: an expired subscription is ready but read-only', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  await registerBusiness(ctx.client, FORM);
  ctx.fake.business(FORM.name).status = 'approved';
  ctx.fake.expireSubscription('owner@shop.test');
  const g = await ctx.gate();
  assert.equal(g.state, 'ready');
  assert.equal(g.readOnly, true);
});

test('gate: a disabled account, a disabled membership and a remotely revoked session', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  await registerBusiness(ctx.client, FORM);
  ctx.fake.business(FORM.name).status = 'approved';
  ctx.fake.setMember(FORM.name, 'owner@shop.test', { status: 'disabled' });
  assert.equal((await ctx.gate()).state, 'member_disabled');
  ctx.fake.setMember(FORM.name, 'owner@shop.test', { status: 'active' });
  ctx.fake.disableUser('owner@shop.test');
  assert.equal((await ctx.gate()).state, 'account_disabled');
  ctx.fake.user('owner@shop.test').disabled = false;
  ctx.fake.revokeSessionsOf('owner@shop.test');
  assert.equal((await ctx.gate()).state, 'session_revoked');
  assert.equal(ctx.storage.get(SESSION_KEY), null, 'a revoked session is signed out locally');
  assert.equal((await ctx.gate()).state, 'signed_out');
});

test('gate OFFLINE: the last verified answer keeps the POS usable for 7 days, then the person must reconnect', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  await registerBusiness(ctx.client, FORM);
  ctx.fake.business(FORM.name).status = 'approved';
  assert.equal((await ctx.gate()).state, 'ready'); // online check → cached
  ctx.fake.setOffline(true);

  const day3 = (ctx.clock.t += 3 * 24 * 3600 * 1000);
  const g = await resolveGate(ctx.client, { storage: ctx.storage, now: () => day3 });
  assert.equal(g.state, 'ready');
  assert.equal(g.offline, true);

  const day8 = (ctx.clock.t += 5 * 24 * 3600 * 1000);
  assert.equal((await resolveGate(ctx.client, { storage: ctx.storage, now: () => day8 })).state, 'offline_blocked');
  assert.ok(OFFLINE_GRACE_MS === 7 * 24 * 3600 * 1000);
});

test('gate OFFLINE: with no earlier verified answer the person is blocked, never let in', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  ctx.fake.setOffline(true);
  assert.equal((await ctx.gate()).state, 'offline_blocked');
  assert.equal(ctx.storage.get(ACCESS_KEY), null);
});

test('gate OFFLINE: a cached answer of ANOTHER person is never used', async () => {
  const ctx = setup();
  await login(ctx, 'first@shop.test');
  await registerBusiness(ctx.client, FORM);
  ctx.fake.business(FORM.name).status = 'approved';
  await ctx.gate();
  await ctx.client.auth.signOut();
  await login(ctx, 'second@shop.test');
  ctx.fake.setOffline(true);
  assert.equal((await ctx.gate()).state, 'offline_blocked');
});

test('gate: the Super Admin must enrol / pass MFA before the admin powers exist', async () => {
  const ctx = setup();
  await login(ctx, 'root@platform.test', { admin: true });
  assert.equal((await ctx.gate()).state, 'mfa_enroll');
  await rejects(reviewBusiness(ctx.client, 'x', 'approve'), 'not_platform_admin');
  const e = await ctx.client.auth.mfa.enroll();
  await ctx.client.auth.mfa.verify({ factorId: e.factorId, code: ctx.fake.totpCode });
  assert.equal((await ctx.gate()).state, 'super_admin');

  // a later sign-in (aal1 again) is asked for the code, not for enrolment
  await ctx.client.auth.signOut();
  await ctx.client.auth.signInWithPassword({ email: 'root@platform.test', password: 'Str0ngPassw0rd' });
  assert.equal((await ctx.gate()).state, 'mfa_challenge');
});

// ---- registration and approval (the business flow) ---------------------------------------------------------

test('registerBusiness accepts Bengali digits; bad input and the plan limit are explained by code', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  await rejects(registerBusiness(ctx.client, { ...FORM, phone: '12345' }), 'invalid_phone');
  await rejects(registerBusiness(ctx.client, { ...FORM, name: 'x' }), 'invalid_name');
  const id = await registerBusiness(ctx.client, FORM);
  assert.match(id, /^[0-9a-f-]{36}$/);
  assert.equal(ctx.fake.business(FORM.name).phone, '01712345678', 'Bengali digits and the dash were normalised');
  await rejects(registerBusiness(ctx.client, { ...FORM, name: 'দ্বিতীয় দোকান' }), 'plan_limit:businesses');
});

test('an unverified e-mail cannot apply', async () => {
  const ctx = setup();
  ctx.fake.createUser({ email: 'new@shop.test', confirmed: false });
  ctx.fake.user('new@shop.test').confirmed = true; // sign in needs a confirmed e-mail …
  await ctx.client.auth.signInWithPassword({ email: 'new@shop.test', password: 'Str0ngPassw0rd' });
  ctx.fake.user('new@shop.test').confirmed = false; // … the server still re-checks on every call
  await rejects(registerBusiness(ctx.client, FORM), 'email_not_verified');
});

test('the Super Admin approves; a normal owner cannot approve themselves', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  const id = await registerBusiness(ctx.client, FORM);
  await rejects(reviewBusiness(ctx.client, id, 'approve'), 'not_platform_admin');

  const admin = createCloudClient({ url: ctx.fake.url, key: ctx.fake.key, storage: memoryStorage(), fetchImpl: ctx.fake.fetch, now: () => ctx.clock.t });
  ctx.fake.createUser({ email: 'root@platform.test' });
  ctx.fake.addAdmin('root@platform.test');
  await admin.auth.signInWithPassword({ email: 'root@platform.test', password: 'Str0ngPassw0rd' });
  await rejects(reviewBusiness(admin, id, 'approve'), 'not_platform_admin'); // aal1: no MFA yet
  const e = await admin.auth.mfa.enroll();
  await admin.auth.mfa.verify({ factorId: e.factorId, code: ctx.fake.totpCode });

  const pending = await listBusinesses(admin, 'pending');
  assert.equal(pending.length, 1);
  assert.equal(pending[0].owner.email, 'owner@shop.test');

  await reviewBusiness(admin, id, 'approve');
  assert.equal((await listBusinesses(admin, 'pending')).length, 0);
  assert.equal((await listBusinesses(admin, 'approved')).length, 1);
  assert.equal((await ctx.gate()).state, 'ready');
  await rejects(reviewBusiness(admin, id, 'approve'), 'invalid_transition');

  await rejects(setSuspension(admin, id, true, 'no'), 'reason_required');
  await setSuspension(admin, id, true, 'unpaid dues dispute');
  assert.equal((await ctx.gate()).state, 'suspended');
  await setSuspension(admin, id, false);
  assert.equal((await ctx.gate()).state, 'ready');
});

test('rejection needs a reason; the owner sees it, corrects the details and resubmits', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  const id = await registerBusiness(ctx.client, FORM);
  const admin = createCloudClient({ url: ctx.fake.url, key: ctx.fake.key, storage: memoryStorage(), fetchImpl: ctx.fake.fetch, now: () => ctx.clock.t });
  ctx.fake.createUser({ email: 'root@platform.test' });
  ctx.fake.addAdmin('root@platform.test');
  await admin.auth.signInWithPassword({ email: 'root@platform.test', password: 'Str0ngPassw0rd' });
  const e = await admin.auth.mfa.enroll();
  await admin.auth.mfa.verify({ factorId: e.factorId, code: ctx.fake.totpCode });

  await rejects(reviewBusiness(admin, id, 'reject', ''), 'reason_required');
  await reviewBusiness(admin, id, 'reject', 'ট্রেড লাইসেন্স অস্পষ্ট');
  const g = await ctx.gate();
  assert.equal(g.state, 'rejected');
  assert.equal(g.business.status_reason, 'ট্রেড লাইসেন্স অস্পষ্ট');

  await rejects(resubmitBusiness(ctx.client, 'not-mine'), 'business_not_found');
  const rows = await updateApplication(ctx.client, id, { ...FORM, tradeLicense: 'TL-123', phone: '+8801812345678' });
  assert.equal(rows.length, 1);
  assert.equal(rows[0].phone, '01812345678');
  await resubmitBusiness(ctx.client, id);
  assert.equal((await ctx.gate()).state, 'pending');
  await rejects(resubmitBusiness(ctx.client, id), 'invalid_transition');
});

test('the owner cannot change the status through the table API (only the application details)', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  const id = await registerBusiness(ctx.client, FORM);
  await rejects(ctx.client.update('businesses', { id: `eq.${id}` }, { status: 'approved' }), 'permission_denied');
  assert.equal(ctx.fake.business(FORM.name).status, 'pending');
});

test('recordLogin: the first device is not "new among others"; a second one is reported', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  const first = await recordLogin(ctx.client, ctx.storage, { navigator: { userAgent: 'Mozilla Windows' }, crypto });
  assert.equal(first.other_devices, 0);
  assert.equal(deviceIdentity(ctx.storage).id.length >= 8, true);
  assert.equal(deviceIdentity(ctx.storage).label, 'Browser'); // default env has no navigator in Node
  const second = createCloudClient({ url: ctx.fake.url, key: ctx.fake.key, storage: memoryStorage(), fetchImpl: ctx.fake.fetch, now: () => ctx.clock.t });
  await second.auth.signInWithPassword({ email: 'owner@shop.test', password: 'Str0ngPassw0rd' });
  const r = await recordLogin(second, memoryStorage(), { navigator: { userAgent: 'Mozilla Android' }, crypto });
  assert.equal(r.new_device, true);
  assert.equal(r.other_devices, 1);
  ctx.fake.setOffline(true);
  assert.equal(await recordLogin(ctx.client, ctx.storage), null, 'offline is not an error');
});

// ---- phone numbers -------------------------------------------------------------------------------------------------

test('normalizeBdPhone / isBdMobile', () => {
  assert.equal(normalizeBdPhone('০১৭১২-৩৪৫৬৭৮'), '01712345678');
  assert.equal(normalizeBdPhone('+880 1712 345678'), '01712345678');
  assert.equal(normalizeBdPhone('8801712345678'), '01712345678');
  assert.equal(normalizeBdPhone(null), '');
  assert.ok(isBdMobile('01912345678'));
  assert.ok(!isBdMobile('01212345678'), '012… is not a mobile prefix');
  assert.ok(!isBdMobile('1712345678'));
});

// ---- i18n -------------------------------------------------------------------------------------------------------------

test('i18n: both dictionaries have exactly the same keys, none empty, same {placeholders}', () => {
  const ek = Object.keys(en).sort();
  const bk = Object.keys(bn).sort();
  assert.deepEqual(bk.filter((k) => !(k in en)), [], 'keys only in bn');
  assert.deepEqual(ek.filter((k) => !(k in bn)), [], 'keys only in en');
  const ph = (s) => (s.match(/\{\w+\}/g) || []).sort().join(',');
  for (const k of ek) {
    assert.ok(en[k].trim() && bn[k].trim(), `empty text for ${k}`);
    assert.equal(ph(bn[k]), ph(en[k]), `placeholders differ for ${k}`);
  }
});

test('i18n: the Bengali dictionary is Bengali (the few brand / sample strings excepted)', () => {
  const allowed = new Set(['app.name', 'auth.email.placeholder']);
  const latinOnly = Object.entries(bn).filter(([k, v]) => !allowed.has(k) && !/[\u0980-\u09FF]/.test(v)).map(([k]) => k);
  assert.deepEqual(latinOnly, []);
});

test('i18n: t() placeholders, Bengali digits, fallbacks and the start-up language', () => {
  assert.deepEqual(LOCALES.sort(), ['bn', 'en']);
  setLocale('bn');
  try {
    assert.equal(t('auth.otp.resendWait', { s: 42 }), '৪২ সেকেন্ড পর নতুন কোড নিতে পারবেন');
    assert.equal(t('auth.verify.text', { email: 'a1@shop.test' }), 'a1@shop.test ঠিকানায় পাঠানো ৬ সংখ্যার কোডটি লিখুন।', 'strings are not digit-converted');
    assert.equal(t('no.such.key'), 'no.such.key');
    assert.equal(nDigits('2026-11'), '২০২৬-১১');
  } finally {
    setLocale('en');
  }
  assert.equal(t('auth.otp.resendWait', { s: 42 }), 'You can ask for a new code in 42 s');
  assert.equal(nDigits(12), '12');
  assert.equal(toBnDigits('0123456789'), '০১২৩৪৫৬৭৮৯');
  assert.equal(fromBnDigits('০১২৩৪৫৬৭৮৯ abc'), '0123456789 abc');
  assert.throws(() => setLocale('fr'));
  assert.equal(initLocale({ cloudEnabled: true }), 'bn');
  assert.equal(initLocale({ cloudEnabled: false }), 'en');
  assert.equal(initLocale({ cloudEnabled: true, search: '?lang=en' }), 'en');
  assert.equal(initLocale({ cloudEnabled: false, stored: 'bn' }), 'bn');
  assert.equal(initLocale({ cloudEnabled: true, stored: 'xx' }), 'bn');
  setLocale('en');
  assert.equal(getLocale(), 'en');
});

// ---- the running app keeps checking ---------------------------------------------------------------------------------

test('watch: ready is not blocked; a suspension, a revoked session and an unverifiable offline device are', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  await registerBusiness(ctx.client, FORM);
  const b = ctx.fake.business(FORM.name);
  b.status = 'approved';
  assert.deepEqual(await checkOnce(ctx.client, ctx.storage), { blocked: false, state: 'ready' });

  ctx.fake.setOffline(true); // offline with a fresh verified answer: the POS keeps running
  assert.equal((await checkOnce(ctx.client, ctx.storage)).blocked, false);
  ctx.fake.setOffline(false);

  Object.assign(b, { status: 'suspended', status_reason: 'dispute' });
  assert.deepEqual(await checkOnce(ctx.client, ctx.storage), { blocked: true, state: 'suspended' });
  Object.assign(b, { status: 'approved', status_reason: '' });

  ctx.fake.revokeSessionsOf('owner@shop.test');
  assert.equal((await checkOnce(ctx.client, ctx.storage)).state, 'session_revoked');
});

test('watch: an unexpected server failure never blocks the shop', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  const broken = { ...ctx.client, rpc: async () => { throw new CloudError('unknown', 'boom', { status: 500 }); } };
  const warn = console.warn;
  console.warn = () => {};
  try {
    assert.deepEqual(await checkOnce(broken, ctx.storage), { blocked: false, state: 'unknown' });
  } finally {
    console.warn = warn;
  }
});

test('startCloudWatch: calls onBlocked exactly once, then stops; the stop function clears the timer', async () => {
  const ctx = setup();
  await login(ctx, 'owner@shop.test');
  await registerBusiness(ctx.client, FORM);
  const b = ctx.fake.business(FORM.name);
  b.status = 'approved';
  const handlers = [];
  const cleared = [];
  const env = { setInterval: (fn, ms) => (handlers.push([fn, ms]), 7), clearInterval: (id) => cleared.push(id), addEventListener() {}, removeEventListener() {} };
  const blocked = [];
  const stop = startCloudWatch({ client: ctx.client, storage: ctx.storage, onBlocked: (st) => blocked.push(st), intervalMs: 1234, env });
  assert.equal(handlers[0][1], 1234);
  await handlers[0][0]();
  assert.deepEqual(blocked, []);
  b.status = 'suspended';
  await handlers[0][0]();
  await handlers[0][0]();
  assert.deepEqual(blocked, ['suspended'], 'reported once');
  stop();
  assert.deepEqual(cleared, [7]);
});

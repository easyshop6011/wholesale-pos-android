/**
 * Server-side sync rules, tested against the REAL Code.gs (see helpers/apps-script-fake.mjs).
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { createScript, inv } from './helpers/apps-script-fake.mjs';

test('Code.gs: wrong, missing and placeholder tokens are refused; ping reports version and capabilities', () => {
  const s = createScript();
  const bad = JSON.parse(s.api.doPost({ postData: { contents: JSON.stringify({ token: 'nope', action: 'ping' }) } }).getContent());
  assert.equal(bad.ok, false);
  assert.match(bad.error, /Unauthorized/);
  assert.equal(JSON.parse(s.api.doPost({ postData: { contents: JSON.stringify({ action: 'ping' }) } }).getContent()).ok, false);
  assert.ok(!JSON.stringify(bad).includes(s.token), 'the secret is never echoed back');
  const same = createScript({ token: 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET' });
  assert.equal(same.call({ action: 'ping' }).ok, false, 'the placeholder token is refused');
  const ok = s.call({ action: 'ping' });
  assert.equal(ok.ok, true);
  assert.equal(ok.version, 4);
  for (const c of ['invoices', 'payments', 'returns', 'conflicts', 'verify', 'catalog']) assert.ok(ok.capabilities.includes(c), c);
  // a token of the same length but different content is refused too (constant-time compare path)
  assert.equal(createScript({ token: 'abcdefghij' }).api.doPost({ postData: { contents: JSON.stringify({ token: 'abcdefghik', action: 'ping' }) } }).getContent().includes('Unauthorized'), true);
});

test('Code.gs: an invoice is inserted once; re-sending it is a duplicate and adds no rows', () => {
  const s = createScript();
  assert.deepEqual(s.call({ action: 'syncInvoices', invoices: [inv()] }).results, [{ id: 'inv-1', result: 'inserted' }]);
  const sh = s.sheet('Invoices');
  assert.equal(sh.rows().length, 2, 'one row per product line');
  assert.deepEqual(s.call({ action: 'syncInvoices', invoices: [inv(), inv()] }).results.map((r) => r.result), ['duplicate', 'duplicate']);
  assert.equal(sh.rows().length, 2, 'nothing was added by the retries');
  // invoice-level money appears once per invoice so a SUM of the column is right
  assert.deepEqual([sh.rows()[0][8], sh.rows()[1][8]], [100, ''], 'Paid only on the first line');
  assert.equal(sh.rows()[0][14], 300, 'Grand Total on the first line');
  assert.equal(sh.rows()[0][15], 'Cash', 'payment method column');
  // the same id twice INSIDE one batch is also inserted only once
  const s2 = createScript();
  assert.deepEqual(s2.call({ action: 'syncInvoices', invoices: [inv({ id: 'x' }), inv({ id: 'x', invoiceNo: 'INV-2' })] }).results.map((r) => r.result), ['inserted', 'duplicate']);
});

test('Code.gs: a void updates every row; a late older copy can NEVER turn it back to Active', () => {
  const s = createScript();
  s.call({ action: 'syncInvoices', invoices: [inv()] });
  const voided = inv({ status: 'Void', rev: 2, voidReason: 'wrong customer', voidedAt: '2026-10-30T05:00:00.000Z' });
  assert.deepEqual(s.call({ action: 'syncInvoices', invoices: [voided] }).results, [{ id: 'inv-1', result: 'updated' }]);
  const sh = s.sheet('Invoices');
  for (const r of sh.rows()) assert.deepEqual([r[11], r[16], r[17], r[18]], ['Void', 2, 'wrong customer', '2026-10-30T05:00:00.000Z']);
  assert.equal(s.call({ action: 'syncInvoices', invoices: [voided] }).results[0].result, 'duplicate', 'sending the void twice changes nothing');
  assert.equal(s.call({ action: 'syncInvoices', invoices: [inv()] }).results[0].result, 'duplicate', 'a stale rev-1 retry is ignored');
  for (const r of sh.rows()) assert.equal(r[11], 'Void', 'still void');
  // a void sent WITHOUT a revision (older app) still takes effect once
  const s2 = createScript();
  s2.call({ action: 'syncInvoices', invoices: [inv({ rev: undefined })] });
  assert.equal(s2.call({ action: 'syncInvoices', invoices: [inv({ rev: undefined, status: 'Void' })] }).results[0].result, 'updated');
});

test('Code.gs: an invoice NUMBER used by a different invoice (two devices, same device code) is a conflict, not a silent duplicate', () => {
  const s = createScript();
  s.call({ action: 'syncInvoices', invoices: [inv()] });
  const clash = s.call({ action: 'syncInvoices', invoices: [inv({ id: 'inv-OTHER-DEVICE' })] }).results[0];
  assert.equal(clash.result, 'conflict');
  assert.match(clash.message, /INV-261030-0001/);
  assert.equal(s.sheet('Invoices').rows().length, 2, 'nothing was written for the clashing invoice');
  assert.equal(s.call({ action: 'syncInvoices', invoices: [inv({ id: 'inv-2', invoiceNo: 'INV-261030-0002' })] }).results[0].result, 'inserted', 'a different number is fine');
});

test('Code.gs: invalid or hostile payloads are rejected per record; oversized requests are refused; formulas are neutralised', () => {
  const s = createScript();
  const r = s.call({ action: 'syncInvoices', invoices: [inv({ id: 'a', total: 'abc' }), inv({ id: 'b', items: [] }), null, inv({ id: 'c', invoiceNo: 'C1', customer: '=HYPERLINK("http://evil","x")' })] }).results;
  assert.deepEqual(r.map((x) => x.result), ['invalid', 'invalid', 'invalid', 'inserted']);
  assert.equal(s.sheet('Invoices').rows()[0][3].startsWith("'="), true, 'a customer name starting with = cannot become a formula');
  const big = Array.from({ length: 501 }, (_, i) => inv({ id: `i${i}`, invoiceNo: `N${i}` }));
  const res = s.call({ action: 'syncInvoices', invoices: big });
  assert.equal(res.ok, false);
  assert.match(res.error, /Too many records/);
  assert.equal(s.call({ action: 'nonsense' }).ok, false);
});

test('Code.gs: payments and returns are deduplicated and keep their money on the first row only', () => {
  const s = createScript();
  const pay = { id: 'p1', date: '2026-10-30', time: '11:00:00', customer: 'Rahim', phone: '017', amount: 50, method: 'bKash', note: 'cash box' };
  assert.equal(s.call({ action: 'syncPayments', payments: [pay] }).results[0].result, 'inserted');
  assert.equal(s.call({ action: 'syncPayments', payments: [pay, { ...pay, id: 'bad', amount: 'x' }] }).results.map((x) => x.result).join(), 'duplicate,invalid');
  assert.equal(s.sheet('Payments').rows().length, 1);
  assert.equal(s.sheet('Payments').rows()[0][7], 'bKash');
  const ret = { id: 'r1', returnNo: 'RET-1', invoiceNo: 'INV-1', date: '2026-10-30', time: '12:00:00', customer: 'Rahim', phone: '', amount: 150, creditApplied: 100, refund: 50, method: 'Cash', reason: 'damaged', items: [{ name: 'Rice', qty: 1, unitPrice: 100, amount: 100 }, { name: 'Oil', qty: 1, unitPrice: 50, amount: 50 }] };
  assert.equal(s.call({ action: 'syncReturns', returns: [ret] }).results[0].result, 'inserted');
  assert.equal(s.call({ action: 'syncReturns', returns: [ret] }).results[0].result, 'duplicate');
  const rows = s.sheet('Returns').rows();
  assert.equal(rows.length, 2);
  assert.deepEqual([rows[0][11], rows[1][11]], [150, ''], 'Return Value counted once');
});

test('Code.gs: stock written by ANOTHER device is flagged as a conflict (and still updated); same device is not', () => {
  const s = createScript();
  const prod = (o) => ({ id: 'p1', code: 'P-0001', name: 'Rice', sku: '', category: '', unit: 'bag', costPrice: 100, defaultPrice: 120, stock: 10, lowStockLevel: 5, status: 'Active', device: 'dAAAA1111', ...o });
  assert.equal(s.call({ action: 'upsertProducts', products: [prod()] }).results[0].result, 'inserted');
  assert.deepEqual(s.call({ action: 'upsertProducts', products: [prod({ stock: 8 })] }).results[0], { id: 'p1', result: 'updated' }, 'same device: normal update');
  const other = s.call({ action: 'upsertProducts', products: [prod({ stock: 3, device: 'dBBBB2222' })] }).results[0];
  assert.deepEqual(other, { id: 'p1', result: 'updated', conflict: true });
  assert.equal(s.sheet('Products').rows()[0][7], 3, 'last writer wins');
  assert.equal(s.call({ action: 'upsertProducts', products: [prod({ stock: 3, device: 'dCCCC3333' })] }).results[0].conflict, undefined, 'same stock from another device is not a conflict');
  assert.equal(s.call({ action: 'upsertCustomers', customers: [{ id: 'c1', code: 'C-0001', name: 'Rahim', phone: '017', address: '', due: 10 }] }).results[0].result, 'inserted');
});

test('Code.gs: a sheet made by an older script version gets the new column titles without touching its data', () => {
  const s = createScript();
  // simulate a v3 sheet: 15 headers + one existing row
  const old = s.sheets.get('Invoices') || (() => { s.call({ action: 'syncInvoices', invoices: [] }); return s.sheets.get('Invoices'); })();
  old.data = [['Invoice Number', 'Date', 'Time', 'Customer', 'Product', 'Quantity', 'Unit Price', 'Total', 'Paid', 'Due', 'Invoice ID', 'Status', 'Customer Phone', 'Discount', 'Grand Total'], ['OLD-1', '2026-01-01', '09:00:00', 'Karim', 'Rice', 1, 100, 100, 100, 0, 'old-1', 'Active', '', 0, 100]];
  s.call({ action: 'syncInvoices', invoices: [inv()] });
  assert.deepEqual(old.data[0].slice(15), ['Payment Method', 'Revision', 'Void Reason', 'Voided At']);
  assert.deepEqual(old.data[1].slice(0, 3), ['OLD-1', '2026-01-01', '09:00:00'], 'existing data untouched');
  // the old row has no revision: a void with rev 2 still updates it
  assert.equal(s.call({ action: 'syncInvoices', invoices: [inv({ id: 'old-1', invoiceNo: 'OLD-1', status: 'Void', rev: 2 })] }).results[0].result, 'updated');
});

test('Code.gs: verifyInvoices lists only the ids that are really in the sheet', () => {
  const s = createScript();
  s.call({ action: 'syncInvoices', invoices: [inv()] });
  assert.deepEqual(s.call({ action: 'verifyInvoices', ids: ['inv-1', 'ghost'] }).missing, ['ghost']);
});

/**
 * Business time is Asia/Dhaka whatever the device's own zone is. `npm test` runs this file
 * three times with TZ=UTC, America/Los_Angeles and Asia/Tokyo (see package.json).
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { dhakaParts, dhakaDate, fmtDhakaDateTime, fmtDhakaTime, fmtDhakaDate, csvDhakaStamp, dhakaDayBounds, TIME_ZONE } from '../../js/core/datetime.js';
import { dateParts, addDays, monthRange } from '../../js/core/utils.js';

test(`stored date / time / month are Dhaka business time (device zone: ${process.env.TZ || 'default'})`, () => {
  assert.equal(TIME_ZONE, 'Asia/Dhaka');
  // 20:34:09 UTC on 4 Oct = 02:34:09 on 5 Oct in Dhaka (UTC+6, no daylight saving)
  const p = dhakaParts(new Date('2026-10-04T20:34:09Z'));
  assert.deepEqual(p, { date: '2026-10-05', time: '02:34:09', month: '2026-10', iso: '2026-10-04T20:34:09.000Z' });
  assert.deepEqual(dateParts(new Date('2026-12-31T18:00:00Z')), { date: '2027-01-01', time: '00:00:00', month: '2027-01', iso: '2026-12-31T18:00:00.000Z' }, 'new year arrives in Dhaka at 18:00 UTC');
  assert.equal(dateParts(new Date('2026-12-31T17:59:59Z')).date, '2026-12-31');
  assert.equal(dhakaDate('2026-03-01T18:30:00Z'), '2026-03-02');
  assert.equal(dhakaDate('garbage'), '');
  assert.equal(dhakaDate(''), '');
});

test('displayed times are Asia/Dhaka (24-hour, month names) and CSV stamps are sortable', () => {
  const iso = '2026-10-28T10:44:09.000Z';
  assert.equal(fmtDhakaDateTime(iso), '28 Oct 2026, 16:44');
  assert.equal(fmtDhakaDateTime(iso, { seconds: true }), '28 Oct 2026, 16:44:09');
  assert.equal(fmtDhakaTime(iso, { seconds: true }), '16:44:09');
  assert.equal(fmtDhakaDate(iso), '28 Oct 2026');
  assert.equal(csvDhakaStamp(iso), '2026-10-28 16:44:09');
  assert.equal(fmtDhakaDateTime('2026-10-28T18:00:00Z'), '29 Oct 2026, 00:00', 'midnight, not "24:00"');
  assert.equal(fmtDhakaDateTime(null), '');
});

test('calendar arithmetic does not depend on the device zone', () => {
  assert.equal(addDays('2026-10-31', 1), '2026-11-01');
  assert.equal(addDays('2026-03-01', -1), '2026-02-28');
  assert.equal(addDays('2028-02-28', 1), '2028-02-29');
  assert.equal(addDays('2026-12-31', 1), '2027-01-01');
  assert.deepEqual(monthRange('2026-02'), { from: '2026-02-01', to: '2026-02-28' });
  assert.deepEqual(monthRange('2028-02'), { from: '2028-02-01', to: '2028-02-29' });
});

test('a Dhaka day starts and ends at the right UTC instants', () => {
  assert.deepEqual(dhakaDayBounds('2026-10-29'), { startIso: '2026-10-28T18:00:00.000Z', endIso: '2026-10-29T17:59:59.999Z' });
});

/** Unit tests for ESC/POS encoding and the text receipt layout. */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { asciiize, encodeAscii, bitmapFromRGBA, EscPosBuilder } from '../../js/printing/escpos.js';
import { wrapText, leftRight, buildReceiptModel, buildTextReceipt } from '../../js/printing/receipt.js';

test('asciiize maps currency symbols and replaces unsupported characters', () => {
  assert.equal(asciiize('৳1,000 × 2 – ok'), 'Tk1,000 x 2 - ok');
  assert.equal(asciiize('café'), 'caf?');
  assert.deepEqual([...encodeAscii('AB')], [65, 66]);
});

test('builder emits the standard ESC/POS commands', () => {
  const b = new EscPosBuilder().init().align('center').bold(true).size(2, 2).line('Hi').feed(3).cut().build();
  assert.deepEqual([...b], [0x1b, 0x40, 0x1b, 0x61, 1, 0x1b, 0x45, 1, 0x1d, 0x21, 0x11, 72, 105, 10, 0x1b, 0x64, 3, 0x1d, 0x56, 0x42, 0]);
});

test('bitmapFromRGBA packs black pixels into bits (MSB first)', () => {
  const px = (v) => [v, v, v, 255];
  // 8 px wide, 1 row: black white black white black white black white -> 10101010
  const rgba = Uint8ClampedArray.from([0, 255, 0, 255, 0, 255, 0, 255].flatMap(px));
  const bmp = bitmapFromRGBA(rgba, 8, 1);
  assert.equal(bmp.bytesPerRow, 1);
  assert.equal(bmp.data[0], 0b10101010);
});

test('raster output is split into bands with a valid GS v 0 header', () => {
  const bmp = { width: 576, height: 400, bytesPerRow: 72, data: new Uint8Array(72 * 400) };
  const out = new EscPosBuilder().raster(bmp, 192).build();
  assert.equal(out.length, 3 * 8 + 72 * 400); // 192 + 192 + 16 rows
  assert.deepEqual([...out.slice(0, 8)], [0x1d, 0x76, 0x30, 0, 72, 0, 192, 0]);
});

test('wrapText and leftRight respect the column width', () => {
  assert.deepEqual(wrapText('aaa bbb ccc', 7), ['aaa bbb', 'ccc']);
  assert.deepEqual(wrapText('abcdefghij', 4), ['abcd', 'efgh', 'ij']);
  assert.equal(leftRight('Total', '100.00', 20), 'Total         100.00');
  assert.equal(leftRight('Total', '100.00', 20).length, 20);
});

const invoice = { invoiceNo: 'INV-261027-0001', date: '2026-10-27', time: '13:41:45', customerName: 'Rahim Traders', customerPhone: '01711000001', subtotal: 18600, discount: 600, total: 18000, paid: 10000, due: 8000, previousDue: 0, status: 'active', createdByName: 'Irfan' };
const items = [
  { name: 'Basmati Rice 25kg', unit: 'bag', qty: 4, unitPrice: 2450, total: 9800 },
  { name: 'Soybean Oil 5L', unit: 'pc', qty: 10, unitPrice: 880, total: 8800 },
];
const settingsSnap = { businessName: 'Dhaka Wholesale', address: '12 Karwan Bazar', phone: '01700-123456', footer: 'Thank you!', currency: '৳' };

test('80 mm text receipt fits 48 columns and shows every required figure', () => {
  const model = buildReceiptModel(invoice, items, settingsSnap);
  const bytes = buildTextReceipt(model, { columns: 48 });
  const text = Buffer.from(bytes).toString('latin1');
  for (const needle of ['INV-261027-0001', 'Rahim Traders', '01711000001', 'Basmati Rice 25kg', '9,800.00', '18,000.00', '10,000.00', '8,000.00', 'Thank you!', 'Dhaka Wholesale']) {
    assert.ok(text.includes(needle), `missing "${needle}"`);
  }
  // Printable lines (strip ESC/GS control sequences) never exceed the paper width.
  const printable = text.replace(/\x1b[@=]|\x1b[aEd2].|\x1d![\x00-\xff]|\x1dV[\x00-\xff]{2}|\x1b!./g, '').split('\n');
  for (const l of printable) assert.ok(l.length <= 48 + 4, `line too long (${l.length}): ${l}`);
});

/**
 * Runs the REAL integrations/google-apps-script/Code.gs in Node against the in-memory
 * Google fake (tests/shared/fake-google.js). Lets the unit tests prove the SERVER side of
 * the sync (duplicates, void revisions, number conflicts, device conflicts, limits)
 * without a Google account.
 */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { loadScript } from '../../shared/fake-google.js';

const CODE = readFileSync(fileURLToPath(new URL('../../../integrations/google-apps-script/Code.gs', import.meta.url)), 'utf8');

/** Create a fresh fake Google environment with the script already loaded. */
export const createScript = (opts) => loadScript(CODE, opts);

/** Small builder so each test reads like a story. */
export const inv = (o = {}) => ({
  id: 'inv-1', invoiceNo: 'INV-261030-0001', date: '2026-10-30', time: '10:00:00', customer: 'Rahim', phone: '017', status: 'Active',
  discount: 0, total: 300, paid: 100, due: 200, method: 'Cash', rev: 1, voidReason: '', voidedAt: '',
  items: [{ name: 'Rice', qty: 2, unitPrice: 100, total: 200 }, { name: 'Oil', qty: 1, unitPrice: 100, total: 100 }], ...o,
});

/** A small but COMPLETE and internally consistent v2 backup, used to test the validator. */
const hash = { algo: 'PBKDF2-SHA256', iter: 1000, salt: 'c2FsdA==', hash: 'aGFzaA==' };

export function validBackup() {
  const t = '2026-10-29T04:00:00.000Z';
  return {
    format: 'wholesale-pos-backup',
    version: 2,
    exportedAt: '2026-10-30T10:00:00.000Z',
    stores: {
      users: [{ id: 'u1', username: 'owner', usernameLower: 'owner', displayName: 'Owner', role: 'admin', active: true, passHash: hash, pinHash: hash }],
      settings: [{ key: 'businessName', value: 'দোকান' }],
      meta: [{ key: 'seq:2026-10-29', value: 1 }],
      categories: [],
      products: [{ id: 'p1', code: 'P-0001', name: 'Rice', nameLower: 'rice', unit: 'bag', stock: 8, lowStockLevel: 5, costPrice: 100, defaultPrice: 120, active: true }],
      customers: [{ id: 'c1', code: 'C-0001', name: 'রহিম', nameLower: 'রহিম', phone: '01711000001' }],
      invoices: [{ id: 'i1', invoiceNo: 'INV-261029-0001', date: '2026-10-29', time: '10:00:00', createdAt: t, customerId: 'c1', subtotal: 300, discount: 0, total: 300, paid: 100, due: 200, status: 'active' }],
      invoiceItems: [{ id: 'l1', invoiceId: 'i1', productId: 'p1', qty: 3, unitPrice: 100, total: 300 }],
      payments: [{ id: 'pay1', customerId: 'c1', amount: 50, date: '2026-10-29', createdAt: t }],
      auditLog: [{ id: 'a1', createdAt: t, action: 'auth.login' }],
      syncLog: [],
      stockMovements: [
        { id: 'm1', productId: 'p1', type: 'created', qty: 0, previousStock: 0, balance: 0, createdAt: '2026-10-29T03:00:00.000Z' },
        { id: 'm2', productId: 'p1', type: 'initial', qty: 11, previousStock: 0, balance: 11, createdAt: '2026-10-29T03:00:00.001Z' },
        { id: 'm3', productId: 'p1', type: 'sale', qty: -3, previousStock: 11, balance: 8, createdAt: t, ref: 'i1', refNo: 'INV-261029-0001' },
      ],
      salesReturns: [],
    },
  };
}

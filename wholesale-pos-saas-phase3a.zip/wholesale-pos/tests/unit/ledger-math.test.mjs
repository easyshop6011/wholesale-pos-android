/**
 * Pure bookkeeping rules: stock-history chains, customer balances, discount sharing,
 * oldest-first settlement, old-row upgrades and the exported CSV text.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { checkProductLedger, MOVEMENT_TYPES } from '../../js/services/stockledger.js';
import { computeBalances, allocateDiscount, allocateSettlements, customerHistoryToCSV } from '../../js/services/customers.js';
import { movementsToCSV } from '../../js/services/inventory.js';
import { upgradeMovement } from '../../js/core/upgrade.js';
import { redactSecrets, isQuotaError, retryDelayMs, nextDelayMs, QUOTA_COOLDOWN_MS } from '../../js/services/sync-backoff.js';
import { toMinor } from '../../js/core/money.js';

const mv = (o) => ({ id: o.createdAt, productId: 'p', ...o });

test('stock history: a clean chain checks out; a gap, a jump or a wrong total is reported', () => {
  const rows = [
    mv({ createdAt: '2026-10-01T01:00:00.000Z', type: 'created', qty: 0, previousStock: 0, balance: 0 }),
    mv({ createdAt: '2026-10-01T01:00:00.001Z', type: 'initial', qty: 10, previousStock: 0, balance: 10 }),
    mv({ createdAt: '2026-10-02T01:00:00.000Z', type: 'sale', qty: -3, previousStock: 10, balance: 7 }),
    mv({ createdAt: '2026-10-03T01:00:00.000Z', type: 'return', qty: 1, previousStock: 7, balance: 8 }),
  ];
  const ok = checkProductLedger({ stock: 8 }, rows);
  assert.deepEqual([ok.ok, ok.untracked, ok.count], [true, 0, 4]);
  const wrongStock = checkProductLedger({ stock: 9 }, rows);
  assert.equal(wrongStock.ok, false);
  assert.match(wrongStock.problems[0], /Current stock 9 differs from the last recorded balance 8/);
  const jump = [...rows];
  jump[3] = { ...rows[3], previousStock: 6, balance: 7 };
  assert.match(checkProductLedger({ stock: 7 }, jump).problems.join(), /starts at 6 but the previous row ended at 7/);
  const arithmetic = [...rows];
  arithmetic[2] = { ...rows[2], balance: 6 };
  assert.match(checkProductLedger({ stock: 8 }, arithmetic).problems.join(), /10 \+ -3 ≠ 6/);
  // order in the array does not matter — time does
  assert.equal(checkProductLedger({ stock: 8 }, [...rows].reverse()).ok, true);
});

test('stock history: stock that pre-dates the history is REPORTED as untracked, never invented', () => {
  const none = checkProductLedger({ stock: 7 }, []);
  assert.deepEqual([none.ok, none.untracked, none.count, none.firstRecordedAt], [true, 7, 0, '']);
  const partial = checkProductLedger({ stock: 12 }, [mv({ createdAt: '2026-10-05T01:00:00.000Z', type: 'receive', qty: 5, previousStock: 7, balance: 12 })]);
  assert.deepEqual([partial.ok, partial.untracked], [true, 7], '7 units existed before the first recorded change');
  // rows from before this version carry no previousStock: it is derived from balance − qty
  const legacy = checkProductLedger({ stock: 8 }, [mv({ createdAt: '2026-10-05T01:00:00.000Z', type: 'sale', qty: -2, balance: 8 })]);
  assert.deepEqual([legacy.ok, legacy.untracked], [true, 10]);
});

test('every movement type has a label and a direction', () => {
  assert.deepEqual(Object.keys(MOVEMENT_TYPES).sort(), ['adjustment', 'created', 'damage', 'initial', 'receive', 'return', 'sale', 'void']);
  for (const d of Object.values(MOVEMENT_TYPES)) assert.ok(d.label && [-1, 0, 1].includes(d.sign));
});

test('old stock rows are upgraded from facts they already hold — nothing is invented or overwritten', () => {
  const old = { id: 'm', productId: 'p', type: 'sale', qty: -3, balance: 7, reason: 'Sale INV-261029-0001', createdAt: '2026-10-29T20:30:00.000Z', ref: 'i1' };
  const up = upgradeMovement(old);
  assert.deepEqual([up.previousStock, up.date, up.refNo], [10, '2026-10-30', 'INV-261029-0001'], 'Dhaka day of the stored time; invoice number from the reason');
  assert.equal(old.previousStock, undefined, 'input not mutated');
  assert.equal(upgradeMovement(up), up, 'idempotent: an up-to-date row is returned as is');
  assert.equal(upgradeMovement({ ...old, reason: 'Void INV-9' }).refNo, 'INV-9');
  assert.equal(upgradeMovement({ ...old, reason: 'delivery from Karim' }).refNo, undefined, 'free text is not guessed at');
  assert.equal(upgradeMovement({ ...old, previousStock: 99 }).previousStock, 99, 'an existing value is never overwritten');
  assert.equal(upgradeMovement(null), null);
});

test('customer balance = Σ due of ACTIVE invoices − payments − credit from returns (per customer)', () => {
  const invoices = [
    { customerId: 'a', due: 600, status: 'active' },
    { customerId: 'a', due: 300, status: 'void' },
    { customerId: 'b', due: 50.1, status: 'active' },
    { customerId: null, due: 0, status: 'active' },
  ];
  const payments = [{ customerId: 'a', amount: 250 }, { customerId: 'b', amount: 0.1 }, { customerId: 'a', amount: 0.2 }];
  const returns = [{ customerId: 'a', creditApplied: 100 }, { customerId: null, creditApplied: 0 }];
  const b = computeBalances(invoices, payments, returns);
  assert.equal(b.get('a'), 249.8);
  assert.equal(b.get('b'), 50);
  assert.equal(b.has(null), false);
  assert.equal(computeBalances([{ customerId: 'a', due: 100, status: 'void' }], [{ customerId: 'a', amount: 100 }]).get('a'), -100, 'paying for a voided invoice leaves the customer with CREDIT');
  assert.equal(computeBalances([], []).size, 0);
});

test('an invoice discount is shared across its lines and the shares add up EXACTLY', () => {
  const items = [{ total: 100 }, { total: 100 }, { total: 100 }];
  const s = allocateDiscount(items, 10);
  assert.deepEqual(s.map((x) => x.discountShare), [3.33, 3.33, 3.34]);
  assert.equal(toMinor(s.reduce((a, x) => a + x.discountShare, 0)), 1000);
  assert.deepEqual(s.map((x) => x.net), [96.67, 96.67, 96.66]);
  assert.deepEqual(allocateDiscount([{ total: 50 }], 7).map((x) => [x.discountShare, x.net]), [[7, 43]]);
  assert.deepEqual(allocateDiscount([{ total: 10 }, { total: 30 }], 0).map((x) => x.discountShare), [0, 0]);
  for (const [lines, d] of [[[13.37, 99.99, 0.01, 250], 33.33], [[1, 1, 1, 1, 1, 1, 1], 0.07]]) {
    const parts = allocateDiscount(lines.map((total) => ({ total })), d);
    assert.equal(toMinor(parts.reduce((a, x) => a + x.discountShare, 0)), toMinor(d), `shares of ${d}`);
    assert.ok(parts.every((x) => x.discountShare >= 0 && x.net >= 0));
  }
});

test('later payments settle the OLDEST unpaid invoices first (display only)', () => {
  const invs = [
    { id: 'new', createdAt: '2026-10-03T00:00:00Z', due: 300 },
    { id: 'old', createdAt: '2026-10-01T00:00:00Z', due: 500 },
    { id: 'paid', createdAt: '2026-10-02T00:00:00Z', due: 0 },
  ];
  const m = allocateSettlements(invs, toMinor(600));
  assert.deepEqual(m.get('old'), { laterPaid: 500, remainingDue: 0 });
  assert.deepEqual(m.get('new'), { laterPaid: 100, remainingDue: 200 });
  assert.equal(m.has('paid'), false);
  assert.deepEqual(allocateSettlements(invs, 0).get('old'), { laterPaid: 0, remainingDue: 500 });
  assert.deepEqual(allocateSettlements(invs, toMinor(5000)).get('new'), { laterPaid: 300, remainingDue: 0 }, 'surplus is customer credit, not allocated');
});

test('CSV exports: Bengali text intact, times in Dhaka, spreadsheet formulas neutralised, columns line up', () => {
  const rows = [{ createdAt: '2026-10-28T10:44:09.000Z', productId: 'p1', productCode: 'P-0001', productName: 'চাল ২৫ কেজি', type: 'receive', previousStock: 2, qty: 5, balance: 7, reason: '=SUM(A1)', refNo: '', userName: 'রহিম', unitCost: 90, supplier: 'Karim, Bros', batchNo: 'B-1' }];
  const csv = movementsToCSV(rows, { cost: true });
  const [head, line] = csv.split('\n');
  assert.match(head, /^"?Date & time \(Asia\/Dhaka\)"?,/);
  assert.match(line, /2026-10-28 16:44:09/);
  assert.ok(line.includes('চাল ২৫ কেজি') && line.includes('রহিম'));
  assert.ok(line.includes("'=SUM(A1)"), 'a reason starting with = cannot run as a formula');
  assert.ok(line.includes('"Karim, Bros"'), 'commas are quoted');
  assert.equal(head.split(',').length >= 13, true);
  assert.equal(movementsToCSV(rows).split('\n')[0].includes('Purchase cost'), false, 'cost columns only for people who may see them');

  const profile = {
    customer: { id: 'cid', code: 'C-0001', name: 'রহিম ট্রেডার্স', phone: '017' },
    entries: [
      { kind: 'payment', at: '2026-10-29T05:00:00.000Z', balance: 100, payment: { amount: 200, method: 'bkash', note: 'part' } },
      { kind: 'invoice', at: '2026-10-28T10:44:09.000Z', balance: 300, invoice: { invoiceNo: 'INV-1', status: 'active', total: 300, paid: 0, due: 300, paymentMethod: '', notes: '', items: [{ name: 'চাল', qty: 3, unit: 'kg', unitPrice: 100, total: 300, discountShare: 0, net: 300 }] } },
    ],
  };
  const c = customerHistoryToCSV(profile).split('\n');
  assert.equal(c.length, 3);
  assert.ok(c[1].includes('INV-1') && c[1].includes('চাল') && c[1].includes('রহিম ট্রেডার্স') && c[1].includes('2026-10-28 16:44:09'), 'oldest first in the file');
  assert.ok(c[2].includes('Payment received') && c[2].includes('bKash'));
  assert.equal(new Set(c.map((l) => l.split(',').length)).size >= 1, true);
});

test('sync helpers: tokens and script URLs never reach logs; quota errors wait at least 30 minutes', () => {
  const token = 'tok_SECRET_abcdef123456';
  const url = 'https://script.google.com/macros/s/AKfycbxDEPLOYMENT/exec';
  const msg = `Failed: ${url}?token=${token} said "bad ${token}"`;
  const out = redactSecrets(msg, [token, url]);
  assert.equal(out.includes(token), false);
  assert.equal(out.includes('AKfycbx'), false);
  assert.match(out, /\[hidden\]/);
  assert.equal(redactSecrets('see https://script.google.com/macros/s/OTHER/exec now', []).includes('OTHER'), false, 'any Apps Script URL is hidden');
  assert.equal(redactSecrets('plain text', [undefined, '', 'ab']), 'plain text', 'empty / tiny secrets are ignored (they would mangle ordinary text)');
  for (const q of ['Service invoked too many times for one day: urlfetch', 'Exceeded maximum execution time', 'HTTP 429', 'Quota exceeded', 'rate limit hit']) assert.equal(isQuotaError(q), true, q);
  for (const n of ['Network error', 'Server returned HTTP 500', 'Timed out']) assert.equal(isQuotaError(n), false, n);
  assert.ok(retryDelayMs(1, 'Service invoked too many times') >= QUOTA_COOLDOWN_MS);
  const fixed = { rand: () => 0.5 }; // no jitter, so both calls are comparable
  assert.equal(retryDelayMs(1, 'Network error', fixed), nextDelayMs(1, fixed), 'ordinary failures use the normal back-off');
  assert.equal(retryDelayMs(1, 'Quota exceeded', fixed), QUOTA_COOLDOWN_MS);
  assert.equal(QUOTA_COOLDOWN_MS, 30 * 60000);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { round2, round3, roundTo, sum, lineTotal, toMinor, fromMinor, toNum, parseMoney, parseQty, parseNumber, normalizeDigits } from '../../js/core/money.js';

test('round2 uses the decimal the user sees, not the binary expansion (half away from zero)', () => {
  const cases = [[1.005, 1.01], [2.675, 2.68], [1.255, 1.26], [8.345, 8.35], [0.1 + 0.2, 0.3], [-1.005, -1.01], [1.004999, 1], [123456789.125, 123456789.13], [0, 0], [1e-9, 0], [5e-7, 0], [99.995, 100], [0.615, 0.62]];
  for (const [input, want] of cases) assert.equal(round2(input), want, `round2(${input})`);
  assert.equal(Object.is(round2(-0.001), -0), false, 'never returns -0');
  assert.equal(round2(NaN), 0);
  assert.equal(round2(Infinity), 0);
  assert.equal(round3(2.0005), 2.001);
  assert.equal(roundTo(1234.5678, 1), 1234.6);
});

test('the classic float traps are exact: ten 10-paisa items, 19.99 × 3, 0.1 + 0.2', () => {
  assert.equal(sum(Array(10).fill(0.1)), 1);
  assert.equal(sum([0.1, 0.2]), 0.3);
  assert.equal(sum([19.99, 19.99, 19.99]), 59.97);
  assert.equal(sum([]), 0);
  assert.equal(lineTotal(3, 19.99), 59.97);
  assert.equal(lineTotal(2.505, 1.1), 2.76);
  assert.equal(lineTotal(0.333, 100), 33.3);
  assert.equal(lineTotal(1.5, 0.01), 0.02);
  assert.equal(toMinor(1.005), 101);
  assert.equal(fromMinor(101), 1.01);
  assert.throws(() => lineTotal(1e9, 1e9), /too large/);
});

test('one thousand random lines add up exactly the same as integer paisa arithmetic', () => {
  let seed = 7;
  const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  let minor = 0;
  const totals = [];
  for (let i = 0; i < 1000; i++) {
    const qty = Math.round(rnd() * 20000) / 1000; // up to 20.000, 3 decimals
    const price = Math.round(rnd() * 500000) / 100; // up to 5000.00
    const t = lineTotal(qty, price);
    // reference: BigInt exact arithmetic, half up
    const ref = (BigInt(Math.round(qty * 1000)) * BigInt(Math.round(price * 100)) + 500n) / 1000n;
    assert.equal(toMinor(t), Number(ref), `${qty} × ${price}`);
    totals.push(t);
    minor += Number(ref);
  }
  assert.equal(toMinor(sum(totals)), minor);
});

test('strict parsing rejects garbage instead of silently turning it into zero', () => {
  assert.equal(parseMoney('1,250.50', 'Price'), 1250.5);
  assert.equal(parseMoney('১২০.৫০', 'Price'), 120.5, 'Bengali digits are understood');
  assert.equal(parseMoney('', 'Discount'), 0);
  assert.equal(parseMoney(undefined, 'Discount'), 0);
  for (const bad of ['abc', '12abc', '1e3', 'NaN', 'Infinity', '--5', '1.2.3']) assert.throws(() => parseMoney(bad, 'Unit price'), /must be a number/, bad);
  assert.throws(() => parseMoney('-1', 'Paid amount'), /cannot be negative/);
  assert.throws(() => parseMoney(1e12, 'Paid amount'), /too large/);
  assert.throws(() => parseMoney(NaN, 'Paid amount'), /must be a number/);
  assert.equal(parseMoney(10.005, 'x'), 10.01);
  assert.equal(parseQty('2.5', 'Quantity'), 2.5);
  assert.equal(parseQty('0.0004', 'Quantity', { allowZero: true }), 0);
  assert.throws(() => parseQty('0', 'Quantity'), /greater than zero/);
  assert.throws(() => parseQty('0.0004', 'Quantity'), /greater than zero/, 'a quantity below the 3-decimal precision would not move stock');
  assert.throws(() => parseNumber('', 'Name', { empty: null }), /required/);
  assert.equal(normalizeDigits('০১২৩৪৫৬৭৮৯'), '0123456789');
  assert.equal(toNum('৳ 5'), 0, 'lenient parse (display only) never throws');
  assert.equal(toNum('1,000'), 1000);
});

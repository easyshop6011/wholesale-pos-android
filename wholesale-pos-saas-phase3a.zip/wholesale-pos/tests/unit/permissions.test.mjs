import test from 'node:test';
import assert from 'node:assert/strict';
import { PERMISSION_LIST, ROLES, effectivePermissions, userCan, cleanPerms } from '../../js/services/permissions.js';

const all = PERMISSION_LIST.map((p) => p.key);
const can = (role, perm, extra = {}) => userCan({ role, ...extra }, perm);

test('administrator can do everything; nobody else gets settings', () => {
  for (const k of all) assert.equal(can('admin', k), true, k);
  assert.equal(can('manager', 'settings'), false);
  assert.equal(can('employee', 'settings'), false);
});

test('manager: sells, voids, returns, adjusts stock and sees profit — but never settings', () => {
  for (const k of ['pos', 'invoices', 'invoices.void', 'invoices.return', 'customers', 'products.edit', 'inventory.view', 'inventory.adjust', 'reports', 'reports.profit', 'audit']) assert.equal(can('manager', k), true, k);
  assert.equal(can('manager', 'customers.delete'), false);
  assert.equal(can('manager', 'settings'), false);
});

test('cashier: sells, serves customers and VIEWS stock — nothing destructive, no cost or profit', () => {
  for (const k of ['pos', 'invoices', 'customers', 'products.view', 'inventory.view']) assert.equal(can('employee', k), true, k);
  for (const k of ['invoices.void', 'invoices.return', 'customers.delete', 'products.edit', 'inventory.adjust', 'reports', 'reports.profit', 'audit', 'settings']) assert.equal(can('employee', k), false, k);
});

test('a custom list replaces the role defaults, unknown keys are dropped, an admin cannot be restricted', () => {
  assert.equal(can('employee', 'invoices.void', { permissions: ['pos', 'invoices.void'] }), true);
  assert.equal(can('employee', 'customers', { permissions: ['pos'] }), false);
  assert.equal(can('admin', 'settings', { permissions: [] }), true);
  assert.deepEqual(cleanPerms(['pos', 'pos', 'hack', 'settings']), ['pos', 'settings']);
  assert.deepEqual(effectivePermissions(null), []);
  assert.equal(userCan(null, 'pos'), false);
  assert.equal(userCan({ role: 'ghost' }, 'pos'), false, 'an unknown role has no permissions');
  assert.ok(ROLES.employee.label === 'Cashier');
});

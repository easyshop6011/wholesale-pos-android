import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeText, terms, matches, score, rank } from '../../js/core/search.js';

test('normalizeText: case, accents, Bengali digits, spaces', () => {
  assert.equal(normalizeText('  Café   AU Lait '), 'cafe au lait');
  assert.equal(normalizeText('০১৭১১-২৩৪'), '01711-234');
  assert.equal(normalizeText(null), '');
});

test('terms and matches: every word must match, any order', () => {
  assert.deepEqual(terms(' Rice  25 '), ['rice', '25']);
  assert.ok(matches('Basmati Rice 25kg', '25 rice'));
  assert.ok(!matches('Basmati Rice 25kg', 'rice 50'));
  assert.ok(matches('anything', ''));
  assert.ok(matches('Phone 01711000001', '০১৭১১'));
});

test('score ranks exact > prefix > word-start > substring, 0 for no match', () => {
  const exact = score(['rice'], 'rice');
  const prefix = score(['rice flour'], 'rice');
  const word = score(['basmati rice'], 'rice');
  const sub = score(['licerice'], 'rice');
  assert.ok(exact > prefix && prefix > word && word > sub && sub > 0);
  assert.equal(score(['oil'], 'rice'), 0);
  assert.equal(score(['x'], ''), 1);
});

test('rank filters, orders best-first, keeps original order on ties, honours limit', () => {
  const items = [{ n: 'Basmati Rice' }, { n: 'Rice' }, { n: 'Rice Bran Oil' }, { n: 'Soybean Oil' }];
  const out = rank(items, 'rice', (i) => [i.n]);
  assert.deepEqual(out.map((i) => i.n), ['Rice', 'Rice Bran Oil', 'Basmati Rice']);
  assert.equal(rank(items, 'rice', (i) => [i.n], 1).length, 1);
  assert.equal(rank(items, '', (i) => [i.n]).length, 4);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, cpSync, writeFileSync, readFileSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { analyzeSql, analyzeProject, splitStatements, parseSqlPermissions } from '../../tools/check-sql.mjs';

const ROOT = resolve(fileURLToPath(new URL('../..', import.meta.url)));
const codes = (problems) => new Set(problems.map((p) => p.split(' ')[0]));
const has = (problems, re) => problems.some((p) => re.test(p));

// ---- the real project -------------------------------------------------------------------------------

test('the real migrations pass every static rule (S1–S13)', async () => {
  const r = await analyzeProject(ROOT);
  assert.deepEqual(r.problems, []);
  assert.ok(r.tables.size >= 30, `expected ≥30 tables, got ${r.tables.size}`);
  assert.ok(r.policies.length >= 40, `expected ≥40 policies, got ${r.policies.length}`);
});

test('every business-owned table in the real schema is covered by RLS and has tenant-aware policies or none at all', async () => {
  const r = await analyzeProject(ROOT);
  const businessTables = [...r.tables].filter(([, t]) => t.hasBusinessId).map(([n]) => n);
  for (const required of ['products', 'customers', 'invoices', 'invoice_items', 'payments', 'stock_movements', 'purchases', 'sales_returns', 'categories', 'suppliers']) {
    assert.ok(businessTables.includes(required), `${required} must carry business_id`);
  }
  // every policy on a business table goes through a tenant helper
  for (const p of r.policies.filter((x) => businessTables.includes(x.table))) {
    assert.match(`${p.using} ${p.check}`, /my_business_ids|my_admin_business_ids|my_owned_business_ids|is_platform_admin/, `${p.table}.${p.name}`);
  }
});

test('the SQL permission catalogue equals js/services/permissions.js (parsed from the SQL)', () => {
  const dir = join(ROOT, 'supabase', 'migrations');
  const sql = readdirSync(dir).filter((n) => n.endsWith('.sql')).sort().map((n) => readFileSync(join(dir, n), 'utf8')).join('\n');
  const { roles, keys } = parseSqlPermissions(sql);
  assert.equal(keys.length, 16);
  assert.ok(roles.manager.includes('reports.profit') && !roles.manager.includes('settings'));
  assert.ok(roles.cashier.includes('pos') && !roles.cashier.includes('products.edit'));
});

// ---- the tokeniser ----------------------------------------------------------------------------------

test('splitStatements ignores ; inside comments, strings and $$ bodies', () => {
  const { statements, problems } = splitStatements(
    "select 1; -- a comment; with a semicolon\n select ';' as x; create function f() returns int language sql as $$ select 1; select 2; $$; /* block; */ select 3;",
  );
  assert.deepEqual(problems, []);
  assert.equal(statements.length, 4);
  assert.match(statements[2], /select 1; select 2;/);
});

test('splitStatements reports unterminated constructs', () => {
  assert.match(splitStatements("select 'abc").problems.join(), /unterminated string/);
  assert.match(splitStatements('select $$ abc').problems.join(), /unterminated dollar quote/);
  assert.match(splitStatements('select 1').problems.join(), /not terminated/);
  assert.match(splitStatements('select 1; /* open').problems.join(), /unterminated \/\* comment/);
});

// ---- mutations: every rule must actually catch the mistake it exists for ---------------------------------

const BASE = `
create function public.my_business_ids(p_perms text[] default null, p_write boolean default false)
  returns setof uuid language sql stable as $$ select null::uuid $$;
create table public.businesses (id uuid primary key);
create table public.widgets (
  id uuid primary key,
  business_id uuid not null references public.businesses (id),
  unique (business_id, id)
);
alter table public.businesses enable row level security;
alter table public.widgets enable row level security;
create policy widgets_select on public.widgets for select to authenticated
  using (business_id in (select public.my_business_ids()));
revoke all on all tables in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
grant select on public.widgets to authenticated;
`;
const run = (sql) => analyzeSql({ 'x.sql': sql }).problems;
const without = (sql, part) => {
  assert.ok(sql.includes(part), `test bug: "${part.slice(0, 30)}" not in snippet`);
  return sql.replace(part, '');
};

test('mutation baseline: only the unrelated S9 (append-only tables absent from the snippet) is reported', () => {
  const p = run(BASE).filter((x) => !x.startsWith('S9'));
  assert.deepEqual(p, []);
});

test('S1 catches unbalanced parentheses and unterminated statements', () => {
  assert.ok(has(run(`${BASE}\ncreate table public.t (id uuid primary key;`), /^S1 .*unbalanced/));
  assert.ok(has(run(`${BASE}\nselect 1`), /^S1 .*not terminated/));
});

test('S2 catches a table without RLS and a table without a primary key', () => {
  assert.ok(has(run(without(BASE, 'alter table public.widgets enable row level security;')), /^S2 table public\.widgets does not enable row level security/));
  assert.ok(has(run(`${BASE}\ncreate table public.loose (name text);\nalter table public.loose enable row level security;`), /^S2 table public\.loose has no primary key/));
});

test('S3 catches using (true), non-authenticated roles, missing tenant helper and update without with check', () => {
  const policy = 'create policy widgets_select on public.widgets for select to authenticated\n  using (business_id in (select public.my_business_ids()));';
  assert.ok(has(run(BASE.replace(policy, 'create policy p on public.widgets for select to authenticated using (true);')), /^S3 .*using \(true\)/));
  assert.ok(has(run(BASE.replace(policy, 'create policy p on public.widgets for select to anon using (business_id in (select public.my_business_ids()));')), /^S3 .*targets anon/));
  assert.ok(has(run(BASE.replace(policy, 'create policy p on public.widgets for select to authenticated using (created_by = (select auth.uid()));')), /^S3 .*does not use a tenant helper/));
  assert.ok(has(run(`${BASE}\ncreate policy u on public.widgets for update to authenticated using (business_id in (select public.my_business_ids()));`), /^S3 update policy u .*no with check/));
});

test('S4 catches SECURITY DEFINER without search_path = \'\'', () => {
  const bad = `${BASE}\ncreate function public.leaky() returns int language sql security definer as $$ select 1 $$;`;
  assert.ok(has(run(bad), /^S4 .*public\.leaky/));
  const searchPathSet = `${BASE}\ncreate function public.safe() returns int language sql security definer set search_path = '' as $$ select 1 $$;`;
  assert.ok(!has(run(searchPathSet), /^S4/));
  const wrongPath = `${BASE}\ncreate function public.half() returns int language sql security definer set search_path = public as $$ select 1 $$;`;
  assert.ok(has(run(wrongPath), /^S4 .*public\.half/));
});

test('S5 catches a business table with no business_id-leading index', () => {
  assert.ok(has(run(without(BASE, ',\n  unique (business_id, id)')), /^S5 business table widgets/));
  assert.ok(!has(run(`${without(BASE, ',\n  unique (business_id, id)')}\ncreate index w_idx on public.widgets (business_id, id);`), /^S5/));
});

test('S6 catches a single-column reference between two business tables', () => {
  const bad = `${BASE}
create table public.gadgets (
  id uuid primary key,
  business_id uuid not null references public.businesses (id),
  widget_id uuid references public.widgets (id),
  unique (business_id, id)
);
alter table public.gadgets enable row level security;`;
  assert.ok(has(run(bad), /^S6 gadgets references widgets\(id\)/));
  const good = bad.replace('widget_id uuid references public.widgets (id),', 'widget_id uuid,\n  foreign key (business_id, widget_id) references public.widgets (business_id, id),');
  assert.ok(!has(run(good), /^S6/));
});

test('S7 catches client writes to read-only tables and a missing blanket revoke', () => {
  assert.ok(has(run(`${BASE}\ngrant select, insert on public.invoices to authenticated;`), /^S7 authenticated may write to public\.invoices/));
  assert.ok(has(run(`${BASE}\ngrant update (status) on public.invoices to authenticated;`), /^S7 authenticated may write to public\.invoices/));
  assert.ok(has(run(without(BASE, 'revoke all on all tables in schema public from anon, authenticated;')), /^S7 missing/));
});

test('S8 catches grants to anon / PUBLIC, unknown functions and a missing blanket revoke', () => {
  assert.ok(has(run(`${BASE}\ngrant select on public.widgets to anon;`), /^S8 .*grant to anon/));
  assert.ok(has(run(`${BASE}\ngrant execute on function public.fn(uuid) to public;`), /^S8 .*grant to public/));
  assert.ok(has(run(`${BASE}\ngrant execute on function public.nope() to authenticated;`), /^S8 grant execute on unknown function public\.nope/));
  assert.ok(has(run(without(BASE, 'revoke execute on all functions in schema public from public, anon, authenticated;')), /^S8 missing/));
});

test('S9 catches a missing append-only trigger on the real schema', async () => {
  const tmp = copyProject();
  try {
    assert.deepEqual((await analyzeProject(tmp)).problems, []);
    const f = join(tmp, 'supabase', 'migrations', '20261104000003_pos_tables.sql');
    const sql = readFileSync(f, 'utf8');
    const arr = "array['payments', 'sales_returns', 'sales_return_items'"; // the append-only list (the derive-time list is different)
    assert.ok(sql.includes(arr));
    writeFileSync(f, sql.replace(arr, "array['sales_returns', 'sales_return_items'"));
    assert.ok(has((await analyzeProject(tmp)).problems, /^S9 table payments has no append-only trigger/));
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
});

test('S12 catches a column that does not exist in INSERT, UPDATE and GRANT statements', () => {
  assert.ok(has(run(`${BASE}\ninsert into public.widgets (id, colour) values (1, 'x');`), /^S12 .*INSERT names column "colour"/));
  assert.ok(has(run(`${BASE}\ninsert into public.widgets as w (id, colour) values (1, 'x');`), /^S12 .*INSERT names column "colour"/));
  assert.ok(has(run(`${BASE}\nupdate public.widgets set business_id = 1, colour = 'x' where id = 1;`), /^S12 .*UPDATE names column "colour"/));
  assert.ok(has(run(`${BASE}\ngrant select, update (id, colour) on public.widgets to authenticated;`), /^S12 .*GRANT names column "colour"/));
  const fine = `${BASE}\ninsert into public.widgets (id, business_id) values (1, 2);\nupdate public.widgets set business_id = 3 where id = 1;`;
  assert.ok(!has(run(fine), /^S12/));
});

test('S13 catches a call to a function that no migration creates', () => {
  const bad = `${BASE}\ncreate function public.a() returns int language sql as $$ select public.does_not_exist(1) $$;`;
  assert.ok(has(run(bad), /^S13 .*public\.does_not_exist/));
  const ok = `${BASE}\ncreate function public.b() returns int language sql as $$ select 1 $$;\ncreate function public.c() returns int language sql as $$ select public.b() $$;`;
  assert.ok(!has(run(ok), /^S13/));
  // a table followed by "(" (INSERT column list, FK target) is not a function call
  assert.ok(!has(run(`${BASE}\ninsert into public.widgets (id) values (1);`), /^S13/));
});

// ---- project-level rules on a scratch copy ------------------------------------------------------------------

function copyProject() {
  const tmp = mkdtempSync(join(tmpdir(), 'pos-sql-'));
  cpSync(join(ROOT, 'supabase'), join(tmp, 'supabase'), { recursive: true });
  mkdirSync(join(tmp, 'js', 'services'), { recursive: true });
  cpSync(join(ROOT, 'js', 'services', 'permissions.js'), join(tmp, 'js', 'services', 'permissions.js'));
  cpSync(join(ROOT, '.env.example'), join(tmp, '.env.example'));
  cpSync(join(ROOT, '.gitignore'), join(tmp, '.gitignore'));
  return tmp;
}

test('S11: only js/cloud/config.js (which refuses that key) may name the service role — a copy elsewhere is flagged', async () => {
  const tmp = copyProject();
  try {
    mkdirSync(join(tmp, 'js', 'cloud'), { recursive: true });
    writeFileSync(join(tmp, 'js', 'cloud', 'config.js'), "if (role === 'service_role') throw new Error('refused');\n");
    assert.deepEqual((await analyzeProject(tmp)).problems, [], 'the guard itself may name the key');
    writeFileSync(join(tmp, 'js', 'cloud', 'client.js'), "const k = 'service_role';\n");
    assert.ok(has((await analyzeProject(tmp)).problems, /^S11 js\/cloud\/client\.js contains a service-role key reference/));
    rmSync(join(tmp, 'js', 'cloud', 'client.js'));
    writeFileSync(join(tmp, 'js', 'cloud', 'config.js'), "const k = 'sb_secret_abcdefghijklmnopqrstuvwx';\n");
    assert.ok(has((await analyzeProject(tmp)).problems, /^S11 js\/cloud\/config\.js contains a Supabase secret key/), 'the guard file is still scanned for real secrets');
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
});

test('S10 catches a permission that differs between SQL and JavaScript', async () => {
  const tmp = copyProject();
  try {
    const f = join(tmp, 'supabase', 'migrations', '20261104000001_foundation.sql');
    const sql = readFileSync(f, 'utf8');
    assert.ok(sql.includes("'reports', 'reports.profit', 'audit', 'printer'"));
    writeFileSync(f, sql.replace("'reports', 'reports.profit', 'audit', 'printer'", "'reports', 'audit', 'printer'"));
    assert.ok(has((await analyzeProject(tmp)).problems, /^S10 default permissions of manager differ/));
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
});

test('S11 catches a service-role reference in client code, a real-looking .env.example value and a missing .gitignore entry', async () => {
  const tmp = copyProject();
  try {
    writeFileSync(join(tmp, 'js', 'leak.js'), "export const k = 'service_role';\n");
    assert.ok(has((await analyzeProject(tmp)).problems, /^S11 js\/leak\.js contains a service-role key reference/));
    rmSync(join(tmp, 'js', 'leak.js'));

    writeFileSync(join(tmp, 'js', 'jwt.js'), "export const k = 'eyJhbGciOiJIUzI1NiIsInR5cCI6.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYQ.c2lnbmF0dXJlLXNpZ25hdHVyZQ';\n");
    assert.ok(has((await analyzeProject(tmp)).problems, /^S11 js\/jwt\.js contains a JWT-looking token/));
    rmSync(join(tmp, 'js', 'jwt.js'));

    const env = readFileSync(join(tmp, '.env.example'), 'utf8');
    writeFileSync(join(tmp, '.env.example'), `${env}\nSOME_KEY=abcdef0123456789realvalue\n`);
    assert.ok(has((await analyzeProject(tmp)).problems, /^S11 \.env\.example SOME_KEY has a real-looking value/));
    writeFileSync(join(tmp, '.env.example'), env);

    writeFileSync(join(tmp, '.gitignore'), 'node_modules/\n');
    assert.ok(has((await analyzeProject(tmp)).problems, /^S11 \.gitignore does not ignore \.env/));
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
});

test('the rule codes in a failing run are the ones the mutation targeted (no cross-talk)', () => {
  const p = run(without(BASE, 'alter table public.widgets enable row level security;'));
  assert.ok(codes(p).has('S2'));
  assert.ok(!codes(p).has('S3'));
  assert.ok(!codes(p).has('S6'));
});

test('S12 also checks the pgTAP test file against the real schema', async () => {
  const tmp = copyProject();
  try {
    assert.deepEqual((await analyzeProject(tmp)).problems, []);
    const f = join(tmp, 'supabase', 'tests', 'database', '01_tenant_isolation.test.sql');
    writeFileSync(f, `${readFileSync(f, 'utf8')}\ninsert into public.products (id, colour) values ('x', 'red');\n`);
    assert.ok(has((await analyzeProject(tmp)).problems, /^S12 tests\/01_tenant_isolation\.test\.sql: INSERT names column "colour"/));
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
});

test('S13 also checks the pgTAP tests (a typo in a function name is caught before anybody runs them)', async () => {
  const tmp = copyProject();
  try {
    const f = join(tmp, 'supabase', 'tests', 'database', '01_tenant_isolation.test.sql');
    writeFileSync(f, `${readFileSync(f, 'utf8')}\nselect public.review_busines('x');\n`);
    assert.ok(has((await analyzeProject(tmp)).problems, /^S13 tests\/01_tenant_isolation\.test\.sql: calls public\.review_busines/));
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { nextDelayMs, isAttemptDue, isUnsupportedActionError, logIdsToTrim, BACKOFF } from '../../js/services/sync-backoff.js';

const noJitter = { rand: () => 0.5 };

test('back-off doubles from 30 s and caps at 15 minutes', () => {
  const d = [1, 2, 3, 4, 5, 6, 7, 8, 50].map((n) => nextDelayMs(n, noJitter));
  assert.deepEqual(d, [30000, 60000, 120000, 240000, 480000, 900000, 900000, 900000, 900000]);
  assert.equal(nextDelayMs(0), 0);
});

test('jitter stays within ±20 % and never exceeds the cap', () => {
  assert.equal(nextDelayMs(1, { rand: () => 0 }), 24000);
  assert.equal(nextDelayMs(1, { rand: () => 1 }), 36000);
  assert.equal(nextDelayMs(9, { rand: () => 1 }), BACKOFF.capMs);
});

test('attempt is allowed only when online and the delay has elapsed', () => {
  assert.equal(isAttemptDue({ now: 1000, nextAttemptAt: 2000 }), false);
  assert.equal(isAttemptDue({ now: 2000, nextAttemptAt: 2000 }), true);
  assert.equal(isAttemptDue({ now: 5000, nextAttemptAt: 0, online: false }), false);
});

test('unsupported-action detection and log trimming', () => {
  assert.equal(isUnsupportedActionError('Unknown action: syncProducts'), true);
  assert.equal(isUnsupportedActionError('Unauthorized: wrong token'), false);
  const rows = Array.from({ length: 205 }, (_, i) => ({ id: `r${i}`, createdAt: String(1000 + i) }));
  const trim = logIdsToTrim(rows, 200);
  assert.deepEqual(trim, ['r0', 'r1', 'r2', 'r3', 'r4']);
  assert.deepEqual(logIdsToTrim(rows.slice(0, 10), 200), []);
});

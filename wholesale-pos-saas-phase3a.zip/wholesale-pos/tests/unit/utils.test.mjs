/** Unit tests for the pure helpers (run with: npm test). */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { round2, toNum, sum, uuid, dateParts, monotonicNow, addDays, monthRange, normalizePhone, fmtQty, toCSV, bytesToBase64, base64ToBytes } from '../../js/core/utils.js';
import { sha256 } from '../../js/core/sha256.js';

test('round2 avoids floating point surprises', () => {
  assert.equal(round2(1.005), 1.01);
  assert.equal(round2(0.1 + 0.2), 0.3);
  assert.equal(round2('abc'), 0);
});

test('toNum parses user input', () => {
  assert.equal(toNum('1,250.50'), 1250.5);
  assert.equal(toNum(''), 0);
  assert.equal(toNum(null), 0);
  assert.equal(toNum(NaN), 0);
});

test('line total and grand total arithmetic', () => {
  const lines = [{ q: 4, p: 2450 }, { q: 10, p: 880 }].map((l) => round2(l.q * l.p));
  assert.deepEqual(lines, [9800, 8800]);
  assert.equal(sum(lines) - 600, 18000);
});

test('uuid is v4 and unique', () => {
  const ids = new Set(Array.from({ length: 2000 }, uuid));
  assert.equal(ids.size, 2000);
  for (const id of ids) assert.match(id, /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
});

test('monotonicNow never repeats or goes backwards', () => {
  let prev = 0;
  for (let i = 0; i < 5000; i++) {
    const t = monotonicNow().getTime();
    assert.ok(t > prev);
    prev = t;
  }
});

test('dateParts gives BUSINESS time in Asia/Dhaka (UTC+6), whatever the device zone is', () => {
  // 20:34:09 UTC on 4 Oct is already 02:34:09 on 5 Oct in Dhaka.
  const p = dateParts(new Date('2026-10-04T20:34:09Z'));
  assert.deepEqual([p.date, p.time, p.month, p.iso], ['2026-10-05', '02:34:09', '2026-10', '2026-10-04T20:34:09.000Z']);
});

test('addDays and monthRange handle month/year/leap boundaries', () => {
  assert.equal(addDays('2026-12-31', 1), '2027-01-01');
  assert.equal(addDays('2026-03-01', -1), '2026-02-28');
  assert.deepEqual(monthRange('2028-02'), { from: '2028-02-01', to: '2028-02-29' });
});

test('normalizePhone keeps digits and a leading +', () => {
  assert.equal(normalizePhone('+880 1711-000001'), '+8801711000001');
  assert.equal(normalizePhone('(017) 11 00'), '0171100');
  assert.equal(normalizePhone(''), '');
});

test('fmtQty drops trailing zeros', () => {
  assert.equal(fmtQty(2.5), '2.5');
  assert.equal(fmtQty(3), '3');
  assert.equal(fmtQty(0.12345), '0.123');
});

test('toCSV quotes cells and blocks formula injection', () => {
  assert.equal(toCSV([['a,b', 'say "hi"', '=1+1', -5, 'x']]), '"a,b","say ""hi""",\'=1+1,-5,x');
});

test('base64 round trip', () => {
  const bytes = Uint8Array.from({ length: 300 }, (_, i) => i % 256);
  assert.deepEqual(base64ToBytes(bytesToBase64(bytes)), bytes);
});

test('sha256 matches published test vectors', () => {
  const hex = (u8) => [...u8].map((b) => b.toString(16).padStart(2, '0')).join('');
  assert.equal(hex(sha256(new Uint8Array([]))), 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
  assert.equal(hex(sha256(new TextEncoder().encode('abc'))), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
});

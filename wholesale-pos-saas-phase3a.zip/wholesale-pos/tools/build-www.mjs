/**
 * build-www.mjs — assemble the static web bundle in ./www (used by Capacitor
 * for the Android app, and deployable as-is to any static host for the PWA).
 *   node tools/build-www.mjs
 */
import { cp, rm, mkdir } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const OUT = join(ROOT, 'www');

// 1. fresh service worker with an up-to-date precache list
const r = spawnSync(process.execPath, [join(ROOT, 'tools/gen-sw.mjs')], { stdio: 'inherit' });
if (r.status !== 0) process.exit(r.status ?? 1);

// 2. copy only what the app needs at runtime
await rm(OUT, { recursive: true, force: true });
await mkdir(OUT, { recursive: true });
for (const p of ['index.html', 'manifest.webmanifest', 'sw.js', 'css', 'js', 'icons']) await cp(join(ROOT, p), join(OUT, p), { recursive: true });
console.log('www/ ready');

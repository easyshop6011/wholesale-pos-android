/**
 * check-sql.mjs — `npm run check:sql`. Static safety checks for supabase/migrations/*.sql.
 *
 * WHAT THIS IS (and is not): there is no PostgreSQL in the build environment, so this does NOT run
 * the SQL. It parses it (comments, strings and $$ bodies are tokenised properly) and enforces the
 * structural rules that tenant isolation depends on. A green run means "no rule below is broken";
 * it does not prove the SQL executes — run supabase/tests/database/*.test.sql (pgTAP) for that.
 *
 * Rules
 *   S1  every statement is terminated, quotes / $$ / comments / parentheses are balanced
 *   S2  every `public` table has a primary key and RLS enabled
 *   S3  no policy is `using (true)` / `with check (true)`; policies target `authenticated` only and
 *       every policy expression contains a recognised guard (auth.uid(), tenant helper, …)
 *   S4  every SECURITY DEFINER function sets `search_path = ''`
 *   S5  every business-owned table (has business_id) has an index that starts with business_id
 *   S6  a business-owned table never references another business-owned table by `id` alone —
 *       only through a composite (business_id, id) foreign key
 *   S7  API roles get only SELECT on money / security tables (writes go through server functions)
 *   S8  nothing is granted to anon / PUBLIC; EXECUTE is revoked wholesale and re-granted to a list
 *       of functions that all exist
 *   S9  append-only triggers exist on the audit / money tables
 *   S10 role_default_permissions() and all_permission_keys() equal js/services/permissions.js
 *   S11 no service-role key / JWT / secret in client code; .env.example has no real values and
 *       .gitignore ignores .env
 *   S12 every column named in `insert into public.t (…)`, `update public.t set …` and column-level
 *       `grant … (cols) on public.t` exists in that table — in the migrations AND in the pgTAP tests
 *   S13 every `public.fn(…)` / `private.fn(…)` call (bodies, triggers, grants, tests) names a function that
 *       some migration creates
 */
import { readdirSync, readFileSync, existsSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));

/** Tables that clients may only READ (every write goes through a server function or the Auth system). */
export const READ_ONLY_FOR_CLIENTS = [
  'subscriptions', 'subscription_events', 'business_approvals', 'business_members', 'business_invitations',
  'user_devices', 'revoked_sessions', 'user_security_events', 'audit_logs', 'access_logs', 'platform_admins',
  'customer_accounts', 'customer_invitations',
  'invoices', 'invoice_items', 'payments', 'sales_returns', 'sales_return_items', 'stock_movements',
  'purchases', 'purchase_items', 'supplier_payments',
];

/** Tables that must be append-only (a trigger refuses UPDATE / DELETE). */
export const APPEND_ONLY = ['subscription_events', 'business_approvals', 'audit_logs', 'access_logs', 'payments', 'sales_returns', 'sales_return_items', 'stock_movements', 'supplier_payments'];

const GUARDS = ['auth.uid', 'is_platform_admin', 'my_business_ids', 'my_admin_business_ids', 'my_owned_business_ids', 'can_view_profile', 'is_active', 'is_public'];
const TENANT_HELPERS = ['my_business_ids', 'my_admin_business_ids', 'my_owned_business_ids', 'is_platform_admin'];

// ---- tokenising ----------------------------------------------------------------------------------

/**
 * Split SQL into top-level statements. Comments are removed; strings and dollar-quoted bodies are kept
 * intact (a `;` inside them does not split).
 * @returns {{statements: string[], problems: string[]}}
 */
export function splitStatements(sql) {
  const statements = [];
  const problems = [];
  let cur = '';
  let i = 0;
  const n = sql.length;
  while (i < n) {
    const c = sql[i];
    const d = sql[i + 1];
    if (c === '-' && d === '-') {
      while (i < n && sql[i] !== '\n') i++;
      cur += ' ';
      continue;
    }
    if (c === '/' && d === '*') {
      const end = sql.indexOf('*/', i + 2);
      if (end === -1) {
        problems.push('unterminated /* comment');
        i = n;
      } else i = end + 2;
      cur += ' ';
      continue;
    }
    if (c === "'") {
      let j = i + 1;
      for (;;) {
        if (j >= n) {
          problems.push('unterminated string literal');
          break;
        }
        if (sql[j] === "'") {
          if (sql[j + 1] === "'") {
            j += 2;
            continue;
          }
          break;
        }
        j++;
      }
      cur += sql.slice(i, j + 1);
      i = j + 1;
      continue;
    }
    if (c === '$') {
      const m = /^\$([A-Za-z_][A-Za-z0-9_]*)?\$/.exec(sql.slice(i, i + 64));
      if (m) {
        const tag = m[0];
        const end = sql.indexOf(tag, i + tag.length);
        if (end === -1) {
          problems.push(`unterminated dollar quote ${tag}`);
          cur += sql.slice(i);
          i = n;
        } else {
          cur += sql.slice(i, end + tag.length);
          i = end + tag.length;
        }
        continue;
      }
    }
    if (c === ';') {
      if (cur.trim()) statements.push(cur.trim());
      cur = '';
      i++;
      continue;
    }
    cur += c;
    i++;
  }
  if (cur.trim()) problems.push(`last statement is not terminated by ";": ${cur.trim().slice(0, 60)}…`);
  return { statements, problems };
}

/** Replace string literals and dollar bodies by spaces so only real SQL structure remains. */
function structureOnly(stmt) {
  let out = '';
  let i = 0;
  while (i < stmt.length) {
    const c = stmt[i];
    if (c === "'") {
      let j = i + 1;
      while (j < stmt.length && !(stmt[j] === "'" && stmt[j + 1] !== "'")) j += stmt[j] === "'" ? 2 : 1;
      out += ' '.repeat(j + 1 - i);
      i = j + 1;
      continue;
    }
    if (c === '$') {
      const m = /^\$([A-Za-z_][A-Za-z0-9_]*)?\$/.exec(stmt.slice(i, i + 64));
      if (m) {
        const end = stmt.indexOf(m[0], i + m[0].length);
        const stop = end === -1 ? stmt.length : end + m[0].length;
        out += ' '.repeat(stop - i);
        i = stop;
        continue;
      }
    }
    out += c;
    i++;
  }
  return out;
}

const balanced = (s) => {
  let depth = 0;
  for (const ch of s) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (depth < 0) return false;
  }
  return depth === 0;
};

/** Text of the parenthesised group that starts at the first "(" at or after `from`. */
function groupAt(text, from) {
  const open = text.indexOf('(', from);
  if (open === -1) return null;
  let depth = 0;
  for (let i = open; i < text.length; i++) {
    if (text[i] === '(') depth++;
    else if (text[i] === ')') {
      depth--;
      if (depth === 0) return text.slice(open + 1, i);
    }
  }
  return null;
}

/** Split on commas that are not inside parentheses. */
function topLevelSplit(text) {
  const parts = [];
  let depth = 0;
  let cur = '';
  for (const ch of text) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (ch === ',' && depth === 0) {
      parts.push(cur.trim());
      cur = '';
    } else cur += ch;
  }
  if (cur.trim()) parts.push(cur.trim());
  return parts;
}

/** Column names declared in a CREATE TABLE body. */
export function columnsOfBody(body) {
  return topLevelSplit(body || '')
    .filter((it) => !/^(constraint|unique|primary|foreign|check)\b/i.test(it))
    .map((it) => it.split(/\s+/)[0].replace(/"/g, ''));
}

/**
 * S12 — typo guard. Finds INSERT column lists, UPDATE … SET targets and column-level GRANTs that name
 * a public table and verifies every column exists there.
 * @param {string} text   SQL (comments already removed)
 * @param {Map<string,{body:string}>} tables
 */
export function checkColumnRefs(text, tables, label) {
  const problems = [];
  const cols = new Map([...tables].map(([n, t]) => [n, new Set(columnsOfBody(t.body))]));
  const check = (table, names, where) => {
    const known = cols.get(table);
    if (!known) return; // not a table of this schema (auth.users, tests.ids …)
    for (const c of names) if (c && !known.has(c)) problems.push(`S12 ${label}: ${where} names column "${c}" which public.${table} does not have`);
  };
  for (const m of text.matchAll(/insert\s+into\s+public\.(\w+)(?:\s+as\s+\w+)?\s*\(([^)]*)\)/gi)) {
    check(m[1], m[2].split(',').map((x) => x.trim().replace(/"/g, '')), 'INSERT');
  }
  for (const m of text.matchAll(/update\s+public\.(\w+)(?:\s+as\s+\w+)?\s+set\s+([\s\S]*?)(?=\bwhere\b|\bfrom\b|\breturning\b|;|\$q\$|\$\$|\)\s*select|$)/gi)) {
    const targets = topLevelSplit(m[2]).map((a) => /^\s*(\w+)\s*=/.exec(a)?.[1]).filter(Boolean);
    check(m[1], targets, 'UPDATE');
  }
  for (const m of text.matchAll(/grant\s+([\s\S]+?)\s+on\s+public\.(\w+)/gi)) {
    for (const g of m[1].matchAll(/\b(?:select|insert|update)\s*\(([^)]*)\)/gi)) check(m[2], g[1].split(',').map((x) => x.trim()), 'GRANT');
  }
  return problems;
}

/** S13 — every schema-qualified call names a function that exists (tables followed by "(" are not calls). */
export function checkFunctionRefs(text, tables, functionNames, label) {
  const problems = [];
  const seen = new Set();
  for (const m of text.matchAll(/\b(public|private)\.(\w+)\s*\(/g)) {
    const full = `${m[1]}.${m[2]}`;
    if (m[1] === 'public' && tables.has(m[2])) continue;
    if (functionNames.has(full) || seen.has(full)) continue;
    seen.add(full);
    problems.push(`S13 ${label}: calls ${full}(…) but no migration creates it`);
  }
  return problems;
}

// ---- analysis of SQL text ---------------------------------------------------------------------------

/**
 * @param {Record<string,string>} files  file name → SQL text (applied in key order)
 * @returns {{problems: string[], tables: Map<string, {hasBusinessId: boolean, hasPk: boolean}>, functions: Map<string, object>}}
 */
export function analyzeSql(files) {
  const problems = [];
  const tables = new Map();
  const functions = new Map();
  const rlsEnabled = new Set();
  const policies = [];
  const indexes = []; // {table, firstCol}
  const grants = []; // {privs, targets, role, kind}
  const executeGrants = [];
  const appendOnly = new Set();
  const bodyOf = new Map();
  let revokeAllFunctions = false;
  let revokeAllTables = false;

  const all = [];
  for (const [file, text] of Object.entries(files)) {
    const { statements, problems: p } = splitStatements(text);
    for (const x of p) problems.push(`S1 ${file}: ${x}`);
    for (const s of statements) all.push({ file, s });
  }

  for (const { file, s } of all) {
    const code = structureOnly(s);
    if (!balanced(code)) problems.push(`S1 ${file}: unbalanced parentheses in: ${s.slice(0, 70).replace(/\s+/g, ' ')}…`);

    let m;
    // --- tables
    if ((m = /^create table\s+(?:if not exists\s+)?public\.(\w+)\s*\(/i.exec(code))) {
      const name = m[1];
      const body = groupAt(code, code.indexOf('('));
      const items = topLevelSplit(body || '');
      const cols = items.filter((it) => !/^(constraint|unique|primary|foreign|check)\b/i.test(it)).map((it) => it.split(/\s+/)[0].replace(/"/g, ''));
      const hasPk = /primary key/i.test(body || '');
      tables.set(name, { hasBusinessId: cols.includes('business_id') || /primary key\s*\(\s*business_id/i.test(body || ''), hasPk, body: body || '' });
    }
    // --- RLS
    if ((m = /^alter table\s+public\.(\w+)\s+enable row level security/i.exec(code))) rlsEnabled.add(m[1]);
    // --- policies
    if ((m = /^create policy\s+(\w+)\s+on\s+public\.(\w+)\s+for\s+(\w+)\s+to\s+([\w,\s]+?)\s+(?=using|with check)/i.exec(code))) {
      const using = (() => {
        const i = code.search(/\busing\s*\(/i);
        return i === -1 ? '' : groupAt(code, i) || '';
      })();
      const check = (() => {
        const i = code.search(/\bwith check\s*\(/i);
        return i === -1 ? '' : groupAt(code, i) || '';
      })();
      policies.push({ file, name: m[1], table: m[2], cmd: m[3].toLowerCase(), roles: m[4].split(',').map((r) => r.trim().toLowerCase()), using, check });
    } else if (/^create policy/i.test(code)) {
      problems.push(`S3 ${file}: policy not understood by the checker (use "create policy n on public.t for cmd to role using (...)"): ${s.slice(0, 70).replace(/\s+/g, ' ')}`);
    }
    // --- functions
    if ((m = /^create (?:or replace )?function\s+([\w.]+)\s*\(/i.exec(code))) {
      const header = s.slice(0, s.search(/\bas\s+\$[A-Za-z_]*\$/i) === -1 ? s.length : s.search(/\bas\s+\$[A-Za-z_]*\$/i));
      functions.set(m[1], {
        file,
        definer: /security\s+definer/i.test(header),
        searchPathEmpty: /set\s+search_path\s*=\s*''/i.test(header),
        trigger: /returns\s+trigger/i.test(header),
      });
      bodyOf.set(m[1], s);
    }
    // --- indexes
    if ((m = /^create\s+(?:unique\s+)?index\s+(?:if not exists\s+)?\w+\s+on\s+public\.(\w+)\s*(?:using\s+\w+\s*)?\(\s*([^),]+)/i.exec(code))) {
      indexes.push({ table: m[1], firstCol: m[2].trim().replace(/"/g, '') });
    }
    // --- grants / revokes
    if ((m = /^grant\s+(.+?)\s+on\s+(function|all functions in schema|schema|table|sequence)?\s*([\s\S]+?)\s+to\s+([\w,\s]+)$/i.exec(code))) {
      const privs = m[1];
      const kind = (m[2] || 'table').toLowerCase();
      const roles = m[4].split(',').map((r) => r.trim().toLowerCase());
      if (kind === 'function') {
        for (const f of m[3].matchAll(/public\.(\w+)\s*\(/g)) executeGrants.push({ name: `public.${f[1]}`, roles });
      } else if (kind === 'table') {
        const targets = [...m[3].matchAll(/public\.(\w+)/g)].map((x) => x[1]);
        grants.push({ privs, targets, roles });
      }
      for (const r of roles) if (r === 'anon' || r === 'public') problems.push(`S8 ${file}: grant to ${r}: ${s.slice(0, 80).replace(/\s+/g, ' ')}`);
    }
    if (/^revoke\s+execute\s+on\s+all functions in schema public\s+from\s+[\w,\s]*public[\w,\s]*anon/i.test(code)) revokeAllFunctions = true;
    if (/^revoke\s+all\s+on\s+all tables in schema public\s+from\s+anon,\s*authenticated/i.test(code)) revokeAllTables = true;
    // --- append-only triggers (created inside DO blocks that loop over an array of tables)
    for (const blk of s.matchAll(/foreach\s+t\s+in\s+array\s+array\s*\[([^\]]*)\]\s+loop\s+execute\s+format\(\s*'create trigger (?:append_only|no_update) before ([^']*?) on/gi)) {
      if (/delete/i.test(blk[2]) || /update/i.test(blk[2])) for (const t of blk[1].matchAll(/'(\w+)'/g)) appendOnly.add(t[1]);
    }
    // user_security_events uses a one-off statement
    if (/create trigger append_only before update on public\.user_security_events/i.test(s)) appendOnly.add('user_security_events');
  }

  // S2
  for (const [name, t] of tables) {
    if (!t.hasPk) problems.push(`S2 table public.${name} has no primary key`);
    if (!rlsEnabled.has(name)) problems.push(`S2 table public.${name} does not enable row level security`);
  }

  // S3
  for (const p of policies) {
    if (!tables.has(p.table)) problems.push(`S3 policy ${p.name} is on unknown table public.${p.table}`);
    if (p.roles.some((r) => r !== 'authenticated')) problems.push(`S3 policy ${p.name} on ${p.table} targets ${p.roles.join(',')} (only authenticated allowed)`);
    for (const [label, expr] of [['using', p.using], ['with check', p.check]]) {
      if (/^\s*\(?\s*true\s*\)?\s*$/i.test(expr) && expr !== '') problems.push(`S3 policy ${p.name} on ${p.table} has ${label} (true)`);
    }
    const exprAll = `${p.using} ${p.check}`;
    if (!GUARDS.some((g) => exprAll.includes(g))) problems.push(`S3 policy ${p.name} on ${p.table} has no recognised guard (${GUARDS.join(' / ')})`);
    const t = tables.get(p.table);
    if (t?.hasBusinessId && !TENANT_HELPERS.some((g) => exprAll.includes(g))) problems.push(`S3 policy ${p.name} on business table ${p.table} does not use a tenant helper (${TENANT_HELPERS.join(' / ')})`);
    if (p.cmd !== 'select' && p.cmd !== 'delete' && !p.check && p.cmd !== 'update') problems.push(`S3 policy ${p.name} (${p.cmd}) needs a with check expression`);
    if (p.cmd === 'update' && !p.check) problems.push(`S3 update policy ${p.name} on ${p.table} has no with check (rows could be moved to another business)`);
  }

  // S4
  for (const [name, f] of functions) {
    if (f.definer && !f.searchPathEmpty) problems.push(`S4 SECURITY DEFINER function ${name} does not set search_path = ''`);
  }

  // S5
  for (const [name, t] of tables) {
    if (!t.hasBusinessId) continue;
    const viaIndex = indexes.some((ix) => ix.table === name && ix.firstCol === 'business_id');
    const viaConstraint = /(?:^|,|\n)\s*unique\s*\(\s*business_id\b/i.test(t.body) || /primary key\s*\(\s*business_id\b/i.test(t.body);
    if (!viaIndex && !viaConstraint) problems.push(`S5 business table ${name} has no index starting with business_id`);
  }

  // S6
  for (const [name, t] of tables) {
    if (!t.hasBusinessId) continue;
    for (const ref of t.body.matchAll(/references\s+public\.(\w+)\s*\(([^)]*)\)/gi)) {
      const target = tables.get(ref[1]);
      const cols = ref[2].split(',').map((c) => c.trim());
      if (target?.hasBusinessId && !(cols[0] === 'business_id' && cols.length === 2)) {
        problems.push(`S6 ${name} references ${ref[1]}(${cols.join(', ')}) — business tables must use a composite (business_id, id) reference`);
      }
    }
  }

  // S7
  for (const g of grants) {
    if (!g.roles.includes('authenticated')) continue;
    const privWords = g.privs.toLowerCase().replace(/\([^)]*\)/g, '').match(/\b(select|insert|update|delete|truncate|references|trigger|all)\b/g) || [];
    for (const t of g.targets) {
      if (READ_ONLY_FOR_CLIENTS.includes(t) && privWords.some((w) => w !== 'select')) problems.push(`S7 authenticated may write to public.${t} (${[...new Set(privWords)].join('/')}) — it must be read-only for clients`);
    }
  }
  if (!revokeAllTables) problems.push('S7 missing: revoke all on all tables in schema public from anon, authenticated');

  // S8
  if (!revokeAllFunctions) problems.push('S8 missing: revoke execute on all functions in schema public from public, anon, authenticated');
  for (const eg of executeGrants) {
    if (!functions.has(eg.name)) problems.push(`S8 grant execute on unknown function ${eg.name}`);
  }
  const granted = new Set(executeGrants.map((g) => g.name));
  for (const [name, f] of functions) {
    if (name.startsWith('private.') || f.trigger) continue;
    if (!granted.has(name) && f.definer && /^public\.(register_|resubmit_|review_|set_business|my_|record_|revoke_|log_|get_)/.test(name)) problems.push(`S8 RPC ${name} is never granted to authenticated`);
  }

  // S9
  for (const t of APPEND_ONLY) if (!appendOnly.has(t)) problems.push(`S9 table ${t} has no append-only trigger`);

  // S12
  const byFile = new Map();
  for (const { file, s } of all) byFile.set(file, `${byFile.get(file) || ''}${s};\n`);
  for (const [file, text] of byFile) problems.push(...checkColumnRefs(text, tables, file));

  // S13
  const fnNames = new Set(functions.keys());
  for (const [file, text] of byFile) problems.push(...checkFunctionRefs(text, tables, fnNames, file));

  return { problems, tables, functions, policies, grants };
}

// ---- project-level checks ----------------------------------------------------------------------------

const walk = (dir, skip = []) =>
  existsSync(dir)
    ? readdirSync(dir).flatMap((n) => {
        if (n === 'node_modules' || n === 'www' || n.startsWith('.') || skip.includes(n)) return [];
        const p = join(dir, n);
        return statSync(p).isDirectory() ? walk(p, skip) : [p];
      })
    : [];

/** `when 'role' then array[...]` and the all-keys array out of the SQL, to compare with the JS catalogue. */
export function parseSqlPermissions(sqlText) {
  const roles = {};
  const fn = /function public\.role_default_permissions[\s\S]*?\$\$([\s\S]*?)\$\$/i.exec(sqlText)?.[1] || '';
  for (const m of fn.matchAll(/when\s+'(\w+)'\s+then\s+array\[([^\]]*)\]/gi)) roles[m[1]] = [...m[2].matchAll(/'([^']+)'/g)].map((x) => x[1]);
  const keysFn = /function public\.all_permission_keys[\s\S]*?\$\$([\s\S]*?)\$\$/i.exec(sqlText)?.[1] || '';
  const keys = [...(/array\[([^\]]*)\]/i.exec(keysFn)?.[1] || '').matchAll(/'([^']+)'/g)].map((x) => x[1]);
  return { roles, keys };
}

const sameSet = (a, b) => a.length === b.length && [...a].sort().join('|') === [...b].sort().join('|');

export async function analyzeProject(root = ROOT) {
  const problems = [];
  const dir = join(root, 'supabase', 'migrations');
  if (!existsSync(dir)) return { problems: ['supabase/migrations is missing'] };
  const files = {};
  for (const f of readdirSync(dir).filter((n) => n.endsWith('.sql')).sort()) files[f] = readFileSync(join(dir, f), 'utf8');
  const res = analyzeSql(files);
  problems.push(...res.problems);
  const testDir = join(root, 'supabase', 'tests', 'database');
  if (existsSync(testDir)) {
    for (const f of readdirSync(testDir).filter((n) => n.endsWith('.sql')).sort()) {
      const { statements } = splitStatements(readFileSync(join(testDir, f), 'utf8'));
      problems.push(...checkColumnRefs(statements.join(';\n'), res.tables, `tests/${f}`));
      problems.push(...checkFunctionRefs(statements.join(';\n'), res.tables, new Set(res.functions.keys()), `tests/${f}`));
    }
  }

  // S10 permission parity with the JavaScript catalogue
  const { ROLES, PERMISSION_LIST } = await import(pathToFileURL(join(root, 'js', 'services', 'permissions.js')).href);
  const sql = Object.values(files).join('\n');
  const parsed = parseSqlPermissions(sql);
  const jsKeys = PERMISSION_LIST.map((p) => p.key);
  if (!sameSet(parsed.keys, jsKeys)) problems.push(`S10 all_permission_keys() differs from PERMISSION_LIST: sql=[${parsed.keys}] js=[${jsKeys}]`);
  const roleMap = { manager: 'manager', cashier: 'employee' };
  for (const [sqlRole, jsRole] of Object.entries(roleMap)) {
    if (!parsed.roles[sqlRole]) problems.push(`S10 role_default_permissions() has no "${sqlRole}"`);
    else if (!sameSet(parsed.roles[sqlRole], ROLES[jsRole].permissions)) problems.push(`S10 default permissions of ${sqlRole} differ from ROLES.${jsRole}: sql=[${parsed.roles[sqlRole]}] js=[${ROLES[jsRole].permissions}]`);
  }

  // S11 secrets
  const clientFiles = [...walk(join(root, 'js')), ...walk(join(root, 'android-plugin')), ...walk(join(root, 'integrations')), ...['index.html', 'sw.js', 'manifest.webmanifest', 'capacitor.config.json'].map((f) => join(root, f))].filter(existsSync);
  const secretPatterns = [
    [/service[_-]?role/i, 'service-role key reference'],
    [/sb_secret_[A-Za-z0-9_-]{10,}/, 'Supabase secret key'],
    [/eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{5,}/, 'JWT-looking token'],
    [/SUPABASE_SERVICE/i, 'SUPABASE_SERVICE… variable'],
    [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, 'private key'],
    [/GOCSPX-[A-Za-z0-9_-]{10,}/, 'Google OAuth client secret'],
  ];
  // The ONE file that may name the service-role key is the one that REFUSES it (it has to recognise it).
  // Every other pattern (JWT, secret key, private key …) still applies to it.
  const MAY_NAME_SERVICE_ROLE = new Set(['js/cloud/config.js']);
  for (const f of clientFiles) {
    const text = readFileSync(f, 'utf8');
    const rel = relative(root, f).split('\\').join('/');
    for (const [re, label] of secretPatterns) {
      if (label === 'service-role key reference' && MAY_NAME_SERVICE_ROLE.has(rel)) continue;
      if (re.test(text)) problems.push(`S11 ${rel} contains a ${label}`);
    }
  }
  const envExample = join(root, '.env.example');
  if (!existsSync(envExample)) problems.push('S11 .env.example is missing');
  else {
    for (const line of readFileSync(envExample, 'utf8').split('\n')) {
      const m = /^([A-Z0-9_]+)=(.*)$/.exec(line.trim());
      if (m && m[2] && !/^(<.*>|your[-_ ].*|changeme.*|http:\/\/127\.0\.0\.1.*|https:\/\/your-.*|com\.wholesalepos\.app:\/\/[\w\/.-]+)$/i.test(m[2])) problems.push(`S11 .env.example ${m[1]} has a real-looking value`);
    }
  }
  const gi = join(root, '.gitignore');
  if (!existsSync(gi) || !/^\.env$/m.test(readFileSync(gi, 'utf8'))) problems.push('S11 .gitignore does not ignore .env');

  return { problems, tables: res.tables, functions: res.functions, policies: res.policies, fileCount: Object.keys(files).length };
}

// ---- CLI -------------------------------------------------------------------------------------------------
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const r = await analyzeProject();
  if (r.problems.length) {
    console.error(r.problems.map((p) => `✘ ${p}`).join('\n'));
    console.error(`\ncheck-sql: ${r.problems.length} problem(s)`);
    process.exit(1);
  }
  console.log(`check-sql: ${r.fileCount} migrations · ${r.tables.size} tables · ${r.policies.length} policies · ${r.functions.size} functions — rules S1–S13 OK`);
  console.log('(static checks only: nothing was executed — see supabase/tests/database for the pgTAP tests)');
}

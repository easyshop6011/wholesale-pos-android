/**
 * lint.mjs — `npm run lint`. The project has no ESLint, so this does two things:
 *   1. a SYNTAX check of every .js / .mjs file and of Code.gs;
 *   2. the project's own safety rules, which a syntax check cannot see (each one guards a bug this version fixed):
 *        R1  stock is changed only through the stock ledger (never `put('products', …)` elsewhere);
 *        R2  screens save settings with `settings.update` (permission-checked), never `settings.set`;
 *        R3  business time is Asia/Dhaka: no device-zone date/time formatting outside core/datetime.js;
 *        R4  secrets are never written to the console;
 *        R5  every sensitive service function authorizes the caller (`authorize…` inside its body).
 * Exits 1 with a list when something is wrong.
 */
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const problems = [];
const walk = (dir) => readdirSync(dir).flatMap((n) => (n === 'node_modules' || n === 'www' || n.startsWith('.') ? [] : statSync(join(dir, n)).isDirectory() ? walk(join(dir, n)) : [join(dir, n)]));
const files = ['js', 'tests', 'tools', 'integrations'].flatMap((d) => walk(join(ROOT, d))).filter((f) => /\.(m?js|gs)$/.test(f));
const rel = (f) => relative(ROOT, f);

// 1. syntax
for (const f of files) {
  if (f.endsWith('.gs')) {
    try {
      new Function(readFileSync(f, 'utf8')); // eslint-disable-line no-new-func
    } catch (e) {
      problems.push(`${rel(f)}: syntax error — ${e.message}`);
    }
  } else {
    const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
    if (r.status !== 0) problems.push(`${rel(f)}: syntax error — ${r.stderr.split('\n').find((l) => /Error/.test(l)) || 'see node --check'}`);
  }
}
try {
  JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'));
} catch (e) {
  problems.push(`package.json: ${e.message}`);
}

// 2. project rules (application code only)
const app = files.filter((f) => rel(f).startsWith('js/'));
const code = (f) => readFileSync(f, 'utf8').split('\n').map((l, i) => ({ l: l.replace(/\/\/.*$/, ''), n: i + 1 })); // line comments ignored
for (const f of app) {
  const r = rel(f);
  for (const { l, n } of code(f)) {
    if (/\b(?:tx\.put|dbPut)\(\s*['"]products['"]/.test(l) && !/^js\/services\/(stockledger|catalog)\.js$/.test(r)) problems.push(`${r}:${n} R1 products are written only by stockledger.js / catalog.js (stock changes must go through recordMovement)`);
    if (/\bsettings\.set\(/.test(l) && r.startsWith('js/ui/')) problems.push(`${r}:${n} R2 use settings.update(…) in screens (it checks the permission and logs the change)`);
    // (formatting a calendar-date STRING at local noon — `new Date(`${d}T12:00:00`)` — prints the same day in every zone, so it is allowed)
    if ((/\.toTimeString\(|\.toLocaleTimeString\(|\.getHours\(/.test(l) || (/\.toLocaleDateString\(/.test(l) && !/T12:00:00/.test(l))) && r !== 'js/core/datetime.js') problems.push(`${r}:${n} R3 device-zone time formatting — use core/datetime.js (Asia/Dhaka)`);
    if (/console\.(log|info|warn|error|debug)\(/.test(l) && /token/i.test(l)) problems.push(`${r}:${n} R4 a secret may be written to the console`);
  }
}

/** Body of `export async function name(` / object method `async name(` up to the next declaration. */
function bodyOf(text, name) {
  const m = new RegExp(`(?:export (?:async )?function ${name}\\(|\\n  async ${name}\\()`).exec(text);
  if (!m) return null;
  const rest = text.slice(m.index + m[0].length);
  const end = rest.search(/\n(?:export |\/\*\*)|\n  (?:async \w+\(|\w+\(.*\) \{|\/\*\*)/);
  return end === -1 ? rest : rest.slice(0, end);
}
const GUARDED = {
  'js/services/sales.js': ['createInvoice', 'voidInvoice', 'getInvoice', 'queryInvoices'],
  'js/services/returns.js': ['returnSale', 'listReturns', 'returnableLines'],
  'js/services/customers.js': ['saveCustomer', 'deleteCustomer', 'receivePayment', 'customerProfile', 'listCustomers'],
  'js/services/catalog.js': ['saveProduct', 'deleteProduct', 'saveCategory', 'deleteCategory'],
  'js/services/inventory.js': ['receiveStock', 'writeOffStock', 'adjustStock', 'queryMovements', 'productHistory', 'verifyStockLedger'],
  'js/services/backup.js': ['createBackupFile', 'importDatabase', 'listDriveBackups', 'restoreFromDrive'],
  'js/services/autobackup.js': ['getSnapshot', 'deleteSnapshot', 'restoreSnapshot'],
  'js/services/auth.js': ['createUser', 'updateUser', 'listUsers', 'setCredentials'],
  'js/services/reports.js': ['dashboard', 'dailyReport', 'monthlyReport', 'profitReport', 'productSalesReport', 'salesTrend', 'dueAging'],
  'js/services/audit.js': ['listAudit'],
  'js/services/sync.js': ['testConnection', 'getQueue', 'getSyncLog', 'clearSyncLog', 'retryFailed', 'verifyUploaded', 'resetCatalogSync'],
};
for (const [file, names] of Object.entries(GUARDED)) {
  const text = readFileSync(join(ROOT, file), 'utf8');
  for (const name of names) {
    const body = bodyOf(text, name);
    if (body === null) problems.push(`${file}: R5 function ${name} not found (update tools/lint.mjs)`);
    else if (!/authorize|currentActor/.test(body)) problems.push(`${file}: R5 ${name}() does not authorize the caller`);
  }
}

if (problems.length) {
  console.log(`lint: ${problems.length} problem(s)\n  ${problems.join('\n  ')}`);
  process.exit(1);
}
console.log(`lint: ${files.length} files, syntax OK, rules R1–R5 OK`);

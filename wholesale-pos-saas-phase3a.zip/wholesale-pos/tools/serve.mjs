/**
 * serve.mjs — zero-dependency static file server for development and for
 * running the app on a shop LAN.   Usage:  node tools/serve.mjs [port]
 *
 * NOTE: Service workers, Web Bluetooth and WebUSB only work on https:// or on
 * http://localhost. For other devices on the LAN use a tunnel / reverse proxy
 * with HTTPS (see docs/ANDROID.md) or install the Capacitor APK.
 */
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const PORT = Number(process.argv[2] || process.env.PORT || 5173);
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.md': 'text/plain; charset=utf-8',
};
/** Only the PWA itself is served — never tests, tools, node_modules or android sources. */
const PUBLIC = /^\/(index\.html|manifest\.webmanifest|sw\.js|css\/|js\/|icons\/)/;

export function createAppServer() {
  return createServer(async (req, res) => {
    try {
      let path = decodeURIComponent(new URL(req.url, 'http://x').pathname);
      if (path === '/') path = '/index.html';
      if (!PUBLIC.test(path)) throw Object.assign(new Error('nf'), { code: 'ENOENT' });
      const file = normalize(join(ROOT, path));
      if (!file.startsWith(ROOT)) throw Object.assign(new Error('nf'), { code: 'ENOENT' });
      if (!(await stat(file)).isFile()) throw Object.assign(new Error('nf'), { code: 'ENOENT' });
      const body = await readFile(file);
      res.writeHead(200, {
        'Content-Type': TYPES[extname(file)] || 'application/octet-stream',
        // Always revalidate so a deploy is picked up; the service worker handles offline use.
        'Cache-Control': 'no-cache',
        'X-Content-Type-Options': 'nosniff',
      });
      res.end(body);
    } catch (e) {
      res.writeHead(e.code === 'ENOENT' ? 404 : 500, { 'Content-Type': 'text/plain' });
      res.end(e.code === 'ENOENT' ? 'Not found' : 'Server error');
    }
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  createAppServer().listen(PORT, () => console.log(`Wholesale POS running at http://localhost:${PORT}`));
}

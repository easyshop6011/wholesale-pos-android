/**
 * setup-android.mjs — create / refresh the native Android project.
 *
 *   npm run android:setup
 *
 * Steps (all idempotent):
 *   1. build ./www
 *   2. `cap add android` if ./android does not exist yet
 *   3. copy android-plugin/*.java into the app (ThermalPrinter plugin + MainActivity)
 *   4. add Bluetooth / USB permissions to AndroidManifest.xml
 *   5. `cap sync android`
 * Then build with Android Studio (npm run android:open) or `npm run android:apk`.
 */
import { existsSync } from 'node:fs';
import { readFile, writeFile, copyFile, mkdir } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const sh = (cmd, args) => {
  const r = spawnSync(cmd, args, { cwd: ROOT, stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) process.exit(r.status ?? 1);
};

sh(process.execPath, ['tools/build-www.mjs']);
if (!existsSync(join(ROOT, 'android'))) sh('npx', ['cap', 'add', 'android']);

// ---- native plugin sources ----
const javaDir = join(ROOT, 'android/app/src/main/java/com/wholesalepos/app');
await mkdir(javaDir, { recursive: true });
for (const f of ['ThermalPrinterPlugin.java', 'MainActivity.java']) await copyFile(join(ROOT, 'android-plugin', f), join(javaDir, f));

// ---- manifest permissions ----
const manifestPath = join(ROOT, 'android/app/src/main/AndroidManifest.xml');
let xml = await readFile(manifestPath, 'utf8');
const wanted = [
  '<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />',
  '<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />',
  '<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />',
  '<uses-feature android:name="android.hardware.usb.host" android:required="false" />',
  '<uses-feature android:name="android.hardware.bluetooth" android:required="false" />',
];
const missing = wanted.filter((line) => !xml.includes(line.match(/android:name="([^"]+)"/)[1]));
if (missing.length) {
  xml = xml.replace('</manifest>', `    ${missing.join('\n    ')}\n</manifest>`);
  await writeFile(manifestPath, xml);
  console.log(`AndroidManifest.xml: added ${missing.length} entries`);
}

sh('npx', ['cap', 'sync', 'android']);
console.log('\nAndroid project ready. Next: npm run android:open  (or npm run android:apk)');
